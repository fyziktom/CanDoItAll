# Current repo alignment

This document maps the proposed learning-package architecture onto the current `zyphonote-web-ui-refresh` repository.

## Existing building blocks that should be reused

### Existing domain and finance tables
Already present and should remain the source of truth for shared concerns:

- `users`
- `user_roles`
- `entitlements`
- `scores`
- `score_versions`
- `score_market_listings`
- `score_purchases`
- `seller_profiles`
- `wallet_accounts`
- `wallet_transactions`
- `wallet_topups`
- `seller_payout_requests`
- `audit_log_entries`

### Existing PHP domain services
Already present and should inspire the same split for the new feature:

- `src/lib/marketplace.php`
- `src/lib/user-auth.php`
- `src/api/v1/index.php`

### Existing UI capabilities
Already present and useful in stage 1:

- VexFlow score rendering
- Tailwind/shared app stylesheet
- account pages for dashboard/store/marketplace
- creator public page
- protected storage under `src/storage/api/*`

## Design principle for the new feature

Add a new PHP domain library:

- `src/lib/learning-packages.php`

That library must contain the actual business logic for:
- package authoring,
- package version saving,
- package asset storage,
- listing and purchase rules,
- library loading,
- progress tracking,
- asset access checks.

Then reuse that shared logic from:
- server-rendered PHP pages,
- `/api/v1` routes.

This prevents the common trap where:
- the PHP mockup uses one logic path,
- the future WASM API uses another logic path,
- both drift and become inconsistent.

## Why a sibling domain is the right fit

Do **not** overload `scores` to represent courses or bundles.

A package is different because it needs:
- multiple nested items,
- mixed item types (`score`, `text`, `video`, `image`, `checkpoint`, `attachment`),
- progress and resume state,
- protected asset streaming,
- immutable package-version snapshots,
- runtime module configuration for future WASM widgets.

So the right model is:

- **scores remain atomic notation assets**
- **learning packages orchestrate score items plus explanatory content**

## Existing code paths that should be extended

### Pages
Recommended additions and changes:

- Add `account-learning.php`  
  User learning library and resume landing.
- Add `account-learning-builder.php`  
  Creator-facing package builder / editor.
- Add `account-learning-package.php`  
  Purchased package study view / mock runtime.
- Extend `account-store.php`  
  Add a Packages / Lessons marketplace tab.
- Extend `account-dashboard.php`  
  Add “Continue learning” and package summary widgets.
- Extend `creator.php`  
  Add published package cards beside score listings.
- Extend `account-marketplace.php`  
  Show package sales/purchases summary in finance views.

### API v1
Recommended new route groups:

- `/learning/packages/*` – authoring + package read models
- `/learning/library/*` – purchased package runtime + progress
- `/marketplace/packages/*` – package listings, store detail, purchase
- `/admin/marketplace/packages/*` – moderation and package review

## What should stay intentionally separate in stage 1

Do not force package purchases into the existing `score_purchases` rows.

Instead:
- keep `score_purchases` for direct score commerce,
- add package purchases as a sibling table,
- introduce a new entitlement/access layer for package runtime.

This avoids breaking the existing purchased-score flows while enabling packages cleanly.

## Migration philosophy

Stage 1 should be additive:
- new tables,
- new pages,
- new routes,
- new storage roots,
- minimal risk to current score marketplace.

That is the safest way to ship the new concept without destabilizing the running app.
