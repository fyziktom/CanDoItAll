# Final self-review checklist

- [ ] No business logic is duplicated between page layer and API layer.
- [ ] Package versions are immutable snapshots.
- [ ] Manifests and assets are content-addressed.
- [ ] Package access is entitlement-based, not inferred only from purchases.
- [ ] Resume works after refresh/navigation.
- [ ] Version update state is visible and correct.
- [ ] Locked media cannot be accessed anonymously or without ownership.
- [ ] The builder is understandable without developer explanation.
- [ ] The store clearly distinguishes scores from packages.
- [ ] The learning library clearly distinguishes “continue” from “owned”.
- [ ] The study page feels credible even without MIDI playback.
- [ ] Seed data proves the feature in multiple realistic scenarios.
- [ ] Docs/checklists were updated if any implementation detail changed.
