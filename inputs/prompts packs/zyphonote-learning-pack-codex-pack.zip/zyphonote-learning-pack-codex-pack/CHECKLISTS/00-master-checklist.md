# Master implementation checklist

The implementation is not done until every section here is explicitly checked.

## Planning and architecture
- [ ] Read the full pack before changing code.
- [ ] Confirm the current repository structure and integration points.
- [ ] Use `src/lib/learning-packages.php` as the shared domain layer.
- [ ] Keep package domain separate from `scores`.
- [ ] Keep package kind, learning mode, and item type separate in the model.
- [ ] Use immutable package versions.
- [ ] Use CID-ready storage for manifests and assets.

## Database and storage
- [ ] Add the learning package migration.
- [ ] Add storage config roots for manifests and assets.
- [ ] Add helpers for content-addressed storage paths.
- [ ] Add manifest save/load helpers.
- [ ] Add protected asset streaming with range support for videos.
- [ ] Add validation for score references and asset ownership.

## Authoring
- [ ] Add creator package list.
- [ ] Add package create flow.
- [ ] Add package metadata edit flow.
- [ ] Add curriculum builder with sections/items.
- [ ] Add score item linking.
- [ ] Add text/video/image/checkpoint item support.
- [ ] Add annotation editor for score items.
- [ ] Add listing/pricing step.
- [ ] Add preview step.
- [ ] Add publish/moderation request flow.

## Marketplace
- [ ] Add package cards to the store.
- [ ] Add package detail page/modal.
- [ ] Add previewable curriculum display.
- [ ] Add purchase flow using wallet logic.
- [ ] Add package purchases and package sales views.
- [ ] Add creator public package cards on `creator.php`.

## Learning library and study
- [ ] Add `account-learning.php`.
- [ ] Add `account-learning-package.php`.
- [ ] Add package progress and resume logic.
- [ ] Add per-item state updates.
- [ ] Add manual measure save for score items.
- [ ] Add manual item completion toggle.
- [ ] Add update-available banner if a newer published version exists.
- [ ] Keep WASM-only features visible as non-executing badges/placeholders.

## Admin and moderation
- [ ] Add package moderation list/query.
- [ ] Add approve/reject/block action.
- [ ] Add audit log entries for package moderation and major package actions.

## Seed data and QA
- [ ] Extend `tools/seed_dev_data.php`.
- [ ] Seed at least 4 different package archetypes.
- [ ] Seed purchases and progress states.
- [ ] Add smoke tests for create -> list -> buy -> open -> progress.
- [ ] Add protected asset-access tests.
- [ ] Add version-update scenario test.

## UI quality gates
- [ ] Package cards clearly communicate value and type.
- [ ] Learning library emphasizes resume.
- [ ] Builder feels structured, not like a raw JSON dump.
- [ ] Locked vs owned content is visually obvious.
- [ ] Progress is visible without opening the package.
- [ ] Mobile layouts remain usable.

## Final audit
- [ ] Run the dedicated final audit prompt.
- [ ] Update implementation log/documentation.
- [ ] Fix all discovered gaps before declaring completion.
