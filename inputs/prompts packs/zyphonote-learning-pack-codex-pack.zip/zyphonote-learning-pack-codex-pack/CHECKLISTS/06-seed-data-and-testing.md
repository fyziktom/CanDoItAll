# Seed data and testing checklist

- [ ] Seed at least one package of each archetype:
  - [ ] score bundle
  - [ ] guided lesson
  - [ ] etudes/practice program
  - [ ] composer collection
- [ ] Seed package assets (cover/video/image) metadata.
- [ ] Seed at least one buyer-owned package in progress.
- [ ] Seed at least one completed package.
- [ ] Seed at least one package with locked video.
- [ ] Seed at least one package with update available.
- [ ] Add smoke test for package create.
- [ ] Add smoke test for listing + moderation.
- [ ] Add smoke test for purchase.
- [ ] Add smoke test for learning library load.
- [ ] Add smoke test for progress update.
- [ ] Add smoke test for protected asset denial before purchase.
- [ ] Add smoke test for protected asset allow after purchase.
