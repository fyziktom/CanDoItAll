# Web creator authoring checklist

- [ ] Add creator-facing package dashboard/list.
- [ ] Add package create CTA in dashboard or creator tools area.
- [ ] Add structured builder steps:
  - [ ] Basics
  - [ ] Curriculum
  - [ ] Media and annotations
  - [ ] Pricing
  - [ ] Preview
  - [ ] Submit
- [ ] Allow section add/remove/reorder.
- [ ] Allow item add/remove/reorder.
- [ ] Allow score linking from owned scores.
- [ ] Allow item types `score`, `text`, `video`, `image`, `checkpoint`.
- [ ] Allow cover and hero asset upload.
- [ ] Allow measure-annotation editing on score items.
- [ ] Show validation errors inline and clearly.
- [ ] Add local draft autosave and unsaved-change warning.
- [ ] Make preview look like the buyer-facing package detail.
