# API and security checklist

- [ ] Add `/learning/packages/*` routes.
- [ ] Add `/learning/library/*` routes.
- [ ] Add `/marketplace/packages/*` routes.
- [ ] Add `/admin/marketplace/packages/*` routes.
- [ ] Keep auth and error style aligned with current API v1.
- [ ] Do not duplicate business logic inside route handlers.
- [ ] Protect all package-authoring routes by ownership/auth.
- [ ] Protect all runtime/library routes by entitlement/access checks.
- [ ] Protect all asset stream routes by access checks.
- [ ] Implement HTTP range support for video endpoints.
- [ ] Never expose raw storage paths.
- [ ] Return consistent errors for denied/missing access.
- [ ] Log major admin moderation actions to audit.
