# Study runtime mock checklist

- [ ] Add `account-learning-package.php`.
- [ ] Load active package version manifest.
- [ ] Load package user state.
- [ ] Load item user states.
- [ ] Resolve current item from resume target.
- [ ] Render curriculum sidebar.
- [ ] Render current item viewer.
- [ ] For score items, render VexFlow preview.
- [ ] Show measure annotations beside score items.
- [ ] Provide manual “save current measure” action.
- [ ] Provide item complete / incomplete action.
- [ ] Update package completion after item changes.
- [ ] Show package progress summary.
- [ ] Show WASM-only modules as non-executing placeholders/badges.
- [ ] Show update-available banner when applicable.
