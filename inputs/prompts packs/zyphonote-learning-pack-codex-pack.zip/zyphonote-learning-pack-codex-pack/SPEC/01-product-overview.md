# Product overview and key decisions

## Goal

Add a new product layer that lets creators sell:

- pure score sets,
- guided lessons,
- etudes packs,
- composer collections,
- standards collections,
- mixed study packs,
- technique/practice programs.

The user must be able to:
- buy them,
- browse them,
- open them later,
- resume where they stopped,
- see progress,
- consume protected text/images/video,
- eventually use the same package in the WASM app with MIDI/audio-follow capabilities.

## The three most important product distinctions

A lot of systems fail here by mixing unrelated concepts into one enum.
This design keeps three different axes separate.

### 1) Package kind (marketing / discovery)
How the product should be presented in the catalog.

Recommended enum:
- `score_bundle`
- `guided_lesson`
- `course`
- `etudes_pack`
- `repertoire_pack`
- `composer_collection`
- `standards_pack`
- `technique_pack`
- `custom`

### 2) Learning mode (runtime behavior)
How the package behaves after purchase.

Recommended enum:
- `free_browse`
- `guided_path`
- `practice_program`

Meaning:
- `free_browse`  
  Best for collections and reference packs. Users open items in any order.
- `guided_path`  
  Best for lessons/courses. Users are nudged step-by-step through a sequence.
- `practice_program`  
  Best for etudes/technical drills. Users have milestones, loops, target tempos, and stronger progress semantics.

### 3) Item type (rendering/runtime)
What each content item actually is.

Recommended item types:
- `score`
- `text`
- `video`
- `image`
- `attachment`
- `checkpoint`

## Non-goals for stage 1 (PHP web mockup)

Do not build full MIDI/audio runtime in PHP.
Stage 1 should mock the end-to-end learning flow credibly, but the actual real-time practice runtime stays in WASM.

So stage 1 **does** need:
- package browsing,
- purchase flow,
- locked vs unlocked content,
- secure asset access,
- curriculum navigation,
- progress and resume,
- measure-anchored annotations in the data model,
- believable study UI with VexFlow previews.

Stage 1 **does not** need:
- real MIDI playback,
- live note-follow,
- live audio/spectral analysis,
- scoring/accuracy engines.

## Product archetypes that must be supported

### A. Pure score set
Example:
- “10 Jazz Standards – Starter Set”

Characteristics:
- mostly score items,
- maybe a short intro text,
- no strong sequencing,
- `learning_mode = free_browse`

### B. Guided lesson
Example:
- “How to Play Fast Broken Chords”

Characteristics:
- intro video,
- explanation text,
- 1–3 score examples,
- measure callouts,
- strong resume flow,
- `learning_mode = guided_path`

### C. Etudes pack
Example:
- “Czerny Op. 599 – Selected Etudes”

Characteristics:
- many score items,
- optional tips/videos,
- progress useful,
- target tempo / loop regions / checkpoints useful,
- `learning_mode = practice_program`

### D. Composer collection
Example:
- “Bach Inventions – Complete Learning Set”

Characteristics:
- many score items,
- historical/context text may exist,
- weak sequencing,
- `learning_mode = free_browse` or `guided_path` depending on author intent

### E. Technique pack
Example:
- “ii-V-I Progressions in 12 Keys”

Characteristics:
- score snippets,
- practice goals,
- widget-heavy future WASM use,
- `learning_mode = practice_program`

## Must-have end-user value

A package should make sense to a musician even before advanced runtime exists.

So every package should be able to express:

- what is included,
- who it is for,
- difficulty,
- prerequisites,
- learning goals,
- estimated time,
- which practice aids are supported,
- which parts are videos/text vs notation,
- how far the user got,
- where the user should continue.

## Package metadata that should exist from day 1

Recommended top-level metadata:

- title
- subtitle
- short description
- full marketing description
- package kind
- learning mode
- difficulty level
- instruments
- genres/styles
- skill tags
- composer focus
- estimated minutes
- cover image
- hero image
- prerequisites
- learning outcomes
- feature flags / practice modules
- visibility
- moderation state
- current published version
- current draft version

## Key decisions that keep this practical

### Decision 1: immutable package versions
Every meaningful save is a version snapshot.
Published versions are immutable.
This is essential for:
- stable purchases,
- reliable resume state,
- future offline/WASM caching,
- clean diff/audit behavior.

### Decision 2: content-addressed manifests and assets
Manifest files and media assets should be stored using:
- `sha256`
- `cid_v1_raw`

and file names based on the CID.
This matches the future IPFS migration path.

### Decision 3: progress at package + item level
Tracking only “purchase complete” is not enough.
Tracking only low-level runtime events is too much for stage 1.
Use two state layers:
- overall package state
- per-item state

This is enough now and extensible later.

### Decision 4: web mockup must share backend logic with API v1
Do not implement fake page-only logic.
The PHP pages should call the same library functions the API will call.

## Moderation and trust

Package publishing should go through the same trust mindset as score listings:
- seller terms accepted,
- payout profile valid,
- rights confirmed,
- listing moderation,
- audit entries for admin changes.

If a package contains protected media, moderation should review:
- cover/hero asset sanity,
- package description,
- content type and rights declarations,
- preview behavior.

## Future-proofing for WASM

Package data should already describe:
- measure annotations,
- practice widgets,
- loop regions,
- chord symbol overlays,
- tempo ladders,
- progression drills,
- follow-along readiness.

The PHP stage does not execute those modules.
But it **must store them now**, so the WASM client can light them up later without schema redesign.
