# Progress, versioning, and runtime state

## Why progress must be designed now

The user explicitly needs the package to flip cleanly from:
- “I bought this”
to
- “I am actively using this”

That transition only feels good if the backend already knows:
- what the current package version is,
- what the current item is,
- where the user stopped,
- how much is complete,
- whether a newer package version exists.

## Recommended state layers

### Package-level state
Stored in `learning_package_user_states`.

Purpose:
- package status
- overall completion
- last activity
- resume target
- current active version

Recommended fields:
- `user_id`
- `package_id`
- `active_version_id`
- `status`
- `completion_percent`
- `required_completed_count`
- `required_total_count`
- `last_opened_item_key`
- `last_opened_item_type`
- `last_score_id`
- `last_measure_no`
- `last_position_json`
- `first_started_utc`
- `last_activity_utc`
- `completed_utc`
- `is_archived`

### Item-level state
Stored in `learning_package_item_user_states`.

Purpose:
- item status
- item completion
- item-specific resume data
- future practice statistics

Recommended fields:
- `user_id`
- `package_id`
- `package_version_id`
- `item_key`
- `status`
- `progress_percent`
- `last_position_json`
- `practice_stats_json`
- `last_opened_utc`
- `completed_utc`

## Recommended status values

### Package status
- `NotStarted`
- `InProgress`
- `Completed`
- `Archived`

### Item status
- `NotStarted`
- `InProgress`
- `Completed`
- `Skipped`

Do not use `Locked` as a stored user status.
Locked is a computed runtime state based on package unlock rules.

## Completion model

### For `free_browse`
Completion is light-touch:
- optional progress
- strong emphasis on last opened item
- user may manually mark items complete

### For `guided_path`
Completion is stronger:
- required items count toward completion
- next recommended item is explicit

### For `practice_program`
Completion should keep room for future runtime signals:
- viewed/opened now,
- manual completion now,
- later MIDI/audio stats can enrich `practice_stats_json`

## Resume behavior

The default resume target should be:
1. last opened incomplete item
2. last opened item
3. first incomplete required item
4. first item in the curriculum

This should be computed centrally in the domain service.

## Version update policy

This is a subtle but important point.

A creator may publish version 2 after buyers already started version 1.

Recommended approach:
- purchase stores `purchased_version_id`
- user state stores `active_version_id`
- package root stores `current_published_version_id`

At runtime:
- if `active_version_id != current_published_version_id`
- return `updateAvailable = true`

The PHP stage can simply show:
- “A newer edition is available”

The user can later choose to adopt it.

This avoids silently breaking progress.

## Why not always auto-upgrade

Because package structures can change:
- items may move,
- annotations may change,
- score versions may differ.

Auto-upgrading without migration logic can destroy the feeling of continuity.

So the safe stage-1 rule is:
- keep user on current `active_version_id`
- inform them when a newer published version exists

## `last_position_json` recommendation

Keep this generic from day 1.

Examples:

### Score item
```json
{
  "partId": "P1",
  "measure": 17,
  "beat": 1.0,
  "scrollAnchor": "measure_17"
}
```

### Video item
```json
{
  "seconds": 93
}
```

### Text item
```json
{
  "scrollPercent": 62
}
```

This makes the model future-proof without overdesign.

## Future WASM enrichment

Later the WASM app can write richer state into:
- `practice_stats_json`
- `last_position_json`

Examples:
- tempo reached
- loop region last used
- midi note-match stats
- audio follow confidence
- last widget selection

The schema should not need to change for that.

## Progress rules for stage 1

Because the PHP app does not have live performance runtime, stage 1 should support:

- manual mark complete
- manual unmark complete
- save current measure
- update current item
- recompute overall completion from required items

That is enough to test the learning flow properly.

## Study-page behavior summary

When the user opens a package:
- ensure entitlement exists
- load package user state
- load active manifest version
- compute current item
- load item states
- render viewer and sidebars

When the user switches item or saves progress:
- update item state
- update package resume pointer
- update overall completion
- update last activity
