# Database and migration plan

The proposed SQL lives in `DB/2026-03-06-learning-packages-proposed.sql`.

## Migration strategy

Ship this feature as an additive migration.
Do not rework existing score marketplace tables unless absolutely necessary.

## Recommended new tables

### `learning_packages`
Catalog root + current version pointers.

### `learning_package_versions`
Immutable manifest snapshots with content-addressed storage keys.

### `learning_package_assets`
Protected/public media registry.

### `learning_package_score_links`
Derived index of score references from a package version.

### `learning_package_listings`
Package commerce and moderation layer.

### `learning_package_purchases`
Package purchase journal.

### `content_entitlements`
Generic access layer.

### `learning_package_user_states`
Per-user package progress and resume.

### `learning_package_item_user_states`
Per-user per-item state.

## Why a generic `content_entitlements` table is worth it

Today:
- direct score purchase access is inferred from `score_purchases`
- package access does not exist yet

Tomorrow:
- package purchase may grant package access
- package purchase may also optionally grant score-level access
- admin gifts/promotions may exist
- subscriptions may include access

A generic entitlement table handles all those cases cleanly.

## Suggested migration order

1. create learning package tables
2. extend config for storage roots and limits
3. add PHP domain library and manifest persistence
4. add authoring pages/routes
5. add package store/listings/purchases
6. add package library/progress
7. extend seed data
8. extend admin moderation views

## Backfill expectations

No backfill is required for existing scores.

Optional future helper:
- convert some existing score sets into starter packages

But that is content work, not schema work.

## Validation rules that should be enforced before publish

A package cannot be published unless:

- owner exists
- title and short description exist
- package kind and learning mode are set
- at least one section exists
- at least one item exists
- at least one `score` item exists
- every score item resolves to an owned score version
- all referenced assets exist and belong to the same owner
- cover image exists
- listing price and currency are valid
- rights owner confirmed
- seller profile is eligible to sell
- draft manifest passes schema validation

## Derived data to populate after every draft save

After saving a draft manifest:
- total items
- total required items
- total score items
- total video items
- total duration seconds
- search text
- taxonomy/feature summary
- score link index table

This makes listing pages much faster and simpler.

## Why package versions should store resolved score version IDs

If a package only stores `scoreId`, then:
- the score can change later,
- the package content changes silently,
- progress/resume may point at moved measures,
- purchase snapshots become fuzzy.

So on package draft save or publish:
- resolve to the intended `scoreVersionId`
- store that exact version in the manifest snapshot

That gives stable learning content.

## Concurrency recommendation

When editing the builder:
- require the current draft version ID or revision token on save
- reject stale saves with a clear error

This prevents two tabs overwriting each other silently.

## Seed data recommendation

The seed script should create:
- creators with multiple scores
- packages composed from those scores
- package listings
- buyer purchases
- progress rows with different states
- protected assets metadata
- at least one package with an update-available scenario
