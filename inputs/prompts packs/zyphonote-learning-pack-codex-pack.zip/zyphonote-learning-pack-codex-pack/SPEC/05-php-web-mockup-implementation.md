# PHP web mockup implementation plan

## Design goal

The PHP app should become a **credible facsimile** of the final product flow, not a throwaway admin form.

That means:
- the package store must feel real,
- the learning library must feel resume-driven,
- the study page must feel like a serious practice space,
- the builder must make package structure understandable.

## Shared backend principle

All business logic should live in:

- `src/lib/learning-packages.php`

Pages should call that library directly for server-rendered flows.
`/api/v1` should call the same library for machine clients and future WASM use.

## Recommended file map

### New files
- `src/lib/learning-packages.php`
- `src/lib/account-learning-page.php`
- `src/account-learning.php`
- `src/account-learning-builder.php`
- `src/account-learning-package.php`
- `src/assets/js/learning-builder.js`
- `src/assets/js/learning-player.js`
- `src/assets/js/learning-store.js`

### Files to extend
- `src/api/v1/index.php`
- `src/account-store.php`
- `src/account-dashboard.php`
- `src/account-marketplace.php`
- `src/creator.php`
- `src/input.css`
- `tools/seed_dev_data.php`
- `src/lib/config.example.php`

## Recommended page responsibilities

### `account-learning.php`
Responsibilities:
- load owned packages
- group by status (`Continue`, `In progress`, `Completed`, `Archived`)
- render progress cards
- support simple filtering and search
- show resume CTA

### `account-learning-package.php`
Responsibilities:
- verify access
- load package manifest for the user’s active version
- load user state + per-item state
- render current item
- handle actions:
  - mark item complete
  - unmark item complete
  - save current measure
  - switch current item
  - archive/unarchive package view
  - adopt newer package version if available later

### `account-learning-builder.php`
Responsibilities:
- create new package
- edit basics
- edit curriculum
- upload assets
- add score annotations
- configure pricing/listing
- preview before submit
- submit for moderation

### `account-store.php`
Responsibilities:
- add a package marketplace tab or route switch
- render package cards and package detail modal/page
- show ownership state
- allow package purchase

### `creator.php`
Responsibilities:
- show creator’s published packages
- keep scores and packages visually distinct but cohesive

## Builder UX recommendations

### Step 1 – Basics
Fields:
- title
- subtitle
- short description
- package kind
- learning mode
- difficulty
- instruments/styles/skills
- estimated minutes
- cover image
- hero image

### Step 2 – Curriculum
Use structured cards:
- section cards
- item cards inside section

Support actions:
- add section
- rename section
- add item
- change item type
- link score item to existing score
- reorder with Up/Down buttons
- remove item

### Step 3 – Media and annotations
For score items:
- annotation list editor
- measure start / end
- title / body
- display mode
- tone
- widget hint

For video/image items:
- upload asset
- preview asset
- poster / caption / duration metadata

### Step 4 – Pricing
Fields:
- price
- currency
- license preset
- rights confirmation
- moderation note for internal use if needed

### Step 5 – Preview
Render:
- buyer-facing package detail page
- curriculum outline
- preview score excerpts
- locked media states
- feature badges

### Step 6 – Submit
Action:
- create/update listing
- request moderation
- show validation failures clearly

## Buyer-side page components

Recommended component inventory:

- `PackageCard`
- `PackageHero`
- `PackageMetaChips`
- `CurriculumAccordion`
- `LockedItemRow`
- `ProgressBar`
- `ResumePanel`
- `FeatureBadgeList`
- `PracticeModuleBadge`
- `AnnotationSidebar`
- `PackageOwnershipCard`

## Study page mock-runtime widgets

Even in PHP, the study page should visibly communicate future depth.

For score items, render:
- notation preview
- current item metadata
- loop regions list
- annotations grouped by measure range
- practice modules as badges or disabled widget cards

Example modules to display:
- MIDI Follow
- MIDI Record
- Keyboard Visualizer
- Chord Symbols
- Tempo Ladder
- Section Loop
- Audio Follow (future)

Mark modules that are not active in PHP as:
- `WASM runtime`
- `Future`

## Important practical simplifications

### Simplification 1: no full client-side SPA builder
Use server-rendered forms plus targeted JS enhancements.
This fits the current repository style and reduces complexity.

### Simplification 2: no drag-and-drop dependency in v1
Prefer robust reorder buttons.
If drag-and-drop is added later, it can be progressive enhancement.

### Simplification 3: no exact score-overlay editor in v1
Measure annotations can be form-driven.
Do not block shipping on graphical measure picking.

### Simplification 4: manual completion is acceptable in PHP
The real auto-runtime completion belongs in WASM later.

## JS responsibilities

### `learning-builder.js`
- dynamic add/remove section and item cards
- maintain manifest draft JSON in hidden field or structured form
- local draft autosave
- warn on unsaved changes
- client-side validation hints

### `learning-player.js`
- open/close curriculum sections
- switch current item
- save last measure / current location
- item complete toggle
- annotation sidebar interactions

### `learning-store.js`
- switch store sub-tab
- package detail modal interactions if modal-based
- preview section toggles

## Tailwind styling priorities

Focus first on:
- spacing
- clear card hierarchy
- readable curriculum
- strong progress visibility
- obvious locked/unlocked states
- consistent CTA placement

Do not spend time on:
- overly custom animation,
- experimental layout tricks,
- fragile visual gimmicks.

## Seed data requirements for the mockup

The seed generator must create at least:

1. a free-browse score bundle
2. a guided lesson with text + video + score
3. an etudes/practice program
4. a composer collection

And for each:
- a published package listing
- a purchase by a test buyer
- at least one package already in progress
- at least one completed package
- at least one package with locked video assets

Without this seed data, the mockup will be hard to evaluate.
