# Rollout phases, risks, and acceptance criteria

## Recommended implementation phases

### Phase 1 – Domain + DB + storage
Deliver:
- migrations
- storage config
- manifest persistence
- asset persistence
- package domain service

### Phase 2 – Authoring
Deliver:
- creator builder page
- score linking
- asset upload
- annotation editor
- listing submit flow

### Phase 3 – Marketplace
Deliver:
- package cards in store
- package detail page
- purchase flow
- sales/purchases integration

### Phase 4 – Learning library + study mock
Deliver:
- learning library page
- study page
- progress/resume flow
- protected asset access

### Phase 5 – Admin + seed + QA
Deliver:
- moderation support
- test data
- smoke tests
- final docs update

## Main risks and mitigations

### Risk 1 – package model becomes too score-centric
If packages are treated as “just many scores”, videos/text/progress become awkward.

Mitigation:
- keep package as its own root entity.

### Risk 2 – package model becomes too course-centric
If packages are treated as only guided courses, simple collections become awkward.

Mitigation:
- keep `package_kind` separate from `learning_mode`.

### Risk 3 – versioning is skipped
If versions are mutable, progress and access become brittle.

Mitigation:
- immutable package versions from day 1.

### Risk 4 – media delivery is naive
If videos are stored publicly or without range support, UX/security suffer.

Mitigation:
- protected asset endpoints + range support.

### Risk 5 – PHP mockup drifts from future API
If pages implement their own special logic, future WASM integration becomes expensive.

Mitigation:
- shared `src/lib/learning-packages.php` domain layer.

### Risk 6 – authoring UI becomes too ambitious
A fragile builder delays the whole feature.

Mitigation:
- reliable wizard + reorder buttons first.

## Acceptance criteria for the first serious internal release

### Domain
- package create/edit/publish flow works
- immutable draft and published versions exist
- manifest validation exists
- score references resolve to score versions

### Commerce
- package listing can be created
- package listing can be moderated
- package can be bought with wallet flow
- purchase creates access/entitlement

### Runtime
- owned package appears in learning library
- continue/resume works
- item-level completion works
- package progress updates
- locked media stays protected

### UI
- store package cards look coherent
- package detail page explains the product clearly
- study page is usable as a mock runtime
- builder is understandable for creators
- progress visibility is obvious

### Seed and QA
- sample packages cover multiple archetypes
- smoke tests cover create/list/buy/open/progress
- documentation is updated

## Recommended future wave after stage 1

Not required now, but made easier by this design:
- package reviews/comments
- gifts/coupons
- subscriptions/plan-based access
- collaborative creators/co-authors
- richer practice analytics
- update migration UI between package versions
- package-to-score entitlement convergence
