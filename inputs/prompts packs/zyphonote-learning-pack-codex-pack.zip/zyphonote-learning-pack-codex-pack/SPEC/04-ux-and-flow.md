# UX and interaction flow

This feature is only worth building if the UX model is clear.

The PHP web UI does not need the full WASM runtime, but it must make the end-to-end experience believable and testable.

## UX principles

1. **Separate store context from study context**  
   Do not make the user “study inside a buy modal”.

2. **Make resume the primary post-purchase action**  
   After first use, the default CTA should be “Continue”.

3. **Use package type and learning mode in the UI**  
   Users should instantly understand whether something is:
   - a collection,
   - a guided lesson,
   - a practice program.

4. **Show locked media honestly**  
   Do not pretend it is playable before purchase.

5. **Make future WASM tools visible but clearly labeled**  
   Example: show “MIDI follow”, “Keyboard visualizer”, “Chord symbols” as badges or disabled widgets in the PHP study page.

6. **Do not overbuild authoring drag-and-drop in v1**  
   Reliable add/edit/reorder with buttons is better than fragile drag-and-drop if logic quality is more important.

## Primary journeys

### Journey A – browse and buy a package

```mermaid
flowchart TD
  A[Store page] --> B[Packages tab]
  B --> C[Package card]
  C --> D[Package detail]
  D --> E[Preview curriculum]
  D --> F[Preview score excerpt]
  D --> G[See prerequisites and learning goals]
  D --> H[Buy package]
  H --> I[Package in learning library]
```

### Journey B – continue learning

```mermaid
flowchart TD
  A[Dashboard widget or account-learning.php] --> B[Continue package]
  B --> C[Study page opens on last item]
  C --> D[User reads/watches/views score]
  D --> E[User marks item complete or saves position]
  E --> F[Overall progress updates]
```

### Journey C – creator authors a package

```mermaid
flowchart TD
  A[Dashboard / creator tools] --> B[Create package]
  B --> C[Basics]
  C --> D[Curriculum builder]
  D --> E[Media and annotations]
  E --> F[Pricing and listing]
  F --> G[Preview]
  G --> H[Submit for review]
  H --> I[Published]
```

## Recommended page map

### `account-store.php`
Add a top-level switch or tabs:
- `Scores`
- `Packages & Lessons`

Package store cards must show:
- cover image
- title
- package kind
- learning mode
- difficulty
- included counts (`12 scores`, `4 videos`, `23 notes`)
- estimated time
- price
- badges for practice modules
- creator/seller identity
- progress chip if already owned

### `package detail` view
Can be:
- a dedicated page,
- or a large modal if consistent with existing store UX.

Must include:
- hero area
- sticky purchase card
- curriculum accordion
- prerequisites
- learning outcomes
- included content summary
- preview area for public score excerpts
- locked/unlocked media treatment
- seller identity and trust block

### `account-learning.php`
This is the user learning library landing page.

Recommended sections:
- Continue learning
- Recently opened
- In progress
- Completed
- Archived
- Optional user tags

Each card should show:
- package cover
- current module/item
- progress bar
- last activity
- CTA: `Continue` / `Open`

### `account-learning-package.php`
This is the study/mock-runtime page.

Recommended layout:
- left: curriculum tree / sections / item list
- center: current item viewer
- right: progress, notes, annotations, prerequisites, module badges

For a score item, the center area should show:
- VexFlow score rendering
- current measure note or manual measure-save control
- annotation list grouped by measure range
- future WASM widgets as visible placeholders/badges

For a video item:
- protected video player
- poster
- duration
- text notes under it

For a text item:
- readable lesson article layout
- next/previous item actions

### `account-learning-builder.php`
Creator editing screen.

Recommended steps:
1. Basics
2. Curriculum
3. Media
4. Pricing
5. Preview
6. Submit

The builder should feel like a structured wizard, not a giant undifferentiated form.

## Minimum credible interactivity in the PHP stage

### For buyers
- Expand/collapse curriculum sections
- Preview public score excerpts
- See locked items
- Start package
- Mark item complete
- Save current measure / resume point
- Filter learning library by status

### For creators
- Add/remove sections
- Add/remove items
- Reorder items
- Link existing scores
- Upload cover/video/image assets
- Add measure annotations through a form
- Preview package detail page before publish

## Measure annotations in the web stage

The data model must be exact enough for WASM later.
The web stage can be simpler in UX.

Recommended v1 web interaction:
- show annotation list beside the score
- each annotation shows measure range
- clicking the annotation scrolls to or highlights the relevant score block if practical
- if exact highlight is hard in VexFlow v1 mockup, showing a readable grouped list is still acceptable

Do not block the feature on perfect score-overlay authoring.

## Package detail information architecture

Recommended order:
1. Title + subtitle
2. package kind / learning mode / difficulty / duration
3. CTA / price / ownership state
4. Short value statement
5. Curriculum outline
6. Included score/media counts
7. Prerequisites
8. Learning outcomes
9. Practice module badges
10. Creator block

## Study page information architecture

Recommended order:
- sticky header: package title, progress, next item
- left nav: curriculum
- main viewer: current content
- right sidebar:
  - package progress
  - item notes
  - annotations
  - WASM-ready practice modules
  - “open in WASM app later” placeholder CTA

## Web vs WASM capability matrix

| Capability | PHP web stage | WASM stage |
|---|---|---|
| Browse packages | Yes | Yes |
| Buy package | Yes | Yes |
| VexFlow/static notation preview | Yes | Optional |
| Protected videos/images | Yes | Yes |
| Progress bar and resume | Yes | Yes |
| Mark item complete manually | Yes | Yes |
| Save last opened measure manually | Yes | Yes |
| MIDI playback | No | Yes |
| MIDI recording | No | Yes |
| Auto-follow by MIDI | No | Yes |
| Audio/spectral follow | No | Future |
| Chord symbol widget | Mock badge only | Yes |
| Progression drill widget | Mock badge only | Yes |

## Why this UX split is the right one

It makes the PHP layer genuinely testable:
- real marketplace behavior,
- real access control,
- real progress flows,
- real authoring structure.

But it avoids wasting time recreating the WASM runtime in PHP.
