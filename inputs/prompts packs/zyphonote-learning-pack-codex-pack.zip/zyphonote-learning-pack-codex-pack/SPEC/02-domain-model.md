# Domain model

## High-level model

```mermaid
flowchart TD
  U[users]
  S[scores]
  SV[score_versions]
  LP[learning_packages]
  LPV[learning_package_versions]
  LPA[learning_package_assets]
  LPL[learning_package_listings]
  LPP[learning_package_purchases]
  CE[content_entitlements]
  LPS[learning_package_user_states]
  LPIS[learning_package_item_user_states]

  U --> S
  S --> SV
  U --> LP
  LP --> LPV
  LP --> LPA
  LP --> LPL
  LPL --> LPP
  LPP --> CE
  LP --> LPS
  LP --> LPIS
  LPV --> LPS
  LPV --> LPIS
```

## Why the package version is central

The version is the immutable snapshot that contains:
- the curriculum tree,
- item ordering,
- score references,
- text blocks,
- video/image/attachment references,
- prerequisites,
- learning outcomes,
- measure annotations,
- practice module configuration,
- preview rules.

This is the package runtime contract.

## Core entities

### `learning_packages`
Mutable root entity used for:
- ownership,
- catalog metadata,
- current draft pointer,
- current published pointer,
- search/filter data,
- status and moderation.

### `learning_package_versions`
Immutable snapshot entity used for:
- exact package structure,
- runtime rendering,
- purchase snapshot stability,
- future cache/offline support.

### `learning_package_assets`
Protected or public media registry:
- cover images,
- hero images,
- lesson videos,
- screenshots,
- attachments,
- thumbnails.

### `learning_package_listings`
Commerce layer for package selling:
- price,
- license,
- rights snapshot template,
- moderation state,
- status.

### `learning_package_purchases`
Finance and audit record for package buying.

### `content_entitlements`
Access layer.
A user may have access because of:
- direct purchase,
- package purchase,
- admin grant,
- gift,
- future subscription or plan.

This is intentionally separate from the finance journal.

### `learning_package_user_states`
One row per user/package.
Used for:
- current package status,
- current active version,
- overall completion,
- resume pointer,
- last activity.

### `learning_package_item_user_states`
One row per user/package/item key.
Used for:
- completed vs in progress,
- last position,
- per-item notes/bookmarks later,
- future practice stats.

## Important relationship rules

### A package owns versions
- one package → many versions
- one package → one current draft version
- one package → zero or one current published version

### A package version references score versions
Published package versions should reference **exact score versions**, not floating score IDs.
That avoids “the content changed under me” problems.

### A package listing sells a package, not a score
A package listing has its own:
- license snapshot,
- price,
- moderation,
- purchase journal.

### A purchase grants access through entitlements
Do not read package access directly from the purchase table forever.
Instead:
- purchase row = commercial event
- entitlement row = access rule

This is how the model stays extensible.

## Why not normalize every package item into its own table?

Because the curriculum tree changes often and needs version stability.

The best balance here is:

- `learning_package_versions` hold the canonical immutable manifest file
- selected derived/index tables provide query speed and validation help

Recommended derived table:
- `learning_package_score_links`

This index can be rebuilt from a saved manifest and makes it easy to:
- validate score ownership,
- list included scores,
- compute counts,
- join score metadata for discovery.

## Derived/index data that is worth storing

Recommended in `learning_packages`:

- total item count
- total required item count
- total score count
- total video count
- total duration seconds
- difficulty
- instrument/style/skill discovery JSON or search text
- feature flags JSON
- cover/hero asset IDs

Recommended derived table:
- `learning_package_score_links`

Fields should include:
- package ID
- package version ID
- item key
- score ID
- score version ID
- section key
- required flag
- sort order

## The crucial “three layers” after purchase

### Layer 1: package ownership
The user bought the package.
That is the commercial fact.

### Layer 2: package access
The user may open package content, stream protected assets, and store progress.
That is the entitlement fact.

### Layer 3: runtime state
The user opened Module 2 / Item 3 and stopped at measure 17.
That is the learning state.

Keeping these separate prevents brittle logic later.

## Lifecycle state machines

### Package authoring lifecycle

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Draft: save draft version
  Draft --> PendingReview: submit publish request
  PendingReview --> Published: approved
  PendingReview --> Rejected: rejected
  Rejected --> Draft: revise
  Published --> Draft: edit new draft
  Published --> Archived: archive
  Archived --> Draft: reopen edit flow
```

### User learning lifecycle

```mermaid
stateDiagram-v2
  [*] --> NotStarted
  NotStarted --> InProgress: first open
  InProgress --> InProgress: resume/update item states
  InProgress --> Completed: required items complete
  Completed --> InProgress: new version adopted or user reopens
  InProgress --> Archived: user archives personal view
```

## Design rule for unstable references

Stable identifiers inside a manifest:

- section keys must be stable
- item keys must be stable
- annotation keys should be stable when edited
- duplicating an item must create new keys
- reordering must never regenerate keys

This is what allows package progress to survive edits and version migrations.
