# API contract summary

The canonical route set is defined in `API/learning-packages.openapi.yaml`.

This document explains the intent behind the route groups.

## Route groups

### 1) Authoring routes
Used by:
- PHP builder page
- future richer creator tools
- future WASM-admin style tools if needed

Recommended group:
- `/learning/packages/*`

### 2) Learning runtime routes
Used by:
- PHP learning library and study page
- future WASM runtime

Recommended group:
- `/learning/library/*`

### 3) Marketplace/package commerce routes
Used by:
- store page
- package detail page
- purchase flow

Recommended group:
- `/marketplace/packages/*`

### 4) Admin moderation routes
Used by:
- admin dashboard finance/moderation tabs

Recommended group:
- `/admin/marketplace/packages/*`

## Minimal authoring endpoints

- `GET /learning/packages/mine`
- `POST /learning/packages`
- `GET /learning/packages/{packageId}`
- `PUT /learning/packages/{packageId}/metadata`
- `PUT /learning/packages/{packageId}/draft-manifest`
- `POST /learning/packages/{packageId}/assets`
- `POST /learning/packages/{packageId}/publish-request`

## Minimal runtime endpoints

- `GET /learning/library/packages`
- `GET /learning/library/packages/{packageId}`
- `PUT /learning/library/packages/{packageId}/state`
- `PUT /learning/library/packages/{packageId}/items/{itemKey}/state`
- `GET /learning/library/packages/{packageId}/assets/{assetId}`

## Minimal marketplace endpoints

- `GET /marketplace/packages/store`
- `GET /marketplace/packages/store/{listingId}`
- `POST /marketplace/packages/store/{listingId}/buy`
- `POST /marketplace/packages/listings/upsert`
- `POST /marketplace/packages/listings/{listingId}/activate`
- `POST /marketplace/packages/listings/{listingId}/archive`
- `GET /marketplace/packages/purchases`
- `GET /marketplace/packages/sales`

## Minimal admin endpoints

- `GET /admin/marketplace/packages`
- `POST /admin/marketplace/packages/{listingId}/moderate`

## API design rules

### Rule 1
Reuse the existing API style already present in `src/api/v1/index.php`.

### Rule 2
Keep auth, wallet, and moderation behavior aligned with the score marketplace.

### Rule 3
Do not make the PHP pages dependent on API-only behavior if shared PHP domain functions already exist.

### Rule 4
Return enough data for the web mockup to render:
- package cards,
- curriculum,
- locked state,
- progress,
- resume target.

## Important response models

### Package store card
Must include:
- listing ID
- package ID
- title
- cover image
- package kind
- learning mode
- difficulty
- counts
- price
- creator info
- feature badges
- ownership state

### Package detail
Must include:
- top metadata
- package manifest summary
- previewable items
- prerequisites
- learning outcomes
- listing/license info
- creator info

### Learning library card
Must include:
- package ID
- active version ID
- status
- completion percent
- last opened item key/title
- last activity
- continue URL token or enough state to build it

### Study payload
Must include:
- package metadata
- manifest for active version
- package user state
- item user states
- current item
- version update info if a newer published version exists

## Access-control behavior

### Asset download/stream
The asset endpoint must deny access when:
- the user does not own the package,
- the asset is purchased-only and package access is missing,
- the asset belongs to another creator and no admin/owner access applies.

### Preview
Package detail may expose previewable content without purchase only if:
- the item or asset is marked previewable/public.

## Versioning behavior

When a user bought version A and version B is published later:
- the runtime should still know the user’s `activeVersionId`
- the response may include:
  - `latestPublishedVersionId`
  - `updateAvailable: true/false`

The PHP stage can show a banner.
The WASM stage can later offer smarter migration UX.

## Error behavior

Match the existing API conventions:
- RFC7807 / ProblemDetails style where already used
- include correlation ID
- do not leak storage internals
- return `403` for protected asset denial
- return `404` for missing package/item only when appropriate
