# Storage, access control, and IPFS readiness

## Requirement

All package manifests and media files should already be stored in a way that is compatible with a future IPFS migration.

The user explicitly requested that file names keep the same hashing logic used by IPFS.

## Recommendation

Use:
- `sha256`
- `cid_v1_raw`

Store the file physically under its CID-derived file name.

## Why `cid_v1_raw`

The current repo already contains CID-v1-raw hashing logic in the API layer.
Reusing the same algorithm keeps things consistent.

For raw file bytes:
- compute SHA-256
- compute CIDv1 raw multihash/base32 lowercase
- store file under that CID

Recommended physical file name pattern:

- `<cid_v1_raw>.<extension>`

Examples:
- `bafkreigh2akiscaildc...mp4`
- `bafkreib3c6w7x4wz2...jpg`
- `bafkreif3k2qv6....json`

## Storage roots

Add config roots such as:

- `LEARNING_MANIFESTS_ROOT`
- `LEARNING_ASSETS_ROOT`

Recommended defaults:
- `src/storage/api/learning/manifests`
- `src/storage/api/learning/assets`

## Recommended directory sharding

To avoid giant flat directories on cheap hosting, shard by CID prefix:

- `assets/ba/fk/<cid>.mp4`
- `manifests/ba/fk/<cid>.json`

Any simple deterministic sharding is fine.

## What should be stored by content address

### Package manifests
Yes, absolutely.

Why:
- immutable snapshots,
- cheap deduplication,
- future cache sync,
- easy diff/audit,
- future IPFS export.

### Uploaded lesson media
Yes.

Why:
- stable files,
- easy deduplication,
- CDN/IPFS friendliness later.

### Generated thumbnails/posters
Also yes.

Why:
- they are derived immutable assets too.

## What should stay in the database

The DB row should keep:
- owner/package relationship,
- metadata,
- mime type,
- original filename,
- dimensions/duration,
- access scope,
- moderation state,
- created timestamps,
- logical linkage.

The file bytes should stay on disk.

## Protected media access

The hosting environment is PHP on cheap hosting, so the access model should be realistic.

Recommended rule:
- all lesson media files stay outside public web access
- access is only through authenticated PHP endpoints
- those endpoints verify:
  - the asset exists,
  - the asset belongs to a package,
  - the current user is the owner/author/admin **or** has entitlement via purchase,
  - public previews are allowed only if the asset/item is marked previewable

## Video-specific requirement: HTTP Range support

If videos are stored locally and played in `<video>`, the endpoint should support:

- `Range` requests
- `206 Partial Content`
- `Accept-Ranges: bytes`

Without that, video seeking will feel broken.

Even in the PHP stage, this is worth implementing because:
- the mockup becomes more realistic,
- the final system will need it anyway.

## Preview behavior

Protected package assets should support three visibility levels:

- `public`
- `preview`
- `purchased`

Meaning:
- `public`  
  visible in package detail before purchase
- `preview`  
  safe teaser material before purchase
- `purchased`  
  visible only after purchase/access grant

## Asset policy recommendations

### Cover image
- public
- small and cached aggressively

### Hero image
- public or preview
- used in detail page

### Video lesson
- purchased by default
- optional teaser video or teaser poster may be public/preview

### Images/diagrams
- preview or purchased depending on author choice

### Attachments
- purchased by default

## Security notes

- never expose raw storage paths in public URLs
- stream through validated endpoints
- validate asset ownership on upload
- validate mime type and extension
- keep original filename as metadata only
- store with CID file name instead of original filename
- log suspicious denied access in audit or app logs if practical

## Why this setup is future-proof

When later moving to IPFS:
- the bytes already have stable CIDs,
- DB rows already know their CIDs,
- a migration can pin existing files and keep references unchanged,
- manifest files are already immutable and content-addressed.

That means the current filesystem solution is not throwaway work.
