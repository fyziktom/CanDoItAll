# Package manifest schema

The manifest is the immutable runtime snapshot for a package version.

It should be stored as a JSON file on disk, content-addressed by CID-compatible hashing, and referenced by the package version row.

## Root shape

```json
{
  "schemaVersion": 1,
  "packageId": "uuid",
  "packageVersionId": "uuid",
  "title": "Fast Broken Chords",
  "subtitle": "A guided lesson for intermediate pianists",
  "packageKind": "guided_lesson",
  "learningMode": "guided_path",
  "difficultyLevel": "intermediate",
  "estimatedMinutes": 75,
  "taxonomy": {
    "instruments": ["piano"],
    "genres": ["classical", "technique"],
    "skills": ["arpeggios", "broken-chords", "speed-building"],
    "composerFocus": []
  },
  "learningOutcomes": [
    "Play broken chords evenly at moderate tempo",
    "Understand wrist motion for speed",
    "Recognize safe practice loops"
  ],
  "prerequisites": [],
  "unlockMode": "sequential_item",
  "completionRule": "required_items",
  "supportedPracticeModules": [
    "midi_follow",
    "midi_record",
    "audio_follow_future",
    "chord_symbols",
    "tempo_ladder",
    "section_loop",
    "keyboard_visualizer"
  ],
  "sections": []
}
```

## Section shape

```json
{
  "key": "sec_7c38c59b",
  "title": "Module 1 – Core pattern",
  "subtitle": "Understand the movement first",
  "summary": "Start with the hand shape and the first loop.",
  "required": true,
  "sortOrder": 10,
  "items": []
}
```

## Item types

### `score`
Used for MusicXML/VexFlow/notation-driven learning.

Recommended fields:
- `key`
- `type`
- `title`
- `required`
- `scoreId`
- `scoreVersionId`
- `scoreFormat`
- `estimatedMinutes`
- `practiceConfig`
- `annotations`
- `displayConfig`
- `previewPolicy`
- `completionConfig`

### `text`
Used for lesson explanations or summaries.

Recommended fields:
- `key`
- `type`
- `title`
- `required`
- `bodyMarkdown`
- `displayMode`
- `estimatedMinutes`

### `video`
Used for teacher explanations.

Recommended fields:
- `key`
- `type`
- `title`
- `required`
- `assetId`
- `posterAssetId`
- `durationSeconds`
- `captionsAssetId`
- `streamingPolicy`
- `estimatedMinutes`

### `image`
Used for photos, diagrams, hand positions, fingering hints.

Recommended fields:
- `key`
- `type`
- `title`
- `required`
- `assetId`
- `caption`
- `displayMode`

### `attachment`
Used for downloadables such as PDF cheat sheets later.

Recommended fields:
- `key`
- `type`
- `title`
- `required`
- `assetId`
- `downloadPolicy`

### `checkpoint`
Used for explicit progress gates.

Recommended fields:
- `key`
- `type`
- `title`
- `required`
- `instructions`
- `completionMode`

## Score item shape

```json
{
  "key": "item_27af8c8c",
  "type": "score",
  "title": "Broken Chords Exercise 1",
  "required": true,
  "scoreId": "8fd7f7a7-2f76-4c83-b857-b6b3a1cf95ea",
  "scoreVersionId": "08bfef3f-f600-47dd-9110-3c278d6ee4ab",
  "scoreFormat": "musicxml-v1",
  "estimatedMinutes": 20,
  "displayConfig": {
    "showKeyboardVisualizer": true,
    "showMiniMap": true,
    "showMeasureCallouts": true,
    "defaultZoom": 1.0
  },
  "previewPolicy": {
    "publicPreviewMeasures": 8,
    "allowPreviewBeforePurchase": true
  },
  "completionConfig": {
    "mode": "manual_or_runtime",
    "markCompleteButtonEnabled": true
  },
  "practiceConfig": {
    "defaultTempo": 68,
    "targetTempos": [68, 80, 92],
    "loopRegions": [
      {
        "key": "loop_1",
        "label": "Bars 1–8",
        "measureStart": 1,
        "measureEnd": 8
      }
    ],
    "widgets": [
      {
        "code": "tempo_ladder",
        "enabled": true
      },
      {
        "code": "keyboard_visualizer",
        "enabled": true
      },
      {
        "code": "midi_follow",
        "enabled": true
      }
    ]
  },
  "annotations": []
}
```

## Annotation shape

Annotations are the important future-proofing piece.

They must support:
- global comments,
- measure-range callouts,
- popup behavior,
- widget hints.

Recommended shape:

```json
{
  "key": "ann_9e4bd8aa",
  "kind": "measure_comment",
  "title": "Keep the wrist loose",
  "bodyMarkdown": "Do not force the speed yet. Focus on evenness first.",
  "tone": "tip",
  "displayMode": "on_enter",
  "anchor": {
    "partId": "P1",
    "measureStart": 9,
    "measureEnd": 12,
    "beatStart": null,
    "beatEnd": null
  },
  "widgetHint": {
    "code": "tempo_ladder",
    "message": "Stay at the current step until bars 9–12 feel relaxed."
  }
}
```

Recommended enum values:

### `kind`
- `global_note`
- `measure_comment`
- `warning`
- `teacher_tip`
- `milestone`

### `tone`
- `info`
- `tip`
- `warning`
- `focus`

### `displayMode`
- `always_visible`
- `sidebar_only`
- `on_enter`
- `manual`

## Prerequisite shape

Support both structured and free-form prerequisites.

```json
{
  "kind": "package",
  "requiredLevel": "recommended",
  "packageId": "uuid",
  "label": "Piano Basics I"
}
```

```json
{
  "kind": "knowledge",
  "requiredLevel": "recommended",
  "code": "major_scales_two_octaves",
  "label": "Major scales in two octaves"
}
```

Recommended values:

### `kind`
- `package`
- `knowledge`
- `technique`
- `equipment`

### `requiredLevel`
- `required`
- `recommended`
- `optional`

## Why this schema works well

It is expressive enough for:
- simple score bundles,
- heavy lesson products,
- future WASM widgets,
- progress/resume,
- measure commentary.

But it avoids premature complexity like:
- full nested relational editing for every item field,
- ultra-granular runtime event requirements in stage 1.

## Authoring rule for manifest saves

Every time the creator saves the package draft:
- validate the manifest,
- normalize ordering,
- ensure stable section/item keys,
- resolve linked score version IDs,
- write a new immutable package version snapshot,
- update `learning_packages.current_draft_version_id`.

On publish approval:
- set `current_published_version_id` to the approved snapshot.
