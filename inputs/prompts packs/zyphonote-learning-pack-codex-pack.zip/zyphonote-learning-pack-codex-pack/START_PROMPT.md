You are implementing a new **Learning Packages / Lesson Packs** feature into the current Zyphonote PHP 8.2 + MariaDB repository.

## Inputs

You have:
- the current repo (`zyphonote-web-ui-refresh`)
- this implementation pack

## Objective

Implement a new product/runtime layer that allows creators to sell:
- score bundles,
- lessons,
- courses,
- etudes packs,
- composer collections,
- standards packs,
- technique/practice packs,

where each package can contain:
- linked score items,
- text explanations,
- images,
- protected videos,
- checkpoints,
- measure-anchored annotations,
- future WASM practice-module configuration.

The PHP web app is the first delivery stage and must provide a **credible end-to-end mockup** for:
- authoring,
- browsing,
- buying,
- opening,
- resuming,
- tracking progress,
- viewing protected media,
- testing UX and API logic.

The WASM app will later consume the same data model and APIs for:
- MIDI playback,
- MIDI record/follow,
- keyboard visualization,
- chord-symbol widgets,
- progression drills,
- future audio/spectral follow.

## Hard requirements

- PHP 8.2 + MariaDB
- no external services required
- keep the existing score marketplace working
- do not model packages as hacked-up scores
- use a new sibling domain for packages
- create immutable package versions
- store package manifests and media assets with CID-ready hashing/file naming
- all code comments must be in English
- keep PHP pages and `/api/v1` routes on the same shared domain logic
- the PHP stage must not fake MIDI playback; it must mock the study/runtime flow honestly

## Mandatory reading order

Read in this order before coding:
1. `README.md`
2. `CURRENT_REPO_ALIGNMENT.md`
3. `SPEC/01-product-overview.md`
4. `SPEC/02-domain-model.md`
5. `SPEC/03-manifest-schema.md`
6. `SPEC/04-ux-and-flow.md`
7. `SPEC/05-php-web-mockup-implementation.md`
8. `SPEC/06-storage-access-and-ipfs.md`
9. `SPEC/07-api-contract.md`
10. `SPEC/08-db-and-migration-plan.md`
11. `SPEC/09-progress-versioning-and-runtime.md`
12. `SPEC/10-rollout-risks-and-phases.md`
13. `API/learning-packages.openapi.yaml`
14. `DB/2026-03-06-learning-packages-proposed.sql`
15. `DB/manifest-example.json`
16. all files under `CHECKLISTS/`

## Execution mode

Execute the prompts in `PROMPTS/` sequentially:

1. `PROMPTS/01-analysis-and-plan.md`
2. `PROMPTS/02-domain-db.md`
3. `PROMPTS/03-api-routes.md`
4. `PROMPTS/04-authoring-ui.md`
5. `PROMPTS/05-buyer-and-library-ui.md`
6. `PROMPTS/06-study-mock-and-progress.md`
7. `PROMPTS/07-seeds-tests-docs.md`
8. `PROMPTS/08-final-audit.md`

Do not skip any step.
Do not mark the task complete until every checklist item is satisfied or explicitly documented with a justified deviation and a safe equivalent implementation.

## Critical modeling rules

- Separate:
  - `package kind`
  - `learning mode`
  - `item type`

- Use:
  - `learning_packages`
  - `learning_package_versions`
  - `learning_package_assets`
  - `learning_package_listings`
  - `learning_package_purchases`
  - `content_entitlements`
  - package and item runtime state tables

- Package versions must be immutable manifest snapshots.
- Published package versions should reference exact `scoreVersionId` values for score items.
- Package purchases must create access/entitlement records.
- Resume/progress must work in the PHP stage already.
- Protected media must not be public files.

## UX intent

The PHP UI must feel like a serious product, not a temporary admin page.
Prioritize:
- understandable structure,
- strong resume flow,
- clear locked/unlocked states,
- readable curriculum,
- clear package value on store cards,
- a creator builder that feels step-based and manageable.

Start now with `PROMPTS/01-analysis-and-plan.md`.
