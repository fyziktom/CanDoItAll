# Zyphonote Learning Packages – Codex implementation pack

This pack is tailored for the current **`zyphonote-web-ui-refresh`** PHP 8.2 + MariaDB repository.

It introduces a new **Learning Packages / Lesson Packs** layer that sits on top of the existing score marketplace and is designed to work in two stages:

1. **PHP web stage**  
   A realistic server-rendered mockup for authoring, browsing, buying, opening, and resuming lesson packs.

2. **WASM stage**  
   The same data model and API become the runtime source for MIDI playback, MIDI recording, auto-follow, audio/spectral follow, progress tracking, and advanced practice widgets.

## What this pack solves

The current repository already supports:
- user accounts,
- score creation and versioning,
- score marketplace listings,
- purchases and wallet flows,
- VexFlow rendering in the web UI,
- a PHP `/api/v1` layer,
- seller profiles and creator-facing discovery.

What is missing is a product layer for:
- **course-like products** composed of multiple scores,
- **collections** such as etudes, composer works, and standards packs,
- protected **text / images / videos** inside purchased content,
- **progress**, **resume**, and **current learning state**,
- future **WASM practice modules** without redesigning the backend later.

## Pack contents

- `START_PROMPT.md`
- `CURRENT_REPO_ALIGNMENT.md`
- `SPEC/` – product, architecture, UX, storage, API, progress, rollout
- `DB/` – proposed migration SQL and example manifest
- `API/learning-packages.openapi.yaml`
- `CHECKLISTS/` – execution and QA gates
- `PROMPTS/` – sequenced Codex prompts, including a final audit prompt

## Recommended usage

1. Give Codex:
   - the current PHP repo,
   - this pack.

2. Start with:
   - `START_PROMPT.md`

3. Make Codex execute the prompt sequence in `PROMPTS/` in order.

4. Do not skip the final self-audit prompt and checklist pass.

## Core architectural stance

The most important decision in this pack is:

- **Learning packages are not modeled as “just another score”.**
- They are modeled as a new root entity with:
  - immutable package versions,
  - content-addressed manifests,
  - protected media assets,
  - learning runtime state,
  - package listings and purchases,
  - optional score entitlements derived from package access later.

This lets the PHP mockup be credible now, while avoiding a painful redesign when the WASM app becomes the main runtime.
