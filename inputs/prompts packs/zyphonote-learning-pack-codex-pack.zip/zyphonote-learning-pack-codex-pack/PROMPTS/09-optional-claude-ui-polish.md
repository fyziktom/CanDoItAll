This prompt is optional and intended for a second-pass UI/design model after Codex finishes the logic.

Read the implemented learning packages feature and improve the UI/UX polish without changing the core data model or domain logic.

Focus on:
- visual hierarchy
- card quality
- curriculum readability
- learning-library “Continue” emphasis
- locked-content clarity
- study-page layout comfort
- responsive behavior
- creator builder step clarity

Do not redesign backend contracts.
Do not break working flows.
Polish the UI on top of the already-correct implementation.
