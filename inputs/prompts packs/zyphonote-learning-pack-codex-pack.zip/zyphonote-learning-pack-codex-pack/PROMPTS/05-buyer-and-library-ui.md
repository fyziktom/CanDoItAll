Implement the buyer-facing package marketplace and learning library.

Scope:
- package cards in the store
- package detail page/modal
- purchase flow
- account learning library page
- package cards on public creator profile
- package finance visibility where appropriate

Required references:
- `SPEC/04-ux-and-flow.md`
- `SPEC/05-php-web-mockup-implementation.md`
- `CHECKLISTS/04-web-buyer-marketplace-library.md`

Implementation rules:
- make package cards clearly different from score cards
- emphasize what is included and what the user gets
- clearly show locked vs owned content
- emphasize “Continue” on owned/in-progress packages
- keep seller/creator trust visible

When done:
- verify every item in `CHECKLISTS/04-web-buyer-marketplace-library.md`
- confirm purchase -> learning library flow works end-to-end
