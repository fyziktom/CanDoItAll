You are implementing the Zyphonote Learning Packages feature inside the current PHP 8.2 + MariaDB repository.

Before changing code:

1. Read:
- `README.md`
- `CURRENT_REPO_ALIGNMENT.md`
- `SPEC/01-product-overview.md`
- `SPEC/02-domain-model.md`
- `SPEC/03-manifest-schema.md`
- `SPEC/04-ux-and-flow.md`
- `SPEC/05-php-web-mockup-implementation.md`
- `SPEC/08-db-and-migration-plan.md`
- `CHECKLISTS/00-master-checklist.md`

2. Inspect the current repository structure and identify:
- existing marketplace helpers,
- existing score/version tables and routes,
- current page structure and nav patterns,
- existing storage helpers,
- current admin moderation flow.

3. Produce a concrete implementation plan mapped to actual files in this repo.

4. Explicitly confirm the following in your plan:
- learning packages will be a sibling domain to scores, not a score hack
- package versions will be immutable snapshots
- shared domain logic will live in `src/lib/learning-packages.php`
- the PHP pages and `/api/v1` routes will reuse that shared logic
- manifests/assets will use CID-ready storage naming
- the PHP stage will mock study/runtime but not fake MIDI playback

Do not start coding until the file-by-file plan is clear.
