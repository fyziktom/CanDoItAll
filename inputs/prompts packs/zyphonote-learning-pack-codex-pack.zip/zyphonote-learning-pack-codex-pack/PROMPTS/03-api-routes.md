Implement the API layer for learning packages.

Scope:
- `/learning/packages/*`
- `/learning/library/*`
- `/marketplace/packages/*`
- `/admin/marketplace/packages/*`

Required references:
- `SPEC/07-api-contract.md`
- `API/learning-packages.openapi.yaml`
- `CHECKLISTS/02-api-and-security.md`

Implementation rules:
- reuse shared domain logic from `src/lib/learning-packages.php`
- do not reimplement business rules inside route handlers
- keep auth/error style consistent with current `/api/v1`
- protect package assets correctly
- support HTTP range requests for video asset streaming
- write audit entries for admin moderation and important package actions

When done:
- verify every item in `CHECKLISTS/02-api-and-security.md`
- add or update smoke tests where the new routes are covered
