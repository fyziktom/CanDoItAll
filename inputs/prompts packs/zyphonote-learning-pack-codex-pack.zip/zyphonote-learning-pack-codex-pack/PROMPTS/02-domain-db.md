Implement the backend foundation first.

Scope:
- migrations
- config
- storage helpers
- `src/lib/learning-packages.php`
- manifest persistence
- asset persistence
- package save/load domain logic
- validation
- derived summary/index rebuild logic

Required references:
- `SPEC/02-domain-model.md`
- `SPEC/03-manifest-schema.md`
- `SPEC/06-storage-access-and-ipfs.md`
- `SPEC/08-db-and-migration-plan.md`
- `DB/2026-03-06-learning-packages-proposed.sql`
- `DB/manifest-example.json`
- `CHECKLISTS/01-backend-domain-db.md`

Implementation rules:
- all code comments must be in English
- do not implement page-only shortcuts
- keep package versions immutable
- store manifest snapshots on disk
- compute `sha256`
- compute `cid_v1_raw` or reuse the project’s equivalent helper
- rebuild the score-link index from every saved manifest

When done:
- verify every item in `CHECKLISTS/01-backend-domain-db.md`
- update docs if you made any justified deviation
