Implement the creator-facing PHP web UI for package authoring.

Scope:
- creator package list
- create package flow
- package builder page
- curriculum editor
- score linking
- media upload
- annotation editor
- pricing/listing step
- preview step
- publish submission step

Required references:
- `SPEC/04-ux-and-flow.md`
- `SPEC/05-php-web-mockup-implementation.md`
- `CHECKLISTS/03-web-creator-authoring.md`

Implementation rules:
- follow the current PHP + Tailwind style of the repo
- prefer reliable structured forms over fragile drag-and-drop
- use progressive enhancement JS only where it adds clear value
- make the builder step-based and understandable
- keep the preview close to the buyer-facing package detail layout

When done:
- verify every item in `CHECKLISTS/03-web-creator-authoring.md`
- ensure the builder can produce a valid manifest that the backend accepts
