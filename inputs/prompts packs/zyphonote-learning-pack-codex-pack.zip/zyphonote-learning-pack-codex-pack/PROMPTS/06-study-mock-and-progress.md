Implement the study/runtime mock page and progress flow.

Scope:
- `account-learning-package.php`
- package manifest rendering
- current item viewer
- package progress
- item progress
- resume logic
- annotation sidebar
- measure-save flow
- version-update banner
- WASM-ready module badges/placeholders

Required references:
- `SPEC/04-ux-and-flow.md`
- `SPEC/05-php-web-mockup-implementation.md`
- `SPEC/09-progress-versioning-and-runtime.md`
- `CHECKLISTS/05-study-runtime-mock.md`

Implementation rules:
- do not fake MIDI playback
- do make the study page feel credible for real package use
- make resume work after refresh/navigation
- manual completion and manual measure-save are acceptable in PHP
- show future WASM module capability honestly

When done:
- verify every item in `CHECKLISTS/05-study-runtime-mock.md`
- confirm item updates also update package-level progress
