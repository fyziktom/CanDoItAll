Extend seed data, tests, and docs so the feature is reviewable without manual setup pain.

Scope:
- `tools/seed_dev_data.php`
- smoke tests
- sample creator packages
- sample purchases and progress
- documentation updates tied to actual implementation

Required references:
- `SPEC/10-rollout-risks-and-phases.md`
- `CHECKLISTS/06-seed-data-and-testing.md`

Implementation rules:
- seed multiple package archetypes
- seed protected assets metadata and ownership
- seed at least one in-progress package
- seed at least one completed package
- seed at least one update-available scenario
- add deterministic tests for the main flow

When done:
- verify every item in `CHECKLISTS/06-seed-data-and-testing.md`
- make sure a reviewer can log in and see realistic package scenarios quickly
