Implement the piezo hit detector refinement package in this folder.

Read first:
1. `README_PACKAGE.md`
2. `CHECKLIST.md`
3. `docs/01-executive-summary.md`
4. `docs/02-current-code-audit.md`
5. `docs/03-root-cause-analysis.md`
6. `docs/04-open-source-survey.md`
7. `docs/05-piezo-signal-and-drummer-behavior.md`
8. `docs/06-firmware-detector-v2-design.md`
9. `docs/07-unit-model-calibration-and-polarity.md`
10. `docs/08-wasm-ui-protocol-changes.md`
11. `docs/09-file-touch-plan.md`
12. `docs/10-acceptance-and-playtest.md`
13. `docs/11-sources-and-licensing.md`

Then execute prompts strictly in order:
- `prompts/00-master-start.md`
- `prompts/01-baseline-and-unit-lock.md`
- `prompts/02-firmware-front-end-and-filtering.md`
- `prompts/03-firmware-state-machine-and-velocity.md`
- `prompts/04-firmware-calibration-and-protocol.md`
- `prompts/05-wasm-ui-and-guided-wizard.md`
- `prompts/06-tuning-presets-and-regression.md`
- `prompts/07-final-audit.md`

Non-negotiable rules:
- do not skip any phase,
- do not keep the current mixed-unit ambiguity,
- do not keep the current `piezoSamplesPerTick` dual-role design,
- do not keep plain median filtering as the default attack path for stick-piezo mode,
- do not keep absolute-peak velocity mapping as the main low-end tuning basis,
- keep source comments in English only,
- keep BLE MIDI transport stable,
- keep existing mapping and config persistence unless a documented compatibility change is required,
- return to `CHECKLIST.md` after every phase and state exactly what is complete and what remains.

Your first response must contain:
- a checklist-to-task mapping,
- a risk list,
- an exact file-touch plan,
- the phase execution order,
- the first files you will inspect.
