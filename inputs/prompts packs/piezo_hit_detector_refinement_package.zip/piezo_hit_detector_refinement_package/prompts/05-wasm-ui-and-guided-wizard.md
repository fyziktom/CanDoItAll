Phase 5 goals:
- make the tuning UI trustworthy
- add a guided calibration workflow
- remove ambiguity from the advanced settings

Required actions:
1. Update protocol models and client code for the new calibration and stats payloads
2. Make every detector field unit-explicit in the UI
3. Show raw-count equivalents next to human-readable values
4. Add the guided calibration wizard:
   - quiet capture
   - gentle hits
   - medium hits
   - hard hits
   - review and apply
5. Replace misleading static text with measured recommendations
6. Display the computed values the firmware is actually using

Do not leave the current mixed unit language in place.
Do not hide host-side normalizations from the user.
