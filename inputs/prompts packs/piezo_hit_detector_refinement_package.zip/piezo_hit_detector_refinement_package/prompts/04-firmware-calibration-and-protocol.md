Phase 4 goals:
- finish calibration properly
- extend the existing protocol in the smallest sensible way

Required actions:
1. Extend the calibration path so `CalibrateReq` supports:
   - `stillness`
   - `piezo_quiet`
   - `piezo_hits`
2. Implement quiet capture percentiles
3. Implement hit capture summaries for:
   - gentle
   - medium
   - hard
4. Derive recommended detector values from captures
5. Resolve auto polarity from hit captures
6. Extend `StatsResp` with the detector V2 telemetry fields
7. Keep legacy protocol requests working where practical

Do not leave calibration as a placeholder.
Do not invent a second separate calibration protocol if the existing request family can be extended cleanly.
