Implement this package as the source of truth.

Read in this exact order:
1. `CHECKLIST.md`
2. `docs/01-executive-summary.md`
3. `docs/02-current-code-audit.md`
4. `docs/03-root-cause-analysis.md`
5. `docs/04-open-source-survey.md`
6. `docs/05-piezo-signal-and-drummer-behavior.md`
7. `docs/06-firmware-detector-v2-design.md`
8. `docs/07-unit-model-calibration-and-polarity.md`
9. `docs/08-wasm-ui-protocol-changes.md`
10. `docs/09-file-touch-plan.md`
11. `docs/10-acceptance-and-playtest.md`
12. `docs/11-sources-and-licensing.md`

Then execute prompts strictly in order from `01-baseline-and-unit-lock.md` to `07-final-audit.md`.

Non-negotiable rules:
- do not skip any phase
- do not keep the current mixed-unit ambiguity
- do not keep the current `piezoSamplesPerTick` dual-role design
- do not keep plain median filtering as the default attack path for stick-piezo mode
- do not keep absolute-peak velocity mapping as the main low-end tuning basis
- keep source comments in English only
- keep BLE MIDI transport stable
- keep existing mapping and config persistence unless a documented compatibility change is required
- after every phase, return to `CHECKLIST.md` and say exactly what is done and what remains

Your first response must contain:
- a checklist-to-task mapping
- a risk list
- an exact file-touch plan
- the phase execution order
- the first files you will inspect
