Phase 2 goals:
- repair light-hit loss at the detector input
- keep BLE and mapping untouched
- prepare the detector for proper rearm logic

Required actions:
1. Replace plain median-first attack handling with an attack-preserving filter
2. Add polarity modes:
   - auto
   - positive
   - negative
   - absolute
3. Make the default stick-piezo profile use:
   - attack-preserving filter
   - auto polarity
4. Restrict baseline and noise adaptation to genuine quiet-idle conditions
5. Split `piezoSamplesPerTick` into:
   - sampler rate
   - consume budget
6. Keep the current scope page working, but expose any new front-end telemetry that helps tuning

Do not implement the final state-machine redesign yet.
Do not remove backward compatibility unless it is clearly documented.
