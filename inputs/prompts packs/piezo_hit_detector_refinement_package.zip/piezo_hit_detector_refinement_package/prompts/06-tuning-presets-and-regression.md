Phase 6 goals:
- tune the default presets
- verify the detector under realistic play patterns
- protect existing behavior that must not regress

Required actions:
1. Add at least one low-level-friendly preset for stick-mounted piezo mode
2. Add acceptance checks for:
   - isolated soft hits
   - isolated hard hits
   - alternating soft and hard hits
   - fast repeated taps
   - strong-hit then quiet tapping
3. Verify BLE note output still matches the intended mapped target
4. Verify config save/load still works
5. Verify the scope page still works
6. If the codebase layout allows it, leave the detector implementation reusable enough for a later InvisibleDrums piezo port

Do not widen scope into unrelated transport or audio changes.
