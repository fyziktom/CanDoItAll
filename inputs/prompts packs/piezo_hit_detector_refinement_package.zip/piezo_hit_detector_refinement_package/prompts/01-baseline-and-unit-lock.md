Phase 1 goals:
- freeze the current baseline
- lock the unit model before touching the detector
- identify every field that is counts vs mV today

Required actions:
1. Inspect the current firmware and WASM files listed in `docs/09-file-touch-plan.md`
2. Write down every piezo-related field and classify it as:
   - internal raw counts
   - explicit mV
   - mixed / ambiguous
3. Split the design conceptually into:
   - sampler rate
   - consume budget per tick
4. Produce a short compatibility note explaining how legacy requests will be interpreted after the refactor

Do not change detector behavior yet except for small no-risk telemetry needed to expose units.

Deliverables for this phase:
- updated protocol type definitions if needed for explicit unit metadata
- updated docs or code comments describing the unit model
- a small summary of ambiguous fields that will be fixed in the next phase
