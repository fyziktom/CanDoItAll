Final phase goals:
- prove that every checklist item is either complete or explicitly deferred
- audit compatibility and observability
- leave the code and docs ready for another developer

Required actions:
1. Return to `CHECKLIST.md` and mark every item
2. Produce a checklist-to-code mapping
3. Produce a short risk register for anything intentionally deferred
4. Confirm:
   - BLE MIDI path still works
   - tuning units are now explicit
   - calibration is real, not placeholder
   - the default front-end is no longer plain `Median3NoiseGuard` for stick mode
   - velocity is now based on peak-above-threshold
5. Update docs so another developer can continue without hidden assumptions

Your final response in that phase must list:
- what changed
- what was intentionally not changed
- what should be tested next on hardware
