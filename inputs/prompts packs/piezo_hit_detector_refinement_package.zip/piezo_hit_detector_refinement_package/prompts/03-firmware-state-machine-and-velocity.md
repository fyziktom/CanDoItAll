Phase 3 goals:
- implement the detector V2 state machine
- separate short mask from true rearm
- decouple velocity feel from raw absolute threshold changes

Required actions:
1. Keep scan start at threshold crossing
2. Implement:
   - Idle
   - Scan
   - Mask
   - Rearm
3. Add hysteresis with:
   - start threshold
   - release threshold
4. Add a fast-retrigger path after mask for legitimate new rising attacks
5. Map velocity from `peak above thresholdStart`, not from raw absolute peak
6. Preserve target freeze-on-scan-start behavior
7. Add start / mask / rearm reject counters and reason fields

Required validation:
- a single strong strike does not double trigger
- light hits can now pass more easily than before
- strong-hit then soft-hit transitions are better than baseline
