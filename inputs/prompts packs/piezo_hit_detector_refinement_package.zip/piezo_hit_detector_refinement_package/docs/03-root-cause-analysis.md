# Root cause analysis

## 1. Why the scope can show a pulse while the detector still misses it

A piezo strike is not a DC value. It is a fast transient with a polarity, a first lobe, and a decaying ring.

The current path effectively does this:

1. raw ADC sample
2. optional median-3
3. optional positive-only rectification
4. deadband
5. envelope
6. threshold crossing
7. scan
8. mask
9. quiet wait

That means a light hit can be lost before step 6.

### Important low-level consequence
If the signal is light enough, the attack is the most valuable part of the waveform. A median filter can soften exactly that attack.

This is why the package requires an **attack-preserving filter** instead of a plain median-on-everything approach.

## 2. The current defaults are stacked against small hits

The current snapshot combines:
- a default deadband of 40 mV,
- a median-3 based input path,
- a positive-only default,
- a multi-layer threshold floor.

For a synthetic light pulse, the filtered peak can fall below the 40 mV deadband even if the raw pulse looked real on the oscilloscope. See `../references/analysis/median_deadband_example.md`.

## 3. The threshold model is too complex for human tuning

Right now the operator can touch:
- sensitivity level
- preset
- deadband
- positive-only
- hit threshold
- threshold margin
- threshold K
- scan
- mask
- quiet
- runtime overrides
- ADC attenuation

But the detector then derives:
- threshold floor
- threshold offset
- dynamic threshold
- quiet threshold
- velocity peak minimum
- velocity peak reference

This creates a situation where two parameters that look independent are not independent at all.

Codex must fix this by introducing a **canonical detector model** with a small set of directly meaningful quantities:
- deadband
- start threshold floor
- dynamic threshold addend
- scan min/max
- short mask
- release threshold behavior
- velocity curve above threshold

## 4. Calibration exists in name only

The current code reserves piezo calibration fields but still starts from a short boot baseline window. That is not enough for:
- quiet-noise estimation
- polarity detection
- low-end velocity mapping
- mount-specific retuning

A real piezo detector needs:
- quiet capture for noise percentiles
- hit capture for polarity and peak percentiles

## 5. The current system does not separate "ignore the same ring" from "allow the next real hit"

A professional e-drum style detector usually treats these as different things:
- **mask**: short absolute ignore period right after a hit
- **rearm / retrigger**: logic that decides when a new attack is truly independent

The current detector does have mask and wait-quiet states, but the rearm logic is too simple and not attack-aware enough. This is why the package defines:
- a short fixed mask,
- a release threshold,
- and an explicit fast-retrigger path for legitimate new attacks.

## 6. Why strong-hit then light-tap transitions currently feel worse than they should

The user wants this pattern to work:
- big hit
- big hit
- immediately very quiet cymbal taps

That pattern stresses three things:
- front-end sensitivity
- rearm timing
- velocity mapping

Current failure modes:
- the front-end removes the light onset
- the release model still treats the detector as "too close to the previous hit"
- the velocity model is tied to absolute peak instead of peak-above-threshold

Fixing only one of those three will not be enough.
