# Open-source survey

## Projects and documents reviewed

### HelloDrum
Usefulness:
- strong reference for the classic e-drum pipeline
- permissive license
- simple mental model for threshold, scan, mask, and velocity

Takeaways we should keep:
- threshold crossing starts the scan
- scan finds the peak
- mask prevents immediate re-entry
- settings must be per-trigger and understandable

Takeaways we should not copy blindly:
- Arduino-era defaults that assume larger pad signals than a tiny stick-mounted piezo may produce

### Open E-Drums sensing notes
Usefulness:
- concise explanation of threshold -> scan -> peak -> mask
- confirms that our detector should stay in that family

Takeaway:
- the "scan for peak after threshold, then mask" model is correct and should stay

### edrumulus
Usefulness:
- high-quality reference project for serious trigger performance
- very relevant behavioral inspiration

Important lesson:
- the maintainer explicitly described moving to a more standardized model where **scan starts at threshold crossing** and **mask starts after scan end**
- that matches the detector shape we want

Limit:
- GPL family licensing, so do not copy code

### EavesDrum
Usefulness:
- modern open-source project with WebUI-oriented tuning
- strong reference for browser-based monitoring and parameter discovery

Takeaways:
- real-time signal monitoring in the UI is worth it
- latency is strongly coupled to scan-time choices
- browser-based parameter tuning is a valid first-class workflow

Limit:
- GPL-3.0, so use only as behavioral inspiration, not as copy source

## Practical conclusions for this project

We should keep these principles:
1. threshold crossing starts a scan
2. scan captures the peak
3. a short mask suppresses the immediate ring
4. a separate rearm condition decides when a new attack is legitimate
5. the host UI must expose signal monitoring and guided parameter tuning

We should add project-specific improvements that the current open-source references do not solve for us directly:
- attack-preserving filtering for tiny stick piezo signals
- explicit raw-count vs mV unit discipline
- polarity auto-detection
- guided quiet/gentle/medium/hard capture workflow
- velocity based on **peak above threshold**, not just raw peak
