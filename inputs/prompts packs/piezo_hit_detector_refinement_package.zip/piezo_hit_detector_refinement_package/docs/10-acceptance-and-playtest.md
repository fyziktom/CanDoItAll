# Acceptance and playtest plan

## 1. Bench acceptance

### Light hit acceptance
Target:
- hits in the user's observed low range should be triggerable after calibration
- repeated gentle taps should not require unrealistically low deadband values

### Double-trigger rejection
Target:
- a single strong strike should not create a duplicate note from the same ring

### Strong-to-soft transition
Target:
- after two strong hits, very quiet tapping should still trigger without waiting for a long blanket refractory

### Polarity robustness
Target:
- reversing piezo wiring or mount orientation should not force a manual rewrite of the whole threshold model

## 2. Manual play scenarios

Run these with visible stats:
1. isolated soft hits
2. isolated hard hits
3. alternating soft and hard hits
4. straight sixteenth-notes
5. quarter-note accents with quiet interleaved taps
6. two hard hits then sustained quiet cymbal tapping
7. very fast repeated light taps on the same target

Record:
- hit count
- missed count
- false double count
- average accepted peak
- reject counters by reason

## 3. Recommended default preset after the refactor

For the first shipped pass, ship a default close to `SensitiveStick`:
- attack-preserving filter
- auto polarity
- deadband from quiet capture
- short mask
- low release threshold
- velocity above threshold

Do not ship the current `Median3NoiseGuard` + 40 mV deadband combination as the recommended default for stick-mounted piezo mode.

## 4. Regression rules

Must not regress:
- BLE connectivity
- current note mapping behavior
- target freeze-on-scan-start logic
- config persistence
- display scope page

## 5. Documentation done criteria

Documentation is complete only when it explains:
- internal units
- UI units
- every state-machine timing
- how calibration derives recommendations
- which open-source projects were used as inspiration and why their code was not copied
