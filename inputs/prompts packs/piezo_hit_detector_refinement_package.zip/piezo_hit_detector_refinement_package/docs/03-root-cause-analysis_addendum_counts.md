# Addendum: counts and attenuation quick notes

This addendum is optional reading.

At 11 dB attenuation and the current firmware's simple full-scale assumption:
- full scale is treated as about 3900 mV
- 1 raw count is therefore close to 0.95 mV

That means the current ambiguity between some raw-count fields and UI labels that say "mV" can look almost harmless at 11 dB.
It is still a bug.

Why it matters:
- if the user changes ADC attenuation, the same human-readable number no longer means the same detector threshold
- this is exactly why the next pass must carry explicit unit metadata

See:
- `../references/analysis/adc_mv_to_counts_examples.csv`
