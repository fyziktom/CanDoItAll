# Piezo signal and drummer behavior

## 1. What the player is physically doing

The user is not hitting identical notes in isolation. Real stick work includes:
- isolated strong hits
- isolated gentle hits
- even quarter-note taps
- fast sixteenth and thirty-second-note runs
- immediate transitions from loud accents to very quiet cymbal ticks

That means the detector must handle:
- large dynamic range
- variable inter-hit spacing
- different stroke lengths
- different rebound behaviors

## 2. What the piezo actually sees

The piezo does not see "a drum hit". It sees a transient waveform:
- a first lobe with a polarity
- a local peak
- a decaying oscillation
- sometimes mounting-dependent ring
- sometimes the opposite polarity is stronger depending on wiring and mechanics

For a stick-mounted piezo, the signal is often smaller than a normal drum-pad piezo. That makes the first attack more valuable and plain median smoothing more dangerous.

## 3. What a good detector should infer

A useful detector should infer:
- **attack started**
- **local peak has been captured**
- **this is a real hit, not just the same ring**
- **the next hit is now allowed again**
- **velocity should reflect the hit energy above the active threshold**

## 4. Why peak-above-threshold is the right velocity basis

If velocity is mapped from the absolute peak only, then threshold changes alter feel in two ways:
- trigger sensitivity changes
- velocity feel changes

That coupling is bad.

Instead define:
- `effective_peak = max(0, peak - threshold_start)`

Then map MIDI velocity from `effective_peak`.

Benefits:
- threshold tuning and velocity tuning become more independent
- low-end response is easier to shape
- a rise in dynamic threshold during noisy situations does not completely destroy expressiveness

## 5. Why short mask plus explicit rearm is better than a long blanket refractory

A long global refractory prevents doubles, but it also throws away legitimate fast notes.

A better model is:
- **short mask** to suppress the immediate ring after the hit
- **release / rearm** to decide when the signal has settled enough
- **fast reattack path** to allow a clearly new rising attack even before full quiet

This is especially important for the pattern:
- loud hit
- loud hit
- very light repeated tapping

## 6. What "adaptive" should mean here

Adaptive should not mean:
- uncontrolled self-moving thresholds that become impossible to tune

Adaptive should mean:
- quiet-noise estimation from quiet data only
- polarity estimation from captured hits
- recommended thresholds from measured percentiles
- optional preset scaling for different mounting styles

The detector should stay predictable.
