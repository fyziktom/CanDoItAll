# Unit model, calibration, and polarity

## 1. Why unit discipline matters here

The current UI already presents several controls as mV-like values.

That is acceptable only if the firmware does one of these two things consistently:
- interprets them as mV and converts them to counts, or
- labels them as counts and stops pretending they are mV

The next Codex pass must choose one model and document it.

## 2. Required model

### Internal detector model
- raw counts only

### Host-facing model
- explicit unit field on write operations
- explicit metadata on read operations

Recommended request shape:
- `units = "counts"` or `units = "mv"`

When `units = "mv"`:
- every threshold-like field must be converted using the active attenuation

Fields that must be convertible, not just deadband:
- `deadband`
- `start slope`
- `threshold floor`
- `threshold offset`
- `quiet / release threshold`
- `velocity low reference`
- `velocity high reference`

## 3. ADC attenuation and UI truthfulness

At 11 dB on ESP32, the effective measurable range is large, which is convenient for hard hits. But low-end calibration near tens of millivolts is still approximate and hardware dependent.

Therefore:
- runtime logic should remain in counts
- the UI should present mV as **approximate** unless a calibrated path proves otherwise
- the UI must always show the raw-count equivalent next to mV when advanced tuning is enabled

## 4. Real calibration flow

### Quiet calibration
Capture for 1.5 to 2.0 seconds while the stick is idle.

Compute:
- `quietP95Raw`
- `quietP99Raw`
- `quietMaxRaw`

Recommended derived values:
- `deadbandRaw = quietP99Raw + quietMargin`
- `thresholdFloorRaw = max(deadbandRaw + 2, quietMaxRaw + floorMargin)`

### Hit calibration
Separate phases:
- gentle
- medium
- hard

Collect:
- accepted peak raw values
- first-lobe positive vs negative energy
- ring-down durations

Use that to derive:
- resolved polarity
- velocity low reference
- velocity high reference
- optional recommended preset

## 5. Backward compatibility rule

Backward compatibility is allowed, but not at the cost of ambiguity.

Recommended compatibility rule:
- if request has no `units`, keep the current legacy interpretation
- if request has `units = "mv"`, convert every relevant field properly
- mark legacy behavior as deprecated in the docs and UI

## 6. Reuse the existing calibrate request instead of inventing a second calibration message

Preferred extension:
- `CalibrateReq` gains `mode`

Modes:
- `stillness`
- `piezo_quiet`
- `piezo_hits`

This keeps the protocol surface smaller and lets the host build a guided wizard on top of one endpoint family.
