# File touch plan

## Firmware repository / current piezo tuning branch

Primary files:
- `firmware/IRDrums/PiezoHitEngine.h`
- `firmware/IRDrums/PiezoHitEngine.cpp`
- `firmware/IRDrums/IRDrums.ino`
- `firmware/IRDrums/src/Protocol.h`
- `firmware/IRDrums/src/Protocol.cpp`

Expected tasks:
- replace the current front-end with V2 logic
- split sample-rate and consume-budget config
- add calibration summaries
- extend stats payload
- keep existing BLE MIDI note flow intact

## Zyphonote repo

Primary files:
- `src/App.Blazor/Pages/IrDrums.razor`
- `src/App.Blazor/Pages/IrDrums.razor.css`
- `src/InvisibleDrums.Protocol/IdrmTypes.cs`
- `src/InvisibleDrums.Protocol/IdrmDeviceClient.cs`
- `src/App.Blazor/Services/InvisibleDrumsSessionService.cs`

Possible additional files:
- `src/App.Blazor/Services/IdrmMidiTransportAdapter.cs`
- small chart helper JS if the current page needs it

Expected tasks:
- explicit unit model
- guided calibration workflow
- richer telemetry
- removal of misleading static text
- compatibility handling for legacy requests if still needed

## Tests and fixtures

Add or update:
- protocol tests for new calibration modes
- small detector tests for:
  - light-hit acceptance
  - double-trigger rejection
  - strong-hit then light-hit transition
  - auto-polarity resolution
- sample JSON fixtures for calibration responses
