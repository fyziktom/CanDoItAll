# Sources and licensing notes

Human-readable reference list used to build this package.

1. HelloDrum Arduino Library
   - Repository and documentation pages describing threshold, sensitivity, scan time, mask time, and velocity mapping
   - License: MIT
   - Relevance: classic simple e-drum detector model

2. Open E-Drums sensing notes
   - Public sensing explanation page
   - Relevance: concise statement of threshold -> scan -> peak -> mask behavior

3. edrumulus
   - Project repository and maintainer discussion about standardized scan/mask timing behavior
   - License family: GPL-2.0-or-later
   - Relevance: high-quality behavioral inspiration only
   - Rule for this project: no direct code copying

4. EavesDrum
   - Project website and repository
   - License family: GPL-3.0
   - Relevance: browser-based trigger tuning and signal monitoring inspiration only
   - Rule for this project: no direct code copying

5. Arduino-ESP32 ADC documentation
   - Official documentation for `analogRead`, `analogReadMilliVolts`, ADC resolution, and attenuation ranges
   - Relevance: required for honest UI units and attenuation-aware conversion rules

## Licensing rule for Codex

Safe to reuse structurally:
- our own current code
- MIT-licensed HelloDrum snippets, if truly necessary and properly preserved

Do not copy code from:
- edrumulus
- EavesDrum

You may still use those projects for:
- terminology
- behavior comparison
- design inspiration
- acceptance targets
