# Executive summary

The current system is close, but the remaining light-hit problem is not a single bad threshold. It is the result of several detector decisions stacking on top of each other:

1. the front door is too strict for light hits,
2. the tuning model mixes several different threshold layers,
3. the browser labels suggest mV semantics while the firmware mainly reasons in raw counts,
4. piezo calibration is only scaffolded, not actually implemented.

The most important concrete findings from the current code snapshot are:

- the default piezo filter mode is `Median3NoiseGuard`
- the default UI deadband is `40 mV`
- the detector can run in `positive_only` mode by default
- the current threshold model adds preset floor, configured floor, safety floor, noise scale, and filter-mode adjustments on top of each other
- `piezoSamplesPerTick` currently drives both sample-rate selection and per-loop consume budget
- `piezoCalibrationMs`, `calibrateSamples`, and `calibrateNoiseAccum` exist, but the code does not yet use them to produce a real piezo calibration result

That combination is enough to explain why the MCU scope can show a real pulse while the detector still misses a light strike.

This package therefore requires a detector redesign in four layers:

- **unit discipline**: raw counts internally, explicit conversion at the UI/protocol boundary
- **front-end sensitivity**: attack-preserving filter plus auto-polarity
- **state machine clarity**: short mask, explicit rearm, velocity from peak-above-threshold
- **guided calibration**: quiet + gentle + medium + hard capture with percentile-derived recommendations

The target outcome is not "maximum sensitivity at any cost". The target outcome is:

- light hits should pass,
- false positives should remain low,
- strong hits followed by quiet tapping should still work,
- the settings should finally be explainable.

Use the diagrams in `../diagrams/` and the pseudocode in `../references/pseudocode/` as the implementation scaffold.
