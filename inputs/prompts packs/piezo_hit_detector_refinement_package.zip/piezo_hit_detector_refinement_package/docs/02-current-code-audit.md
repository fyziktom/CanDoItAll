# Current code audit

## Firmware findings

### A. Default input suppression is aggressive
Reference:
- `IRDrums.ino` line 1269: default filter mode = `Median3NoiseGuard`
- `IRDrums.ino` line 1270: default `piezoDeadbandMv_`
- `IRDrums.ino` line 1272: default `piezoPositiveOnly_`

Impact:
- a small hit can be reduced by the median filter before it even reaches the detector
- the deadband then removes what remains
- if polarity is wrong, `positive_only` can erase a legitimate first lobe completely

### B. One control currently changes two different subsystems
Reference:
- `IRDrums.ino` line 2082: `piezoSamplesPerTick` influences `sampleRateHz`
- `IRDrums.ino` lines 2949-2955: `piezoSamplesPerTick` also influences consume budget

Impact:
- a user who tries to "read more samples per tick" is also silently changing the actual sampling rate
- this makes tuning non-intuitive
- Codex must split this into two controls:
  - `piezoSamplerRateHz`
  - `piezoConsumeBudgetPerTick`

### C. Threshold construction is too layered
Reference:
- `IRDrums.ino` lines 2084-2119
- preset values from `PiezoHitEngine.h`
- runtime overrides at lines 2121-2153

Current stack:
- preset threshold floor
- preset threshold offset
- configured `hit_thr`
- configured `thr_margin`
- safety floor
- safety offset
- dynamic noise scale
- filter-mode quiet adjustments

Impact:
- a user cannot easily predict what changing one number actually does
- Codex must simplify the model and expose the final computed values

### D. Baseline and noise tracking are not quiet-only
Reference:
- `PiezoHitEngine.cpp` lines 101-117

Current behavior:
- baseline tracking is disabled only in `Scan`
- noise tracking runs in `Idle` and `WaitQuiet`

Impact:
- post-hit residual energy can still influence baseline/noise adaptation
- this is not ideal for a detector that must jump from strong hits to very light hits

### E. Median filtering happens before the detector sees the onset
Reference:
- `IRDrums.ino` lines 2958-2971 and 2977-2988

Impact:
- rising attack detail can be suppressed
- the detector then only sees a softened version of the onset
- this is especially harmful for tiny stick-mounted piezo signals

### F. Velocity is still tied too closely to absolute peak
Reference:
- `PiezoHitEngine.cpp` lines 67-74
- `IRDrums.ino` lines 2105-2107

Impact:
- changes in threshold floor implicitly change the velocity feel
- the low end is harder to tune consistently
- velocity should instead depend on **peak above the start threshold**

### G. Piezo calibration scaffolding exists but is unfinished
Reference:
- `IRDrums.ino` line 473
- `IRDrums.ino` lines 1075, 1084, 1085
- `IRDrums.ino` lines 2229, 2238, 2239

Impact:
- the code reserves fields for calibration, but the detector is still effectively bootstrapped from a short startup baseline window
- Codex must implement real quiet calibration and real hit-capture calibration

## WASM and protocol findings

### H. The tuning UI uses mV language too broadly
Reference:
- `IrDrums.razor` lines 1378-1403
- `IrDrums.razor` lines 1407-1488

Impact:
- `deadband_mv` and `rise_guard_mv` are truly mV-like fields
- but many threshold-like fields are only treated as raw detector values in the firmware
- at 11 dB this looks roughly correct by accident because 1 count is close to 1 mV
- at other attenuations the mismatch becomes real and confusing

### I. The UI normalizer can fight the operator
Reference:
- `IrDrums.razor` lines 1417-1468

Impact:
- the page silently rewrites relationships between deadband, threshold, quiet threshold, and velocity thresholds
- this is not wrong in principle, but today it happens on top of an already ambiguous unit model
- Codex must keep only a small set of safe relations and show every normalization explicitly

### J. The current host does not expose a guided capture workflow
Impact:
- the user is still tuning by intuition and static text
- a strong detector needs guided captures:
  - quiet
  - gentle hits
  - medium hits
  - hard hits

## Root conclusion

The current code is close enough that a full rewrite is unnecessary.

The correct repair is:
1. keep the BLE MIDI transport,
2. keep the general threshold -> scan -> mask shape,
3. replace the front-end and state-machine details,
4. finish calibration and unit handling.
