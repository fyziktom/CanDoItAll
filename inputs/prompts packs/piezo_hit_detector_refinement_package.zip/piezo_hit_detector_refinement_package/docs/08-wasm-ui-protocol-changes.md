# WASM UI and protocol changes

## 1. UI changes

### Replace the current ambiguous advanced editor
The advanced piezo section must:
- show unit for every field
- show the current attenuation
- show raw-count equivalents
- show the **computed detector config** the firmware is actually using

### Add a guided wizard
Pages or steps:
1. quiet capture
2. gentle hit capture
3. medium hit capture
4. hard hit capture
5. review recommended preset
6. apply
7. save

### Remove static hard-coded advice
Replace:
- static paragraphs about suggested mV ranges

With:
- measured percentiles from calibration
- recommended values derived from actual captures

## 2. Host charts and overlays

Add:
- raw waveform chart
- filtered waveform chart
- envelope
- start threshold
- release threshold
- peak markers
- reject counters

A good host UI should let the user answer:
- Did the detector see the onset?
- Did the filter soften the onset?
- Did thresholding reject it?
- Was it blocked by mask or rearm?

## 3. Protocol changes

### Extend `SetSensitivityReq`
Add:
- `units`
- `scan_min_ms`
- `scan_max_ms`
- `rearm_quiet_ms`
- `release_ratio`
- `start_slope`
- `vel_min_above_thr`
- `vel_ref_above_thr`

### Extend `StatsResp`
Add:
- `pz_filtered`
- `pz_slope`
- `pz_thr_start`
- `pz_thr_release`
- `pz_polarity`
- `pz_clip`
- `pz_rej_start`
- `pz_rej_rearm`

### Extend `CalibrateReq` / `CalibrateResp`
Add:
- `mode`
- quiet percentiles
- hit percentiles
- polarity summary
- recommended values
- optional decimated waveform

## 4. Session service changes

The Zyphonote host layer should:
- expose new calibration calls
- expose the richer stats model
- map the new detector fields into Blazor without extra ambiguity
- keep the BLE MIDI transport API stable

## 5. UX rule for attenuation changes

When ADC attenuation changes:
- either re-express UI values under the new attenuation explicitly
- or force the user to confirm re-scaling
- but never silently keep the same human-readable mV numbers while changing only the raw detector meaning

## 6. Minimum telemetry panel

Even in the compact view, show:
- state
- polarity
- filtered peak
- start threshold
- release threshold
- deadband
- last reject reason
- last accepted velocity
