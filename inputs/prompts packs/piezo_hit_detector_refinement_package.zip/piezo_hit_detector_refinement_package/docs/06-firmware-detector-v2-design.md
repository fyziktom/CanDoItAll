# Firmware detector V2 design

## Design goals

- keep BLE MIDI stable
- preserve the threshold -> scan -> peak -> mask family
- improve low-end sensitivity
- keep false triggers low
- make parameter meaning explicit

## 1. Canonical internal units

All runtime detector values must use raw ADC counts internally.

That includes:
- deadband
- threshold floor
- threshold offset
- noise estimate
- peak
- release threshold
- velocity reference points

The firmware may convert mV <-> counts at the boundary, but the detector core must stay in counts.

## 2. Split configuration that is currently overloaded

Replace the current `piezoSamplesPerTick` dual-role behavior with:
- `piezoSamplerRateHz`
- `piezoConsumeBudgetPerTick`

Reason:
- sample-rate tuning and queue-consume tuning are not the same problem

## 3. Front-end V2

### 3.1 Baseline
Track baseline only in real quiet idle, not in every state except scan.

Recommended rule:
- update baseline only when state is `Idle`
- and filtered signal is below the active start threshold

### 3.2 Polarity
Support:
- `auto`
- `positive`
- `negative`
- `absolute`

Default:
- `auto`

Auto-mode behavior:
- determine the dominant first lobe sign from captured hits
- use signed half-wave rectification for runtime
- expose the resolved sign in telemetry

### 3.3 Filter
Replace median-first behavior with an attack-preserving filter.

Recommended online rule:
- compute median3
- if raw rectified exceeds median by `attackPreserveDelta` and slope is positive enough, keep raw
- otherwise use the smoothed value

This preserves attacks while still suppressing isolated junk.

## 4. Threshold model V2

Use:
- `deadbandRaw`
- `thresholdFloorRaw`
- `thresholdOffsetRaw`
- `noiseScale`

Then compute:

- `thresholdStartRaw = max(thresholdFloorRaw, deadbandRaw + 2, noiseRaw * noiseScale + thresholdOffsetRaw)`

Also define:

- `thresholdReleaseRaw = max(releaseFloorRaw, min(lastPeakRaw * releaseRatio, thresholdStartRaw * 0.55))`

This yields:
- a start threshold,
- and a lower release/rearm threshold with hysteresis.

## 5. State machine V2

### Idle
Start scan when:
- filtered >= thresholdStart
- and slope >= startSlopeMin

### Scan
Track:
- peak
- optional local-fall condition
- timeout

End scan when:
- `scanMinMs` has elapsed and a local fall is observed
- or `scanMaxMs` is reached

### Mask
Short fixed ignore time.

Recommended starting range:
- 1.8 to 3.2 ms for stick-mounted piezo
- do not default back to the current 14 ms style unless data proves it is necessary

### Rearm
Allow the next hit when:
- filtered stays below `thresholdReleaseRaw` for `rearmQuietMs`

Also allow fast retrigger when:
- mask is already over
- a new rising attack crosses start threshold
- slope exceeds `fastRetriggerSlopeMinRaw`

## 6. Velocity model V2

Compute:
- `effectivePeakRaw = max(0, scanPeakRaw - thresholdStartRaw)`

Then map MIDI velocity from `effectivePeakRaw` using:
- `velocityMinAboveThresholdRaw`
- `velocityRefAboveThresholdRaw`
- `velocityGamma`

This is the most important velocity change in the package.

## 7. Telemetry fields that must exist after the refactor

Required:
- raw counts
- centered counts
- signed counts
- rectified counts
- filtered counts
- envelope counts
- noise counts
- start threshold counts
- release threshold counts
- slope counts
- resolved polarity sign
- current state
- scan peak
- last peak
- last velocity
- start rejects
- mask rejects
- rearm rejects
- clipping count

Nice to have:
- approximate mV mirrors for display only
- recent decimated waveform for host-side overlay

## 8. Non-goals for this pass

Do not:
- rewrite BLE transport
- replace the entire protocol stack
- jump directly to analog continuous driver work unless the current sampler proves broken
- copy GPL code
