#include "PiezoDetectorV2.h"

#include <math.h>

namespace idrm {

namespace {

static uint32_t msToUs(float ms) {
  if (ms < 0.0f) {
    ms = 0.0f;
  }
  return static_cast<uint32_t>(lroundf(ms * 1000.0f));
}

static uint16_t clampU16(int value) {
  if (value < 0) {
    return 0;
  }
  if (value > 65535) {
    return 65535;
  }
  return static_cast<uint16_t>(value);
}

}  // namespace

void PiezoDetectorV2::reset(uint16_t baselineRaw) {
  baselineRaw_ = static_cast<float>(baselineRaw);
  envelopeRaw_ = 0.0f;
  noiseRaw_ = 0.0f;
  scanPeakRaw_ = 0;
  scanStartedUs_ = 0;
  maskUntilUs_ = 0;
  quietStartedUs_ = 0;
  recentRectified_[0] = 0;
  recentRectified_[1] = 0;
  recentRectified_[2] = 0;
  recentRectifiedCount_ = 0;
  stats_ = PiezoLiveStatsV2 {};
}

void PiezoDetectorV2::applyConfig(const PiezoDetectorConfigV2& config) {
  config_ = config;
}

void PiezoDetectorV2::applyCalibration(const PiezoCalibrationSummary& calibration) {
  calibration_ = calibration;
  stats_.polaritySign = calibration.resolvedPolaritySign == 0 ? 1 : calibration.resolvedPolaritySign;
}

uint16_t PiezoDetectorV2::rectifiedByPolarity(int16_t centered) const {
  const int sign = stats_.polaritySign >= 0 ? 1 : -1;
  switch (config_.polarityMode) {
    case PiezoPolarityMode::Positive:
      return centered > 0 ? centered : 0;
    case PiezoPolarityMode::Negative:
      return centered < 0 ? static_cast<uint16_t>(-centered) : 0;
    case PiezoPolarityMode::Absolute:
      return static_cast<uint16_t>(abs(centered));
    case PiezoPolarityMode::Auto:
    default: {
      const int signedValue = sign * centered;
      return signedValue > 0 ? static_cast<uint16_t>(signedValue) : 0;
    }
  }
}

uint16_t PiezoDetectorV2::applyAttackPreservingFilter(uint16_t rectified, int16_t slope) {
  recentRectified_[0] = recentRectified_[1];
  recentRectified_[1] = recentRectified_[2];
  recentRectified_[2] = rectified;
  if (recentRectifiedCount_ < 3) {
    recentRectifiedCount_++;
  }

  uint16_t median = rectified;
  if (recentRectifiedCount_ == 3) {
    uint16_t a = recentRectified_[0];
    uint16_t b = recentRectified_[1];
    uint16_t c = recentRectified_[2];
    if (a > b) {
      uint16_t t = a;
      a = b;
      b = t;
    }
    if (b > c) {
      uint16_t t = b;
      b = c;
      c = t;
    }
    if (a > b) {
      uint16_t t = a;
      a = b;
      b = t;
    }
    median = b;
  }

  switch (config_.filterMode) {
    case PiezoFilterModeV2::None:
      return rectified;
    case PiezoFilterModeV2::AttackPreservingMean3:
      if (recentRectifiedCount_ == 3) {
        const uint16_t mean3 = static_cast<uint16_t>((recentRectified_[0] + recentRectified_[1] + recentRectified_[2]) / 3U);
        if (rectified > mean3 + config_.attackPreserveDeltaRaw && slope > static_cast<int16_t>(config_.startSlopeMinRaw)) {
          return rectified;
        }
        return mean3;
      }
      return rectified;
    case PiezoFilterModeV2::AttackPreservingMedian3:
    default:
      if (rectified > median + config_.attackPreserveDeltaRaw && slope > static_cast<int16_t>(config_.startSlopeMinRaw)) {
        return rectified;
      }
      return median;
  }
}

uint16_t PiezoDetectorV2::computeStartThresholdRaw() const {
  const uint16_t dynamicNoise = static_cast<uint16_t>(lroundf(noiseRaw_ * config_.noiseScale));
  uint16_t threshold = config_.thresholdFloorRaw;
  threshold = max<uint16_t>(threshold, static_cast<uint16_t>(config_.deadbandRaw + 2U));
  threshold = max<uint16_t>(threshold, static_cast<uint16_t>(dynamicNoise + config_.thresholdOffsetRaw));
  return threshold;
}

uint16_t PiezoDetectorV2::computeReleaseThresholdRaw(uint16_t lastPeakRaw, uint16_t thresholdStartRaw) const {
  const uint16_t proportional = static_cast<uint16_t>(lroundf(static_cast<float>(lastPeakRaw) * config_.releaseRatio));
  const uint16_t scaledStart = static_cast<uint16_t>(lroundf(static_cast<float>(thresholdStartRaw) * 0.55f));
  return max<uint16_t>(config_.releaseFloorRaw, min<uint16_t>(proportional, scaledStart));
}

uint8_t PiezoDetectorV2::mapVelocity(uint16_t scanPeakRaw, uint16_t thresholdStartRaw) const {
  const int above = max<int>(0, static_cast<int>(scanPeakRaw) - static_cast<int>(thresholdStartRaw));
  const int minAbove = max<int>(1, config_.velocityMinAboveThresholdRaw);
  const int refAbove = max<int>(minAbove + 1, config_.velocityRefAboveThresholdRaw);
  const float normalized = constrain(static_cast<float>(above - minAbove) / static_cast<float>(refAbove - minAbove), 0.0f, 1.0f);
  const float curved = powf(normalized, config_.velocityGamma);
  const float span = static_cast<float>(config_.velocityMaxMidi - config_.velocityMinMidi);
  const float mapped = static_cast<float>(config_.velocityMinMidi) + curved * span;
  return static_cast<uint8_t>(constrain(static_cast<int>(lroundf(mapped)), 1, 127));
}

bool PiezoDetectorV2::updateSample(uint16_t raw, uint32_t nowUs) {
  const int16_t centered = static_cast<int16_t>(lroundf(static_cast<float>(raw) - baselineRaw_));
  const int16_t signedRaw = centered;
  const uint16_t rectified = rectifiedByPolarity(centered);
  const int16_t slope = static_cast<int16_t>(static_cast<int>(rectified) - static_cast<int>(stats_.rectifiedRaw));
  const uint16_t filtered = applyAttackPreservingFilter(rectified, slope);
  const uint16_t thresholdStart = computeStartThresholdRaw();

  // Quiet-only baseline and noise tracking.
  if (stats_.state == PiezoStateV2::Idle && filtered < thresholdStart) {
    baselineRaw_ += config_.baselineAlphaQuiet * (static_cast<float>(raw) - baselineRaw_);
    noiseRaw_ += config_.noiseAlphaQuiet * (static_cast<float>(filtered) - noiseRaw_);
  }

  envelopeRaw_ = max(static_cast<float>(filtered), envelopeRaw_ * config_.envDecay);
  const uint16_t envelope = static_cast<uint16_t>(lroundf(envelopeRaw_));
  const uint16_t thresholdRelease = computeReleaseThresholdRaw(stats_.lastPeakRaw, thresholdStart);

  stats_.centeredRaw = centered;
  stats_.signedRaw = signedRaw;
  stats_.rectifiedRaw = rectified;
  stats_.filteredRaw = filtered;
  stats_.envelopeRaw = envelope;
  stats_.noiseRaw = static_cast<uint16_t>(lroundf(noiseRaw_));
  stats_.thresholdStartRaw = thresholdStart;
  stats_.thresholdReleaseRaw = thresholdRelease;
  stats_.slopeRaw = slope;

  bool committed = false;

  switch (stats_.state) {
    case PiezoStateV2::Idle:
      if (filtered >= thresholdStart && slope >= static_cast<int16_t>(config_.startSlopeMinRaw)) {
        stats_.state = PiezoStateV2::Scan;
        scanStartedUs_ = nowUs;
        scanPeakRaw_ = filtered;
      } else if (filtered >= thresholdStart) {
        stats_.startRejects++;
      }
      break;

    case PiezoStateV2::Scan: {
      scanPeakRaw_ = max<uint16_t>(scanPeakRaw_, filtered);
      const uint32_t elapsedUs = nowUs - scanStartedUs_;
      const bool minElapsed = elapsedUs >= msToUs(config_.scanMinMs);
      const bool timedOut = elapsedUs >= msToUs(config_.scanMaxMs);
      const bool localFall = minElapsed && slope <= 0 && filtered <= thresholdStart;
      if (timedOut || localFall) {
        stats_.lastPeakRaw = scanPeakRaw_;
        stats_.lastVelocity = mapVelocity(scanPeakRaw_, thresholdStart);
        stats_.hits++;
        stats_.state = PiezoStateV2::Mask;
        maskUntilUs_ = nowUs + msToUs(config_.maskMs);
        quietStartedUs_ = 0;
        committed = true;
      }
      break;
    }

    case PiezoStateV2::Mask:
      if (nowUs >= maskUntilUs_) {
        stats_.state = PiezoStateV2::Rearm;
      } else if (filtered >= thresholdStart) {
        stats_.maskRejects++;
      }
      break;

    case PiezoStateV2::Rearm:
      if (filtered <= thresholdRelease) {
        if (quietStartedUs_ == 0) {
          quietStartedUs_ = nowUs;
        }
        if (nowUs - quietStartedUs_ >= msToUs(config_.rearmQuietMs)) {
          stats_.state = PiezoStateV2::Idle;
          quietStartedUs_ = 0;
        }
      } else {
        quietStartedUs_ = 0;
        const bool fastRetrigger = (nowUs >= maskUntilUs_ + msToUs(config_.fastRetriggerMinMs)) &&
                                   filtered >= thresholdStart &&
                                   slope >= static_cast<int16_t>(config_.fastRetriggerSlopeMinRaw);
        if (fastRetrigger) {
          stats_.state = PiezoStateV2::Scan;
          scanStartedUs_ = nowUs;
          scanPeakRaw_ = filtered;
        } else if (filtered >= thresholdStart) {
          stats_.rearmRejects++;
        }
      }
      break;
  }

  stats_.scanPeakRaw = scanPeakRaw_;
  return committed;
}

const PiezoDetectorConfigV2& PiezoDetectorV2::config() const {
  return config_;
}

const PiezoLiveStatsV2& PiezoDetectorV2::stats() const {
  return stats_;
}

}  // namespace idrm
