#pragma once

#include <Arduino.h>

namespace idrm {

// Pseudocode header for the next detector generation.
// Comments are intentionally brief and in English so the file can be used as
// a coding scaffold for Codex.

enum class PiezoPolarityMode : uint8_t {
  Auto = 0,
  Positive = 1,
  Negative = 2,
  Absolute = 3,
};

enum class PiezoFilterModeV2 : uint8_t {
  None = 0,
  AttackPreservingMedian3 = 1,
  AttackPreservingMean3 = 2,
};

enum class PiezoStateV2 : uint8_t {
  Idle = 0,
  Scan = 1,
  Mask = 2,
  Rearm = 3,
};

struct PiezoUnits {
  uint8_t adcAttenDb {11};
  float fullScaleMv {3900.0f};
};

struct PiezoDetectorConfigV2 {
  bool enabled {true};
  int8_t pin {32};
  uint16_t sampleRateHz {12000};

  PiezoPolarityMode polarityMode {PiezoPolarityMode::Auto};
  PiezoFilterModeV2 filterMode {PiezoFilterModeV2::AttackPreservingMedian3};

  float baselineAlphaQuiet {0.002f};
  float envDecay {0.965f};
  float noiseAlphaQuiet {0.01f};

  uint16_t deadbandRaw {12};
  uint16_t thresholdFloorRaw {16};
  uint16_t thresholdOffsetRaw {6};
  float noiseScale {1.8f};

  uint16_t startSlopeMinRaw {6};
  uint16_t attackPreserveDeltaRaw {5};

  float scanMinMs {0.8f};
  float scanMaxMs {1.8f};
  float maskMs {2.4f};
  float rearmQuietMs {0.35f};

  float releaseRatio {0.42f};
  uint16_t releaseFloorRaw {8};
  float fastRetriggerMinMs {3.0f};
  uint16_t fastRetriggerSlopeMinRaw {10};

  uint16_t velocityMinAboveThresholdRaw {6};
  uint16_t velocityRefAboveThresholdRaw {120};
  float velocityGamma {0.72f};
  uint8_t velocityMinMidi {1};
  uint8_t velocityMaxMidi {127};
};

struct PiezoCalibrationSummary {
  uint8_t resolvedPolaritySign {1};
  uint16_t quietP95Raw {0};
  uint16_t quietP99Raw {0};
  uint16_t gentleP50PeakRaw {0};
  uint16_t gentleP90PeakRaw {0};
  uint16_t mediumP90PeakRaw {0};
  uint16_t hardP90PeakRaw {0};
};

struct PiezoLiveStatsV2 {
  PiezoStateV2 state {PiezoStateV2::Idle};
  int16_t centeredRaw {0};
  int16_t signedRaw {0};
  uint16_t rectifiedRaw {0};
  uint16_t filteredRaw {0};
  uint16_t envelopeRaw {0};
  uint16_t noiseRaw {0};
  uint16_t thresholdStartRaw {0};
  uint16_t thresholdReleaseRaw {0};
  int16_t slopeRaw {0};
  uint16_t scanPeakRaw {0};
  uint16_t lastPeakRaw {0};
  uint8_t lastVelocity {0};
  uint8_t polaritySign {1};
  uint32_t hits {0};
  uint32_t startRejects {0};
  uint32_t rearmRejects {0};
  uint32_t maskRejects {0};
};

class PiezoDetectorV2 {
 public:
  void reset(uint16_t baselineRaw = 0);
  void applyConfig(const PiezoDetectorConfigV2& config);
  void applyCalibration(const PiezoCalibrationSummary& calibration);

  bool updateSample(uint16_t raw, uint32_t nowUs);

  const PiezoDetectorConfigV2& config() const;
  const PiezoLiveStatsV2& stats() const;

 private:
  uint16_t rectifiedByPolarity(int16_t centered) const;
  uint16_t applyAttackPreservingFilter(uint16_t rectified, int16_t slope);
  uint8_t mapVelocity(uint16_t scanPeakRaw, uint16_t thresholdStartRaw) const;
  uint16_t computeStartThresholdRaw() const;
  uint16_t computeReleaseThresholdRaw(uint16_t lastPeakRaw, uint16_t thresholdStartRaw) const;

  PiezoDetectorConfigV2 config_ {};
  PiezoCalibrationSummary calibration_ {};
  PiezoLiveStatsV2 stats_ {};

  float baselineRaw_ {0.0f};
  float envelopeRaw_ {0.0f};
  float noiseRaw_ {0.0f};

  uint16_t recentRectified_[3] {};
  uint8_t recentRectifiedCount_ {0};

  uint16_t scanPeakRaw_ {0};
  uint32_t scanStartedUs_ {0};
  uint32_t maskUntilUs_ {0};
  uint32_t quietStartedUs_ {0};
};

}  // namespace idrm
