using System.Text.Json;
using MusicNotation.Editor.Services;
using Zyphonote.InvisibleDrums.Protocol;

namespace App.Blazor.Services;

public sealed class InvisibleDrumsSessionService : IDisposable
{
    private const int MaxDiagnosticsEntries = 250;
    private static readonly string[] GroupRoles = ["ls", "rs", "lf", "rf"];

    private readonly IMidiService midiService;
    private readonly IdrmMidiTransportAdapter transport;
    private readonly SemaphoreSlim gate = new(1, 1);
    private readonly object sync = new();
    private readonly List<MidiPortInfo> ports = [];
    private readonly List<InvisibleDrumsLogEntry> diagnostics = [];
    private readonly IdrmRequestOptions requestOptions = IdrmRequestOptions.Default;

    private Dictionary<string, ModuleHandle> modulesByKey = new(StringComparer.Ordinal);
    private bool busy;
    private bool disposed;
    private string? lastError;
    private string? selectedModuleKey;

    public InvisibleDrumsSessionService(IMidiService midiService)
    {
        this.midiService = midiService ?? throw new ArgumentNullException(nameof(midiService));
        transport = new IdrmMidiTransportAdapter(this.midiService);
        this.midiService.RawMessageReceived += HandleRawMidiMessage;
        this.midiService.PortsChanged += HandlePortsChanged;
    }

    public event Action? Changed;

    public bool IsBusy
    {
        get
        {
            lock (sync)
            {
                return busy;
            }
        }
    }

    public string? LastError
    {
        get
        {
            lock (sync)
            {
                return lastError;
            }
        }
    }

    public bool IsSupported => midiService.IsSupported;
    public bool IsInitialized => midiService.IsInitialized;
    public bool IsSysExEnabled => midiService.IsSysExEnabled;
    public MidiInitializationStatus InitializationStatus => midiService.InitializationStatus;
    public string? InitializationError => midiService.LastInitializationError;

    public IReadOnlyList<MidiPortInfo> AvailablePorts
    {
        get
        {
            lock (sync)
            {
                return ports.ToArray();
            }
        }
    }

    public IReadOnlyCollection<string> SubscribedInputIds => midiService.ConnectedInputIds;

    public IReadOnlyList<InvisibleDrumsDiscoveredModule> DiscoveredModules
    {
        get
        {
            lock (sync)
            {
                return modulesByKey.Values
                    .Select(ModuleHandle.ToView)
                    .OrderBy(module => module.Role, StringComparer.OrdinalIgnoreCase)
                    .ThenBy(module => module.ModuleUid, StringComparer.Ordinal)
                    .ToArray();
            }
        }
    }

    public string? SelectedModuleKey
    {
        get
        {
            lock (sync)
            {
                return selectedModuleKey;
            }
        }
    }

    public InvisibleDrumsDiscoveredModule? SelectedModule
    {
        get
        {
            lock (sync)
            {
                if (selectedModuleKey is null || !modulesByKey.TryGetValue(selectedModuleKey, out var handle))
                {
                    return null;
                }

                return ModuleHandle.ToView(handle);
            }
        }
    }

    public IReadOnlyList<InvisibleDrumsLogEntry> DiagnosticsLog
    {
        get
        {
            lock (sync)
            {
                return diagnostics.ToArray();
            }
        }
    }

    public void ClearDiagnosticsLog()
    {
        lock (sync)
        {
            diagnostics.Clear();
        }

        NotifyChanged();
    }

    public IReadOnlyList<string> MissingRoles
    {
        get
        {
            lock (sync)
            {
                var knownRoles = modulesByKey.Values
                    .Select(module => module.Binding.Role)
                    .Where(role => !string.IsNullOrWhiteSpace(role))
                    .Select(role => role!.Trim().ToLowerInvariant())
                    .ToHashSet(StringComparer.Ordinal);

                return GroupRoles.Where(role => !knownRoles.Contains(role)).ToArray();
            }
        }
    }

    public IReadOnlyList<string> DuplicateRoles
    {
        get
        {
            lock (sync)
            {
                return modulesByKey.Values
                    .GroupBy(
                        module => string.IsNullOrWhiteSpace(module.Binding.Role)
                            ? string.Empty
                            : module.Binding.Role.Trim().ToLowerInvariant(),
                        StringComparer.Ordinal)
                    .Where(group => group.Count() > 1 && !string.IsNullOrWhiteSpace(group.Key))
                    .Select(group => group.Key)
                    .OrderBy(role => role, StringComparer.Ordinal)
                    .ToArray();
            }
        }
    }

    public void SelectModule(string? moduleKey)
    {
        lock (sync)
        {
            if (string.IsNullOrWhiteSpace(moduleKey))
            {
                selectedModuleKey = null;
            }
            else if (modulesByKey.ContainsKey(moduleKey))
            {
                selectedModuleKey = moduleKey;
            }
        }

        NotifyChanged();
    }

    public Task<bool> InitializeMidiWithSysExAsync(CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Initialize MIDI + SysEx",
            async () =>
            {
                await midiService.InitializeWithSysExAsync().ConfigureAwait(false);
                AddDiagnostic("info", "MIDI initialized with SysEx support.");
                return true;
            },
            cancellationToken);
    }

    public Task<bool> InitializeMidiAsync(CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Initialize MIDI",
            async () =>
            {
                await midiService.InitializeAsync().ConfigureAwait(false);
                AddDiagnostic("info", "MIDI initialized without SysEx request.");
                return true;
            },
            cancellationToken);
    }

    public Task<bool> RefreshPortsAsync(CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Refresh ports",
            async () =>
            {
                var refreshed = await midiService.GetPortsAsync().ConfigureAwait(false);
                lock (sync)
                {
                    ports.Clear();
                    ports.AddRange(refreshed);
                }

                AddDiagnostic("info", $"Port refresh completed: {refreshed.Count} total.");
                return true;
            },
            cancellationToken);
    }

    public Task<bool> SubscribeCandidateInputsAsync(bool preferIdrmPrefix = true, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Subscribe candidate inputs",
            async () =>
            {
                var selectedInputs = SelectInputCandidates(preferIdrmPrefix);
                if (selectedInputs.Count == 0)
                {
                    AddDiagnostic("warn", "No input ports available to subscribe.");
                    return false;
                }

                await midiService.ConnectInputsAsync(selectedInputs.Select(port => port.Id)).ConfigureAwait(false);
                AddDiagnostic(
                    "info",
                    $"Subscribed to {selectedInputs.Count} inputs: {string.Join(", ", selectedInputs.Select(port => port.Name))}");
                return true;
            },
            cancellationToken);
    }

    public Task<bool> SubscribeInputsAsync(IEnumerable<string> inputPortIds, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Subscribe selected inputs",
            async () =>
            {
                var ids = inputPortIds
                    .Where(id => !string.IsNullOrWhiteSpace(id))
                    .Distinct(StringComparer.Ordinal)
                    .ToArray();
                if (ids.Length == 0)
                {
                    AddDiagnostic("warn", "No input ids supplied for subscription.");
                    return false;
                }

                await midiService.ConnectInputsAsync(ids).ConfigureAwait(false);
                AddDiagnostic("info", $"Subscribed inputs: {string.Join(", ", ids)}");
                return true;
            },
            cancellationToken);
    }

    public Task<bool> ClearInputSubscriptionsAsync(CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Clear input subscriptions",
            async () =>
            {
                await midiService.DisconnectInputAsync().ConfigureAwait(false);
                AddDiagnostic("info", "All MIDI input subscriptions were cleared.");
                return true;
            },
            cancellationToken);
    }

    public Task<bool> DiscoverModulesAsync(bool preferIdrmPrefix = true, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Discover modules",
            async () =>
            {
                await transport.InitializeAsync(requestSysEx: true, cancellationToken).ConfigureAwait(false);
                var groupClient = new IdrmGroupClient(transport, requestOptions);
                var discoveredBindings = await groupClient
                    .DiscoverBindingsAsync(
                        preferIdrmPrefix,
                        trace: message => AddDiagnostic("trace", $"DISC {message}"),
                        cancellationToken: cancellationToken)
                    .ConfigureAwait(false);

                IReadOnlyList<IdrmPortBinding> bindings = discoveredBindings;
                if (bindings.Count == 0)
                {
                    var provisionalBindings = await BuildProvisionalBindingsAsync(cancellationToken).ConfigureAwait(false);
                    if (provisionalBindings.Count > 0)
                    {
                        bindings = provisionalBindings;
                        AddDiagnostic(
                            "warn",
                            $"Discovery fallback active: created {bindings.Count} provisional binding(s) from MIDI ports.");
                    }
                }

                var clients = groupClient.CreateDeviceClients(bindings).ToArray();

                var next = new Dictionary<string, ModuleHandle>(StringComparer.Ordinal);
                for (var i = 0; i < bindings.Count; i++)
                {
                    if (clients[i] is not IdrmDeviceClient deviceClient)
                    {
                        continue;
                    }

                    var handle = new ModuleHandle(bindings[i], deviceClient)
                    {
                        LastSeenUtc = DateTimeOffset.UtcNow
                    };
                    next[handle.Key] = handle;
                }

                Dictionary<string, ModuleHandle> previous;
                lock (sync)
                {
                    previous = modulesByKey;
                    modulesByKey = next;

                    if (selectedModuleKey is null || !modulesByKey.ContainsKey(selectedModuleKey))
                    {
                        selectedModuleKey = modulesByKey.Keys.FirstOrDefault();
                    }
                }

                foreach (var handle in previous.Values)
                {
                    handle.Dispose();
                }

                AddDiagnostic("info", $"Discovery completed. Bound modules: {next.Count}.");
                return true;
            },
            cancellationToken);
    }

    public Task<string?> PingModuleAsync(string? moduleKey = null, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Ping module",
            async () =>
            {
                var module = RequireModule(moduleKey);
                using var response = await module.Client.PingAsync(cancellationToken).ConfigureAwait(false);
                var payload = response.RootElement.GetRawText();
                module.LastPingPayload = payload;
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic("info", $"Ping response from {module.Binding.ModuleUid}: {payload}");
                return payload;
            },
            cancellationToken);
    }

    public Task<string?> GetConfigAsync(string? moduleKey = null, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Get config",
            async () =>
            {
                var module = RequireModule(moduleKey);
                var configJson = await module.Client.GetConfigJsonAsync(cancellationToken).ConfigureAwait(false);
                module.LastConfigJson = configJson;
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic("info", $"Config loaded from {module.Binding.ModuleUid}.");
                return configJson;
            },
            cancellationToken);
    }

    public Task<bool> SetConfigAsync(string asciiJson, bool apply, string? moduleKey = null, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Set config",
            async () =>
            {
                var module = RequireModule(moduleKey);
                await module.Client.SetConfigJsonAsync(asciiJson, apply, cancellationToken).ConfigureAwait(false);
                module.LastConfigJson = asciiJson;
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic("info", $"Config staged on {module.Binding.ModuleUid} (apply={(apply ? 1 : 0)}).");
                return true;
            },
            cancellationToken);
    }

    public Task<bool> SaveConfigAsync(string? moduleKey = null, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Save config",
            async () =>
            {
                var module = RequireModule(moduleKey);
                await module.Client.SaveConfigAsync(cancellationToken).ConfigureAwait(false);
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic("info", $"Config saved on {module.Binding.ModuleUid}.");
                return true;
            },
            cancellationToken);
    }

    public Task<bool> CalibrateModuleAsync(
        ushort delayMs,
        ushort windowMs,
        string? moduleKey = null,
        CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Calibrate module",
            async () =>
            {
                var module = RequireModule(moduleKey);
                using var response = await module.Client
                    .CalibrateAsync(delayMs, windowMs, cancellationToken)
                    .ConfigureAwait(false);
                module.LastCalibrationPayload = response.RootElement.GetRawText();
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic("info", $"Calibration completed for {module.Binding.ModuleUid}: {module.LastCalibrationPayload}");
                return true;
            },
            cancellationToken);
    }

    public async Task<IReadOnlyList<IdrmGroupOperationResult>> CalibrateGroupAsync(
        ushort delayMs,
        ushort windowMs,
        CancellationToken cancellationToken = default)
    {
        return await ExecuteAsync(
            "Calibrate group",
            async () =>
            {
                var groupClient = new IdrmGroupClient(transport, requestOptions);
                var modules = SnapshotModuleClients();
                if (modules.Count == 0)
                {
                    AddDiagnostic("warn", "Group calibration requested without discovered modules.");
                    return Array.Empty<IdrmGroupOperationResult>();
                }

                // Calibrate from a known disarmed state to reduce false triggers during the calibration window.
                _ = await groupClient.ArmGroupAsync(modules, armed: false, cancellationToken).ConfigureAwait(false);
                var results = await groupClient.CalibrateGroupAsync(modules, delayMs, windowMs, cancellationToken).ConfigureAwait(false);
                AddDiagnostic("info", $"Group calibration finished. Success={results.Count(result => result.Ok)}/{results.Count}.");
                return results;
            },
            cancellationToken).ConfigureAwait(false) ?? Array.Empty<IdrmGroupOperationResult>();
    }

    public Task<bool> SetArmedAsync(bool armed, string? moduleKey = null, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            armed ? "Arm module" : "Disarm module",
            async () =>
            {
                var module = RequireModule(moduleKey);
                await module.Client.SetArmedAsync(armed, cancellationToken).ConfigureAwait(false);
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic("info", $"{(armed ? "Armed" : "Disarmed")} module {module.Binding.ModuleUid}.");
                return true;
            },
            cancellationToken);
    }

    public async Task<IReadOnlyList<IdrmGroupOperationResult>> SetGroupArmedAsync(bool armed, CancellationToken cancellationToken = default)
    {
        return await ExecuteAsync(
            armed ? "Arm group" : "Disarm group",
            async () =>
            {
                var groupClient = new IdrmGroupClient(transport, requestOptions);
                var modules = SnapshotModuleClients();
                if (modules.Count == 0)
                {
                    AddDiagnostic("warn", "Group arm/disarm requested without discovered modules.");
                    return Array.Empty<IdrmGroupOperationResult>();
                }

                var results = await groupClient.ArmGroupAsync(modules, armed, cancellationToken).ConfigureAwait(false);
                AddDiagnostic("info", $"Group {(armed ? "arm" : "disarm")} finished. Success={results.Count(result => result.Ok)}/{results.Count}.");
                return results;
            },
            cancellationToken).ConfigureAwait(false) ?? Array.Empty<IdrmGroupOperationResult>();
    }

    public Task<IdrmStatsResponse?> GetStatsAsync(string? moduleKey = null, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Get stats",
            async () =>
            {
                var module = RequireModule(moduleKey);
                var stats = await module.Client.GetStatsAsync(cancellationToken).ConfigureAwait(false);
                module.LastStatsJson = JsonSerializer.Serialize(stats);
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic("info", $"Stats loaded from {module.Binding.ModuleUid}: {module.LastStatsJson}");
                return stats;
            },
            cancellationToken);
    }

    public Task<IdrmMapListResponse?> GetMapListAsync(string? moduleKey = null, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Get IR map list",
            async () =>
            {
                var module = RequireModule(moduleKey);
                var map = await module.Client.GetMapListAsync(cancellationToken).ConfigureAwait(false);
                module.LastConfigJson = JsonSerializer.Serialize(map);
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic("info", $"IR map loaded from {module.Binding.ModuleUid}: slots={map.Slots?.Count ?? 0}.");
                return map;
            },
            cancellationToken);
    }

    public Task<IdrmMapSelectResponse?> MapSelectAsync(
        IdrmMapSelectRequest request,
        string? moduleKey = null,
        CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "IR map assign",
            async () =>
            {
                var module = RequireModule(moduleKey);
                var response = await module.Client.MapSelectAsync(request, cancellationToken).ConfigureAwait(false);
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic(
                    "info",
                    $"IR map assign on {module.Binding.ModuleUid}: beacon={request.Beacon} note={request.Note} pending={response.Pending ?? 0}.");
                return response;
            },
            cancellationToken);
    }

    public Task<IdrmSetFreqResponse?> SetFrequenciesAsync(
        IReadOnlyCollection<ushort> frequenciesHz,
        string? moduleKey = null,
        CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Set IR frequencies",
            async () =>
            {
                var module = RequireModule(moduleKey);
                var response = await module.Client.SetFrequenciesAsync(frequenciesHz, cancellationToken).ConfigureAwait(false);
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic(
                    "info",
                    $"IR frequency bank set on {module.Binding.ModuleUid}: count={response.Count ?? frequenciesHz.Count}.");
                return response;
            },
            cancellationToken);
    }

    public Task<IdrmSetSensitivityResponse?> SetHitSensitivityAsync(
        byte level,
        string? filter = null,
        byte? adcDb = null,
        IReadOnlyDictionary<string, object?>? advanced = null,
        bool resetPiezoTune = false,
        string? moduleKey = null,
        CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Set hit sensitivity",
            async () =>
            {
                var module = RequireModule(moduleKey);
                var response = await module.Client
                    .SetSensitivityAsync(level, filter, adcDb, advanced, resetPiezoTune, cancellationToken)
                    .ConfigureAwait(false);
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                var advancedSuffix = advanced is { Count: > 0 }
                    ? $", advanced={advanced.Count}"
                    : string.Empty;
                AddDiagnostic(
                    "info",
                    $"Hit sensitivity set on {module.Binding.ModuleUid}: level={response.Level ?? level}, " +
                    $"filter={response.Filter ?? filter ?? "n/a"}, adc_db={response.AdcAttenuationDb?.ToString() ?? (adcDb?.ToString() ?? "n/a")}{advancedSuffix}.");
                return response;
            },
            cancellationToken);
    }

    public Task<bool> FactoryResetAsync(string? moduleKey = null, CancellationToken cancellationToken = default)
    {
        return ExecuteAsync(
            "Factory reset",
            async () =>
            {
                var module = RequireModule(moduleKey);
                await module.Client.FactoryResetAsync(cancellationToken).ConfigureAwait(false);
                module.LastSeenUtc = DateTimeOffset.UtcNow;
                AddDiagnostic("warn", $"Factory reset requested for {module.Binding.ModuleUid}.");
                return true;
            },
            cancellationToken);
    }

    private async Task<T?> ExecuteAsync<T>(
        string operationName,
        Func<Task<T>> action,
        CancellationToken cancellationToken)
    {
        await gate.WaitAsync(cancellationToken).ConfigureAwait(false);
        lock (sync)
        {
            busy = true;
            lastError = null;
        }

        NotifyChanged();

        try
        {
            return await action().ConfigureAwait(false);
        }
        catch (OperationCanceledException) when (cancellationToken.IsCancellationRequested)
        {
            AddDiagnostic("warn", $"{operationName} canceled.");
            throw;
        }
        catch (Exception exception)
        {
            lock (sync)
            {
                lastError = $"{operationName}: {exception.Message}";
            }

            AddDiagnostic("error", $"{operationName} failed: {exception.Message}");
            return default;
        }
        finally
        {
            lock (sync)
            {
                busy = false;
            }

            gate.Release();
            NotifyChanged();
        }
    }

    private IReadOnlyList<MidiPortInfo> SelectInputCandidates(bool preferIdrmPrefix)
    {
        var allInputs = AvailablePorts
            .Where(port => port.Direction == MidiPortDirection.Input)
            .ToArray();
        if (!preferIdrmPrefix)
        {
            return allInputs;
        }

        var preferred = allInputs
            .Where(IsIdrmNamedPort)
            .ToArray();
        return preferred.Length > 0 ? preferred : allInputs;
    }

    private static bool IsIdrmNamedPort(MidiPortInfo port)
    {
        return port.Name.StartsWith("IDRM-", StringComparison.OrdinalIgnoreCase);
    }

    private async Task<IReadOnlyList<IdrmPortBinding>> BuildProvisionalBindingsAsync(CancellationToken cancellationToken)
    {
        var ports = await transport.GetPortsAsync(cancellationToken).ConfigureAwait(false);
        var allInputs = ports.Where(port => port.Direction == IdrmPortDirection.Input).ToArray();
        var allOutputs = ports.Where(port => port.Direction == IdrmPortDirection.Output).ToArray();
        if (allInputs.Length == 0 || allOutputs.Length == 0)
        {
            return Array.Empty<IdrmPortBinding>();
        }

        var likelyOutputs = allOutputs.Where(IsLikelyIdrmPort).ToArray();
        if (likelyOutputs.Length == 0)
        {
            return Array.Empty<IdrmPortBinding>();
        }

        var likelyInputs = allInputs.Where(IsLikelyIdrmPort).ToArray();
        var bindings = new List<IdrmPortBinding>(likelyOutputs.Length);
        foreach (var output in likelyOutputs)
        {
            var input = allInputs.FirstOrDefault(candidate => string.Equals(candidate.Id, output.Id, StringComparison.Ordinal))
                        ?? likelyInputs.FirstOrDefault(candidate => NamesLikelyMatch(candidate.Name, output.Name))
                        ?? likelyInputs.FirstOrDefault()
                        ?? allInputs.FirstOrDefault();

            if (input is null)
            {
                continue;
            }

            var moduleUidSeed = string.IsNullOrWhiteSpace(output.Id) ? output.Name : output.Id;
            moduleUidSeed ??= "idrm_prov";
            var moduleUid = $"prov_{moduleUidSeed}"
                .Replace('|', '_')
                .Replace(' ', '_');

            bindings.Add(
                new IdrmPortBinding(
                    InputPortId: input.Id,
                    OutputPortId: output.Id,
                    ModuleUid: moduleUid,
                    Role: "unknown",
                    DeviceName: string.IsNullOrWhiteSpace(output.Name) ? "IDRM provisional" : output.Name,
                    FirmwareVersion: "unknown",
                    Board: "unknown",
                    Caps: ["provisional_binding"]));
        }

        return bindings
            .GroupBy(binding => new { binding.InputPortId, binding.OutputPortId, binding.ModuleUid })
            .Select(group => group.First())
            .ToArray();
    }

    private static bool IsLikelyIdrmPort(IdrmPortInfo port)
    {
        if (port is null)
        {
            return false;
        }

        if (string.Equals(port.Id, "__idrm_ble_midi__", StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        var name = port.Name ?? string.Empty;
        return name.StartsWith("IDRM-", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("IDRM", StringComparison.OrdinalIgnoreCase) ||
               name.Contains("BLE", StringComparison.OrdinalIgnoreCase);
    }

    private static bool NamesLikelyMatch(string? left, string? right)
    {
        if (string.IsNullOrWhiteSpace(left) || string.IsNullOrWhiteSpace(right))
        {
            return false;
        }

        var leftTrimmed = left.Trim();
        var rightTrimmed = right.Trim();
        return string.Equals(leftTrimmed, rightTrimmed, StringComparison.OrdinalIgnoreCase) ||
               leftTrimmed.Contains(rightTrimmed, StringComparison.OrdinalIgnoreCase) ||
               rightTrimmed.Contains(leftTrimmed, StringComparison.OrdinalIgnoreCase);
    }

    private ModuleHandle RequireModule(string? moduleKey)
    {
        lock (sync)
        {
            var resolvedKey = string.IsNullOrWhiteSpace(moduleKey) ? selectedModuleKey : moduleKey;
            if (resolvedKey is null || !modulesByKey.TryGetValue(resolvedKey, out var module))
            {
                throw new IdrmProtocolException("No module selected.");
            }

            return module;
        }
    }

    private IReadOnlyList<IdrmDeviceClient> SnapshotModuleClients()
    {
        lock (sync)
        {
            return modulesByKey.Values
                .Select(module => module.Client)
                .ToArray();
        }
    }

    private void HandleRawMidiMessage(object? sender, RawMidiMessage message)
    {
        if (disposed || message.Data is null || message.Data.Count == 0)
        {
            return;
        }

        var bytes = message.Data.ToArray();
        if (!IsLikelyIdrmSysEx(bytes))
        {
            return;
        }

        if (!IdrmProtocolCodec.TryParseFrame(bytes, out var frame, out var parseError))
        {
            AddDiagnostic("warn", $"RX invalid SysEx from {message.InputId ?? "(unknown)"}: {parseError}");
            return;
        }

        if (!string.IsNullOrWhiteSpace(message.InputId))
        {
            lock (sync)
            {
                foreach (var module in modulesByKey.Values.Where(module =>
                             string.Equals(module.Binding.InputPortId, message.InputId, StringComparison.Ordinal)))
                {
                    module.LastSeenUtc = DateTimeOffset.UtcNow;
                }
            }
        }

        var chunkCount = frame.ChunkCount < 1 ? 1 : frame.ChunkCount;
        var prefix = $"RX {frame.Type} seq={frame.Sequence} chunk={frame.ChunkIndex + 1}/{chunkCount}";
        if (frame.Type == IdrmMsgType.Nack)
        {
            AddDiagnostic("warn", $"{prefix} payload={TrimForLog(frame.Payload)}");
        }
        else
        {
            AddDiagnostic("trace", $"{prefix} payloadLen={frame.Payload.Length}");
        }
    }

    private void HandlePortsChanged(object? sender, EventArgs e)
    {
        _ = RefreshPortsAsync(CancellationToken.None);
    }

    private static bool IsLikelyIdrmSysEx(IReadOnlyList<byte> data)
    {
        return data.Count >= 7 &&
               data[0] == 0xF0 &&
               data[^1] == 0xF7 &&
               data[1] == IdrmProtocolConstants.ManufacturerId &&
               data[2] == (byte)'I' &&
               data[3] == (byte)'D' &&
               data[4] == (byte)'R' &&
               data[5] == (byte)'M';
    }

    private static string TrimForLog(string payload, int max = 80)
    {
        if (payload.Length <= max)
        {
            return payload;
        }

        return payload[..max] + "...";
    }

    private void AddDiagnostic(string level, string message)
    {
        lock (sync)
        {
            diagnostics.Add(new InvisibleDrumsLogEntry(DateTimeOffset.UtcNow, level, message));
            if (diagnostics.Count > MaxDiagnosticsEntries)
            {
                diagnostics.RemoveRange(0, diagnostics.Count - MaxDiagnosticsEntries);
            }
        }

        NotifyChanged();
    }

    private void NotifyChanged()
    {
        Changed?.Invoke();
    }

    public void Dispose()
    {
        if (disposed)
        {
            return;
        }

        disposed = true;
        midiService.RawMessageReceived -= HandleRawMidiMessage;
        midiService.PortsChanged -= HandlePortsChanged;
        gate.Dispose();
        transport.Dispose();

        ModuleHandle[] modulesToDispose;
        lock (sync)
        {
            modulesToDispose = modulesByKey.Values.ToArray();
            modulesByKey.Clear();
        }

        foreach (var module in modulesToDispose)
        {
            module.Dispose();
        }
    }

    private sealed class ModuleHandle : IDisposable
    {
        public ModuleHandle(IdrmPortBinding binding, IdrmDeviceClient client)
        {
            Binding = binding;
            Client = client;
            Key = $"{binding.ModuleUid}|{binding.InputPortId}|{binding.OutputPortId}";
        }

        public string Key { get; }
        public IdrmPortBinding Binding { get; }
        public IdrmDeviceClient Client { get; }
        public DateTimeOffset LastSeenUtc { get; set; } = DateTimeOffset.UtcNow;
        public string? LastConfigJson { get; set; }
        public string? LastStatsJson { get; set; }
        public string? LastPingPayload { get; set; }
        public string? LastCalibrationPayload { get; set; }

        public static InvisibleDrumsDiscoveredModule ToView(ModuleHandle handle)
        {
            return new InvisibleDrumsDiscoveredModule(
                Key: handle.Key,
                ModuleUid: handle.Binding.ModuleUid,
                Role: handle.Binding.Role,
                DeviceName: handle.Binding.DeviceName,
                FirmwareVersion: handle.Binding.FirmwareVersion,
                Board: handle.Binding.Board,
                InputPortId: handle.Binding.InputPortId,
                OutputPortId: handle.Binding.OutputPortId,
                LastSeenUtc: handle.LastSeenUtc,
                LastConfigJson: handle.LastConfigJson,
                LastStatsJson: handle.LastStatsJson,
                LastPingPayload: handle.LastPingPayload,
                LastCalibrationPayload: handle.LastCalibrationPayload,
                HitSource: handle.Binding.HitSource,
                Battery: handle.Binding.Battery,
                BatteryAvailable: handle.Binding.BatteryAvailable,
                PiezoPin: handle.Binding.PiezoPin,
                PiezoPreset: handle.Binding.PiezoPreset,
                Caps: handle.Binding.Caps);
        }

        public void Dispose()
        {
            Client.Dispose();
        }
    }
}

public sealed record InvisibleDrumsDiscoveredModule(
    string Key,
    string ModuleUid,
    string Role,
    string DeviceName,
    string FirmwareVersion,
    string Board,
    string InputPortId,
    string OutputPortId,
    DateTimeOffset LastSeenUtc,
    string? LastConfigJson,
    string? LastStatsJson,
    string? LastPingPayload,
    string? LastCalibrationPayload,
    string? HitSource,
    int? Battery,
    int? BatteryAvailable,
    int? PiezoPin,
    string? PiezoPreset,
    IReadOnlyList<string>? Caps)
{
    public string DisplayName
    {
        get
        {
            var core = string.IsNullOrWhiteSpace(DeviceName)
                ? $"{Role}|{ModuleUid}"
                : DeviceName;
            return BatteryAvailable == 0 ? $"{core} (BAT --)" : core;
        }
    }
}

public sealed record InvisibleDrumsLogEntry(
    DateTimeOffset TimestampUtc,
    string Level,
    string Message);
