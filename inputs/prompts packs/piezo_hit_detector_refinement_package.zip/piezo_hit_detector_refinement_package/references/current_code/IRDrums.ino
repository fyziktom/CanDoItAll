#include <M5Unified.h>
#include <Preferences.h>
#include <ArduinoJson.h>
#include <Wire.h>
#if defined(ESP32)
#include <driver/gpio.h>
#endif

#include "src/BleMidiBackendEsp32BleMidi.h"
#include "src/Protocol.h"
#include "PiezoHitEngine.h"

using namespace idrm;

namespace {

static constexpr char kFirmwareVersion[] = "0.1.4-irdrums";
static constexpr char kPrefsNamespace[] = "irdrums";

static constexpr uint8_t kMaxBeacons = 24;
static constexpr uint8_t kDefaultBeaconCount = 20;
static constexpr uint16_t kMaxFrameSamples = 256;
static constexpr uint16_t kMinTargetStableMs = 6;
static constexpr float kMinTargetConfidence = 0.24f;
static constexpr uint8_t kSensitivityMinLevel = 1;
static constexpr uint8_t kSensitivityMaxLevel = 20;

static constexpr uint8_t kMaxCatchUpSamples = 96;
static constexpr uint16_t kBusyWaitThresholdUs = 180;
static constexpr uint32_t kIdleYieldIntervalUs = 2000;

static constexpr uint8_t kUiPages = 4;
static constexpr uint32_t kUiRefreshMs = 50;
static constexpr uint32_t kSerialHealthMs = 1000;
static constexpr uint32_t kButtonMultiClickWindowMs = 360;
static constexpr uint8_t kSpectrogramRows = 92;
static constexpr uint8_t kPiezoScopePoints = 76;
static constexpr uint8_t kPiezoScopeFastDecimation = 24;
static constexpr uint8_t kPiezoScopeSlowDecimation = 96;
static constexpr uint16_t kStillnessCalibrationMs = 700;
static constexpr uint16_t kStillnessSamplePeriodMs = 5;
static constexpr uint16_t kDefaultPiezoCalibrationMs = 1400;
static constexpr float kPiezoMinThreshold = 6.0f;
static constexpr float kDefaultPiezoDeadbandMv = 40.0f;
static constexpr float kDefaultPiezoRiseGuardMv = 0.0f;

static constexpr uint32_t kConfigMagic = 0x4952444Du;  // "IRDM"
static constexpr uint16_t kConfigVersion = 1;

static constexpr uint8_t kMsgMapSelectReq = 0x20;
static constexpr uint8_t kMsgMapSelectResp = 0x21;
static constexpr uint8_t kMsgMapListReq = 0x22;
static constexpr uint8_t kMsgMapListResp = 0x23;
static constexpr uint8_t kMsgSaveReq = 0x24;
static constexpr uint8_t kMsgSaveResp = 0x25;
static constexpr uint8_t kMsgSetFreqReq = 0x26;
static constexpr uint8_t kMsgSetFreqResp = 0x27;
static constexpr uint8_t kMsgSetSensitivityReq = 0x28;
static constexpr uint8_t kMsgSetSensitivityResp = 0x29;

static constexpr uint16_t kDefaultFrequencies[kDefaultBeaconCount] = {
    1280, 1410, 1540, 1670, 1800, 1930, 2060, 2190, 2320, 2450,
    2580, 2710, 2840, 2970, 3100, 3240, 3380, 3520, 3660, 3800,
};

static constexpr uint8_t kDefaultNotes[kDefaultBeaconCount] = {
    36, 38, 42, 46, 48, 45, 50, 49, 51, 43,
    41, 47, 57, 55, 52, 54, 56, 39, 40, 37,
};

static constexpr const char* kDefaultLabels[kDefaultBeaconCount] = {
    "KICK", "SNARE", "HH_C", "HH_O", "TOM1", "TOM2", "TOM3", "CR1", "RD1", "FLR",
    "LOM", "MID", "CR2", "SPL", "CHN", "TAB", "COW", "CLP", "RIM", "SD2",
};

static constexpr size_t kSensitivityTableSize = 10;
static constexpr float kSensitivityArmScale[10] = {1.36f, 1.28f, 1.20f, 1.12f, 1.00f, 0.90f, 0.82f, 0.74f, 0.66f, 0.58f};
static constexpr float kSensitivityTriggerScale[10] = {1.30f, 1.22f, 1.14f, 1.06f, 1.00f, 0.90f, 0.82f, 0.74f, 0.66f, 0.58f};
static constexpr float kSensitivityFallRatio[10] = {0.84f, 0.82f, 0.80f, 0.78f, 0.75f, 0.72f, 0.69f, 0.66f, 0.63f, 0.60f};
static constexpr uint16_t kSensitivityPeakTimeoutMs[10] = {60, 57, 54, 51, 48, 45, 42, 39, 36, 34};
static constexpr uint16_t kSensitivityMinGapMs[10] = {28, 25, 22, 20, 18, 16, 15, 14, 13, 12};

float clampf(float value, float lo, float hi) {
  if (value < lo) {
    return lo;
  }
  if (value > hi) {
    return hi;
  }
  return value;
}

float lerpf(float a, float b, float t) {
  return a + ((b - a) * t);
}

float sensitivityLevelToUnit(uint8_t level) {
  const int clamped = constrain(static_cast<int>(level), static_cast<int>(kSensitivityMinLevel), static_cast<int>(kSensitivityMaxLevel));
  return static_cast<float>(clamped - static_cast<int>(kSensitivityMinLevel)) /
         static_cast<float>(kSensitivityMaxLevel - kSensitivityMinLevel);
}

float lookupSensitivityCurveF(const float* table, size_t count, uint8_t level) {
  if (table == nullptr || count == 0) {
    return 0.0f;
  }
  if (count == 1) {
    return table[0];
  }

  const float pos = sensitivityLevelToUnit(level) * static_cast<float>(count - 1);
  const size_t lo = min(static_cast<size_t>(pos), count - 1);
  const size_t hi = min(lo + 1, count - 1);
  const float mix = pos - static_cast<float>(lo);
  return lerpf(table[lo], table[hi], mix);
}

uint16_t lookupSensitivityCurveU16(const uint16_t* table, size_t count, uint8_t level) {
  if (table == nullptr || count == 0) {
    return 0;
  }
  if (count == 1) {
    return table[0];
  }

  const float pos = sensitivityLevelToUnit(level) * static_cast<float>(count - 1);
  const size_t lo = min(static_cast<size_t>(pos), count - 1);
  const size_t hi = min(lo + 1, count - 1);
  const float mix = pos - static_cast<float>(lo);
  const float value = lerpf(static_cast<float>(table[lo]), static_cast<float>(table[hi]), mix);
  return static_cast<uint16_t>(roundf(value));
}

uint16_t median3u16(uint16_t a, uint16_t b, uint16_t c) {
  if (a > b) {
    const uint16_t tmp = a;
    a = b;
    b = tmp;
  }
  if (b > c) {
    const uint16_t tmp = b;
    b = c;
    c = tmp;
  }
  if (a > b) {
    const uint16_t tmp = a;
    a = b;
    b = tmp;
  }
  return b;
}

float sqrf(float x) {
  return x * x;
}

float vectorNorm3(float x, float y, float z) {
  return sqrtf(sqrf(x) + sqrf(y) + sqrf(z));
}

float componentByAxis(float x, float y, float z, int8_t axisIndex) {
  switch (axisIndex) {
    case 0:
      return x;
    case 1:
      return y;
    case 2:
    default:
      return z;
  }
}

template <typename T>
auto callEndIfAvailable(T& device, int) -> decltype(device.end(), bool()) {
  device.end();
  return true;
}

template <typename T>
bool callEndIfAvailable(T&, long) {
  return false;
}

void setAdcAttenuationDb(int8_t pin, uint8_t attenuationDb) {
#if defined(ADC_ATTEN_DB_0) && defined(ADC_ATTEN_DB_2_5) && defined(ADC_ATTEN_DB_6) && defined(ADC_ATTEN_DB_12)
  if (attenuationDb <= 1U) {
    analogSetPinAttenuation(pin, ADC_ATTEN_DB_0);
  } else if (attenuationDb <= 4U) {
    analogSetPinAttenuation(pin, ADC_ATTEN_DB_2_5);
  } else if (attenuationDb <= 8U) {
    analogSetPinAttenuation(pin, ADC_ATTEN_DB_6);
  } else {
    analogSetPinAttenuation(pin, ADC_ATTEN_DB_12);
  }
#elif defined(ADC_0db) && defined(ADC_2_5db) && defined(ADC_6db) && defined(ADC_11db)
  if (attenuationDb <= 1U) {
    analogSetPinAttenuation(pin, ADC_0db);
  } else if (attenuationDb <= 4U) {
    analogSetPinAttenuation(pin, ADC_2_5db);
  } else if (attenuationDb <= 8U) {
    analogSetPinAttenuation(pin, ADC_6db);
  } else {
    analogSetPinAttenuation(pin, ADC_11db);
  }
#else
  (void)pin;
  (void)attenuationDb;
#endif
}

void configurePiezoInputPin(int8_t pin) {
  if (pin < 0) {
    return;
  }
  pinMode(pin, INPUT);
#if defined(ESP32)
  const gpio_num_t gpio = static_cast<gpio_num_t>(pin);
  gpio_pullup_dis(gpio);
  gpio_pulldown_dis(gpio);
#endif
}

enum class StrokePhase : uint8_t {
  Idle = 0,
  Candidate = 1,
  Approach = 2,
  TriggeredRecovery = 3,
};

enum class TriggerReason : uint8_t {
  None = 0,
  PeakFall = 1,
  Rebound = 2,
  Reversal = 3,
  Timeout = 4,
};

enum class RejectReason : uint8_t {
  None = 0,
  WeakPeak = 1,
  TargetLost = 2,
  CandidateDrop = 3,
  CandidateTimeout = 4,
};

enum class HitProfile : uint8_t {
  StickDrum = 0,
  StickCymbal = 1,
  FootKick = 2,
  FootHat = 3,
};

enum class PiezoInputFilterMode : uint8_t {
  None = 0,
  Median3 = 1,
  NoiseGuard = 2,
  Median3NoiseGuard = 3,
};

const char* piezoInputFilterToken(PiezoInputFilterMode mode) {
  switch (mode) {
    case PiezoInputFilterMode::Median3:
      return "median3";
    case PiezoInputFilterMode::NoiseGuard:
      return "noise_guard";
    case PiezoInputFilterMode::Median3NoiseGuard:
      return "median3_guard";
    case PiezoInputFilterMode::None:
    default:
      return "none";
  }
}

PiezoInputFilterMode parsePiezoInputFilterMode(const char* token, PiezoInputFilterMode fallback) {
  if (token == nullptr || token[0] == '\0') {
    return fallback;
  }

  String mode(token);
  mode.trim();
  mode.toLowerCase();
  if (mode == "none" || mode == "off" || mode == "0") {
    return PiezoInputFilterMode::None;
  }
  if (mode == "median3" || mode == "median") {
    return PiezoInputFilterMode::Median3;
  }
  if (mode == "noise_guard" || mode == "guard" || mode == "noise") {
    return PiezoInputFilterMode::NoiseGuard;
  }
  if (mode == "median3_guard" || mode == "median3_noise_guard" || mode == "hybrid") {
    return PiezoInputFilterMode::Median3NoiseGuard;
  }
  return fallback;
}

bool piezoInputFilterUsesMedian(PiezoInputFilterMode mode) {
  return mode == PiezoInputFilterMode::Median3 || mode == PiezoInputFilterMode::Median3NoiseGuard;
}

bool piezoInputFilterUsesNoiseGuard(PiezoInputFilterMode mode) {
  return mode == PiezoInputFilterMode::NoiseGuard || mode == PiezoInputFilterMode::Median3NoiseGuard;
}

uint8_t normalizeAdcAttenuationDb(uint8_t attenuationDb) {
  if (attenuationDb <= 1U) {
    return 0U;
  }
  if (attenuationDb <= 4U) {
    return 2U;
  }
  if (attenuationDb <= 8U) {
    return 6U;
  }
  return 11U;
}

float adcFullScaleMillivolts(uint8_t attenuationDb) {
  const uint8_t normalized = normalizeAdcAttenuationDb(attenuationDb);
  if (normalized <= 0U) {
    return 1100.0f;
  }
  if (normalized <= 2U) {
    return 1500.0f;
  }
  if (normalized <= 6U) {
    return 2200.0f;
  }
  return 3900.0f;
}

uint16_t millivoltsToAdcCounts(float millivolts, uint8_t attenuationDb) {
  const float fullScaleMv = adcFullScaleMillivolts(attenuationDb);
  const float clampedMv = clampf(millivolts, 0.0f, fullScaleMv);
  const float normalized = clampedMv / fullScaleMv;
  return static_cast<uint16_t>(constrain(static_cast<int>(lroundf(normalized * 4095.0f)), 0, 4095));
}

float adcCountsToMillivolts(float counts, uint8_t attenuationDb) {
  const float fullScaleMv = adcFullScaleMillivolts(attenuationDb);
  const float clamped = clampf(counts, 0.0f, 4095.0f);
  return (clamped / 4095.0f) * fullScaleMv;
}

struct HitProfileTuning {
  HitProfile profile {HitProfile::StickDrum};
  const char* code {"SDR"};
  float approachGyroWeight {0.72f};
  float approachAccelWeight {0.28f};
  float reboundGyroWeight {0.75f};
  float reboundAccelWeight {0.25f};
  float velocityGyroWeight {0.70f};
  float velocityAccelWeight {0.30f};
  float velocityGamma {0.95f};
  float velocityGyroRef {170.0f};
  float velocityAccelRef {0.85f};
  float armScale {1.00f};
  float triggerScale {1.00f};
  float fallRatio {0.72f};
  float reboundThresholdScale {1.00f};
  uint16_t peakTimeoutMs {46};
  uint16_t minGapMs {17};
};

const char* strokePhaseCode(StrokePhase phase) {
  switch (phase) {
    case StrokePhase::Idle:
      return "IDL";
    case StrokePhase::Candidate:
      return "CND";
    case StrokePhase::Approach:
      return "APP";
    case StrokePhase::TriggeredRecovery:
      return "REC";
    default:
      return "UNK";
  }
}

const char* triggerReasonCode(TriggerReason reason) {
  switch (reason) {
    case TriggerReason::PeakFall:
      return "fall";
    case TriggerReason::Rebound:
      return "rebd";
    case TriggerReason::Reversal:
      return "revs";
    case TriggerReason::Timeout:
      return "tout";
    case TriggerReason::None:
    default:
      return "none";
  }
}

const char* rejectReasonCode(RejectReason reason) {
  switch (reason) {
    case RejectReason::WeakPeak:
      return "weak";
    case RejectReason::TargetLost:
      return "tgt";
    case RejectReason::CandidateDrop:
      return "cdrp";
    case RejectReason::CandidateTimeout:
      return "ctou";
    case RejectReason::None:
    default:
      return "none";
  }
}

const char* hitProfileCode(HitProfile profile) {
  switch (profile) {
    case HitProfile::StickDrum:
      return "SDR";
    case HitProfile::StickCymbal:
      return "SCY";
    case HitProfile::FootKick:
      return "FKK";
    case HitProfile::FootHat:
      return "FHT";
    default:
      return "UNK";
  }
}

struct BeaconSlot {
  uint16_t frequencyHz {0};
  uint8_t note {38};
  uint8_t channel {9};
  uint8_t velocityMin {20};
  uint8_t velocityMax {127};
  uint8_t enabled {1};
  char label[12] {0};
};

struct IRDrumsConfig {
  uint32_t magic {kConfigMagic};
  uint16_t version {kConfigVersion};
  char uid[9] {"00000000"};
  char deviceName[24] {"IRDrums"};

  int8_t aoPin {36};
  int8_t doPin {-1};
  uint16_t sampleRateHz {10000};
  uint16_t frameSamples {96};
  float smoothingAlpha {0.35f};
  float confidenceThreshold {0.30f};
  float dominanceThreshold {0.18f};
  float winnerShareThreshold {0.28f};
  float minWinnerMagnitude {2.0f};
  uint16_t switchHoldMs {8};

  float armAccelG {0.45f};
  float hitAccelG {1.10f};
  float hitGyroDps {125.0f};
  float releaseAccelG {0.25f};
  uint16_t refractoryMs {24};
  uint8_t hitSensitivityLevel {8};

  uint8_t sendNoteOff {1};
  uint16_t noteLengthMs {22};

  int8_t piezoPin {32};
  uint8_t piezoAdcAttenDb {11};
  uint8_t piezoSamplesPerTick {32};
  float piezoBaselineAlpha {0.004f};
  float piezoEnvDecay {0.965f};
  float piezoHitThreshold {18.0f};
  uint16_t piezoRefractoryMs {14};
  float piezoThresholdK {3.4f};
  float piezoThresholdMargin {7.0f};
  uint16_t piezoCalibrationMs {kDefaultPiezoCalibrationMs};
  uint8_t piezoPreset {static_cast<uint8_t>(PiezoPreset::Default)};
  uint8_t powerTelemetryEnabled {1};

  uint8_t beaconCount {kDefaultBeaconCount};
  BeaconSlot slots[kMaxBeacons] {};
};

struct ScannerConfig {
  int8_t aoPin {36};
  int8_t doPin {-1};
  uint16_t sampleRateHz {10000};
  uint16_t frameSamples {96};
  float smoothingAlpha {0.35f};
  float confidenceThreshold {0.30f};
  float dominanceThreshold {0.18f};
  float winnerShareThreshold {0.28f};
  float minWinnerMagnitude {2.0f};
  uint16_t switchHoldMs {8};
  uint8_t beaconCount {0};
  uint16_t frequenciesHz[kMaxBeacons] {};
};

struct ScannerSnapshot {
  bool running {false};
  int8_t aoPin {36};
  int8_t doPin {-1};
  int8_t doState {-1};
  uint8_t beaconCount {0};

  uint16_t rawAdc {0};
  uint16_t rawMinAdc {0};
  uint16_t rawMaxAdc {0};

  uint16_t configuredSampleRateHz {0};
  float measuredSampleRateHz {0.0f};
  uint16_t frameSamples {0};
  uint32_t frameTimeUs {0};
  uint32_t frameCount {0};
  uint32_t droppedCycles {0};

  float confidence {0.0f};
  float dominance {0.0f};
  float winnerShare {0.0f};
  float peakToNoise {0.0f};
  float noiseFloor {0.0f};
  float dynamicMinMagnitude {0.0f};
  float winnerMagnitude {0.0f};
  float secondMagnitude {0.0f};
  float totalMagnitude {0.0f};

  int8_t candidateIndex {-1};
  int8_t winnerIndex {-1};
  int8_t activeIndex {-1};
  uint8_t activeLatched {0};

  uint16_t frequenciesHz[kMaxBeacons] {};
  float magnitudes[kMaxBeacons] {};
  int8_t topIndex[3] {-1, -1, -1};
  float topMagnitude[3] {0.0f, 0.0f, 0.0f};
};

class IRScanner {
 public:
  void configure(const ScannerConfig& config);
  ScannerSnapshot snapshot() const;

 private:
  static void workerEntry(void* arg);
  void workerLoop();

  ScannerConfig sanitize(const ScannerConfig& in) const;
  float makeCoeff(float sampleRateHz, float targetHz) const;
  float goertzelMagnitude(const float* samples, uint16_t count, float coeff) const;
  void applyInputSetup();
  void buildWindow();
  void buildCoefficients();
  void resetRuntime();
  void updateTop(ScannerSnapshot& snap);
  void processFrame(uint32_t frameDurationUs);

  mutable portMUX_TYPE lock_ = portMUX_INITIALIZER_UNLOCKED;
  TaskHandle_t taskHandle_ {nullptr};

  ScannerConfig pendingConfig_ {};
  ScannerConfig activeConfig_ {};
  uint32_t configRevision_ {0};
  uint32_t appliedRevision_ {0};

  ScannerSnapshot snapshot_ {};

  uint16_t rawFrame_[kMaxFrameSamples] {};
  float frameWork_[kMaxFrameSamples] {};
  float window_[kMaxFrameSamples] {};
  float coeff_[kMaxBeacons] {};
  float smoothMagnitude_[kMaxBeacons] {};

  bool smoothReady_ {false};

  uint16_t frameIndex_ {0};
  uint32_t frameSum_ {0};
  uint32_t frameWallStartUs_ {0};
  uint16_t frameMin_ {4095};
  uint16_t frameMax_ {0};

  uint32_t samplePeriodUs_ {100};
  uint32_t nextSampleUs_ {0};
  uint32_t droppedCycles_ {0};
  uint32_t lastIdleYieldUs_ {0};
  uint16_t lastRawAdc_ {0};

  int8_t stableCandidate_ {-1};
  uint32_t stableSinceMs_ {0};
  int8_t activeIndex_ {-1};
  uint32_t lastValidMs_ {0};
  float noiseFloor_ {0.0f};
};

void IRScanner::configure(const ScannerConfig& config) {
  ScannerConfig sanitized = sanitize(config);

  bool shouldCreateTask = false;
  taskENTER_CRITICAL(&lock_);
  pendingConfig_ = sanitized;
  configRevision_++;
  if (taskHandle_ == nullptr) {
    shouldCreateTask = true;
  }
  taskEXIT_CRITICAL(&lock_);

  if (shouldCreateTask) {
    TaskHandle_t task = nullptr;
    BaseType_t ok = xTaskCreatePinnedToCore(&IRScanner::workerEntry, "IRScanWorker", 8192, this, 1, &task, 0);
    if (ok != pdPASS) {
      ok = xTaskCreate(&IRScanner::workerEntry, "IRScanWorker", 8192, this, 1, &task);
    }

    taskENTER_CRITICAL(&lock_);
    if (ok == pdPASS) {
      taskHandle_ = task;
    }
    taskEXIT_CRITICAL(&lock_);
  }
}

ScannerSnapshot IRScanner::snapshot() const {
  ScannerSnapshot out;
  taskENTER_CRITICAL(&lock_);
  out = snapshot_;
  taskEXIT_CRITICAL(&lock_);
  return out;
}

void IRScanner::workerEntry(void* arg) {
  auto* self = static_cast<IRScanner*>(arg);
  if (self) {
    self->workerLoop();
  }
  vTaskDelete(nullptr);
}

ScannerConfig IRScanner::sanitize(const ScannerConfig& in) const {
  ScannerConfig cfg = in;
  if (cfg.aoPin < 0) {
    cfg.aoPin = 36;
  }
  if (cfg.doPin < -1) {
    cfg.doPin = -1;
  }

  cfg.sampleRateHz = constrain(cfg.sampleRateHz, 6200, 14000);
  cfg.frameSamples = constrain(cfg.frameSamples, 64, kMaxFrameSamples);
  cfg.smoothingAlpha = clampf(cfg.smoothingAlpha, 0.02f, 0.95f);
  cfg.confidenceThreshold = clampf(cfg.confidenceThreshold, 0.02f, 0.98f);
  cfg.dominanceThreshold = clampf(cfg.dominanceThreshold, 0.02f, 0.98f);
  cfg.winnerShareThreshold = clampf(cfg.winnerShareThreshold, 0.02f, 0.98f);
  cfg.minWinnerMagnitude = max(0.0f, cfg.minWinnerMagnitude);
  cfg.switchHoldMs = constrain(cfg.switchHoldMs, static_cast<uint16_t>(6), static_cast<uint16_t>(300));
  cfg.beaconCount = constrain(cfg.beaconCount, static_cast<uint8_t>(1), kMaxBeacons);

  for (uint8_t i = 0; i < cfg.beaconCount; ++i) {
    cfg.frequenciesHz[i] = constrain(cfg.frequenciesHz[i], static_cast<uint16_t>(700), static_cast<uint16_t>(5600));
  }

  return cfg;
}

float IRScanner::makeCoeff(float sampleRateHz, float targetHz) const {
  const float omega = 2.0f * PI * targetHz / max(1.0f, sampleRateHz);
  return 2.0f * cosf(omega);
}

float IRScanner::goertzelMagnitude(const float* samples, uint16_t count, float coeff) const {
  float q0 = 0.0f;
  float q1 = 0.0f;
  float q2 = 0.0f;

  for (uint16_t i = 0; i < count; ++i) {
    q0 = (coeff * q1) - q2 + samples[i];
    q2 = q1;
    q1 = q0;
  }

  const float power = (q1 * q1) + (q2 * q2) - (coeff * q1 * q2);
  if (power <= 0.0f) {
    return 0.0f;
  }
  return sqrtf(power) / static_cast<float>(count);
}

void IRScanner::applyInputSetup() {
  pinMode(activeConfig_.aoPin, INPUT);
  if (activeConfig_.doPin >= 0) {
    pinMode(activeConfig_.doPin, INPUT);
  }

  analogReadResolution(12);
#if defined(ADC_ATTEN_DB_12)
  analogSetPinAttenuation(activeConfig_.aoPin, ADC_ATTEN_DB_12);
#elif defined(ADC_11db)
  analogSetPinAttenuation(activeConfig_.aoPin, ADC_11db);
#endif
}

void IRScanner::buildWindow() {
  const uint16_t n = activeConfig_.frameSamples;
  if (n < 2) {
    window_[0] = 1.0f;
    return;
  }

  for (uint16_t i = 0; i < n; ++i) {
    const float phase = (2.0f * PI * static_cast<float>(i)) / static_cast<float>(n - 1U);
    window_[i] = 0.5f - (0.5f * cosf(phase));
  }
}

void IRScanner::buildCoefficients() {
  const float sampleRateHz = 1000000.0f / static_cast<float>(max<uint32_t>(1, samplePeriodUs_));
  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    coeff_[i] = makeCoeff(sampleRateHz, static_cast<float>(activeConfig_.frequenciesHz[i]));
    smoothMagnitude_[i] = 0.0f;
  }
}

void IRScanner::resetRuntime() {
  frameIndex_ = 0;
  frameSum_ = 0;
  frameWallStartUs_ = 0;
  frameMin_ = 4095;
  frameMax_ = 0;
  nextSampleUs_ = 0;
  droppedCycles_ = 0;
  lastIdleYieldUs_ = 0;
  lastRawAdc_ = 0;

  smoothReady_ = false;
  stableCandidate_ = -1;
  stableSinceMs_ = 0;
  activeIndex_ = -1;
  lastValidMs_ = 0;
  noiseFloor_ = 0.0f;

  taskENTER_CRITICAL(&lock_);
  snapshot_ = ScannerSnapshot{};
  snapshot_.running = true;
  snapshot_.aoPin = activeConfig_.aoPin;
  snapshot_.doPin = activeConfig_.doPin;
  snapshot_.beaconCount = activeConfig_.beaconCount;
  snapshot_.configuredSampleRateHz = activeConfig_.sampleRateHz;
  snapshot_.frameSamples = activeConfig_.frameSamples;
  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    snapshot_.frequenciesHz[i] = activeConfig_.frequenciesHz[i];
  }
  taskEXIT_CRITICAL(&lock_);
}

void IRScanner::updateTop(ScannerSnapshot& snap) {
  for (uint8_t i = 0; i < 3; ++i) {
    snap.topIndex[i] = -1;
    snap.topMagnitude[i] = 0.0f;
  }

  for (uint8_t i = 0; i < snap.beaconCount; ++i) {
    const float value = snap.magnitudes[i];
    if (value > snap.topMagnitude[0]) {
      snap.topMagnitude[2] = snap.topMagnitude[1];
      snap.topIndex[2] = snap.topIndex[1];
      snap.topMagnitude[1] = snap.topMagnitude[0];
      snap.topIndex[1] = snap.topIndex[0];
      snap.topMagnitude[0] = value;
      snap.topIndex[0] = static_cast<int8_t>(i);
    } else if (value > snap.topMagnitude[1]) {
      snap.topMagnitude[2] = snap.topMagnitude[1];
      snap.topIndex[2] = snap.topIndex[1];
      snap.topMagnitude[1] = value;
      snap.topIndex[1] = static_cast<int8_t>(i);
    } else if (value > snap.topMagnitude[2]) {
      snap.topMagnitude[2] = value;
      snap.topIndex[2] = static_cast<int8_t>(i);
    }
  }
}

void IRScanner::processFrame(uint32_t frameDurationUs) {
  const uint16_t n = activeConfig_.frameSamples;
  if (n == 0 || n > kMaxFrameSamples) {
    return;
  }

  const float mean = static_cast<float>(frameSum_) / static_cast<float>(n);
  for (uint16_t i = 0; i < n; ++i) {
    frameWork_[i] = (static_cast<float>(rawFrame_[i]) - mean) * window_[i];
  }

  float total = 0.0f;
  float best = -1.0f;
  float second = -1.0f;
  int8_t bestIndex = -1;
  float smoothedMagnitude[kMaxBeacons] {};

  const float alpha = activeConfig_.smoothingAlpha;
  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    const float mag = goertzelMagnitude(frameWork_, n, coeff_[i]);
    if (!smoothReady_) {
      smoothMagnitude_[i] = mag;
    } else {
      smoothMagnitude_[i] += alpha * (mag - smoothMagnitude_[i]);
    }
    smoothedMagnitude[i] = smoothMagnitude_[i];
  }
  smoothReady_ = true;

  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    const float mag = smoothedMagnitude[i];
    total += mag;

    if (mag > best) {
      second = best;
      best = mag;
      bestIndex = static_cast<int8_t>(i);
    } else if (mag > second) {
      second = mag;
    }
  }

  if (second < 0.0f) {
    second = 0.0f;
  }

  const float eps = 1e-6f;
  const float residual = max(0.0f, total - max(0.0f, best));
  const float meanNoise = residual / static_cast<float>(max<uint8_t>(1, activeConfig_.beaconCount - 1U));
  if (noiseFloor_ <= 0.0f) {
    noiseFloor_ = meanNoise;
  } else {
    // Learn background faster when there is no clear winner, slower when a winner is present.
    const bool likelySignal = bestIndex >= 0 && best > (noiseFloor_ * 1.8f + activeConfig_.minWinnerMagnitude * 0.35f);
    const float beta = likelySignal ? 0.02f : 0.14f;
    noiseFloor_ += beta * (meanNoise - noiseFloor_);
  }
  noiseFloor_ = max(0.0f, noiseFloor_);

  const float dynamicMinMagnitude = max(activeConfig_.minWinnerMagnitude, noiseFloor_ * 1.35f + 0.25f);
  const float peakToNoise = best > 0.0f ? (best / (noiseFloor_ + 0.25f + eps)) : 0.0f;
  // Use top-two share to stay robust when many beacons are configured.
  const float winnerShare = best > 0.0f ? (best / (best + second + eps)) : 0.0f;
  const float dominance = best > 0.0f ? ((best - second) / (best + eps)) : 0.0f;
  const float strength = best > 0.0f ? (best / (best + dynamicMinMagnitude + eps)) : 0.0f;
  const float separability = clampf((peakToNoise - 1.0f) / 2.8f, 0.0f, 1.0f);
  const float confidence = clampf((0.45f * strength) + (0.30f * dominance) + (0.25f * separability), 0.0f, 1.0f);
  const float shareFloorByCount = activeConfig_.beaconCount >= 16
                                      ? 0.58f
                                      : (activeConfig_.beaconCount >= 10 ? 0.52f : (activeConfig_.beaconCount >= 6 ? 0.46f : 0.40f));
  const float dominanceFloorByCount =
      activeConfig_.beaconCount >= 16 ? 0.22f : (activeConfig_.beaconCount >= 10 ? 0.20f : (activeConfig_.beaconCount >= 6 ? 0.18f : 0.14f));
  const float shareThreshold = max(clampf(activeConfig_.winnerShareThreshold, 0.12f, 0.92f), shareFloorByCount);
  const float dominanceThreshold = max(activeConfig_.dominanceThreshold, dominanceFloorByCount);
  const float minPeakToNoise = activeConfig_.beaconCount >= 12 ? 1.12f : 1.08f;
  const float absoluteWinnerFloor =
      max(dynamicMinMagnitude, max(activeConfig_.minWinnerMagnitude * 1.4f + 0.45f, noiseFloor_ * 1.9f + 0.30f));
  const bool basicSignal = bestIndex >= 0 && best >= absoluteWinnerFloor && peakToNoise >= minPeakToNoise;
  const bool separated = (winnerShare >= shareThreshold) ||
                         (dominance >= dominanceThreshold) ||
                         (confidence >= max(activeConfig_.confidenceThreshold, 0.34f) && winnerShare >= (shareThreshold * 0.92f));
  bool winnerValid = basicSignal && separated;

  float activeMagnitude = 0.0f;
  if (activeIndex_ >= 0 && activeIndex_ < static_cast<int8_t>(activeConfig_.beaconCount)) {
    activeMagnitude = smoothedMagnitude[activeIndex_];
  }

  const float switchMagnitudeFloor = max(absoluteWinnerFloor * 1.08f, noiseFloor_ * 2.3f + 0.55f);
  if (winnerValid && activeIndex_ >= 0 && bestIndex >= 0 && bestIndex != activeIndex_) {
    // Keep target stable unless the challenger is clearly and consistently stronger.
    const bool activeStillCompetitive =
        activeMagnitude >= (best * 0.91f) || activeMagnitude >= (absoluteWinnerFloor * 0.95f);
    const bool challengerStrongEnough =
        best >= max(activeMagnitude * 1.34f + 0.30f, switchMagnitudeFloor) &&
        winnerShare >= max(shareThreshold, 0.66f) &&
        dominance >= max(dominanceThreshold, 0.24f) &&
        peakToNoise >= (minPeakToNoise + 0.06f);
    if (activeStillCompetitive && !challengerStrongEnough) {
      winnerValid = false;
    }
  }

  // Fast takeover path: if a new beacon is clearly stronger than current active,
  // allow switching even when confidence terms briefly degrade during stick motion.
  const bool fastOverride = bestIndex >= 0 &&
                            activeIndex_ >= 0 &&
                            bestIndex != activeIndex_ &&
                            best >= max(activeMagnitude * 1.95f + 0.55f, switchMagnitudeFloor * 1.10f) &&
                            winnerShare >= max(0.74f, shareThreshold + 0.08f) &&
                            dominance >= max(0.28f, dominanceThreshold + 0.06f) &&
                            peakToNoise >= max(1.30f, minPeakToNoise + 0.15f);
  if (!winnerValid && fastOverride) {
    winnerValid = true;
  }

  const uint32_t nowMs = millis();
  const int8_t candidate = winnerValid ? bestIndex : -1;

  if (candidate != stableCandidate_) {
    stableCandidate_ = candidate;
    stableSinceMs_ = nowMs;
  }

  if (candidate >= 0) {
    const bool acquiring = activeIndex_ < 0;
    const bool switchingToNew = activeIndex_ >= 0 && candidate != activeIndex_;
    uint16_t holdMs = activeConfig_.switchHoldMs;
    if (acquiring) {
      holdMs = max<uint16_t>(holdMs, 8U);
    } else if (switchingToNew) {
      holdMs = max<uint16_t>(static_cast<uint16_t>(holdMs * 2U), static_cast<uint16_t>(holdMs + 8U));
    }

    const bool fastSwitch = switchingToNew &&
                            best >= max(activeMagnitude * 1.98f + 0.55f, switchMagnitudeFloor * 1.14f) &&
                            winnerShare >= max(0.76f, shareThreshold + 0.10f) &&
                            dominance >= max(0.30f, dominanceThreshold + 0.08f) &&
                            peakToNoise >= max(1.36f, minPeakToNoise + 0.18f) &&
                            confidence >= max(activeConfig_.confidenceThreshold, 0.40f);
    if (fastSwitch || (nowMs - stableSinceMs_) >= holdMs) {
      activeIndex_ = candidate;
    }
    lastValidMs_ = nowMs;
  }

  ScannerSnapshot next;
  taskENTER_CRITICAL(&lock_);
  next = snapshot_;
  taskEXIT_CRITICAL(&lock_);

  next.running = true;
  next.aoPin = activeConfig_.aoPin;
  next.doPin = activeConfig_.doPin;
  next.doState = activeConfig_.doPin >= 0 ? digitalRead(activeConfig_.doPin) : -1;
  next.beaconCount = activeConfig_.beaconCount;
  next.rawAdc = lastRawAdc_;
  next.rawMinAdc = frameMin_;
  next.rawMaxAdc = frameMax_;
  next.configuredSampleRateHz = activeConfig_.sampleRateHz;
  next.measuredSampleRateHz = frameDurationUs == 0
                                  ? static_cast<float>(activeConfig_.sampleRateHz)
                                  : (1000000.0f * static_cast<float>(n)) / static_cast<float>(frameDurationUs);
  next.frameSamples = n;
  next.frameTimeUs = frameDurationUs;
  next.frameCount++;
  next.droppedCycles = droppedCycles_;

  next.confidence = confidence;
  next.dominance = dominance;
  next.winnerShare = winnerShare;
  next.peakToNoise = peakToNoise;
  next.noiseFloor = noiseFloor_;
  next.dynamicMinMagnitude = dynamicMinMagnitude;
  next.winnerMagnitude = max(0.0f, best);
  next.secondMagnitude = max(0.0f, second);
  next.totalMagnitude = total;
  next.candidateIndex = candidate;
  next.winnerIndex = bestIndex;
  next.activeIndex = activeIndex_;
  next.activeLatched = activeIndex_ >= 0 ? 1 : 0;

  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    next.frequenciesHz[i] = activeConfig_.frequenciesHz[i];
    next.magnitudes[i] = smoothMagnitude_[i];
  }

  updateTop(next);

  taskENTER_CRITICAL(&lock_);
  snapshot_ = next;
  taskEXIT_CRITICAL(&lock_);
}

void IRScanner::workerLoop() {
  for (;;) {
    bool changed = false;

    taskENTER_CRITICAL(&lock_);
    if (configRevision_ != appliedRevision_) {
      activeConfig_ = pendingConfig_;
      appliedRevision_ = configRevision_;
      changed = true;
    }
    taskEXIT_CRITICAL(&lock_);

    if (changed) {
      samplePeriodUs_ = max<uint32_t>(50, 1000000UL / max<uint16_t>(1, activeConfig_.sampleRateHz));
      applyInputSetup();
      buildWindow();
      buildCoefficients();
      resetRuntime();
    }

    if (appliedRevision_ == 0 || activeConfig_.beaconCount == 0) {
      vTaskDelay(pdMS_TO_TICKS(4));
      continue;
    }

    const uint32_t nowUs = micros();
    if (nextSampleUs_ == 0) {
      nextSampleUs_ = nowUs + samplePeriodUs_;
      lastIdleYieldUs_ = nowUs;
      continue;
    }

    const int32_t untilUs = static_cast<int32_t>(nextSampleUs_ - nowUs);
    if (untilUs > 0) {
      if (untilUs > static_cast<int32_t>(kBusyWaitThresholdUs)) {
        vTaskDelay(pdMS_TO_TICKS(1));
        lastIdleYieldUs_ = micros();
      } else {
        delayMicroseconds(static_cast<uint32_t>(untilUs));
      }
      continue;
    }

    uint8_t collected = 0;
    while (static_cast<int32_t>(micros() - nextSampleUs_) >= 0 && collected < kMaxCatchUpSamples) {
      const uint16_t raw = static_cast<uint16_t>(analogRead(activeConfig_.aoPin));
      lastRawAdc_ = raw;

      if (frameIndex_ == 0) {
        frameWallStartUs_ = micros();
        frameMin_ = 4095;
        frameMax_ = 0;
      }

      rawFrame_[frameIndex_] = raw;
      frameSum_ += raw;
      frameMin_ = min(frameMin_, raw);
      frameMax_ = max(frameMax_, raw);

      frameIndex_++;
      nextSampleUs_ += samplePeriodUs_;
      collected++;

      if (frameIndex_ >= activeConfig_.frameSamples) {
        const uint32_t frameDurationUs = max<uint32_t>(1, micros() - frameWallStartUs_);
        processFrame(frameDurationUs);
        frameIndex_ = 0;
        frameSum_ = 0;
      }
    }

    if (collected >= kMaxCatchUpSamples && static_cast<int32_t>(micros() - nextSampleUs_) >= 0) {
      droppedCycles_++;
      nextSampleUs_ = micros() + samplePeriodUs_;
    }

    const uint32_t guardUs = micros();
    if (lastIdleYieldUs_ == 0 || (guardUs - lastIdleYieldUs_) >= kIdleYieldIntervalUs) {
      vTaskDelay(pdMS_TO_TICKS(1));
      lastIdleYieldUs_ = micros();
    }
  }
}

struct PendingNote {
  bool active {false};
  uint8_t channel {9};
  uint8_t note {38};
  uint8_t velocity {100};
  uint32_t offAtMs {0};
};

struct PendingAssignment {
  bool active {false};
  int8_t requestedBeacon {-1};
  uint8_t note {38};
  uint8_t channel {9};
  uint8_t velocityMin {20};
  uint8_t velocityMax {127};
  char label[12] {0};
};

struct PiezoRuntimeState {
  bool configured {false};
  bool calibrated {false};
  float baseline {0.0f};
  float env {0.0f};
  float peak {0.0f};
  float noiseFloor {0.0f};
  float threshold {kPiezoMinThreshold};
  float rectified {0.0f};
  uint16_t lastRaw {0};
  uint32_t calibrateStartedMs {0};
  uint32_t calibrateSamples {0};
  double calibrateNoiseAccum {0.0};
  uint32_t lastHitMs {0};
};

class IRDrumsApp {
 public:
  IRDrumsApp();
  void begin();
  void tick();

 private:
  static IRDrumsApp* instance_;
  static void onMidiMessageStatic(const IncomingMidiMessage& message);

  void onMidiMessage(const IncomingMidiMessage& message);
  void sendFrame(uint8_t sequence, MsgType type, const String& payload, uint8_t chunkIndex = 0, uint8_t chunkCount = 1);
  void sendChunked(uint8_t sequence, MsgType type, const String& payload);
  void sendNack(uint8_t sequence, const char* reason);

  void respondHello(uint8_t sequence);
  void handleArmReq(uint8_t sequence, const String& payload);
  void handleSaveReq(uint8_t sequence);
  void handleStatsReq(uint8_t sequence);
  void handleFactoryReset(uint8_t sequence);
  void handleSetFreqReq(uint8_t sequence, const String& payload);
  void handleSetSensitivityReq(uint8_t sequence, const String& payload);
  void handleCalibrateReq(uint8_t sequence, const String& payload);
  void handleMapSelectReq(uint8_t sequence, const String& payload);
  bool assignToBeacon(int8_t beaconIndex, const PendingAssignment& assignment, uint8_t responseSequence);
  void sendMappingList(uint8_t sequence, MsgType type);
  PiezoConfig composePiezoConfigModel() const;

  void applyScannerConfig();
  void detachI2cForPiezoMode();
  void configurePiezoAdc();
  void resetPiezoTuneRuntime();
  static void piezoSamplerEntry(void* arg);
  void piezoSamplerLoop();
  void ensurePiezoSamplerTask();
  void resetPiezoSampleQueue();
  bool popPiezoSample(uint16_t& raw, uint32_t& sampleUs);

  void processButtons();
  void processAssignmentClickWindow();
  void confirmPendingAssignment();
  float sensitivityScale() const;
  uint16_t computeRefractoryMs(float hitScore) const;
  HitProfile classifyProfileForBeacon(int8_t beaconIndex) const;
  HitProfileTuning composeProfileTuning(HitProfile profile) const;
  uint8_t velocityFromDirectionalPeaks(float peakGyroDps, float peakAccelG, const HitProfileTuning& tuning,
                                       const BeaconSlot& slot) const;
  bool runStillnessCalibration(uint16_t durationMs);
  void updateTargetTracking(const ScannerSnapshot& snap, uint32_t nowMs);
  bool canArmOnLiveTarget() const;
  void processSensorsAndHit();
  void processImuRefinement(uint32_t nowMs);
  bool processPiezoHit(const ScannerSnapshot& snap, uint32_t nowMs);
  int8_t resolveHitTarget(const ScannerSnapshot& snap) const;
  static PiezoTargetSnapshot freezePiezoTargetStatic(void* userData);
  static bool commitPiezoHitStatic(void* userData, const PiezoTargetSnapshot& frozenTarget, uint8_t velocity, uint16_t peak);
  PiezoTargetSnapshot freezePiezoTarget();
  bool commitPiezoHit(const PiezoTargetSnapshot& frozenTarget, uint8_t velocity, uint16_t peak);
  void scheduleNoteOff(uint8_t channel, uint8_t note, uint8_t velocity, uint16_t afterMs);
  void processNoteOffQueue();

  void drawHeader(const ScannerSnapshot& snap);
  void drawPageMain(const ScannerSnapshot& snap);
  void drawPageSpectrum(const ScannerSnapshot& snap);
  void drawPageMapping(const ScannerSnapshot& snap);
  void drawPagePiezoScope(const ScannerSnapshot& snap);
  void drawPiezoScopeTrace(int x, int y, int w, int h, const uint16_t* samples, uint8_t count, uint16_t baseline,
                           uint16_t color, uint16_t centerColor);
  void resetPiezoScopeBuffers();
  void recordPiezoScopeSample(uint16_t raw);
  void updateSpectrogram(const ScannerSnapshot& snap);
  void drawSpectrogram(const ScannerSnapshot& snap, int x, int y, int w, int h);
  uint16_t heatColor(uint8_t value) const;
  void drawUi(bool force);
  void logHealth();

  void makeDefaultConfig(IRDrumsConfig& out);
  bool validateConfig(IRDrumsConfig& cfg);
  void loadConfig();
  bool saveConfig();

  String detectUid() const;

  IRDrumsConfig config_ {};
  IRScanner scanner_ {};
  BleMidiBackendEsp32BleMidi midi_ {};

  PendingAssignment pendingAssignment_ {};
  PendingNote noteOffQueue_[10] {};

  bool armed_ {true};
  bool strokeTracking_ {false};
  StrokePhase strokePhase_ {StrokePhase::Idle};
  uint32_t refractoryUntilMs_ {0};
  uint32_t phaseEnteredAtMs_ {0};
  uint16_t lastRefractoryMs_ {0};
  uint32_t strokeStartMs_ {0};
  int8_t liveTargetBeacon_ {-1};
  int8_t frozenStrokeTargetBeacon_ {-1};
  uint32_t liveTargetStableSinceMs_ {0};
  uint32_t frozenTargetArmedAtMs_ {0};
  uint16_t liveTargetStableMs_ {0};
  uint8_t liveTargetConfident_ {0};
  uint32_t liveTargetSwitchCount_ {0};
  int8_t attackAxisIndex_ {1};
  float attackAxisSign_ {1.0f};
  bool gravityReady_ {false};
  float gravityX_ {0.0f};
  float gravityY_ {0.0f};
  float gravityZ_ {1.0f};
  float gyroBiasX_ {0.0f};
  float gyroBiasY_ {0.0f};
  float gyroBiasZ_ {0.0f};
  float noiseFloorAccelG_ {0.02f};
  float noiseFloorGyroDps_ {2.0f};
  bool stillnessCalibrated_ {false};
  HitProfile activeProfile_ {HitProfile::StickDrum};
  float approachScoreFilt_ {0.0f};
  float reboundScoreFilt_ {0.0f};
  float projectedGyroDps_ {0.0f};
  float projectedAccelG_ {0.0f};
  float approachGyroDps_ {0.0f};
  float approachAccelG_ {0.0f};
  float reboundGyroDps_ {0.0f};
  float reboundAccelG_ {0.0f};
  uint8_t lastTriggerReason_ {0};
  uint8_t lastRejectReason_ {0};
  float prevImpactScore_ {0.0f};
  float strokePeakScore_ {0.0f};
  float strokePeakAccelG_ {0.0f};
  float strokePeakGyroDps_ {0.0f};
  float lastImpactScore_ {0.0f};
  float lastStrokePeakScore_ {0.0f};

  float lastLinearAccelG_ {0.0f};
  float lastGyroDps_ {0.0f};
  int8_t lastHitBeacon_ {-1};
  uint8_t lastHitNote_ {0};
  uint8_t lastHitVelocity_ {0};
  uint32_t lastHitAtMs_ {0};
  uint32_t totalHitCount_ {0};
  uint32_t totalRejectCount_ {0};

  int8_t lastAssignedBeacon_ {-1};
  uint32_t lastAssignedAtMs_ {0};

  uint8_t uiPage_ {0};
  uint32_t lastUiDrawMs_ {0};
  uint32_t lastHealthLogMs_ {0};
  uint8_t spectrogram_[kSpectrogramRows][kMaxBeacons] {};
  uint32_t lastSpectrogramFrameCount_ {0};
  float spectrogramScale_ {1.0f};
  mutable portMUX_TYPE piezoScopeLock_ = portMUX_INITIALIZER_UNLOCKED;
  uint16_t piezoScopeFast_[kPiezoScopePoints] {};
  uint8_t piezoScopeFastHead_ {0};
  uint8_t piezoScopeFastCount_ {0};
  uint32_t piezoScopeFastAccum_ {0};
  uint8_t piezoScopeFastAccumCount_ {0};
  uint16_t piezoScopeSlow_[kPiezoScopePoints] {};
  uint8_t piezoScopeSlowHead_ {0};
  uint8_t piezoScopeSlowCount_ {0};
  uint32_t piezoScopeSlowAccum_ {0};
  uint8_t piezoScopeSlowAccumCount_ {0};

  uint8_t btnBClickCount_ {0};
  uint32_t btnBLastReleaseMs_ {0};
  uint32_t protocolMuteUntilMs_ {0};
  bool i2cDetached_ {false};
  bool imuRefinementAvailable_ {true};
  uint32_t imuReadFailCount_ {0};
  uint32_t imuLastOkMs_ {0};
  float imuPeakLinearAccel_ {0.0f};
  float imuPeakGyroDps_ {0.0f};
  PiezoRuntimeState piezo_ {};
  PiezoHitEngine piezoEngine_ {};
  ScannerSnapshot latestScannerSnapshot_ {};
  float frozenTargetConfidenceAtScan_ {0.0f};
  uint8_t beaconSwitchDuringScan_ {0};
  uint8_t powerTelemetryEnabled_ {1};
  bool piezoCommittedThisTick_ {false};
  PiezoInputFilterMode piezoInputFilterMode_ {PiezoInputFilterMode::Median3NoiseGuard};
  float piezoDeadbandMv_ {kDefaultPiezoDeadbandMv};
  float piezoRiseGuardMv_ {kDefaultPiezoRiseGuardMv};
  uint8_t piezoPositiveOnly_ {1};
  float piezoTuneScanMs_ {0.0f};
  float piezoTuneMaskMs_ {0.0f};
  float piezoTuneQuietMs_ {0.0f};
  float piezoTuneThresholdFloor_ {0.0f};
  float piezoTuneThresholdOffset_ {0.0f};
  float piezoTuneNoiseAlpha_ {0.0f};
  float piezoTuneNoiseScale_ {0.0f};
  float piezoTuneQuietThreshold_ {0.0f};
  float piezoTuneVelocityPeakMin_ {0.0f};
  float piezoTuneVelocityPeakRef_ {0.0f};
  float piezoTuneVelocityGamma_ {0.0f};
  uint16_t piezoMedianHistory_[3] {0, 0, 0};
  uint8_t piezoMedianCount_ {0};
  mutable portMUX_TYPE piezoQueueLock_ = portMUX_INITIALIZER_UNLOCKED;
  TaskHandle_t piezoSamplerTask_ {nullptr};
  static constexpr uint16_t kPiezoQueueSize = 512;
  uint16_t piezoQueueRaw_[kPiezoQueueSize] {};
  uint32_t piezoQueueUs_[kPiezoQueueSize] {};
  uint16_t piezoQueueHead_ {0};
  uint16_t piezoQueueTail_ {0};
  uint32_t piezoQueueDropped_ {0};
  volatile bool piezoSamplerEnabled_ {false};
  volatile int8_t piezoSamplerPin_ {32};
  volatile uint16_t piezoSamplerIntervalUs_ {80};

  String uidToken_ {"00000000"};
};

IRDrumsApp::IRDrumsApp() {
  instance_ = this;
}

void IRDrumsApp::begin() {
  auto cfg = M5.config();
  cfg.internal_imu = true;
  cfg.output_power = true;
  cfg.clear_display = true;
  cfg.serial_baudrate = 115200;
  cfg.fallback_board = m5::board_t::board_M5StickC;
  M5.begin(cfg);

  M5.Display.setRotation(0);
  M5.Display.setBrightness(180);
  M5.Display.setTextWrap(false);
  M5.Display.clear(TFT_BLACK);

  uidToken_ = detectUid();
  makeDefaultConfig(config_);
  loadConfig();
  powerTelemetryEnabled_ = config_.powerTelemetryEnabled ? 1 : 0;
  resetPiezoTuneRuntime();
  piezoEngine_.applyConfig(composePiezoConfigModel());

  Serial.println();
  Serial.printf("[IRDR] boot uid=%s name=%s\n", uidToken_.c_str(), config_.deviceName);
  Serial.printf("[IRDR] ir ao=%d fs=%u n=%u beacons=%u\n", config_.aoPin, config_.sampleRateHz, config_.frameSamples,
                config_.beaconCount);

  M5.Display.fillRect(0, 0, 80, 160, TFT_BLACK);
  M5.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5.Display.setTextSize(1);
  M5.Display.setCursor(4, 28);
  M5.Display.printf("IRDrums boot");
  M5.Display.setCursor(4, 42);
  M5.Display.printf("Stillness cal...");
  const bool calibrationOk = runStillnessCalibration(kStillnessCalibrationMs);
  Serial.printf("[IRDR] stillness_calibrated=%d\n", calibrationOk ? 1 : 0);
  configurePiezoAdc();

  applyScannerConfig();
  memset(spectrogram_, 0, sizeof(spectrogram_));
  lastSpectrogramFrameCount_ = 0;
  spectrogramScale_ = 1.0f;

  midi_.setReceiveCallback(&IRDrumsApp::onMidiMessageStatic);
  const bool bleStarted = midi_.begin(config_.deviceName);
  armed_ = bleStarted;
  Serial.printf("[IRDR] ble_started=%d name=%s\n", bleStarted ? 1 : 0, config_.deviceName);

  drawUi(true);
}

void IRDrumsApp::tick() {
  M5.update();
  midi_.poll();

  processButtons();
  processSensorsAndHit();
  processNoteOffQueue();
  processAssignmentClickWindow();

  drawUi(false);
  logHealth();
}

void IRDrumsApp::onMidiMessageStatic(const IncomingMidiMessage& message) {
  if (instance_) {
    instance_->onMidiMessage(message);
  }
}

void IRDrumsApp::onMidiMessage(const IncomingMidiMessage& message) {
  if (!message.isSysEx || !message.sysExData || message.sysExLength < 2) {
    return;
  }

  SysExFrame frame;
  if (!Protocol::parseFrame(message.sysExData, message.sysExLength, frame)) {
    return;
  }

  const uint8_t msg = static_cast<uint8_t>(frame.type);
  switch (msg) {
    case static_cast<uint8_t>(MsgType::HelloReq):
      respondHello(frame.sequence);
      break;
    case static_cast<uint8_t>(MsgType::Ping):
      sendFrame(frame.sequence, MsgType::Pong, "{}");
      break;
    case static_cast<uint8_t>(MsgType::ArmReq):
      handleArmReq(frame.sequence, frame.payload);
      break;
    case static_cast<uint8_t>(MsgType::StatsReq):
      handleStatsReq(frame.sequence);
      break;
    case static_cast<uint8_t>(MsgType::CalibrateReq):
      handleCalibrateReq(frame.sequence, frame.payload);
      break;
    case static_cast<uint8_t>(MsgType::GetCfgReq):
    case kMsgMapListReq:
      sendMappingList(frame.sequence, static_cast<MsgType>(kMsgMapListResp));
      break;
    case kMsgMapSelectReq:
      handleMapSelectReq(frame.sequence, frame.payload);
      break;
    case kMsgSaveReq:
    case static_cast<uint8_t>(MsgType::SaveCfgReq):
      handleSaveReq(frame.sequence);
      break;
    case kMsgSetFreqReq:
      handleSetFreqReq(frame.sequence, frame.payload);
      break;
    case kMsgSetSensitivityReq:
      handleSetSensitivityReq(frame.sequence, frame.payload);
      break;
    case static_cast<uint8_t>(MsgType::FactoryResetReq):
      handleFactoryReset(frame.sequence);
      break;
    default:
      sendNack(frame.sequence, "unsupported_msg");
      break;
  }
}

void IRDrumsApp::sendFrame(uint8_t sequence, MsgType type, const String& payload, uint8_t chunkIndex, uint8_t chunkCount) {
  // Keep realtime note traffic out of chunked SysEx windows.
  protocolMuteUntilMs_ = max(protocolMuteUntilMs_, millis() + 45U);
  uint8_t out[256] {};
  const size_t length = Protocol::buildFrame(sequence, type, chunkIndex, chunkCount, payload, out, sizeof(out));
  if (length > 0) {
    midi_.sendSysEx(out, length);
  }
}

void IRDrumsApp::sendChunked(uint8_t sequence, MsgType type, const String& payload) {
  // Use conservative chunk size to reduce BLE packet loss and CRC failures on Web Bluetooth stacks.
  static constexpr size_t kChunkSize = 96;
  const size_t total = payload.length();
  const uint8_t chunkCount = max<uint8_t>(1, static_cast<uint8_t>((total + kChunkSize - 1) / kChunkSize));

  if (chunkCount == 1) {
    sendFrame(sequence, type, payload, 0, 1);
    return;
  }

  const uint32_t holdMs = 110U + static_cast<uint32_t>(chunkCount) * 45U;
  protocolMuteUntilMs_ = max(protocolMuteUntilMs_, millis() + holdMs);
  for (uint8_t i = 0; i < chunkCount; ++i) {
    const size_t start = static_cast<size_t>(i) * kChunkSize;
    const size_t end = min(total, start + kChunkSize);
    sendFrame(sequence, type, payload.substring(start, end), i, chunkCount);
    if ((i + 1U) < chunkCount) {
      vTaskDelay(pdMS_TO_TICKS(14));
    }
  }
}

void IRDrumsApp::sendNack(uint8_t sequence, const char* reason) {
  StaticJsonDocument<96> doc;
  doc["ok"] = 0;
  doc["err"] = reason;
  String payload;
  serializeJson(doc, payload);
  sendFrame(sequence, MsgType::Nack, payload);
}

void IRDrumsApp::respondHello(uint8_t sequence) {
  const ScannerSnapshot snap = scanner_.snapshot();

  StaticJsonDocument<448> doc;
  doc["uid"] = uidToken_;
  doc["role"] = "IRDrums";
  doc["board"] = "M5StickC";
  doc["fw"] = kFirmwareVersion;
  doc["name"] = config_.deviceName;
  doc["armed"] = armed_ ? 1 : 0;
  doc["beacons"] = config_.beaconCount;
  doc["active"] = snap.activeIndex;
  doc["conf"] = snap.confidence;
  doc["sens"] = config_.hitSensitivityLevel;
  doc["hit_src"] = "piezo";
  doc["piezo_pin"] = config_.piezoPin;
  doc["pz_preset"] = piezoPresetToken(config_.piezoPreset);
  doc["i2c_detached"] = i2cDetached_ ? 1 : 0;
  doc["batt_avail"] = powerTelemetryEnabled_ ? 1 : 0;
  if (powerTelemetryEnabled_) {
    doc["batt"] = M5.Power.getBatteryLevel();
  }
  doc["min_tgt_ms"] = kMinTargetStableMs;
  doc["profile"] = hitProfileCode(activeProfile_);
  doc["cal"] = stillnessCalibrated_ ? 1 : 0;
  doc["noise_a"] = noiseFloorAccelG_;
  doc["noise_g"] = noiseFloorGyroDps_;

  JsonArray caps = doc.createNestedArray("caps");
  caps.add("midi_note");
  caps.add("ir_bank");
  caps.add("map_assign");
  caps.add("btn_confirm");
  caps.add("switch_latch");
  caps.add("sensitivity");
  caps.add("piezo_hit");
  caps.add("target_freeze");
  caps.add("piezo_cfg");
  caps.add("piezo_stats");
  caps.add("batt_flag");
  caps.add("hit_profiles");
  caps.add("stillness_cal");

  String payload;
  serializeJson(doc, payload);
  sendChunked(sequence, MsgType::HelloResp, payload);
}

void IRDrumsApp::handleArmReq(uint8_t sequence, const String& payload) {
  StaticJsonDocument<96> doc;
  if (deserializeJson(doc, payload) != DeserializationError::Ok) {
    sendNack(sequence, "bad_json");
    return;
  }

  const bool nextArmed = (doc["armed"] | 0) != 0;
  armed_ = nextArmed;

  StaticJsonDocument<64> out;
  out["ok"] = 1;
  out["armed"] = armed_ ? 1 : 0;
  String outPayload;
  serializeJson(out, outPayload);
  sendFrame(sequence, MsgType::ArmResp, outPayload);
}

void IRDrumsApp::handleSaveReq(uint8_t sequence) {
  const bool ok = saveConfig();

  StaticJsonDocument<72> out;
  out["ok"] = ok ? 1 : 0;
  String payload;
  serializeJson(out, payload);
  sendFrame(sequence, static_cast<MsgType>(kMsgSaveResp), payload);
}

void IRDrumsApp::handleStatsReq(uint8_t sequence) {
  const ScannerSnapshot snap = scanner_.snapshot();
  const PiezoStats& pz = piezoEngine_.stats();
  const PiezoConfig piezoCfg = composePiezoConfigModel();
  const uint32_t nowMs = millis();
  StaticJsonDocument<1280> out;
  out["ok"] = 1;
  out["hits"] = totalHitCount_;
  out["rej"] = totalRejectCount_;
  out["hit_src"] = "piezo";
  out["heap"] = static_cast<int>(ESP.getFreeHeap());
  out["phase"] = strokePhaseCode(strokePhase_);
  out["profile"] = hitProfileCode(activeProfile_);
  out["live_tgt"] = liveTargetBeacon_;
  out["frozen_tgt"] = frozenStrokeTargetBeacon_;
  out["tgt_stable_ms"] = liveTargetStableMs_;
  out["tgt_conf"] = liveTargetConfident_;
  out["ap"] = approachScoreFilt_;
  out["rb"] = reboundScoreFilt_;
  out["g_proj"] = projectedGyroDps_;
  out["a_proj"] = projectedAccelG_;
  out["trg_reason"] = triggerReasonCode(static_cast<TriggerReason>(lastTriggerReason_));
  out["rej_reason"] = rejectReasonCode(static_cast<RejectReason>(lastRejectReason_));
  out["cd_ms"] = nowMs < refractoryUntilMs_ ? (refractoryUntilMs_ - nowMs) : 0;
  out["pz_env"] = piezo_.env;
  out["pz_thr"] = piezo_.threshold;
  out["pz_nf"] = piezo_.noiseFloor;
  out["pz_raw"] = piezo_.lastRaw;
  out["pz_signal"] = pz.signal;
  out["pz_deriv"] = pz.derivative;
  out["pz_state"] = PiezoHitEngine::stateToken(pz.state);
  out["pz_preset"] = piezoPresetToken(config_.piezoPreset);
  out["pz_peak"] = pz.scanPeak;
  out["pz_last_peak"] = pz.lastPeak;
  out["pz_last_vel"] = pz.lastVelocity;
  out["pz_mask_ms"] = pz.maskRemainingMs;
  out["pz_quiet_ms"] = pz.quietHoldMs;
  out["pz_filter"] = piezoInputFilterToken(piezoInputFilterMode_);
  out["pz_adc_db"] = config_.piezoAdcAttenDb;
  out["pz_deadband_mv"] = piezoDeadbandMv_;
  out["pz_deadband_raw"] = piezoCfg.deadbandRaw;
  out["pz_rise_guard_mv"] = piezoRiseGuardMv_;
  out["pz_rise_guard_raw"] = piezoCfg.riseGuard;
  out["pz_positive_only"] = piezoCfg.positiveOnly ? 1 : 0;
  out["pz_noise_alpha"] = piezoCfg.noiseAlpha;
  out["pz_noise_scale"] = piezoCfg.noiseScale;
  out["pz_quiet_thr"] = piezoCfg.quietThreshold;
  out["pz_vel_min_peak"] = piezoCfg.velocityPeakMin;
  out["pz_vel_ref_peak"] = piezoCfg.velocityPeakRef;
  out["pz_vel_gamma"] = piezoCfg.velocityGamma;
  out["pz_baseline_alpha"] = piezoCfg.baselineAlpha;
  out["pz_env_decay"] = piezoCfg.envDecay;
  out["pz_samples_tick"] = config_.piezoSamplesPerTick;
  out["pz_refractory_ms"] = config_.piezoRefractoryMs;
  out["pz_hit_thr"] = config_.piezoHitThreshold;
  out["pz_thr_margin"] = config_.piezoThresholdMargin;
  out["pz_thr_k"] = config_.piezoThresholdK;
  out["pz_rej_mask"] = pz.maskRejects;
  out["pz_rej_quiet"] = pz.quietRejects;
  out["pz_rej_rise"] = pz.riseRejects;
  out["frozen_beacon_scan"] = frozenStrokeTargetBeacon_;
  out["beacon_conf_scan"] = frozenTargetConfidenceAtScan_;
  out["beacon_sw_scan"] = beaconSwitchDuringScan_;
  out["batt_avail"] = powerTelemetryEnabled_ ? 1 : 0;
  if (powerTelemetryEnabled_) {
    out["batt"] = M5.Power.getBatteryLevel();
  }
  out["imu_ok"] = imuRefinementAvailable_ ? 1 : 0;
  out["i2c_detached"] = i2cDetached_ ? 1 : 0;
  out["conf"] = snap.confidence;
  out["pn"] = snap.peakToNoise;
  out["noise_a"] = noiseFloorAccelG_;
  out["noise_g"] = noiseFloorGyroDps_;
  String payload;
  serializeJson(out, payload);
  sendChunked(sequence, MsgType::StatsResp, payload);
}

void IRDrumsApp::handleFactoryReset(uint8_t sequence) {
  makeDefaultConfig(config_);
  powerTelemetryEnabled_ = config_.powerTelemetryEnabled ? 1 : 0;
  piezoInputFilterMode_ = PiezoInputFilterMode::Median3NoiseGuard;
  resetPiezoTuneRuntime();
  piezoMedianCount_ = 0;
  applyScannerConfig();
  const bool ok = saveConfig();

  StaticJsonDocument<80> out;
  out["ok"] = ok ? 1 : 0;
  out["beacons"] = config_.beaconCount;
  String payload;
  serializeJson(out, payload);
  sendFrame(sequence, MsgType::FactoryResetResp, payload);
}

void IRDrumsApp::handleSetFreqReq(uint8_t sequence, const String& payload) {
  StaticJsonDocument<1024> doc;
  if (deserializeJson(doc, payload) != DeserializationError::Ok) {
    sendNack(sequence, "bad_json");
    return;
  }

  JsonArrayConst arr = doc["freqs"].as<JsonArrayConst>();
  if (arr.isNull() || arr.size() == 0) {
    sendNack(sequence, "freqs_missing");
    return;
  }

  const uint8_t count = min<uint8_t>(arr.size(), kMaxBeacons);
  config_.beaconCount = count;
  for (uint8_t i = 0; i < count; ++i) {
    config_.slots[i].frequencyHz = constrain(static_cast<uint16_t>(arr[i].as<uint32_t>()), static_cast<uint16_t>(700),
                                             static_cast<uint16_t>(5600));
  }

  applyScannerConfig();

  StaticJsonDocument<96> out;
  out["ok"] = 1;
  out["count"] = config_.beaconCount;
  String outPayload;
  serializeJson(out, outPayload);
  sendFrame(sequence, static_cast<MsgType>(kMsgSetFreqResp), outPayload);
}

void IRDrumsApp::handleSetSensitivityReq(uint8_t sequence, const String& payload) {
  StaticJsonDocument<1024> doc;
  if (deserializeJson(doc, payload) != DeserializationError::Ok) {
    sendNack(sequence, "bad_json");
    return;
  }

  if ((doc["reset_pz_tune"] | 0) != 0) {
    resetPiezoTuneRuntime();
    piezoMedianCount_ = 0;
  }

  const int requestedLevel = doc["level"] | static_cast<int>(config_.hitSensitivityLevel);
  config_.hitSensitivityLevel = constrain(
      requestedLevel,
      static_cast<int>(kSensitivityMinLevel),
      static_cast<int>(kSensitivityMaxLevel));

  if (doc.containsKey("filter")) {
    if (doc["filter"].is<const char*>()) {
      piezoInputFilterMode_ = parsePiezoInputFilterMode(doc["filter"].as<const char*>(), piezoInputFilterMode_);
    } else {
      const int mode = doc["filter"] | static_cast<int>(piezoInputFilterMode_);
      piezoInputFilterMode_ = static_cast<PiezoInputFilterMode>(constrain(mode, 0, 3));
    }
    piezoMedianCount_ = 0;
  }

  const uint8_t prevAdcDb = config_.piezoAdcAttenDb;
  if (doc.containsKey("adc_db")) {
    const int requestedAdc = doc["adc_db"] | static_cast<int>(config_.piezoAdcAttenDb);
    config_.piezoAdcAttenDb = normalizeAdcAttenuationDb(static_cast<uint8_t>(constrain(requestedAdc, 0, 11)));
  }

  if (doc.containsKey("samples_tick")) {
    const int requestedSamples = doc["samples_tick"] | static_cast<int>(config_.piezoSamplesPerTick);
    config_.piezoSamplesPerTick = static_cast<uint8_t>(constrain(requestedSamples, 8, 128));
  }
  if (doc.containsKey("refractory_ms")) {
    const int requestedMask = doc["refractory_ms"] | static_cast<int>(config_.piezoRefractoryMs);
    config_.piezoRefractoryMs = static_cast<uint16_t>(constrain(requestedMask, 2, 320));
  }
  if (doc.containsKey("hit_thr")) {
    const float requestedHitThreshold = doc["hit_thr"] | config_.piezoHitThreshold;
    config_.piezoHitThreshold = clampf(requestedHitThreshold, kPiezoMinThreshold, 380.0f);
  }
  if (doc.containsKey("thr_margin")) {
    const float requestedMargin = doc["thr_margin"] | config_.piezoThresholdMargin;
    config_.piezoThresholdMargin = clampf(requestedMargin, 1.0f, 80.0f);
  }
  if (doc.containsKey("thr_k")) {
    const float requestedNoiseK = doc["thr_k"] | config_.piezoThresholdK;
    config_.piezoThresholdK = clampf(requestedNoiseK, 0.1f, 20.0f);
  }
  if (doc.containsKey("baseline_alpha")) {
    const float requestedBaselineAlpha = doc["baseline_alpha"] | config_.piezoBaselineAlpha;
    config_.piezoBaselineAlpha = clampf(requestedBaselineAlpha, 0.0001f, 0.1f);
  }
  if (doc.containsKey("env_decay")) {
    const float requestedEnvDecay = doc["env_decay"] | config_.piezoEnvDecay;
    config_.piezoEnvDecay = clampf(requestedEnvDecay, 0.80f, 0.9995f);
  }
  if (doc.containsKey("deadband_mv")) {
    const float requestedDeadbandMv = doc["deadband_mv"] | piezoDeadbandMv_;
    piezoDeadbandMv_ = clampf(requestedDeadbandMv, 0.0f, 400.0f);
  }
  if (doc.containsKey("rise_guard_mv")) {
    const float requestedRiseGuardMv = doc["rise_guard_mv"] | piezoRiseGuardMv_;
    piezoRiseGuardMv_ = clampf(requestedRiseGuardMv, 0.0f, 200.0f);
  }
  if (doc.containsKey("positive_only")) {
    bool positiveOnly = piezoPositiveOnly_ != 0;
    const JsonVariantConst rawPositiveOnly = doc["positive_only"];
    if (rawPositiveOnly.is<bool>()) {
      positiveOnly = rawPositiveOnly.as<bool>();
    } else if (rawPositiveOnly.is<const char*>()) {
      String token(rawPositiveOnly.as<const char*>());
      token.trim();
      token.toLowerCase();
      positiveOnly = !(token == "0" || token == "false" || token == "off" || token == "no");
    } else {
      positiveOnly = (rawPositiveOnly.as<int>() != 0);
    }
    piezoPositiveOnly_ = positiveOnly ? 1U : 0U;
  }

  auto applyRuntimeFloat = [&](const char* key, float& target, float lo, float hi) {
    if (!doc.containsKey(key)) {
      return;
    }
    const float requested = doc[key] | target;
    if (requested <= 0.0f) {
      target = 0.0f;
      return;
    }
    target = clampf(requested, lo, hi);
  };

  applyRuntimeFloat("scan_ms", piezoTuneScanMs_, 0.4f, 80.0f);
  applyRuntimeFloat("mask_ms", piezoTuneMaskMs_, 1.0f, 320.0f);
  applyRuntimeFloat("quiet_ms", piezoTuneQuietMs_, 0.2f, 120.0f);
  applyRuntimeFloat("thr_floor", piezoTuneThresholdFloor_, 1.0f, 1200.0f);
  applyRuntimeFloat("thr_offset", piezoTuneThresholdOffset_, 0.0f, 1200.0f);
  applyRuntimeFloat("noise_alpha", piezoTuneNoiseAlpha_, 0.001f, 0.25f);
  applyRuntimeFloat("noise_scale", piezoTuneNoiseScale_, 0.1f, 20.0f);
  applyRuntimeFloat("quiet_thr", piezoTuneQuietThreshold_, 1.0f, 1200.0f);
  applyRuntimeFloat("vel_min_peak", piezoTuneVelocityPeakMin_, 1.0f, 1200.0f);
  applyRuntimeFloat("vel_ref_peak", piezoTuneVelocityPeakRef_, 2.0f, 2200.0f);
  applyRuntimeFloat("vel_gamma", piezoTuneVelocityGamma_, 0.2f, 3.5f);

  const PiezoConfig piezoCfg = composePiezoConfigModel();
  piezoEngine_.applyConfig(piezoCfg);
  piezoSamplerIntervalUs_ =
      max<uint16_t>(45U, static_cast<uint16_t>(1000000UL / max<uint16_t>(1, piezoCfg.sampleRateHz)));

  if (config_.piezoAdcAttenDb != prevAdcDb) {
    piezo_.configured = false;
    configurePiezoAdc();
  }
  const bool ok = saveConfig();

  const HitProfileTuning tuning = composeProfileTuning(activeProfile_);

  StaticJsonDocument<896> out;
  out["ok"] = ok ? 1 : 0;
  out["level"] = config_.hitSensitivityLevel;
  out["scale"] = tuning.triggerScale;
  out["profile"] = hitProfileCode(activeProfile_);
  out["hit_g"] = max(0.07f, config_.hitAccelG * tuning.triggerScale);
  out["hit_dps"] = max(22.0f, config_.hitGyroDps * tuning.triggerScale);
  out["pz_thr"] = piezoCfg.thresholdFloor + piezoCfg.thresholdOffset;
  out["pz_floor"] = piezoCfg.thresholdFloor;
  out["pz_offset"] = piezoCfg.thresholdOffset;
  out["pz_noise_scale"] = piezoCfg.noiseScale;
  out["pz_noise_alpha"] = piezoCfg.noiseAlpha;
  out["pz_scan_ms"] = piezoCfg.scanMs;
  out["pz_mask_ms"] = piezoCfg.maskMs;
  out["pz_quiet_ms"] = piezoCfg.quietMs;
  out["pz_quiet_thr"] = piezoCfg.quietThreshold;
  out["pz_vel_min_peak"] = piezoCfg.velocityPeakMin;
  out["pz_vel_ref_peak"] = piezoCfg.velocityPeakRef;
  out["pz_vel_gamma"] = piezoCfg.velocityGamma;
  out["pz_baseline_alpha"] = piezoCfg.baselineAlpha;
  out["pz_env_decay"] = piezoCfg.envDecay;
  out["pz_deadband_mv"] = piezoDeadbandMv_;
  out["pz_deadband_raw"] = piezoCfg.deadbandRaw;
  out["pz_rise_guard_mv"] = piezoRiseGuardMv_;
  out["pz_rise_guard_raw"] = piezoCfg.riseGuard;
  out["pz_positive_only"] = piezoCfg.positiveOnly ? 1 : 0;
  out["pz_samples_tick"] = config_.piezoSamplesPerTick;
  out["pz_refractory_ms"] = config_.piezoRefractoryMs;
  out["pz_hit_thr"] = config_.piezoHitThreshold;
  out["pz_thr_margin"] = config_.piezoThresholdMargin;
  out["pz_thr_k"] = config_.piezoThresholdK;
  out["filter"] = piezoInputFilterToken(piezoInputFilterMode_);
  out["adc_db"] = config_.piezoAdcAttenDb;
  out["level_max"] = kSensitivityMaxLevel;
  out["min_gap_ms"] = tuning.minGapMs;
  out["peak_ms"] = tuning.peakTimeoutMs;
  String outPayload;
  serializeJson(out, outPayload);
  sendChunked(sequence, static_cast<MsgType>(kMsgSetSensitivityResp), outPayload);
}

void IRDrumsApp::handleCalibrateReq(uint8_t sequence, const String& payload) {
  if (i2cDetached_) {
    StaticJsonDocument<160> out;
    out["ok"] = 0;
    out["mode"] = "unavailable";
    out["hint"] = "imu_unavailable_after_i2c_detach";
    String outPayload;
    serializeJson(out, outPayload);
    sendFrame(sequence, MsgType::CalibrateResp, outPayload);
    return;
  }

  StaticJsonDocument<128> doc;
  uint16_t windowMs = kStillnessCalibrationMs;
  String mode {"stillness"};
  if (deserializeJson(doc, payload) == DeserializationError::Ok) {
    windowMs = constrain(static_cast<uint16_t>(doc["window_ms"] | kStillnessCalibrationMs),
                         static_cast<uint16_t>(300),
                         static_cast<uint16_t>(3000));
    mode = String(static_cast<const char*>(doc["mode"] | "stillness"));
    mode.toLowerCase();
  }

  StaticJsonDocument<224> out;
  bool ok = false;
  if (mode == "stroke") {
    const uint32_t endMs = millis() + windowMs;
    float bestAbs = 0.0f;
    int8_t bestAxis = attackAxisIndex_;
    float bestSign = attackAxisSign_;
    float peakGyro = 0.0f;
    float peakAccel = 0.0f;
    while (millis() < endMs) {
      float ax = 0.0f;
      float ay = 0.0f;
      float az = 0.0f;
      float gx = 0.0f;
      float gy = 0.0f;
      float gz = 0.0f;
      if (M5.Imu.getAccel(&ax, &ay, &az) && M5.Imu.getGyro(&gx, &gy, &gz)) {
        gx -= gyroBiasX_;
        gy -= gyroBiasY_;
        gz -= gyroBiasZ_;
        const float components[3] = {gx, gy, gz};
        for (int8_t axis = 0; axis < 3; ++axis) {
          const float absValue = fabsf(components[axis]);
          if (absValue > bestAbs) {
            bestAbs = absValue;
            bestAxis = axis;
            bestSign = components[axis] >= 0.0f ? 1.0f : -1.0f;
          }
        }
        const float linX = ax - gravityX_;
        const float linY = ay - gravityY_;
        const float linZ = az - gravityZ_;
        peakGyro = max(peakGyro, vectorNorm3(gx, gy, gz));
        peakAccel = max(peakAccel, vectorNorm3(linX, linY, linZ));
      }
      M5.update();
      delay(2);
    }

    attackAxisIndex_ = bestAxis;
    attackAxisSign_ = bestSign;
    ok = bestAbs > 20.0f;
    out["ok"] = ok ? 1 : 0;
    out["mode"] = "stroke";
    out["axis"] = attackAxisIndex_;
    out["sign"] = attackAxisSign_;
    out["peak_g"] = peakAccel;
    out["peak_dps"] = peakGyro;
    out["hint"] = ok ? "axis_updated" : "stroke_too_weak";
  } else {
    ok = runStillnessCalibration(windowMs);
    out["ok"] = ok ? 1 : 0;
    out["mode"] = "stillness";
    out["window_ms"] = windowMs;
    out["noise_a"] = noiseFloorAccelG_;
    out["noise_g"] = noiseFloorGyroDps_;
    out["cal"] = stillnessCalibrated_ ? 1 : 0;
  }
  String outPayload;
  serializeJson(out, outPayload);
  sendFrame(sequence, MsgType::CalibrateResp, outPayload);
}

void IRDrumsApp::handleMapSelectReq(uint8_t sequence, const String& payload) {
  StaticJsonDocument<256> doc;
  if (deserializeJson(doc, payload) != DeserializationError::Ok) {
    sendNack(sequence, "bad_json");
    return;
  }

  PendingAssignment next;
  next.active = true;
  next.requestedBeacon = static_cast<int8_t>(doc["beacon"] | -1);
  next.note = constrain(static_cast<int>(doc["note"] | 38), 0, 127);
  next.channel = constrain(static_cast<int>(doc["ch"] | 9), 0, 15);
  next.velocityMin = constrain(static_cast<int>(doc["vel_min"] | 20), 1, 127);
  next.velocityMax = constrain(static_cast<int>(doc["vel_max"] | 127), static_cast<int>(next.velocityMin), 127);

  const char* label = doc["name"] | "DRUM";
  strlcpy(next.label, label, sizeof(next.label));

  pendingAssignment_ = next;

  int8_t directBeacon = next.requestedBeacon;
  if (directBeacon >= 0) {
    const bool ok = assignToBeacon(directBeacon, pendingAssignment_, sequence);
    if (ok) {
      pendingAssignment_.active = false;
    }
    return;
  }

  StaticJsonDocument<112> out;
  out["ok"] = 1;
  out["pending"] = 1;
  out["note"] = pendingAssignment_.note;
  out["hint"] = "double_click_btnb_to_confirm";
  String outPayload;
  serializeJson(out, outPayload);
  sendFrame(sequence, static_cast<MsgType>(kMsgMapSelectResp), outPayload);
}

bool IRDrumsApp::assignToBeacon(int8_t beaconIndex, const PendingAssignment& assignment, uint8_t responseSequence) {
  if (beaconIndex < 0 || beaconIndex >= static_cast<int8_t>(config_.beaconCount)) {
    if (responseSequence != 0) {
      sendNack(responseSequence, "beacon_out_of_range");
    }
    return false;
  }

  BeaconSlot& slot = config_.slots[beaconIndex];
  slot.note = assignment.note;
  slot.channel = assignment.channel;
  slot.velocityMin = assignment.velocityMin;
  slot.velocityMax = assignment.velocityMax;
  slot.enabled = 1;
  if (assignment.label[0] != '\0') {
    strlcpy(slot.label, assignment.label, sizeof(slot.label));
  }

  if (responseSequence != 0) {
    StaticJsonDocument<192> out;
    out["ok"] = 1;
    out["beacon"] = beaconIndex;
    out["freq"] = slot.frequencyHz;
    out["note"] = slot.note;
    out["ch"] = slot.channel;
    out["label"] = slot.label;
    String payload;
    serializeJson(out, payload);
    sendFrame(responseSequence, static_cast<MsgType>(kMsgMapSelectResp), payload);
  }

  saveConfig();
  return true;
}

void IRDrumsApp::sendMappingList(uint8_t sequence, MsgType type) {
  DynamicJsonDocument doc(4608);
  doc["ok"] = 1;
  doc["beacon_count"] = config_.beaconCount;

  const ScannerSnapshot snap = scanner_.snapshot();
  const PiezoConfig piezoCfg = composePiezoConfigModel();
  doc["active"] = snap.activeIndex;
  doc["candidate"] = snap.candidateIndex;
  doc["winner"] = snap.winnerIndex;
  doc["conf"] = snap.confidence;
  doc["pn"] = snap.peakToNoise;
  doc["noise"] = snap.noiseFloor;
  doc["dyn_min"] = snap.dynamicMinMagnitude;
  doc["sens"] = config_.hitSensitivityLevel;
  doc["sens_max"] = kSensitivityMaxLevel;
  doc["hit_src"] = "piezo";
  doc["batt_avail"] = powerTelemetryEnabled_ ? 1 : 0;
  doc["pz_env"] = piezo_.env;
  doc["pz_thr"] = piezo_.threshold;
  doc["pz_raw"] = piezo_.lastRaw;
  doc["pz_filter"] = piezoInputFilterToken(piezoInputFilterMode_);
  doc["pz_adc_db"] = config_.piezoAdcAttenDb;
  doc["pz_deadband_mv"] = piezoDeadbandMv_;
  doc["pz_deadband_raw"] = piezoCfg.deadbandRaw;
  doc["pz_rise_guard_mv"] = piezoRiseGuardMv_;
  doc["pz_rise_guard_raw"] = piezoCfg.riseGuard;
  doc["pz_positive_only"] = piezoPositiveOnly_;
  doc["pz_samples_tick"] = config_.piezoSamplesPerTick;
  doc["pz_refractory_ms"] = config_.piezoRefractoryMs;
  doc["pz_hit_thr"] = config_.piezoHitThreshold;
  doc["pz_thr_margin"] = config_.piezoThresholdMargin;
  doc["pz_thr_k"] = config_.piezoThresholdK;

  JsonArray slots = doc.createNestedArray("slots");
  for (uint8_t i = 0; i < config_.beaconCount; ++i) {
    JsonObject row = slots.createNestedObject();
    row["idx"] = i;
    row["freq"] = config_.slots[i].frequencyHz;
    row["note"] = config_.slots[i].note;
    row["ch"] = config_.slots[i].channel;
    row["en"] = config_.slots[i].enabled;
    row["name"] = config_.slots[i].label;
  }

  JsonObject piezo = doc.createNestedObject("piezo");
  piezo["enabled"] = 1;
  piezo["preset"] = piezoPresetToken(config_.piezoPreset);
  piezo["pin"] = config_.piezoPin;
  piezo["adc_db"] = config_.piezoAdcAttenDb;
  piezo["filter"] = piezoInputFilterToken(piezoInputFilterMode_);
  piezo["fs_hz"] = piezoCfg.sampleRateHz;
  piezo["scan_ms"] = piezoCfg.scanMs;
  piezo["mask_ms"] = piezoCfg.maskMs;
  piezo["quiet_ms"] = piezoCfg.quietMs;
  piezo["thr_floor"] = piezoCfg.thresholdFloor;
  piezo["thr_offset"] = piezoCfg.thresholdOffset;
  piezo["noise_alpha"] = piezoCfg.noiseAlpha;
  piezo["noise_scale"] = piezoCfg.noiseScale;
  piezo["quiet_thr"] = piezoCfg.quietThreshold;
  piezo["vel_min_peak"] = piezoCfg.velocityPeakMin;
  piezo["vel_ref_peak"] = piezoCfg.velocityPeakRef;
  piezo["vel_gamma"] = piezoCfg.velocityGamma;
  piezo["deadband_mv"] = piezoDeadbandMv_;
  piezo["deadband_raw"] = piezoCfg.deadbandRaw;
  piezo["rise_guard_mv"] = piezoRiseGuardMv_;
  piezo["rise_guard_raw"] = piezoCfg.riseGuard;
  piezo["positive_only"] = piezoCfg.positiveOnly ? 1 : 0;
  piezo["samples_tick"] = config_.piezoSamplesPerTick;
  piezo["refractory_ms"] = config_.piezoRefractoryMs;
  piezo["hit_thr"] = config_.piezoHitThreshold;
  piezo["thr_margin"] = config_.piezoThresholdMargin;
  piezo["thr_k"] = config_.piezoThresholdK;
  piezo["baseline_alpha"] = config_.piezoBaselineAlpha;
  piezo["env_decay"] = config_.piezoEnvDecay;
  piezo["batt_telemetry"] = powerTelemetryEnabled_ ? 1 : 0;

  String payload;
  serializeJson(doc, payload);
  sendChunked(sequence, type, payload);
}

PiezoConfig IRDrumsApp::composePiezoConfigModel() const {
  PiezoConfig cfg {};
  cfg.enabled = true;
  cfg.presetId = config_.piezoPreset;
  cfg.pin = config_.piezoPin;
  cfg.adcAttenDb = config_.piezoAdcAttenDb;
  cfg.sampleRateHz = static_cast<uint16_t>(constrain(static_cast<int>(config_.piezoSamplesPerTick * 380), 2000, 18000));
  applyPiezoPreset(cfg, cfg.presetId);
  const float sensitivityT = sensitivityLevelToUnit(config_.hitSensitivityLevel);
  // Level 1 = strict (harder trigger), level 20 = sensitive/faster.
  const float thresholdScale = 1.12f - (0.72f * sensitivityT);
  const float timingScale = 1.20f - (0.42f * sensitivityT);
  const float noiseScale = 1.32f - (0.60f * sensitivityT);
  const float refractoryScale = 1.20f - (0.48f * sensitivityT);
  const float configuredScale = 1.20f - (0.82f * sensitivityT);

  cfg.scanMs = clampf(cfg.scanMs * timingScale, 0.8f, 12.0f);
  cfg.maskMs = static_cast<float>(constrain(config_.piezoRefractoryMs, static_cast<uint16_t>(2), static_cast<uint16_t>(40)));
  cfg.maskMs = clampf(cfg.maskMs * refractoryScale, 2.0f, 40.0f);
  cfg.quietMs = clampf(cfg.quietMs * timingScale, 0.5f, 12.0f);
  const float configuredFloor = max(kPiezoMinThreshold, config_.piezoHitThreshold * configuredScale);
  const float configuredOffset = max(1.0f, config_.piezoThresholdMargin * configuredScale);
  const float safetyFloor = 8.0f + ((1.0f - sensitivityT) * 4.0f);
  const float safetyOffset = 2.0f + ((1.0f - sensitivityT) * 1.2f);
  cfg.thresholdFloor = max(cfg.thresholdFloor * thresholdScale, max(configuredFloor, safetyFloor));
  cfg.thresholdOffset = max(cfg.thresholdOffset * thresholdScale, max(configuredOffset, safetyOffset));
  cfg.noiseAlpha = 0.02f;
  cfg.noiseScale = max(1.0f, config_.piezoThresholdK * noiseScale);
  cfg.quietThreshold = max(3.0f, cfg.thresholdFloor * 0.52f);
  cfg.velocityPeakMin = max(2.0f, cfg.thresholdFloor + 3.0f);
  cfg.velocityPeakRef = max(cfg.velocityPeakMin + 1.0f, cfg.thresholdFloor * 12.0f);
  cfg.velocityGamma = 0.65f;
  cfg.velocityMin = 1;
  cfg.velocityMax = 127;
  cfg.baselineAlpha = clampf(config_.piezoBaselineAlpha, 0.0004f, 0.08f);
  cfg.envDecay = clampf(config_.piezoEnvDecay, 0.86f, 0.998f);
  if (piezoInputFilterUsesNoiseGuard(piezoInputFilterMode_)) {
    cfg.noiseScale = max(cfg.noiseScale, 2.8f);
    cfg.quietThreshold = max(cfg.quietThreshold, cfg.thresholdFloor * 0.68f);
    cfg.quietMs = max(cfg.quietMs, 1.2f);
  } else {
    cfg.noiseScale = max(1.0f, cfg.noiseScale * 0.95f);
    cfg.quietThreshold = max(1.0f, cfg.quietThreshold * 0.92f);
  }

  if (piezoTuneScanMs_ > 0.0f) {
    cfg.scanMs = clampf(piezoTuneScanMs_, 0.4f, 80.0f);
  }
  if (piezoTuneMaskMs_ > 0.0f) {
    cfg.maskMs = clampf(piezoTuneMaskMs_, 1.0f, 320.0f);
  }
  if (piezoTuneQuietMs_ > 0.0f) {
    cfg.quietMs = clampf(piezoTuneQuietMs_, 0.2f, 120.0f);
  }
  if (piezoTuneThresholdFloor_ > 0.0f) {
    cfg.thresholdFloor = clampf(piezoTuneThresholdFloor_, 1.0f, 1200.0f);
  }
  if (piezoTuneThresholdOffset_ > 0.0f) {
    cfg.thresholdOffset = clampf(piezoTuneThresholdOffset_, 0.0f, 1200.0f);
  }
  if (piezoTuneNoiseAlpha_ > 0.0f) {
    cfg.noiseAlpha = clampf(piezoTuneNoiseAlpha_, 0.001f, 0.25f);
  }
  if (piezoTuneNoiseScale_ > 0.0f) {
    cfg.noiseScale = clampf(piezoTuneNoiseScale_, 0.1f, 20.0f);
  }
  if (piezoTuneQuietThreshold_ > 0.0f) {
    cfg.quietThreshold = clampf(piezoTuneQuietThreshold_, 1.0f, 1200.0f);
  }
  if (piezoTuneVelocityPeakMin_ > 0.0f) {
    cfg.velocityPeakMin = clampf(piezoTuneVelocityPeakMin_, 1.0f, 1200.0f);
  }
  if (piezoTuneVelocityPeakRef_ > 0.0f) {
    cfg.velocityPeakRef = clampf(piezoTuneVelocityPeakRef_, 2.0f, 2200.0f);
  }
  if (piezoTuneVelocityGamma_ > 0.0f) {
    cfg.velocityGamma = clampf(piezoTuneVelocityGamma_, 0.2f, 3.5f);
  }

  cfg.positiveOnly = piezoPositiveOnly_ != 0;
  cfg.deadbandRaw = millivoltsToAdcCounts(piezoDeadbandMv_, cfg.adcAttenDb);
  cfg.riseGuard = static_cast<float>(millivoltsToAdcCounts(piezoRiseGuardMv_, cfg.adcAttenDb));
  cfg.powerTelemetryEnabled = powerTelemetryEnabled_ != 0;
  return cfg;
}

void IRDrumsApp::applyScannerConfig() {
  ScannerConfig sc;
  sc.aoPin = config_.aoPin;
  sc.doPin = config_.doPin;
  sc.sampleRateHz = config_.sampleRateHz;
  sc.frameSamples = config_.frameSamples;
  sc.smoothingAlpha = config_.smoothingAlpha;
  sc.confidenceThreshold = config_.confidenceThreshold;
  sc.dominanceThreshold = config_.dominanceThreshold;
  sc.winnerShareThreshold = config_.winnerShareThreshold;
  sc.minWinnerMagnitude = config_.minWinnerMagnitude;
  sc.switchHoldMs = config_.switchHoldMs;
  sc.beaconCount = config_.beaconCount;

  for (uint8_t i = 0; i < config_.beaconCount; ++i) {
    sc.frequenciesHz[i] = config_.slots[i].frequencyHz;
  }

  scanner_.configure(sc);
}

void IRDrumsApp::detachI2cForPiezoMode() {
  if (i2cDetached_) {
    return;
  }

  Serial.println("[IRDR][I2C] detach begin for piezo GPIO32 ADC");
  const bool imuEnded = callEndIfAvailable(M5.Imu, 0);
  Wire.end();
  i2cDetached_ = true;
  imuRefinementAvailable_ = true;
  Serial.printf("[IRDR][I2C] detach done wire=1 imu_end=%u\n", imuEnded ? 1U : 0U);
}

void IRDrumsApp::resetPiezoTuneRuntime() {
  piezoDeadbandMv_ = kDefaultPiezoDeadbandMv;
  piezoRiseGuardMv_ = kDefaultPiezoRiseGuardMv;
  piezoPositiveOnly_ = 1;
  piezoTuneScanMs_ = 0.0f;
  piezoTuneMaskMs_ = 0.0f;
  piezoTuneQuietMs_ = 0.0f;
  piezoTuneThresholdFloor_ = 0.0f;
  piezoTuneThresholdOffset_ = 0.0f;
  piezoTuneNoiseAlpha_ = 0.0f;
  piezoTuneNoiseScale_ = 0.0f;
  piezoTuneQuietThreshold_ = 0.0f;
  piezoTuneVelocityPeakMin_ = 0.0f;
  piezoTuneVelocityPeakRef_ = 0.0f;
  piezoTuneVelocityGamma_ = 0.0f;
}

void IRDrumsApp::configurePiezoAdc() {
  piezoSamplerEnabled_ = false;
  delay(1);
  configurePiezoInputPin(config_.piezoPin);
  analogReadResolution(12);
  setAdcAttenuationDb(config_.piezoPin, config_.piezoAdcAttenDb);

  uint32_t baselineAccum = 0;
  static constexpr uint8_t kBootSamples = 40;
  for (uint8_t i = 0; i < kBootSamples; ++i) {
    const uint16_t raw = static_cast<uint16_t>(analogRead(config_.piezoPin));
    baselineAccum += raw;
    delayMicroseconds(140);
  }

  piezo_.configured = true;
  piezo_.calibrated = false;
  piezo_.baseline = static_cast<float>(baselineAccum) / static_cast<float>(kBootSamples);
  piezo_.env = 0.0f;
  piezo_.peak = 0.0f;
  piezo_.noiseFloor = 0.0f;
  piezo_.threshold = max(kPiezoMinThreshold, config_.piezoHitThreshold);
  piezo_.rectified = 0.0f;
  piezo_.lastRaw = static_cast<uint16_t>(piezo_.baseline);
  piezo_.calibrateStartedMs = millis();
  piezo_.calibrateSamples = 0;
  piezo_.calibrateNoiseAccum = 0.0;
  piezo_.lastHitMs = 0;

  piezoEngine_.reset(static_cast<uint16_t>(piezo_.baseline));
  const PiezoConfig piezoCfg = composePiezoConfigModel();
  piezoEngine_.applyConfig(piezoCfg);
  piezoSamplerPin_ = config_.piezoPin;
  piezoSamplerIntervalUs_ =
      max<uint16_t>(45U, static_cast<uint16_t>(1000000UL / max<uint16_t>(1, piezoCfg.sampleRateHz)));
  resetPiezoSampleQueue();
  resetPiezoScopeBuffers();
  ensurePiezoSamplerTask();
  piezoSamplerEnabled_ = true;

  Serial.printf("[IRDR][PIEZO] adc_ready pin=%d atten_db=%u baseline=%.1f threshold=%.1f calib_ms=%u\n",
                static_cast<int>(config_.piezoPin),
                static_cast<unsigned>(config_.piezoAdcAttenDb),
                piezo_.baseline,
                piezo_.threshold,
                static_cast<unsigned>(config_.piezoCalibrationMs));
}

void IRDrumsApp::piezoSamplerEntry(void* arg) {
  auto* self = static_cast<IRDrumsApp*>(arg);
  if (self != nullptr) {
    self->piezoSamplerLoop();
  }
  vTaskDelete(nullptr);
}

void IRDrumsApp::ensurePiezoSamplerTask() {
  if (piezoSamplerTask_ != nullptr) {
    return;
  }

  TaskHandle_t task = nullptr;
  BaseType_t ok = xTaskCreatePinnedToCore(&IRDrumsApp::piezoSamplerEntry, "IRPiezoSampler", 4096, this, 2, &task, 0);
  if (ok != pdPASS) {
    ok = xTaskCreate(&IRDrumsApp::piezoSamplerEntry, "IRPiezoSampler", 4096, this, 2, &task);
  }
  if (ok == pdPASS) {
    piezoSamplerTask_ = task;
    Serial.println("[IRDR][PIEZO] sampler task started");
  } else {
    Serial.println("[IRDR][PIEZO] sampler task create failed");
  }
}

void IRDrumsApp::resetPiezoSampleQueue() {
  taskENTER_CRITICAL(&piezoQueueLock_);
  piezoQueueHead_ = 0;
  piezoQueueTail_ = 0;
  piezoQueueDropped_ = 0;
  taskEXIT_CRITICAL(&piezoQueueLock_);
}

void IRDrumsApp::resetPiezoScopeBuffers() {
  taskENTER_CRITICAL(&piezoScopeLock_);
  memset(piezoScopeFast_, 0, sizeof(piezoScopeFast_));
  piezoScopeFastHead_ = 0;
  piezoScopeFastCount_ = 0;
  piezoScopeFastAccum_ = 0;
  piezoScopeFastAccumCount_ = 0;
  memset(piezoScopeSlow_, 0, sizeof(piezoScopeSlow_));
  piezoScopeSlowHead_ = 0;
  piezoScopeSlowCount_ = 0;
  piezoScopeSlowAccum_ = 0;
  piezoScopeSlowAccumCount_ = 0;
  taskEXIT_CRITICAL(&piezoScopeLock_);
}

void IRDrumsApp::recordPiezoScopeSample(uint16_t raw) {
  taskENTER_CRITICAL(&piezoScopeLock_);

  piezoScopeFastAccum_ += raw;
  piezoScopeFastAccumCount_++;
  if (piezoScopeFastAccumCount_ >= kPiezoScopeFastDecimation) {
    const uint16_t averaged = static_cast<uint16_t>(piezoScopeFastAccum_ / piezoScopeFastAccumCount_);
    piezoScopeFast_[piezoScopeFastHead_] = averaged;
    piezoScopeFastHead_ = (piezoScopeFastHead_ + 1U) % kPiezoScopePoints;
    if (piezoScopeFastCount_ < kPiezoScopePoints) {
      piezoScopeFastCount_++;
    }
    piezoScopeFastAccum_ = 0;
    piezoScopeFastAccumCount_ = 0;
  }

  piezoScopeSlowAccum_ += raw;
  piezoScopeSlowAccumCount_++;
  if (piezoScopeSlowAccumCount_ >= kPiezoScopeSlowDecimation) {
    const uint16_t averaged = static_cast<uint16_t>(piezoScopeSlowAccum_ / piezoScopeSlowAccumCount_);
    piezoScopeSlow_[piezoScopeSlowHead_] = averaged;
    piezoScopeSlowHead_ = (piezoScopeSlowHead_ + 1U) % kPiezoScopePoints;
    if (piezoScopeSlowCount_ < kPiezoScopePoints) {
      piezoScopeSlowCount_++;
    }
    piezoScopeSlowAccum_ = 0;
    piezoScopeSlowAccumCount_ = 0;
  }

  taskEXIT_CRITICAL(&piezoScopeLock_);
}

bool IRDrumsApp::popPiezoSample(uint16_t& raw, uint32_t& sampleUs) {
  bool ok = false;
  taskENTER_CRITICAL(&piezoQueueLock_);
  if (piezoQueueHead_ != piezoQueueTail_) {
    raw = piezoQueueRaw_[piezoQueueTail_];
    sampleUs = piezoQueueUs_[piezoQueueTail_];
    piezoQueueTail_ = (piezoQueueTail_ + 1U) % kPiezoQueueSize;
    ok = true;
  }
  taskEXIT_CRITICAL(&piezoQueueLock_);
  return ok;
}

void IRDrumsApp::piezoSamplerLoop() {
  uint32_t nextSampleUs = micros();
  uint16_t samplesSinceYield = 0;
  for (;;) {
    if (!piezoSamplerEnabled_) {
      vTaskDelay(1);
      nextSampleUs = micros();
      samplesSinceYield = 0;
      continue;
    }

    const int8_t pin = piezoSamplerPin_;
    const uint16_t samplerIntervalUs = piezoSamplerIntervalUs_;
    const uint16_t intervalUs = (samplerIntervalUs < 45U) ? 45U : samplerIntervalUs;
    if (pin < 0) {
      vTaskDelay(1);
      continue;
    }

    const uint32_t nowUs = micros();
    if (static_cast<int32_t>(nowUs - nextSampleUs) < 0) {
      const uint32_t waitUs = nextSampleUs - nowUs;
      if (waitUs > 1200U) {
        vTaskDelay(1);
      } else {
        delayMicroseconds(min<uint32_t>(200U, waitUs));
      }
      continue;
    }

    const uint16_t raw = static_cast<uint16_t>(analogRead(pin));
    recordPiezoScopeSample(raw);
    taskENTER_CRITICAL(&piezoQueueLock_);
    const uint16_t nextHead = (piezoQueueHead_ + 1U) % kPiezoQueueSize;
    if (nextHead == piezoQueueTail_) {
      piezoQueueTail_ = (piezoQueueTail_ + 1U) % kPiezoQueueSize;
      piezoQueueDropped_++;
    }
    piezoQueueRaw_[piezoQueueHead_] = raw;
    piezoQueueUs_[piezoQueueHead_] = nowUs;
    piezoQueueHead_ = nextHead;
    taskEXIT_CRITICAL(&piezoQueueLock_);

    nextSampleUs += intervalUs;
    if (static_cast<int32_t>(nowUs - nextSampleUs) > static_cast<int32_t>(intervalUs * 8UL)) {
      nextSampleUs = nowUs + intervalUs;
    }

    samplesSinceYield++;
    if (samplesSinceYield >= 96U) {
      // Prevent task watchdog resets by periodically yielding to idle tasks.
      vTaskDelay(1);
      nextSampleUs = micros() + intervalUs;
      samplesSinceYield = 0;
    }
  }
}

void IRDrumsApp::processButtons() {
  if (M5.BtnA.wasClicked()) {
    armed_ = !armed_;
  }

  if (M5.BtnB.wasReleased()) {
    const uint32_t nowMs = millis();
    if (nowMs - btnBLastReleaseMs_ <= kButtonMultiClickWindowMs) {
      btnBClickCount_++;
    } else {
      btnBClickCount_ = 1;
    }
    btnBLastReleaseMs_ = nowMs;
  }
}

void IRDrumsApp::processAssignmentClickWindow() {
  if (btnBClickCount_ == 0) {
    return;
  }

  const uint32_t nowMs = millis();
  if (nowMs - btnBLastReleaseMs_ <= kButtonMultiClickWindowMs) {
    return;
  }

  const uint8_t clicks = btnBClickCount_;
  btnBClickCount_ = 0;

  if (clicks == 1) {
    uiPage_ = (uiPage_ + 1U) % kUiPages;
    return;
  }

  if (clicks == 2) {
    confirmPendingAssignment();
    return;
  }

  if (clicks >= 3) {
    pendingAssignment_.active = false;
  }
}

void IRDrumsApp::confirmPendingAssignment() {
  if (!pendingAssignment_.active) {
    return;
  }

  const ScannerSnapshot snap = scanner_.snapshot();
  int8_t target = pendingAssignment_.requestedBeacon;
  if (target < 0) {
    target = snap.activeIndex;
  }

  if (target < 0 || target >= static_cast<int8_t>(config_.beaconCount)) {
    Serial.println("[IRDR] assign failed: no active beacon");
    return;
  }

  if (assignToBeacon(target, pendingAssignment_, 0)) {
    lastAssignedBeacon_ = target;
    lastAssignedAtMs_ = millis();
    pendingAssignment_.active = false;
    Serial.printf("[IRDR] assigned beacon=%d freq=%u note=%u\n", target, config_.slots[target].frequencyHz,
                  config_.slots[target].note);
  }
}

float IRDrumsApp::sensitivityScale() const {
  const float t = sensitivityLevelToUnit(config_.hitSensitivityLevel);
  // Level 1 = hard trigger, level 20 = very sensitive.
  return 1.50f - (1.15f * t);
}

uint16_t IRDrumsApp::computeRefractoryMs(float hitScore) const {
  const float normalized = clampf((hitScore - 0.85f) / 2.5f, 0.0f, 1.0f);
  const float factor = 0.38f + (2.25f * normalized);
  const uint16_t base = max<uint16_t>(10, config_.refractoryMs);
  const uint16_t refractory = static_cast<uint16_t>(roundf(static_cast<float>(base) * factor));
  return constrain(refractory, static_cast<uint16_t>(8), static_cast<uint16_t>(320));
}

HitProfile IRDrumsApp::classifyProfileForBeacon(int8_t beaconIndex) const {
  if (beaconIndex < 0 || beaconIndex >= static_cast<int8_t>(config_.beaconCount)) {
    return HitProfile::StickDrum;
  }

  const uint8_t note = config_.slots[beaconIndex].note;
  if (note == 35 || note == 36) {
    return HitProfile::FootKick;
  }
  if (note == 44) {
    return HitProfile::FootHat;
  }
  if (note == 42 || note == 46 || note >= 49) {
    return HitProfile::StickCymbal;
  }
  return HitProfile::StickDrum;
}

HitProfileTuning IRDrumsApp::composeProfileTuning(HitProfile profile) const {
  HitProfileTuning tuning;
  tuning.profile = profile;
  tuning.armScale = lookupSensitivityCurveF(kSensitivityArmScale, kSensitivityTableSize, config_.hitSensitivityLevel);
  tuning.triggerScale = lookupSensitivityCurveF(kSensitivityTriggerScale, kSensitivityTableSize, config_.hitSensitivityLevel);
  tuning.fallRatio = lookupSensitivityCurveF(kSensitivityFallRatio, kSensitivityTableSize, config_.hitSensitivityLevel);
  tuning.peakTimeoutMs = lookupSensitivityCurveU16(kSensitivityPeakTimeoutMs, kSensitivityTableSize, config_.hitSensitivityLevel);
  tuning.minGapMs = lookupSensitivityCurveU16(kSensitivityMinGapMs, kSensitivityTableSize, config_.hitSensitivityLevel);
  tuning.reboundThresholdScale = 1.0f;

  switch (profile) {
    case HitProfile::StickCymbal:
      tuning.code = hitProfileCode(profile);
      tuning.approachGyroWeight = 0.82f;
      tuning.approachAccelWeight = 0.18f;
      tuning.reboundGyroWeight = 0.84f;
      tuning.reboundAccelWeight = 0.16f;
      tuning.velocityGyroWeight = 0.82f;
      tuning.velocityAccelWeight = 0.18f;
      tuning.velocityGamma = 0.90f;
      tuning.velocityGyroRef = 145.0f;
      tuning.velocityAccelRef = 0.72f;
      tuning.fallRatio = max(0.58f, tuning.fallRatio - 0.03f);
      tuning.peakTimeoutMs = max<uint16_t>(32, static_cast<uint16_t>(tuning.peakTimeoutMs - 4));
      tuning.minGapMs = max<uint16_t>(10, static_cast<uint16_t>(tuning.minGapMs - 1));
      tuning.reboundThresholdScale = 0.92f;
      break;
    case HitProfile::FootKick:
      tuning.code = hitProfileCode(profile);
      tuning.approachGyroWeight = 0.45f;
      tuning.approachAccelWeight = 0.55f;
      tuning.reboundGyroWeight = 0.52f;
      tuning.reboundAccelWeight = 0.48f;
      tuning.velocityGyroWeight = 0.45f;
      tuning.velocityAccelWeight = 0.55f;
      tuning.velocityGamma = 1.00f;
      tuning.velocityGyroRef = 130.0f;
      tuning.velocityAccelRef = 1.05f;
      tuning.armScale *= 1.10f;
      tuning.triggerScale *= 1.08f;
      tuning.fallRatio = min(0.85f, tuning.fallRatio + 0.05f);
      tuning.peakTimeoutMs = static_cast<uint16_t>(tuning.peakTimeoutMs + 8);
      tuning.minGapMs = static_cast<uint16_t>(tuning.minGapMs + 6);
      tuning.reboundThresholdScale = 1.08f;
      break;
    case HitProfile::FootHat:
      tuning.code = hitProfileCode(profile);
      tuning.approachGyroWeight = 0.60f;
      tuning.approachAccelWeight = 0.40f;
      tuning.reboundGyroWeight = 0.66f;
      tuning.reboundAccelWeight = 0.34f;
      tuning.velocityGyroWeight = 0.60f;
      tuning.velocityAccelWeight = 0.40f;
      tuning.velocityGamma = 0.92f;
      tuning.velocityGyroRef = 140.0f;
      tuning.velocityAccelRef = 0.86f;
      tuning.armScale *= 1.04f;
      tuning.triggerScale *= 1.02f;
      tuning.peakTimeoutMs = static_cast<uint16_t>(tuning.peakTimeoutMs + 2);
      tuning.minGapMs = static_cast<uint16_t>(tuning.minGapMs + 3);
      tuning.reboundThresholdScale = 1.00f;
      break;
    case HitProfile::StickDrum:
    default:
      tuning.code = hitProfileCode(HitProfile::StickDrum);
      tuning.approachGyroWeight = 0.72f;
      tuning.approachAccelWeight = 0.28f;
      tuning.reboundGyroWeight = 0.75f;
      tuning.reboundAccelWeight = 0.25f;
      tuning.velocityGyroWeight = 0.70f;
      tuning.velocityAccelWeight = 0.30f;
      tuning.velocityGamma = 0.95f;
      tuning.velocityGyroRef = 170.0f;
      tuning.velocityAccelRef = 0.85f;
      break;
  }

  return tuning;
}

uint8_t IRDrumsApp::velocityFromDirectionalPeaks(float peakGyroDps, float peakAccelG, const HitProfileTuning& tuning,
                                                 const BeaconSlot& slot) const {
  const float vg = clampf(peakGyroDps / max(1.0f, tuning.velocityGyroRef), 0.0f, 2.0f);
  const float va = clampf(peakAccelG / max(0.02f, tuning.velocityAccelRef), 0.0f, 2.0f);
  const float energy = (tuning.velocityGyroWeight * vg * vg) + (tuning.velocityAccelWeight * va * va);
  const float normalized = clampf(energy / 1.6f, 0.0f, 1.0f);
  const float curved = powf(normalized, tuning.velocityGamma);
  const float velocitySpan = static_cast<float>(slot.velocityMax - slot.velocityMin);
  const float mapped = static_cast<float>(slot.velocityMin) + curved * velocitySpan;
  return static_cast<uint8_t>(constrain(static_cast<int>(roundf(mapped)), 1, 127));
}

bool IRDrumsApp::runStillnessCalibration(uint16_t durationMs) {
  const uint16_t samplePeriodMs = max<uint16_t>(1, kStillnessSamplePeriodMs);
  const uint16_t targetSamples = max<uint16_t>(40, durationMs / samplePeriodMs);
  float sumAx = 0.0f;
  float sumAy = 0.0f;
  float sumAz = 0.0f;
  float sumGx = 0.0f;
  float sumGy = 0.0f;
  float sumGz = 0.0f;
  float sumSqAx = 0.0f;
  float sumSqAy = 0.0f;
  float sumSqAz = 0.0f;
  float sumSqGx = 0.0f;
  float sumSqGy = 0.0f;
  float sumSqGz = 0.0f;
  uint16_t collected = 0;

  const uint32_t startMs = millis();
  while (collected < targetSamples) {
    float ax = 0.0f;
    float ay = 0.0f;
    float az = 0.0f;
    float gx = 0.0f;
    float gy = 0.0f;
    float gz = 0.0f;
    if (M5.Imu.getAccel(&ax, &ay, &az) && M5.Imu.getGyro(&gx, &gy, &gz)) {
      sumAx += ax;
      sumAy += ay;
      sumAz += az;
      sumGx += gx;
      sumGy += gy;
      sumGz += gz;
      sumSqAx += ax * ax;
      sumSqAy += ay * ay;
      sumSqAz += az * az;
      sumSqGx += gx * gx;
      sumSqGy += gy * gy;
      sumSqGz += gz * gz;
      collected++;
    }
    M5.update();
    delay(samplePeriodMs);
  }

  if (collected < 20) {
    return false;
  }

  const float invN = 1.0f / static_cast<float>(collected);
  const float meanAx = sumAx * invN;
  const float meanAy = sumAy * invN;
  const float meanAz = sumAz * invN;
  const float meanGx = sumGx * invN;
  const float meanGy = sumGy * invN;
  const float meanGz = sumGz * invN;

  auto variance = [](float sumSq, float mean, float invCount) {
    return max(0.0f, (sumSq * invCount) - (mean * mean));
  };

  const float varAx = variance(sumSqAx, meanAx, invN);
  const float varAy = variance(sumSqAy, meanAy, invN);
  const float varAz = variance(sumSqAz, meanAz, invN);
  const float varGx = variance(sumSqGx, meanGx, invN);
  const float varGy = variance(sumSqGy, meanGy, invN);
  const float varGz = variance(sumSqGz, meanGz, invN);

  gravityX_ = meanAx;
  gravityY_ = meanAy;
  gravityZ_ = meanAz;
  gravityReady_ = true;

  gyroBiasX_ = meanGx;
  gyroBiasY_ = meanGy;
  gyroBiasZ_ = meanGz;

  noiseFloorAccelG_ = max(0.01f, sqrtf(varAx + varAy + varAz));
  noiseFloorGyroDps_ = max(0.4f, sqrtf(varGx + varGy + varGz));
  stillnessCalibrated_ = true;

  Serial.printf("[IRDR][CAL] stillness ok samples=%u dur=%lu ax=%.3f ay=%.3f az=%.3f gx=%.2f gy=%.2f gz=%.2f na=%.4f ng=%.3f\n",
                static_cast<unsigned>(collected),
                static_cast<unsigned long>(millis() - startMs),
                gravityX_, gravityY_, gravityZ_,
                gyroBiasX_, gyroBiasY_, gyroBiasZ_,
                noiseFloorAccelG_, noiseFloorGyroDps_);
  return true;
}

void IRDrumsApp::updateTargetTracking(const ScannerSnapshot& snap, uint32_t nowMs) {
  const int8_t nextLive = snap.activeIndex;
  if (nextLive != liveTargetBeacon_) {
    if (liveTargetBeacon_ >= 0 && nextLive >= 0) {
      liveTargetSwitchCount_++;
    }
    liveTargetBeacon_ = nextLive;
    liveTargetStableSinceMs_ = nowMs;
  }

  if (liveTargetBeacon_ < 0) {
    liveTargetStableMs_ = 0;
    liveTargetConfident_ = 0;
    return;
  }

  const uint32_t stableMs = nowMs - liveTargetStableSinceMs_;
  liveTargetStableMs_ = static_cast<uint16_t>(min<uint32_t>(stableMs, 65535U));
  const bool confident = snap.activeLatched != 0 &&
                         snap.activeIndex == liveTargetBeacon_ &&
                         snap.confidence >= kMinTargetConfidence &&
                         snap.peakToNoise >= 1.05f;
  liveTargetConfident_ = confident ? 1 : 0;
}

bool IRDrumsApp::canArmOnLiveTarget() const {
  return liveTargetBeacon_ >= 0 &&
         liveTargetConfident_ != 0 &&
         liveTargetStableMs_ >= kMinTargetStableMs;
}

void IRDrumsApp::processSensorsAndHit() {
  const uint32_t nowMs = millis();
  const ScannerSnapshot snap = scanner_.snapshot();
  latestScannerSnapshot_ = snap;
  updateTargetTracking(snap, nowMs);
  activeProfile_ = classifyProfileForBeacon(liveTargetBeacon_ >= 0 ? liveTargetBeacon_ : lastHitBeacon_);

  if (piezoEngine_.stats().state == PiezoState::Scan && frozenStrokeTargetBeacon_ >= 0 &&
      liveTargetBeacon_ >= 0 && liveTargetBeacon_ != frozenStrokeTargetBeacon_) {
    beaconSwitchDuringScan_ = 1;
  }

  processImuRefinement(nowMs);
  processPiezoHit(snap, nowMs);
}

void IRDrumsApp::processImuRefinement(uint32_t nowMs) {
  if (!imuRefinementAvailable_) {
    lastLinearAccelG_ *= 0.94f;
    lastGyroDps_ *= 0.94f;
    projectedGyroDps_ *= 0.92f;
    projectedAccelG_ *= 0.92f;
    return;
  }

  float ax = 0.0f;
  float ay = 0.0f;
  float az = 0.0f;
  float gx = 0.0f;
  float gy = 0.0f;
  float gz = 0.0f;

  if (!M5.Imu.getAccel(&ax, &ay, &az) || !M5.Imu.getGyro(&gx, &gy, &gz)) {
    imuReadFailCount_++;
    if (imuReadFailCount_ == 1) {
      Serial.println("[IRDR][IMU] read failed, running piezo-only trigger path");
    }
    if (imuReadFailCount_ > 10U) {
      imuRefinementAvailable_ = false;
      Serial.println("[IRDR][IMU] refinement disabled after repeated read failures");
    }
    return;
  }

  imuReadFailCount_ = 0;
  imuLastOkMs_ = nowMs;
  gx -= gyroBiasX_;
  gy -= gyroBiasY_;
  gz -= gyroBiasZ_;

  if (!gravityReady_) {
    gravityX_ = ax;
    gravityY_ = ay;
    gravityZ_ = az;
    gravityReady_ = true;
  }

  float linX = ax - gravityX_;
  float linY = ay - gravityY_;
  float linZ = az - gravityZ_;
  const float gyroNorm = vectorNorm3(gx, gy, gz);
  const float linearMotion = vectorNorm3(linX, linY, linZ);
  const float gravityAlpha = (linearMotion < 0.14f && gyroNorm < 35.0f) ? 0.030f : 0.002f;
  gravityX_ += gravityAlpha * (ax - gravityX_);
  gravityY_ += gravityAlpha * (ay - gravityY_);
  gravityZ_ += gravityAlpha * (az - gravityZ_);

  linX = ax - gravityX_;
  linY = ay - gravityY_;
  linZ = az - gravityZ_;
  const float linearAccel = vectorNorm3(linX, linY, linZ);

  lastLinearAccelG_ = linearAccel;
  lastGyroDps_ = gyroNorm;
  imuPeakLinearAccel_ = max(imuPeakLinearAccel_ * 0.92f, linearAccel);
  imuPeakGyroDps_ = max(imuPeakGyroDps_ * 0.92f, gyroNorm);

  float axisValues[3] = {gx, gy, gz};
  int8_t dominantAxis = 0;
  float dominantAbs = fabsf(axisValues[0]);
  for (int8_t axis = 1; axis < 3; ++axis) {
    const float currentAbs = fabsf(axisValues[axis]);
    if (currentAbs > dominantAbs) {
      dominantAbs = currentAbs;
      dominantAxis = axis;
    }
  }
  attackAxisIndex_ = dominantAxis;
  attackAxisSign_ = axisValues[dominantAxis] >= 0.0f ? 1.0f : -1.0f;

  projectedGyroDps_ = attackAxisSign_ * componentByAxis(gx, gy, gz, attackAxisIndex_);
  projectedAccelG_ = attackAxisSign_ * componentByAxis(linX, linY, linZ, attackAxisIndex_);
}

int8_t IRDrumsApp::resolveHitTarget(const ScannerSnapshot& snap) const {
  if (canArmOnLiveTarget()) {
    return liveTargetBeacon_;
  }

  if (snap.activeIndex >= 0 &&
      snap.activeLatched &&
      snap.confidence >= (kMinTargetConfidence * 0.70f) &&
      snap.peakToNoise >= 1.12f) {
    return snap.activeIndex;
  }

  if (liveTargetBeacon_ >= 0 &&
      snap.confidence >= (kMinTargetConfidence * 0.55f) &&
      snap.peakToNoise >= 1.10f) {
    return liveTargetBeacon_;
  }

  if (snap.winnerIndex >= 0 &&
      snap.winnerMagnitude >= max(1.2f, snap.dynamicMinMagnitude * 1.12f) &&
      snap.peakToNoise >= 1.26f &&
      snap.winnerShare >= 0.66f &&
      snap.confidence >= (kMinTargetConfidence * 0.90f)) {
    return snap.winnerIndex;
  }

  return -1;
}

PiezoTargetSnapshot IRDrumsApp::freezePiezoTargetStatic(void* userData) {
  if (!userData) {
    return PiezoTargetSnapshot{};
  }
  return static_cast<IRDrumsApp*>(userData)->freezePiezoTarget();
}

bool IRDrumsApp::commitPiezoHitStatic(void* userData, const PiezoTargetSnapshot& frozenTarget, uint8_t velocity, uint16_t peak) {
  if (!userData) {
    return false;
  }
  return static_cast<IRDrumsApp*>(userData)->commitPiezoHit(frozenTarget, velocity, peak);
}

PiezoTargetSnapshot IRDrumsApp::freezePiezoTarget() {
  PiezoTargetSnapshot frozen {};
  const int8_t selectedTarget = resolveHitTarget(latestScannerSnapshot_);
  frozen.targetId = selectedTarget;
  frozen.confidence = latestScannerSnapshot_.confidence;
  frozen.stableMs = liveTargetStableMs_;
  frozen.aux0 = latestScannerSnapshot_.winnerMagnitude;
  frozen.aux1 = latestScannerSnapshot_.peakToNoise;

  frozenStrokeTargetBeacon_ = selectedTarget;
  frozenTargetArmedAtMs_ = millis();
  frozenTargetConfidenceAtScan_ = latestScannerSnapshot_.confidence;
  beaconSwitchDuringScan_ = 0;
  return frozen;
}

bool IRDrumsApp::commitPiezoHit(const PiezoTargetSnapshot& frozenTarget, uint8_t velocity, uint16_t peak) {
  const uint32_t nowMs = millis();
  if (!armed_ || nowMs < protocolMuteUntilMs_) {
    lastRejectReason_ = static_cast<uint8_t>(RejectReason::CandidateDrop);
    totalRejectCount_++;
    return false;
  }

  const int8_t selected = static_cast<int8_t>(frozenTarget.targetId);
  if (selected < 0 || selected >= static_cast<int8_t>(config_.beaconCount)) {
    lastRejectReason_ = static_cast<uint8_t>(RejectReason::TargetLost);
    totalRejectCount_++;
    return false;
  }

  BeaconSlot& slot = config_.slots[selected];
  if (!slot.enabled) {
    lastRejectReason_ = static_cast<uint8_t>(RejectReason::WeakPeak);
    totalRejectCount_++;
    return false;
  }

  const uint8_t mappedVelocity = static_cast<uint8_t>(constrain(static_cast<int>(velocity), static_cast<int>(slot.velocityMin),
                                                                static_cast<int>(slot.velocityMax)));
  midi_.sendNoteOn(slot.channel, slot.note, mappedVelocity);
  totalHitCount_++;

  if (config_.sendNoteOff) {
    scheduleNoteOff(slot.channel, slot.note, mappedVelocity, config_.noteLengthMs);
  }

  lastHitBeacon_ = selected;
  lastHitNote_ = slot.note;
  lastHitVelocity_ = mappedVelocity;
  lastHitAtMs_ = nowMs;
  piezo_.lastHitMs = nowMs;
  lastRefractoryMs_ = constrain(config_.piezoRefractoryMs, static_cast<uint16_t>(2), static_cast<uint16_t>(80));
  refractoryUntilMs_ = nowMs + lastRefractoryMs_;
  lastTriggerReason_ = static_cast<uint8_t>(TriggerReason::PeakFall);
  lastRejectReason_ = static_cast<uint8_t>(RejectReason::None);
  strokePeakScore_ = peak;
  lastStrokePeakScore_ = peak;
  strokePeakAccelG_ = imuPeakLinearAccel_;
  strokePeakGyroDps_ = imuPeakGyroDps_;
  imuPeakLinearAccel_ = 0.0f;
  imuPeakGyroDps_ = 0.0f;
  lastImpactScore_ = peak;
  piezoCommittedThisTick_ = true;

  Serial.printf("[IRDR][PIEZO][HIT] t=%lu st=%s peak=%u vel=%u tgt=%d conf=%.2f sw=%u\n",
                static_cast<unsigned long>(nowMs),
                PiezoHitEngine::stateToken(piezoEngine_.stats().state),
                static_cast<unsigned>(peak),
                static_cast<unsigned>(mappedVelocity),
                static_cast<int>(selected),
                frozenTarget.confidence,
                static_cast<unsigned>(beaconSwitchDuringScan_));
  return true;
}

bool IRDrumsApp::processPiezoHit(const ScannerSnapshot& snap, uint32_t nowMs) {
  (void)nowMs;
  if (!piezo_.configured) {
    configurePiezoAdc();
  }

  latestScannerSnapshot_ = snap;
  piezoEngine_.applyConfig(composePiezoConfigModel());

  piezoCommittedThisTick_ = false;
  const uint8_t samplesPerTick = constrain(config_.piezoSamplesPerTick, static_cast<uint8_t>(8), static_cast<uint8_t>(128));
  const bool useMedianFilter = piezoInputFilterUsesMedian(piezoInputFilterMode_);
  if (!useMedianFilter) {
    piezoMedianCount_ = 0;
  }
  const uint16_t maxConsume = max<uint16_t>(32U, static_cast<uint16_t>(samplesPerTick) * 4U);
  uint16_t consumed = 0;
  uint16_t raw = 0;
  uint32_t sampleUs = 0;
  while (consumed < maxConsume && popPiezoSample(raw, sampleUs)) {
    uint16_t engineSample = raw;
    if (useMedianFilter) {
      piezoMedianHistory_[0] = piezoMedianHistory_[1];
      piezoMedianHistory_[1] = piezoMedianHistory_[2];
      piezoMedianHistory_[2] = raw;
      piezoMedianCount_ = min<uint8_t>(3, static_cast<uint8_t>(piezoMedianCount_ + 1));
      if (piezoMedianCount_ >= 3) {
        engineSample = median3u16(piezoMedianHistory_[0], piezoMedianHistory_[1], piezoMedianHistory_[2]);
      }
    }

    piezo_.lastRaw = engineSample;
    piezoEngine_.updateSample(engineSample, sampleUs, this, &IRDrumsApp::freezePiezoTargetStatic, &IRDrumsApp::commitPiezoHitStatic);
    consumed++;
  }

  if (consumed == 0) {
    raw = static_cast<uint16_t>(analogRead(config_.piezoPin));
    uint16_t engineSample = raw;
    if (useMedianFilter) {
      piezoMedianHistory_[0] = piezoMedianHistory_[1];
      piezoMedianHistory_[1] = piezoMedianHistory_[2];
      piezoMedianHistory_[2] = raw;
      piezoMedianCount_ = min<uint8_t>(3, static_cast<uint8_t>(piezoMedianCount_ + 1));
      if (piezoMedianCount_ >= 3) {
        engineSample = median3u16(piezoMedianHistory_[0], piezoMedianHistory_[1], piezoMedianHistory_[2]);
      }
    }
    piezo_.lastRaw = engineSample;
    piezoEngine_.updateSample(engineSample, micros(), this, &IRDrumsApp::freezePiezoTargetStatic, &IRDrumsApp::commitPiezoHitStatic);
  }

  const PiezoStats& pz = piezoEngine_.stats();
  piezo_.peak = pz.scanPeak;
  piezo_.env = pz.envelope;
  piezo_.threshold = pz.threshold;
  piezo_.noiseFloor = pz.noise;
  piezo_.rectified = pz.rectified;
  approachScoreFilt_ = pz.envelope / max(1.0f, pz.threshold);
  reboundScoreFilt_ = pz.threshold > 0.0f ? (static_cast<float>(pz.scanPeak) / pz.threshold) : 0.0f;

  if (!armed_) {
    strokePhase_ = StrokePhase::Idle;
    strokeTracking_ = false;
  } else {
    switch (pz.state) {
      case PiezoState::Idle:
        strokePhase_ = StrokePhase::Idle;
        strokeTracking_ = false;
        break;
      case PiezoState::Scan:
        strokePhase_ = StrokePhase::Candidate;
        strokeTracking_ = true;
        break;
      case PiezoState::Mask:
        strokePhase_ = StrokePhase::TriggeredRecovery;
        strokeTracking_ = false;
        break;
      case PiezoState::WaitQuiet:
      default:
        strokePhase_ = StrokePhase::Approach;
        strokeTracking_ = false;
        break;
    }
  }

  return piezoCommittedThisTick_;
}

void IRDrumsApp::scheduleNoteOff(uint8_t channel, uint8_t note, uint8_t velocity, uint16_t afterMs) {
  for (PendingNote& pending : noteOffQueue_) {
    if (pending.active) {
      continue;
    }
    pending.active = true;
    pending.channel = channel;
    pending.note = note;
    pending.velocity = velocity;
    pending.offAtMs = millis() + afterMs;
    return;
  }

  // Queue saturated fallback.
  midi_.sendNoteOff(channel, note, velocity);
}

void IRDrumsApp::processNoteOffQueue() {
  const uint32_t nowMs = millis();
  if (nowMs < protocolMuteUntilMs_) {
    return;
  }

  for (PendingNote& pending : noteOffQueue_) {
    if (!pending.active || nowMs < pending.offAtMs) {
      continue;
    }

    midi_.sendNoteOff(pending.channel, pending.note, pending.velocity);
    pending.active = false;
  }
}

void IRDrumsApp::drawHeader(const ScannerSnapshot&) {
  M5.Display.fillRect(0, 0, 80, 16, TFT_DARKGREY);
  M5.Display.setTextColor(TFT_WHITE, TFT_DARKGREY);
  M5.Display.setTextSize(1);
  M5.Display.setCursor(2, 4);
  M5.Display.printf("IRD P%u", static_cast<unsigned>(uiPage_));
  M5.Display.setCursor(45, 4);
  if (!powerTelemetryEnabled_) {
    M5.Display.printf("BAT--");
  } else {
    M5.Display.printf("%u%%", M5.Power.getBatteryLevel());
  }
}

void IRDrumsApp::drawPageMain(const ScannerSnapshot& snap) {
  M5.Display.fillRect(0, 16, 80, 144, TFT_BLACK);
  M5.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5.Display.setTextSize(1);

  const int active = snap.activeIndex;
  const uint16_t activeFreq = (active >= 0 && active < snap.beaconCount) ? snap.frequenciesHz[active] : 0;

  M5.Display.setCursor(2, 20);
  M5.Display.printf("ARM:%s BLE:%s", armed_ ? "ON" : "OFF", midi_.isConnected() ? "ON" : "OFF");
  M5.Display.setCursor(2, 32);
  M5.Display.printf("ACT:%d F:%u", active, activeFreq);
  M5.Display.setCursor(2, 44);
  M5.Display.printf("CF:%3u%% LT:%s", static_cast<unsigned>(roundf(snap.confidence * 100.0f)),
                    snap.activeLatched ? "ON" : "OFF");

  if (active >= 0 && active < config_.beaconCount) {
    const BeaconSlot& slot = config_.slots[active];
    M5.Display.setCursor(2, 56);
    M5.Display.printf("N:%u C:%u", slot.note, slot.channel);
    M5.Display.setCursor(2, 68);
    M5.Display.printf("%s", slot.label);
  } else {
    M5.Display.setCursor(2, 56);
    M5.Display.printf("NO ACTIVE BEACON");
  }

  M5.Display.setCursor(2, 80);
  M5.Display.printf("PZ E:%3.0f T:%3.0f", piezo_.env, piezo_.threshold);
  M5.Display.setCursor(2, 92);
  M5.Display.printf("RAW:%4u NF:%2.1f", static_cast<unsigned>(piezo_.lastRaw), piezo_.noiseFloor);
  M5.Display.setCursor(2, 104);
  M5.Display.printf("PH:%s LT:%d HS:PZ",
                    strokePhaseCode(strokePhase_),
                    liveTargetBeacon_);
  M5.Display.setCursor(2, 116);
  M5.Display.printf("IM:%s ST:%ums C:%u", imuRefinementAvailable_ ? "ON" : "OFF",
                    static_cast<unsigned>(liveTargetStableMs_),
                    static_cast<unsigned>(liveTargetConfident_));

  M5.Display.setCursor(2, 128);
  M5.Display.printf("HIT B:%d N:%u V:%u", lastHitBeacon_, lastHitNote_, lastHitVelocity_);

  const uint32_t nowMs = millis();
  const uint32_t cooldownMs = nowMs < refractoryUntilMs_ ? (refractoryUntilMs_ - nowMs) : 0;
  M5.Display.setCursor(2, 140);
  M5.Display.printf("T:%s R:%s C:%u",
                    triggerReasonCode(static_cast<TriggerReason>(lastTriggerReason_)),
                    rejectReasonCode(static_cast<RejectReason>(lastRejectReason_)),
                    static_cast<unsigned>(cooldownMs));

  M5.Display.setCursor(2, 150);
  if (pendingAssignment_.active) {
    M5.Display.printf("PEND N:%u C:%u", pendingAssignment_.note, pendingAssignment_.channel);
  } else if (lastAssignedBeacon_ >= 0 && (nowMs - lastAssignedAtMs_) < 2500) {
    M5.Display.printf("ASSIGNED B:%d", lastAssignedBeacon_);
  } else {
    M5.Display.printf("BtnA ARM/1xB page");
  }
}

void IRDrumsApp::updateSpectrogram(const ScannerSnapshot& snap) {
  if (snap.beaconCount == 0) {
    return;
  }

  if (snap.frameCount == lastSpectrogramFrameCount_) {
    return;
  }
  lastSpectrogramFrameCount_ = snap.frameCount;

  memmove(&spectrogram_[1][0],
          &spectrogram_[0][0],
          static_cast<size_t>(kSpectrogramRows - 1U) * static_cast<size_t>(kMaxBeacons));
  memset(&spectrogram_[0][0], 0, kMaxBeacons);

  const float top = max(1.0f, snap.topMagnitude[0]);
  spectrogramScale_ = max(top, spectrogramScale_ * 0.97f);
  spectrogramScale_ = max(1.0f, spectrogramScale_);

  const float invScale = 1.0f / (spectrogramScale_ + 1e-6f);
  for (uint8_t i = 0; i < snap.beaconCount; ++i) {
    const float normalized = clampf(snap.magnitudes[i] * invScale, 0.0f, 1.6f);
    const float enhanced = sqrtf(normalized * (1.0f / 1.6f));
    const int value = static_cast<int>(roundf(enhanced * 255.0f));
    spectrogram_[0][i] = static_cast<uint8_t>(constrain(value, 0, 255));
  }
}

uint16_t IRDrumsApp::heatColor(uint8_t value) const {
  if (value < 6) {
    return TFT_BLACK;
  }

  uint8_t r = 0;
  uint8_t g = 0;
  uint8_t b = 0;
  if (value < 86) {
    g = static_cast<uint8_t>(value * 2U);
    b = static_cast<uint8_t>(40U + static_cast<uint8_t>(value * 2U));
  } else if (value < 171) {
    const uint8_t t = static_cast<uint8_t>(value - 86U);
    r = static_cast<uint8_t>(t * 3U);
    g = 255U;
    b = static_cast<uint8_t>(255U - t * 2U);
  } else {
    const uint8_t t = static_cast<uint8_t>(value - 171U);
    r = 255U;
    g = static_cast<uint8_t>(255U - min<uint16_t>(255U, static_cast<uint16_t>(t) * 3U));
    b = 0U;
  }

  return M5.Display.color565(r, g, b);
}

void IRDrumsApp::drawSpectrogram(const ScannerSnapshot& snap, int x, int y, int w, int h) {
  const int bins = max(1, static_cast<int>(snap.beaconCount));
  const int rowsToDraw = min(h, static_cast<int>(kSpectrogramRows));
  const float rowStep = static_cast<float>(kSpectrogramRows) / static_cast<float>(max(1, rowsToDraw));

  const int cellW = max(1, w / bins);
  const int usedW = cellW * bins;
  const int x0 = x + ((w - usedW) / 2);

  M5.Display.drawRect(x, y, w, h, TFT_DARKGREY);
  for (int dy = 0; dy < rowsToDraw; ++dy) {
    const int srcRow = min(static_cast<int>(kSpectrogramRows) - 1, static_cast<int>(floorf(static_cast<float>(dy) * rowStep)));
    for (int bin = 0; bin < bins; ++bin) {
      const uint8_t intensity = spectrogram_[srcRow][bin];
      M5.Display.fillRect(x0 + bin * cellW, y + dy, cellW, 1, heatColor(intensity));
    }
  }
}

void IRDrumsApp::drawPageSpectrum(const ScannerSnapshot& snap) {
  M5.Display.fillRect(0, 16, 80, 144, TFT_BLACK);
  M5.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5.Display.setTextSize(1);

  updateSpectrogram(snap);

  M5.Display.setCursor(2, 20);
  M5.Display.printf("Beacon spectrogram");
  M5.Display.setCursor(2, 30);
  M5.Display.printf("A:%d C:%d W:%d", snap.activeIndex, snap.candidateIndex, snap.winnerIndex);
  M5.Display.setCursor(2, 40);
  M5.Display.printf("CF:%2u PN:%2u", static_cast<unsigned>(roundf(snap.confidence * 100.0f)),
                    static_cast<unsigned>(roundf(snap.peakToNoise * 10.0f)));
  M5.Display.setCursor(2, 50);
  M5.Display.printf("MN:%.1f NF:%.1f", snap.dynamicMinMagnitude, snap.noiseFloor);

  drawSpectrogram(snap, 2, 62, 76, 92);

}

void IRDrumsApp::drawPageMapping(const ScannerSnapshot& snap) {
  M5.Display.fillRect(0, 16, 80, 144, TFT_BLACK);
  M5.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5.Display.setTextSize(1);

  M5.Display.setCursor(2, 20);
  M5.Display.printf("Mapping view");
  M5.Display.setCursor(2, 30);
  M5.Display.printf("A:%d C:%d W:%d", snap.activeIndex, snap.candidateIndex, snap.winnerIndex);

  const int8_t active = snap.activeIndex;
  if (active >= 0 && active < config_.beaconCount) {
    const BeaconSlot& slot = config_.slots[active];
    M5.Display.setCursor(2, 42);
    M5.Display.printf("B%u F%u", static_cast<unsigned>(active), slot.frequencyHz);
    M5.Display.setCursor(2, 54);
    M5.Display.printf("N%u C%u", slot.note, slot.channel);
    M5.Display.setCursor(2, 66);
    M5.Display.printf("%s", slot.label);
  } else {
    M5.Display.setCursor(2, 42);
    M5.Display.printf("Point at beacon...");
  }

  M5.Display.setCursor(2, 82);
  M5.Display.printf("Pending:");
  if (pendingAssignment_.active) {
    M5.Display.setCursor(2, 94);
    M5.Display.printf("N%u C%u %s", pendingAssignment_.note, pendingAssignment_.channel, pendingAssignment_.label);
    M5.Display.setCursor(2, 106);
    M5.Display.printf("2x BtnB = assign");
    M5.Display.setCursor(2, 118);
    M5.Display.printf("3x BtnB = cancel");
  } else {
    M5.Display.setCursor(2, 94);
    M5.Display.printf("No pending from app");
    M5.Display.setCursor(2, 106);
    M5.Display.printf("Send MapSelectReq");
  }

  M5.Display.setCursor(2, 130);
  M5.Display.printf("Slots:%u", config_.beaconCount);
  M5.Display.setCursor(2, 142);
  M5.Display.printf("PN:%2u CF:%2u", static_cast<unsigned>(roundf(snap.peakToNoise * 10.0f)),
                    static_cast<unsigned>(roundf(snap.confidence * 100.0f)));
}

void IRDrumsApp::drawPiezoScopeTrace(int x, int y, int w, int h, const uint16_t* samples, uint8_t count, uint16_t baseline,
                                     uint16_t color, uint16_t centerColor) {
  M5.Display.drawRect(x, y, w, h, TFT_DARKGREY);
  if (samples == nullptr || count < 2 || w < 3 || h < 3) {
    return;
  }

  const int innerX = x + 1;
  const int innerY = y + 1;
  const int innerW = w - 2;
  const int innerH = h - 2;
  const int centerY = innerY + (innerH / 2);
  M5.Display.drawFastHLine(innerX, centerY, innerW, centerColor);

  uint16_t maxDeviation = 24;
  for (uint8_t i = 0; i < count; ++i) {
    const int32_t delta = static_cast<int32_t>(samples[i]) - static_cast<int32_t>(baseline);
    maxDeviation = max<uint16_t>(maxDeviation, static_cast<uint16_t>(abs(delta)));
  }
  maxDeviation = min<uint16_t>(maxDeviation, 1800);

  const int usableHalfHeight = max(1, (innerH / 2) - 1);
  int prevX = innerX;
  int prevY = centerY;
  for (uint8_t i = 0; i < count; ++i) {
    const int pointX = innerX + ((static_cast<int>(i) * (innerW - 1)) / max(1, static_cast<int>(count) - 1));
    const int32_t delta = static_cast<int32_t>(samples[i]) - static_cast<int32_t>(baseline);
    const int32_t scaled = (delta * usableHalfHeight) / max<uint16_t>(1, maxDeviation);
    const int pointY = constrain(centerY - static_cast<int>(scaled), innerY, innerY + innerH - 1);
    if (i > 0) {
      M5.Display.drawLine(prevX, prevY, pointX, pointY, color);
    }
    prevX = pointX;
    prevY = pointY;
  }
}

void IRDrumsApp::drawPagePiezoScope(const ScannerSnapshot&) {
  M5.Display.fillRect(0, 16, 80, 144, TFT_BLACK);
  M5.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5.Display.setTextSize(1);

  uint16_t fastSamples[kPiezoScopePoints] {};
  uint16_t slowSamples[kPiezoScopePoints] {};
  uint8_t fastCount = 0;
  uint8_t slowCount = 0;

  taskENTER_CRITICAL(&piezoScopeLock_);
  fastCount = piezoScopeFastCount_;
  slowCount = piezoScopeSlowCount_;
  const uint8_t fastStart = (piezoScopeFastHead_ + kPiezoScopePoints - fastCount) % kPiezoScopePoints;
  const uint8_t slowStart = (piezoScopeSlowHead_ + kPiezoScopePoints - slowCount) % kPiezoScopePoints;
  for (uint8_t i = 0; i < fastCount; ++i) {
    fastSamples[i] = piezoScopeFast_[(fastStart + i) % kPiezoScopePoints];
  }
  for (uint8_t i = 0; i < slowCount; ++i) {
    slowSamples[i] = piezoScopeSlow_[(slowStart + i) % kPiezoScopePoints];
  }
  taskEXIT_CRITICAL(&piezoScopeLock_);

  uint32_t queueDropped = 0;
  taskENTER_CRITICAL(&piezoQueueLock_);
  queueDropped = piezoQueueDropped_;
  taskEXIT_CRITICAL(&piezoQueueLock_);

  const uint16_t baselineRaw = static_cast<uint16_t>(constrain(static_cast<int>(lroundf(piezo_.baseline)), 0, 4095));
  const uint16_t intervalUsSnapshot = piezoSamplerIntervalUs_;
  const uint16_t sampleIntervalUs = intervalUsSnapshot < 45U ? 45U : intervalUsSnapshot;
  const float baselineMv = adcCountsToMillivolts(static_cast<float>(baselineRaw), config_.piezoAdcAttenDb);
  const float rawMv = adcCountsToMillivolts(static_cast<float>(piezo_.lastRaw), config_.piezoAdcAttenDb);
  const float deltaMv = rawMv - baselineMv;
  const float fastPointMs = (static_cast<float>(sampleIntervalUs) * static_cast<float>(kPiezoScopeFastDecimation)) / 1000.0f;
  const float slowPointMs = (static_cast<float>(sampleIntervalUs) * static_cast<float>(kPiezoScopeSlowDecimation)) / 1000.0f;
  const float fastWindowMs = fastPointMs * static_cast<float>(max<uint8_t>(static_cast<uint8_t>(1), fastCount));
  const float slowWindowMs = slowPointMs * static_cast<float>(max<uint8_t>(static_cast<uint8_t>(1), slowCount));
  const char* filterToken = piezoInputFilterToken(piezoInputFilterMode_);
  const char* filterShort = "NG";
  if (strcmp(filterToken, "median3_guard") == 0) {
    filterShort = "M3G";
  } else if (strcmp(filterToken, "median3") == 0) {
    filterShort = "M3";
  } else if (strcmp(filterToken, "none") == 0) {
    filterShort = "OFF";
  }

  M5.Display.setCursor(2, 20);
  M5.Display.printf("Piezo scope");
  M5.Display.setCursor(2, 30);
  M5.Display.printf("d:%+4.0fmV", deltaMv);
  M5.Display.setCursor(2, 40);
  M5.Display.printf("E:%3.0f T:%3.0f", piezo_.env, piezo_.threshold);
  M5.Display.setCursor(2, 50);
  M5.Display.printf("N:%2.1f Q:%lu", piezo_.noiseFloor, static_cast<unsigned long>(queueDropped));
  M5.Display.setCursor(2, 58);
  M5.Display.printf("F%3.0f/%1.1f", fastWindowMs, fastPointMs);
  M5.Display.setCursor(44, 58);
  M5.Display.printf("S%3.0f/%1.1f", slowWindowMs, slowPointMs);
  M5.Display.setCursor(2, 150);
  M5.Display.printf("%s D%.0f R%.0f", filterShort, piezoDeadbandMv_, piezoRiseGuardMv_);

  drawPiezoScopeTrace(2, 66, 76, 40, fastSamples, fastCount, baselineRaw, TFT_GREEN, TFT_DARKGREY);
  drawPiezoScopeTrace(2, 108, 76, 40, slowSamples, slowCount, baselineRaw, TFT_CYAN, TFT_DARKGREY);
}

void IRDrumsApp::drawUi(bool force) {
  const uint32_t nowMs = millis();
  if (!force && (nowMs - lastUiDrawMs_) < kUiRefreshMs) {
    return;
  }

  const ScannerSnapshot snap = scanner_.snapshot();

  drawHeader(snap);
  switch (uiPage_) {
    case 0:
      drawPageMain(snap);
      break;
    case 1:
      drawPageSpectrum(snap);
      break;
    case 2:
      drawPageMapping(snap);
      break;
    case 3:
      drawPagePiezoScope(snap);
      break;
    default:
      drawPageMain(snap);
      break;
  }

  lastUiDrawMs_ = nowMs;
}

void IRDrumsApp::logHealth() {
  const uint32_t nowMs = millis();
  if (nowMs - lastHealthLogMs_ < kSerialHealthMs) {
    return;
  }

  const ScannerSnapshot snap = scanner_.snapshot();
  const PiezoStats& pzFsm = piezoEngine_.stats();
  Serial.printf("[IRDR][IR] phase=%s trg=%s rej=%s act=%d latch=%u win=%d cand=%d live=%d stable=%u confok=%u pz=%.1f th=%.1f pznf=%.2f pzraw=%u pzf=%s pre=%s pzpk=%u pzlv=%u imu=%u gp=%.1f apj=%.2f conf=%.2f dom=%.2f ws=%.2f pn=%.2f mn=%.2f nf=%.2f raw=%u/%u/%u fs=%.0f drop=%lu\n",
                strokePhaseCode(strokePhase_),
                triggerReasonCode(static_cast<TriggerReason>(lastTriggerReason_)),
                rejectReasonCode(static_cast<RejectReason>(lastRejectReason_)),
                snap.activeIndex, snap.activeLatched, snap.winnerIndex, snap.candidateIndex,
                liveTargetBeacon_, static_cast<unsigned>(liveTargetStableMs_),
                static_cast<unsigned>(liveTargetConfident_), piezo_.env, piezo_.threshold, piezo_.noiseFloor,
                static_cast<unsigned>(piezo_.lastRaw),
                PiezoHitEngine::stateToken(pzFsm.state),
                piezoPresetToken(config_.piezoPreset),
                static_cast<unsigned>(pzFsm.scanPeak),
                static_cast<unsigned>(pzFsm.lastVelocity),
                imuRefinementAvailable_ ? 1U : 0U, projectedGyroDps_,
                projectedAccelG_, snap.confidence, snap.dominance, snap.winnerShare,
                snap.peakToNoise, snap.dynamicMinMagnitude,
                snap.noiseFloor, snap.rawAdc, snap.rawMinAdc,
                snap.rawMaxAdc, snap.measuredSampleRateHz, static_cast<unsigned long>(snap.droppedCycles));

  lastHealthLogMs_ = nowMs;
}

void IRDrumsApp::makeDefaultConfig(IRDrumsConfig& out) {
  out = IRDrumsConfig{};
  out.magic = kConfigMagic;
  out.version = kConfigVersion;

  uidToken_.substring(0, 8).toCharArray(out.uid, sizeof(out.uid));
  if (strlen(out.uid) == 0) {
    strlcpy(out.uid, "00000000", sizeof(out.uid));
  }

  snprintf(out.deviceName, sizeof(out.deviceName), "IDRM-IR-%4.4s", out.uid);

  out.beaconCount = kDefaultBeaconCount;
  out.hitSensitivityLevel = 8;
  out.piezoPin = 32;
  out.piezoAdcAttenDb = 11;
  out.piezoSamplesPerTick = 32;
  out.piezoBaselineAlpha = 0.004f;
  out.piezoEnvDecay = 0.965f;
  out.piezoHitThreshold = 10.0f;
  out.piezoRefractoryMs = 14;
  out.piezoThresholdK = 3.4f;
  out.piezoThresholdMargin = 4.0f;
  out.piezoCalibrationMs = kDefaultPiezoCalibrationMs;
  out.piezoPreset = static_cast<uint8_t>(PiezoPreset::Default);
  out.powerTelemetryEnabled = 1;
  for (uint8_t i = 0; i < out.beaconCount; ++i) {
    out.slots[i].frequencyHz = kDefaultFrequencies[i];
    out.slots[i].note = kDefaultNotes[i];
    out.slots[i].channel = 9;
    out.slots[i].velocityMin = 20;
    out.slots[i].velocityMax = 127;
    out.slots[i].enabled = 1;
    strlcpy(out.slots[i].label, kDefaultLabels[i], sizeof(out.slots[i].label));
  }
}

bool IRDrumsApp::validateConfig(IRDrumsConfig& cfg) {
  if (cfg.magic != kConfigMagic || cfg.version != kConfigVersion) {
    return false;
  }

  cfg.aoPin = constrain(cfg.aoPin, static_cast<int8_t>(0), static_cast<int8_t>(39));
  cfg.doPin = constrain(cfg.doPin, static_cast<int8_t>(-1), static_cast<int8_t>(39));
  cfg.sampleRateHz = constrain(cfg.sampleRateHz, static_cast<uint16_t>(6200), static_cast<uint16_t>(14000));
  cfg.frameSamples = constrain(cfg.frameSamples, static_cast<uint16_t>(64), kMaxFrameSamples);
  cfg.smoothingAlpha = clampf(cfg.smoothingAlpha, 0.02f, 0.95f);
  cfg.confidenceThreshold = clampf(cfg.confidenceThreshold, 0.02f, 0.98f);
  cfg.dominanceThreshold = clampf(cfg.dominanceThreshold, 0.02f, 0.98f);
  cfg.winnerShareThreshold = clampf(cfg.winnerShareThreshold, 0.02f, 0.98f);
  cfg.minWinnerMagnitude = max(0.0f, cfg.minWinnerMagnitude);
  cfg.switchHoldMs = constrain(cfg.switchHoldMs, static_cast<uint16_t>(6), static_cast<uint16_t>(300));

  cfg.armAccelG = clampf(cfg.armAccelG, 0.10f, 4.0f);
  cfg.hitAccelG = clampf(cfg.hitAccelG, 0.20f, 8.0f);
  cfg.hitGyroDps = clampf(cfg.hitGyroDps, 40.0f, 1500.0f);
  cfg.releaseAccelG = clampf(cfg.releaseAccelG, 0.02f, 2.0f);
  cfg.refractoryMs = constrain(cfg.refractoryMs, static_cast<uint16_t>(8), static_cast<uint16_t>(250));
  cfg.hitSensitivityLevel = constrain(cfg.hitSensitivityLevel, kSensitivityMinLevel, kSensitivityMaxLevel);

  cfg.piezoPin = constrain(cfg.piezoPin, static_cast<int8_t>(32), static_cast<int8_t>(39));
  cfg.piezoAdcAttenDb = normalizeAdcAttenuationDb(constrain(cfg.piezoAdcAttenDb, static_cast<uint8_t>(0), static_cast<uint8_t>(11)));
  cfg.piezoSamplesPerTick = constrain(cfg.piezoSamplesPerTick, static_cast<uint8_t>(8), static_cast<uint8_t>(128));
  cfg.piezoBaselineAlpha = clampf(cfg.piezoBaselineAlpha, 0.0004f, 0.08f);
  cfg.piezoEnvDecay = clampf(cfg.piezoEnvDecay, 0.86f, 0.998f);
  cfg.piezoHitThreshold = clampf(cfg.piezoHitThreshold, kPiezoMinThreshold, 380.0f);
  cfg.piezoRefractoryMs = constrain(cfg.piezoRefractoryMs, static_cast<uint16_t>(6), static_cast<uint16_t>(320));
  cfg.piezoThresholdK = clampf(cfg.piezoThresholdK, 1.0f, 8.0f);
  cfg.piezoThresholdMargin = clampf(cfg.piezoThresholdMargin, 1.0f, 80.0f);
  cfg.piezoCalibrationMs = constrain(cfg.piezoCalibrationMs, static_cast<uint16_t>(300), static_cast<uint16_t>(3500));
  cfg.piezoPreset = constrain(cfg.piezoPreset, static_cast<uint8_t>(PiezoPreset::Default),
                              static_cast<uint8_t>(PiezoPreset::FastRolls));
  cfg.powerTelemetryEnabled = cfg.powerTelemetryEnabled ? 1 : 0;

  cfg.sendNoteOff = cfg.sendNoteOff ? 1 : 0;
  cfg.noteLengthMs = constrain(cfg.noteLengthMs, static_cast<uint16_t>(5), static_cast<uint16_t>(200));

  cfg.beaconCount = constrain(cfg.beaconCount, static_cast<uint8_t>(1), kMaxBeacons);
  for (uint8_t i = 0; i < cfg.beaconCount; ++i) {
    cfg.slots[i].frequencyHz = constrain(cfg.slots[i].frequencyHz, static_cast<uint16_t>(700), static_cast<uint16_t>(5600));
    cfg.slots[i].note = constrain(static_cast<int>(cfg.slots[i].note), 0, 127);
    cfg.slots[i].channel = constrain(static_cast<int>(cfg.slots[i].channel), 0, 15);
    cfg.slots[i].velocityMin = constrain(static_cast<int>(cfg.slots[i].velocityMin), 1, 127);
    cfg.slots[i].velocityMax = constrain(static_cast<int>(cfg.slots[i].velocityMax), static_cast<int>(cfg.slots[i].velocityMin), 127);
    cfg.slots[i].enabled = cfg.slots[i].enabled ? 1 : 0;
    if (cfg.slots[i].label[0] == '\0') {
      snprintf(cfg.slots[i].label, sizeof(cfg.slots[i].label), "B%u", static_cast<unsigned>(i));
    }
  }

  return true;
}

void IRDrumsApp::loadConfig() {
  Preferences pref;
  pref.begin(kPrefsNamespace, true);
  const size_t expected = sizeof(IRDrumsConfig);
  const size_t n = pref.getBytesLength("cfg");
  if (n == expected) {
    IRDrumsConfig loaded;
    const size_t read = pref.getBytes("cfg", &loaded, sizeof(loaded));
    if (read == expected && validateConfig(loaded)) {
      config_ = loaded;
      pref.end();
      return;
    }
  }

  pref.end();
  makeDefaultConfig(config_);
}

bool IRDrumsApp::saveConfig() {
  Preferences pref;
  if (!pref.begin(kPrefsNamespace, false)) {
    return false;
  }

  const size_t written = pref.putBytes("cfg", &config_, sizeof(config_));
  pref.end();
  return written == sizeof(config_);
}

String IRDrumsApp::detectUid() const {
  const uint64_t mac = ESP.getEfuseMac();
  char uid[9] {};
  snprintf(uid, sizeof(uid), "%08llX", static_cast<unsigned long long>(mac & 0xFFFFFFFFULL));
  return String(uid);
}

IRDrumsApp* IRDrumsApp::instance_ = nullptr;
IRDrumsApp gApp;

}  // namespace

void setup() {
  gApp.begin();
}

void loop() {
  gApp.tick();
}
