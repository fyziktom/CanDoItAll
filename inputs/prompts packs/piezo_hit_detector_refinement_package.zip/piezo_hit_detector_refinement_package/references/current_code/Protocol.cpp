#include "Protocol.h"

namespace idrm {

uint8_t Protocol::crc7(const uint8_t* data, size_t length) {
  if (!data || length == 0) {
    return 0;
  }

  uint8_t crc = 0;
  for (size_t index = 0; index < length; ++index) {
    crc ^= (data[index] & 0x7F);
  }
  return crc & 0x7F;
}

uint8_t Protocol::crc7(const String& text) {
  return crc7(reinterpret_cast<const uint8_t*>(text.c_str()), text.length());
}

bool Protocol::parseFrame(const uint8_t* data, size_t length, SysExFrame& outFrame) {
  if (!data || length < 14) {
    return false;
  }
  if (data[0] != 0xF0 || data[length - 1] != 0xF7) {
    return false;
  }
  if (data[1] != kSysExManufacturerDev) {
    return false;
  }
  if (data[2] != 'I' || data[3] != 'D' || data[4] != 'R' || data[5] != 'M') {
    return false;
  }

  const uint8_t expectedCrc = data[length - 2] & 0x7F;
  const uint8_t actualCrc = crc7(&data[1], length - 3);
  if (expectedCrc != actualCrc) {
    return false;
  }

  outFrame.protoMajor = data[6] & 0x7F;
  outFrame.protoMinor = data[7] & 0x7F;
  outFrame.sequence = data[8] & 0x7F;
  outFrame.type = static_cast<MsgType>(data[9] & 0x7F);
  outFrame.chunkIndex = data[10] & 0x7F;
  outFrame.chunkCount = data[11] & 0x7F;
  outFrame.payload = "";

  for (size_t index = 12; index + 2 < length; ++index) {
    const uint8_t value = data[index] & 0x7F;
    if (value > 0x7F) {
      return false;
    }
    outFrame.payload += static_cast<char>(value);
  }

  return outFrame.chunkCount >= 1;
}

size_t Protocol::buildFrame(uint8_t sequence, MsgType type, uint8_t chunkIndex, uint8_t chunkCount,
                            const String& payload, uint8_t* outBuffer, size_t outBufferSize) {
  if (!outBuffer) {
    return 0;
  }

  const size_t payloadSize = payload.length();
  const size_t totalSize = 1 + 1 + 4 + 1 + 1 + 1 + 1 + 1 + 1 + payloadSize + 1 + 1;
  if (outBufferSize < totalSize) {
    return 0;
  }

  size_t index = 0;
  outBuffer[index++] = 0xF0;
  outBuffer[index++] = kSysExManufacturerDev;
  outBuffer[index++] = 'I';
  outBuffer[index++] = 'D';
  outBuffer[index++] = 'R';
  outBuffer[index++] = 'M';
  outBuffer[index++] = kProtoMajor;
  outBuffer[index++] = kProtoMinor;
  outBuffer[index++] = sequence & 0x7F;
  outBuffer[index++] = static_cast<uint8_t>(type) & 0x7F;
  outBuffer[index++] = chunkIndex & 0x7F;
  outBuffer[index++] = max<uint8_t>(1, chunkCount & 0x7F);

  for (size_t payloadIndex = 0; payloadIndex < payloadSize; ++payloadIndex) {
    outBuffer[index++] = static_cast<uint8_t>(payload[payloadIndex]) & 0x7F;
  }

  // Compute CRC on bytes [manufacturer..payload] before appending CRC itself.
  const uint8_t frameCrc = crc7(&outBuffer[1], index - 1);
  outBuffer[index++] = frameCrc;
  outBuffer[index++] = 0xF7;
  return index;
}

}  // namespace idrm
