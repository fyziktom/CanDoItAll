using System.Text.Json.Serialization;

namespace Zyphonote.InvisibleDrums.Protocol;

public enum IdrmPortDirection
{
    Input = 0,
    Output = 1
}

public sealed record IdrmPortInfo(
    string Id,
    string Name,
    string Manufacturer,
    string State,
    string Connection,
    IdrmPortDirection Direction);

public sealed record IdrmRawMidiMessage(
    string SourcePortId,
    byte[] Data,
    double TimestampMs);

public interface IIdrmMidiTransport
{
    event EventHandler<IdrmRawMidiMessage>? RawMessageReceived;

    Task InitializeAsync(bool requestSysEx, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<IdrmPortInfo>> GetPortsAsync(CancellationToken cancellationToken = default);
    Task SubscribeInputsAsync(IReadOnlyCollection<string> inputPortIds, CancellationToken cancellationToken = default);
    Task UnsubscribeInputsAsync(IReadOnlyCollection<string> inputPortIds, CancellationToken cancellationToken = default);
    Task ClearAllInputSubscriptionsAsync(CancellationToken cancellationToken = default);
    Task SendAsync(string outputPortId, ReadOnlyMemory<byte> data, double? whenMs = null, CancellationToken cancellationToken = default);
}

public enum IdrmMsgType : byte
{
    HelloReq = 0x01,
    HelloResp = 0x02,
    GetCfgReq = 0x03,
    GetCfgResp = 0x04,
    SetCfgBegin = 0x05,
    SetCfgChunk = 0x06,
    SetCfgEnd = 0x07,
    SaveCfgReq = 0x08,
    SaveCfgResp = 0x09,
    CalibrateReq = 0x0A,
    CalibrateResp = 0x0B,
    ArmReq = 0x0C,
    ArmResp = 0x0D,
    Ping = 0x0E,
    Pong = 0x0F,
    StatsReq = 0x10,
    StatsResp = 0x11,
    FactoryResetReq = 0x12,
    FactoryResetResp = 0x13,
    Nack = 0x14,
    LogEvent = 0x15,
    PresetNameReq = 0x16,
    PresetNameResp = 0x17,
    MapSelectReq = 0x20,
    MapSelectResp = 0x21,
    MapListReq = 0x22,
    MapListResp = 0x23,
    SaveReq = 0x24,
    SaveResp = 0x25,
    SetFreqReq = 0x26,
    SetFreqResp = 0x27,
    SetSensitivityReq = 0x28,
    SetSensitivityResp = 0x29
}

public static class IdrmProtocolConstants
{
    public const byte ManufacturerId = 0x7D;
    public const byte ProtocolMajor = 1;
    public const byte ProtocolMinor = 0;
    public static ReadOnlySpan<byte> Magic => "IDRM"u8;
}

public sealed record IdrmSysExFrame(
    byte ProtoMajor,
    byte ProtoMinor,
    byte Sequence,
    IdrmMsgType Type,
    byte ChunkIndex,
    byte ChunkCount,
    string Payload);

public sealed record IdrmPortBinding(
    string InputPortId,
    string OutputPortId,
    string ModuleUid,
    string Role,
    string DeviceName,
    string FirmwareVersion,
    string Board,
    string? HitSource = null,
    int? Battery = null,
    int? BatteryAvailable = null,
    int? PiezoPin = null,
    string? PiezoPreset = null,
    IReadOnlyList<string>? Caps = null);

public class IdrmProtocolException : Exception
{
    public IdrmProtocolException(string message) : base(message)
    {
    }
}

public sealed class IdrmDeviceNackException : IdrmProtocolException
{
    public IdrmDeviceNackException(IdrmNackResponse nack)
        : base($"Device NACK: {nack.Err} {nack.Msg}".Trim())
    {
        Nack = nack;
    }

    public IdrmNackResponse Nack { get; }
}

public sealed class IdrmTimeoutException : IdrmProtocolException
{
    public IdrmTimeoutException(string message) : base(message)
    {
    }
}

public sealed record IdrmHelloResponse(
    [property: JsonPropertyName("uid")] string Uid,
    [property: JsonPropertyName("role")] string Role,
    [property: JsonPropertyName("name")] string? Name,
    [property: JsonPropertyName("fw")] string Firmware,
    [property: JsonPropertyName("board")] string Board,
    [property: JsonPropertyName("hit_src")] string? HitSource,
    [property: JsonPropertyName("caps")] IReadOnlyList<string>? Caps,
    [property: JsonPropertyName("piezo_pin")] int? PiezoPin,
    [property: JsonPropertyName("pz_preset")] string? PiezoPreset,
    [property: JsonPropertyName("batt_avail")] int? BatteryAvailable,
    [property: JsonPropertyName("batt")] int? Battery,
    [property: JsonPropertyName("reboot_req")] int? RebootRequired);

public sealed record IdrmNackResponse(
    [property: JsonPropertyName("ok")] int Ok,
    [property: JsonPropertyName("err")] string Err,
    [property: JsonPropertyName("msg")] string Msg);

public sealed record IdrmStatsResponse(
    [property: JsonPropertyName("ok")] int Ok,
    [property: JsonPropertyName("hits")] int? Hits,
    [property: JsonPropertyName("rej")] int? Rejected,
    [property: JsonPropertyName("ghost")] int? Ghost,
    [property: JsonPropertyName("recal")] int? Recal,
    [property: JsonPropertyName("heap")] int? Heap,
    [property: JsonPropertyName("rssi")] int? Rssi,
    [property: JsonPropertyName("phase")] string? Phase,
    [property: JsonPropertyName("profile")] string? Profile,
    [property: JsonPropertyName("live_tgt")] int? LiveTargetBeacon,
    [property: JsonPropertyName("frozen_tgt")] int? FrozenTargetBeacon,
    [property: JsonPropertyName("tgt_stable_ms")] int? TargetStableMs,
    [property: JsonPropertyName("tgt_conf")] int? TargetConfident,
    [property: JsonPropertyName("ap")] float? ApproachScore,
    [property: JsonPropertyName("rb")] float? ReboundScore,
    [property: JsonPropertyName("g_proj")] float? ProjectedGyro,
    [property: JsonPropertyName("a_proj")] float? ProjectedAccel,
    [property: JsonPropertyName("trg_reason")] string? TriggerReason,
    [property: JsonPropertyName("rej_reason")] string? RejectReason,
    [property: JsonPropertyName("cd_ms")] int? CooldownMs,
    [property: JsonPropertyName("conf")] float? Confidence,
    [property: JsonPropertyName("pn")] float? PeakToNoise,
    [property: JsonPropertyName("noise_a")] float? NoiseAccel,
    [property: JsonPropertyName("noise_g")] float? NoiseGyro,
    [property: JsonPropertyName("hit_src")] string? HitSource,
    [property: JsonPropertyName("live_zone")] int? LiveZone,
    [property: JsonPropertyName("frozen_zone")] int? FrozenZone,
    [property: JsonPropertyName("frozen_sw_scan")] int? FrozenSwitchDuringScan,
    [property: JsonPropertyName("pz_state")] string? PiezoState,
    [property: JsonPropertyName("pz_preset")] string? PiezoPreset,
    [property: JsonPropertyName("pz_raw")] int? PiezoRaw,
    [property: JsonPropertyName("pz_signal")] float? PiezoSignal,
    [property: JsonPropertyName("pz_deriv")] float? PiezoDerivative,
    [property: JsonPropertyName("pz_env")] float? PiezoEnvelope,
    [property: JsonPropertyName("pz_noise")] float? PiezoNoise,
    [property: JsonPropertyName("pz_thr")] float? PiezoThreshold,
    [property: JsonPropertyName("pz_peak")] int? PiezoPeak,
    [property: JsonPropertyName("pz_last_peak")] int? PiezoLastPeak,
    [property: JsonPropertyName("pz_last_vel")] int? PiezoLastVelocity,
    [property: JsonPropertyName("pz_mask_ms")] int? PiezoMaskMs,
    [property: JsonPropertyName("pz_quiet_ms")] int? PiezoQuietMs,
    [property: JsonPropertyName("pz_filter")] string? PiezoFilter,
    [property: JsonPropertyName("pz_adc_db")] int? PiezoAdcAttenuationDb,
    [property: JsonPropertyName("pz_deadband_mv")] float? PiezoDeadbandMv,
    [property: JsonPropertyName("pz_deadband_raw")] int? PiezoDeadbandRaw,
    [property: JsonPropertyName("pz_rise_guard_mv")] float? PiezoRiseGuardMv,
    [property: JsonPropertyName("pz_rise_guard_raw")] float? PiezoRiseGuardRaw,
    [property: JsonPropertyName("pz_positive_only")] int? PiezoPositiveOnly,
    [property: JsonPropertyName("pz_noise_alpha")] float? PiezoNoiseAlpha,
    [property: JsonPropertyName("pz_noise_scale")] float? PiezoNoiseScale,
    [property: JsonPropertyName("pz_quiet_thr")] float? PiezoQuietThreshold,
    [property: JsonPropertyName("pz_vel_min_peak")] float? PiezoVelocityPeakMin,
    [property: JsonPropertyName("pz_vel_ref_peak")] float? PiezoVelocityPeakRef,
    [property: JsonPropertyName("pz_vel_gamma")] float? PiezoVelocityGamma,
    [property: JsonPropertyName("pz_baseline_alpha")] float? PiezoBaselineAlpha,
    [property: JsonPropertyName("pz_env_decay")] float? PiezoEnvDecay,
    [property: JsonPropertyName("pz_samples_tick")] int? PiezoSamplesTick,
    [property: JsonPropertyName("pz_refractory_ms")] int? PiezoRefractoryMs,
    [property: JsonPropertyName("pz_hit_thr")] float? PiezoHitThreshold,
    [property: JsonPropertyName("pz_thr_margin")] float? PiezoThresholdMargin,
    [property: JsonPropertyName("pz_thr_k")] float? PiezoThresholdK,
    [property: JsonPropertyName("pz_rej_mask")] int? PiezoRejectMask,
    [property: JsonPropertyName("pz_rej_quiet")] int? PiezoRejectQuiet,
    [property: JsonPropertyName("pz_rej_rise")] int? PiezoRejectRise,
    [property: JsonPropertyName("batt_avail")] int? BatteryAvailable,
    [property: JsonPropertyName("batt")] int? Battery);

public sealed record IdrmMapSlot(
    [property: JsonPropertyName("idx")] int Index,
    [property: JsonPropertyName("freq")] int FrequencyHz,
    [property: JsonPropertyName("note")] int Note,
    [property: JsonPropertyName("ch")] int Channel,
    [property: JsonPropertyName("en")] int Enabled,
    [property: JsonPropertyName("name")] string? Name,
    [property: JsonPropertyName("mag")] float? Magnitude);

public sealed record IdrmMapListResponse(
    [property: JsonPropertyName("ok")] int Ok,
    [property: JsonPropertyName("beacon_count")] int BeaconCount,
    [property: JsonPropertyName("active")] int? ActiveBeacon,
    [property: JsonPropertyName("candidate")] int? CandidateBeacon,
    [property: JsonPropertyName("winner")] int? WinnerBeacon,
    [property: JsonPropertyName("live_tgt")] int? LiveTargetBeacon,
    [property: JsonPropertyName("frozen_tgt")] int? FrozenTargetBeacon,
    [property: JsonPropertyName("tgt_stable_ms")] int? TargetStableMs,
    [property: JsonPropertyName("tgt_conf")] int? TargetConfident,
    [property: JsonPropertyName("tgt_switch")] int? TargetSwitchCount,
    [property: JsonPropertyName("tgt_freeze_age")] int? TargetFreezeAgeMs,
    [property: JsonPropertyName("ap")] float? ApproachScore,
    [property: JsonPropertyName("rb")] float? ReboundScore,
    [property: JsonPropertyName("g_proj")] float? ProjectedGyro,
    [property: JsonPropertyName("a_proj")] float? ProjectedAccel,
    [property: JsonPropertyName("phase")] string? Phase,
    [property: JsonPropertyName("profile")] string? Profile,
    [property: JsonPropertyName("trg_reason")] string? TriggerReason,
    [property: JsonPropertyName("rej_reason")] string? RejectReason,
    [property: JsonPropertyName("cd_ms")] int? CooldownMs,
    [property: JsonPropertyName("cal")] int? Calibrated,
    [property: JsonPropertyName("noise_a")] float? NoiseAccel,
    [property: JsonPropertyName("noise_g")] float? NoiseGyro,
    [property: JsonPropertyName("conf")] float? Confidence,
    [property: JsonPropertyName("pn")] float? PeakToNoise,
    [property: JsonPropertyName("noise")] float? NoiseFloor,
    [property: JsonPropertyName("dyn_min")] float? DynamicMinMagnitude,
    [property: JsonPropertyName("sens")] int? SensitivityLevel,
    [property: JsonPropertyName("sens_max")] int? SensitivityMaxLevel,
    [property: JsonPropertyName("hit_src")] string? HitSource,
    [property: JsonPropertyName("pz_filter")] string? PiezoFilter,
    [property: JsonPropertyName("pz_adc_db")] int? PiezoAdcAttenuationDb,
    [property: JsonPropertyName("pz_deadband_mv")] float? PiezoDeadbandMv,
    [property: JsonPropertyName("pz_deadband_raw")] int? PiezoDeadbandRaw,
    [property: JsonPropertyName("pz_rise_guard_mv")] float? PiezoRiseGuardMv,
    [property: JsonPropertyName("pz_rise_guard_raw")] float? PiezoRiseGuardRaw,
    [property: JsonPropertyName("pz_positive_only")] int? PiezoPositiveOnly,
    [property: JsonPropertyName("pz_samples_tick")] int? PiezoSamplesTick,
    [property: JsonPropertyName("pz_refractory_ms")] int? PiezoRefractoryMs,
    [property: JsonPropertyName("pz_hit_thr")] float? PiezoHitThreshold,
    [property: JsonPropertyName("pz_thr_margin")] float? PiezoThresholdMargin,
    [property: JsonPropertyName("pz_thr_k")] float? PiezoThresholdK,
    [property: JsonPropertyName("caps")] IReadOnlyList<string>? Caps,
    [property: JsonPropertyName("piezo_pin")] int? PiezoPin,
    [property: JsonPropertyName("pz_preset")] string? PiezoPreset,
    [property: JsonPropertyName("live_zone")] int? LiveZone,
    [property: JsonPropertyName("frozen_zone")] int? FrozenZone,
    [property: JsonPropertyName("frozen_sw_scan")] int? FrozenSwitchDuringScan,
    [property: JsonPropertyName("pz_state")] string? PiezoState,
    [property: JsonPropertyName("pz_raw")] int? PiezoRaw,
    [property: JsonPropertyName("pz_env")] float? PiezoEnvelope,
    [property: JsonPropertyName("pz_noise")] float? PiezoNoise,
    [property: JsonPropertyName("pz_thr")] float? PiezoThreshold,
    [property: JsonPropertyName("pz_peak")] int? PiezoPeak,
    [property: JsonPropertyName("pz_last_peak")] int? PiezoLastPeak,
    [property: JsonPropertyName("pz_last_vel")] int? PiezoLastVelocity,
    [property: JsonPropertyName("pz_mask_ms")] int? PiezoMaskMs,
    [property: JsonPropertyName("pz_quiet_ms")] int? PiezoQuietMs,
    [property: JsonPropertyName("pz_rej_mask")] int? PiezoRejectMask,
    [property: JsonPropertyName("pz_rej_quiet")] int? PiezoRejectQuiet,
    [property: JsonPropertyName("batt_avail")] int? BatteryAvailable,
    [property: JsonPropertyName("batt")] int? Battery,
    [property: JsonPropertyName("slots")] IReadOnlyList<IdrmMapSlot>? Slots);

public sealed record IdrmMapSelectRequest(
    int Beacon,
    int Note,
    int Channel,
    int VelocityMin,
    int VelocityMax,
    string Name);

public sealed record IdrmMapSelectResponse(
    [property: JsonPropertyName("ok")] int Ok,
    [property: JsonPropertyName("pending")] int? Pending,
    [property: JsonPropertyName("beacon")] int? Beacon,
    [property: JsonPropertyName("freq")] int? FrequencyHz,
    [property: JsonPropertyName("note")] int? Note,
    [property: JsonPropertyName("ch")] int? Channel,
    [property: JsonPropertyName("label")] string? Label,
    [property: JsonPropertyName("hint")] string? Hint);

public sealed record IdrmSetFreqResponse(
    [property: JsonPropertyName("ok")] int Ok,
    [property: JsonPropertyName("count")] int? Count);

public sealed record IdrmSetSensitivityResponse(
    [property: JsonPropertyName("ok")] int Ok,
    [property: JsonPropertyName("level")] int? Level,
    [property: JsonPropertyName("level_max")] int? LevelMax,
    [property: JsonPropertyName("scale")] float? Scale,
    [property: JsonPropertyName("filter")] string? Filter,
    [property: JsonPropertyName("adc_db")] int? AdcAttenuationDb,
    [property: JsonPropertyName("hit_g")] float? HitAccelThreshold,
    [property: JsonPropertyName("hit_dps")] float? HitGyroThreshold,
    [property: JsonPropertyName("pz_thr")] float? PiezoThreshold,
    [property: JsonPropertyName("pz_floor")] float? PiezoThresholdFloor,
    [property: JsonPropertyName("pz_offset")] float? PiezoThresholdOffset,
    [property: JsonPropertyName("pz_noise_alpha")] float? PiezoNoiseAlpha,
    [property: JsonPropertyName("pz_noise_scale")] float? PiezoNoiseScale,
    [property: JsonPropertyName("pz_scan_ms")] float? PiezoScanMs,
    [property: JsonPropertyName("pz_mask_ms")] float? PiezoMaskMs,
    [property: JsonPropertyName("pz_quiet_ms")] float? PiezoQuietMs,
    [property: JsonPropertyName("pz_quiet_thr")] float? PiezoQuietThreshold,
    [property: JsonPropertyName("pz_vel_min_peak")] float? PiezoVelocityPeakMin,
    [property: JsonPropertyName("pz_vel_ref_peak")] float? PiezoVelocityPeakRef,
    [property: JsonPropertyName("pz_vel_gamma")] float? PiezoVelocityGamma,
    [property: JsonPropertyName("pz_baseline_alpha")] float? PiezoBaselineAlpha,
    [property: JsonPropertyName("pz_env_decay")] float? PiezoEnvDecay,
    [property: JsonPropertyName("pz_deadband_mv")] float? PiezoDeadbandMv,
    [property: JsonPropertyName("pz_deadband_raw")] int? PiezoDeadbandRaw,
    [property: JsonPropertyName("pz_rise_guard_mv")] float? PiezoRiseGuardMv,
    [property: JsonPropertyName("pz_rise_guard_raw")] float? PiezoRiseGuardRaw,
    [property: JsonPropertyName("pz_positive_only")] int? PiezoPositiveOnly,
    [property: JsonPropertyName("pz_samples_tick")] int? PiezoSamplesTick,
    [property: JsonPropertyName("pz_refractory_ms")] int? PiezoRefractoryMs,
    [property: JsonPropertyName("pz_hit_thr")] float? PiezoHitThreshold,
    [property: JsonPropertyName("pz_thr_margin")] float? PiezoThresholdMargin,
    [property: JsonPropertyName("pz_thr_k")] float? PiezoThresholdK);

public sealed record IdrmRequestOptions(
    TimeSpan HelloTimeout,
    TimeSpan PingTimeout,
    TimeSpan ConfigReadTimeout,
    TimeSpan ConfigChunkAckTimeout,
    TimeSpan CalibrateDefaultTimeout,
    TimeSpan StatsTimeout)
{
    public static IdrmRequestOptions Default { get; } = new(
        HelloTimeout: TimeSpan.FromMilliseconds(1400),
        PingTimeout: TimeSpan.FromMilliseconds(800),
        ConfigReadTimeout: TimeSpan.FromMilliseconds(4200),
        ConfigChunkAckTimeout: TimeSpan.FromMilliseconds(1000),
        CalibrateDefaultTimeout: TimeSpan.FromMilliseconds(3000),
        StatsTimeout: TimeSpan.FromMilliseconds(1500));
}

public sealed record IdrmGroupOperationResult(
    string ModuleUid,
    bool Ok,
    string? Error);
