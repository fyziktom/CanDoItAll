using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text.Json;

namespace Zyphonote.InvisibleDrums.Protocol;

public interface IIdrmDeviceClient
{
    IdrmPortBinding Binding { get; }

    Task<IdrmHelloResponse> HelloAsync(CancellationToken cancellationToken = default);
    Task<JsonDocument> PingAsync(CancellationToken cancellationToken = default);
    Task<string> GetConfigJsonAsync(CancellationToken cancellationToken = default);
    Task SetConfigJsonAsync(string asciiJson, bool apply, CancellationToken cancellationToken = default);
    Task SaveConfigAsync(CancellationToken cancellationToken = default);
    Task<JsonDocument> CalibrateAsync(ushort delayMs, ushort windowMs, CancellationToken cancellationToken = default);
    Task SetArmedAsync(bool armed, CancellationToken cancellationToken = default);
    Task<IdrmStatsResponse> GetStatsAsync(CancellationToken cancellationToken = default);
    Task FactoryResetAsync(CancellationToken cancellationToken = default);
    Task<string> GetPresetNameAsync(CancellationToken cancellationToken = default);
    Task<IdrmMapListResponse> GetMapListAsync(CancellationToken cancellationToken = default);
    Task<IdrmMapSelectResponse> MapSelectAsync(IdrmMapSelectRequest request, CancellationToken cancellationToken = default);
    Task<IdrmSetFreqResponse> SetFrequenciesAsync(IReadOnlyCollection<ushort> frequenciesHz, CancellationToken cancellationToken = default);
    Task<IdrmSetSensitivityResponse> SetSensitivityAsync(
        byte level,
        string? filter = null,
        byte? adcDb = null,
        IReadOnlyDictionary<string, object?>? advanced = null,
        bool resetPiezoTune = false,
        CancellationToken cancellationToken = default);
}

public sealed class IdrmDeviceClient : IIdrmDeviceClient, IDisposable
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    private readonly IIdrmMidiTransport transport;
    private readonly IdrmChunkAssembler chunkAssembler = new();
    private readonly ConcurrentDictionary<byte, PendingRequest> pendingBySequence = new();
    private readonly object sequenceLock = new();
    private readonly IdrmRequestOptions requestOptions;
    private byte nextSequence;
    private bool disposed;

    public IdrmDeviceClient(IIdrmMidiTransport transport, IdrmPortBinding binding, IdrmRequestOptions? requestOptions = null)
    {
        this.transport = transport ?? throw new ArgumentNullException(nameof(transport));
        Binding = binding ?? throw new ArgumentNullException(nameof(binding));
        this.requestOptions = requestOptions ?? IdrmRequestOptions.Default;
        this.transport.RawMessageReceived += OnRawMessageReceived;
    }

    public IdrmPortBinding Binding { get; }

    public async Task<IdrmHelloResponse> HelloAsync(CancellationToken cancellationToken = default)
    {
        var frame = await SendAndAwaitAsync(
            requestType: IdrmMsgType.HelloReq,
            expectedResponseTypes: [IdrmMsgType.HelloResp],
            payload: "{\"q\":\"hello\"}",
            timeout: requestOptions.HelloTimeout,
            cancellationToken).ConfigureAwait(false);

        return DeserializeRequired<IdrmHelloResponse>(frame.Payload, "hello_response_parse_failed");
    }

    public Task<JsonDocument> PingAsync(CancellationToken cancellationToken = default)
    {
        return SendAndParseJsonAsync(
            requestType: IdrmMsgType.Ping,
            expectedResponseType: IdrmMsgType.Pong,
            payload: "{\"ok\":1}",
            timeout: requestOptions.PingTimeout,
            cancellationToken);
    }

    public async Task<string> GetConfigJsonAsync(CancellationToken cancellationToken = default)
    {
        const int maxAttempts = 3;
        Exception? lastException = null;

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            try
            {
                var frame = await SendAndAwaitAsync(
                    requestType: IdrmMsgType.GetCfgReq,
                    expectedResponseTypes: [IdrmMsgType.GetCfgResp],
                    payload: "{\"q\":\"cfg\"}",
                    timeout: requestOptions.ConfigReadTimeout,
                    cancellationToken).ConfigureAwait(false);
                return frame.Payload;
            }
            catch (IdrmTimeoutException exception) when (attempt < maxAttempts)
            {
                lastException = exception;
                await Task.Delay(70, cancellationToken).ConfigureAwait(false);
            }
            catch (IdrmProtocolException exception) when (attempt < maxAttempts &&
                                                          exception.Message.Contains("chunk_", StringComparison.Ordinal))
            {
                lastException = exception;
                await Task.Delay(70, cancellationToken).ConfigureAwait(false);
            }
        }

        throw lastException ?? new IdrmProtocolException("config_read_failed");
    }

    public async Task SetConfigJsonAsync(string asciiJson, bool apply, CancellationToken cancellationToken = default)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(asciiJson);
        IdrmProtocolCodec.EnsureAscii(asciiJson);

        var payloadLength = asciiJson.Length;
        var payloadCrcHex = IdrmProtocolCodec.ComputePayloadCrc7(asciiJson).ToString("X2");
        var beginPayload = JsonSerializer.Serialize(new
        {
            len = payloadLength,
            crc = payloadCrcHex,
            schema = "module-v1"
        });

        _ = await SendAndAwaitAsync(
            requestType: IdrmMsgType.SetCfgBegin,
            expectedResponseTypes: [IdrmMsgType.SetCfgBegin],
            payload: beginPayload,
            timeout: requestOptions.ConfigChunkAckTimeout,
            cancellationToken).ConfigureAwait(false);

        const int chunkSize = 32;
        var chunkCount = (int)Math.Ceiling(asciiJson.Length / (double)chunkSize);
        if (chunkCount == 0)
        {
            chunkCount = 1;
        }

        for (var chunkIndex = 0; chunkIndex < chunkCount; chunkIndex++)
        {
            var start = chunkIndex * chunkSize;
            var length = Math.Min(chunkSize, asciiJson.Length - start);
            var chunkData = length > 0 ? asciiJson.Substring(start, length) : string.Empty;
            var chunkPayload = JsonSerializer.Serialize(new { d = chunkData });

            _ = await SendAndAwaitAsync(
                requestType: IdrmMsgType.SetCfgChunk,
                expectedResponseTypes: [IdrmMsgType.SetCfgChunk],
                payload: chunkPayload,
                timeout: requestOptions.ConfigChunkAckTimeout,
                cancellationToken,
                chunkIndex: (byte)chunkIndex,
                chunkCount: (byte)chunkCount).ConfigureAwait(false);
        }

        var endPayload = JsonSerializer.Serialize(new { apply = apply ? 1 : 0 });
        _ = await SendAndAwaitAsync(
            requestType: IdrmMsgType.SetCfgEnd,
            expectedResponseTypes: [IdrmMsgType.SetCfgEnd],
            payload: endPayload,
            timeout: requestOptions.ConfigChunkAckTimeout,
            cancellationToken).ConfigureAwait(false);
    }

    public async Task SaveConfigAsync(CancellationToken cancellationToken = default)
    {
        _ = await SendAndAwaitAsync(
            requestType: IdrmMsgType.SaveCfgReq,
            expectedResponseTypes: [IdrmMsgType.SaveCfgResp, IdrmMsgType.SaveResp],
            payload: "{\"save\":1}",
            timeout: requestOptions.ConfigChunkAckTimeout,
            cancellationToken).ConfigureAwait(false);
    }

    public Task<JsonDocument> CalibrateAsync(ushort delayMs, ushort windowMs, CancellationToken cancellationToken = default)
    {
        var payload = JsonSerializer.Serialize(new
        {
            mode = "neutral",
            delay_ms = delayMs,
            window_ms = windowMs
        });

        var timeout = TimeSpan.FromMilliseconds(delayMs + windowMs + 1200);
        if (timeout < requestOptions.CalibrateDefaultTimeout)
        {
            timeout = requestOptions.CalibrateDefaultTimeout;
        }

        return SendAndParseJsonAsync(
            requestType: IdrmMsgType.CalibrateReq,
            expectedResponseType: IdrmMsgType.CalibrateResp,
            payload: payload,
            timeout: timeout,
            cancellationToken);
    }

    public async Task SetArmedAsync(bool armed, CancellationToken cancellationToken = default)
    {
        var payload = JsonSerializer.Serialize(new { armed = armed ? 1 : 0 });
        _ = await SendAndAwaitAsync(
            requestType: IdrmMsgType.ArmReq,
            expectedResponseTypes: [IdrmMsgType.ArmResp],
            payload: payload,
            timeout: requestOptions.PingTimeout,
            cancellationToken).ConfigureAwait(false);
    }

    public async Task<IdrmStatsResponse> GetStatsAsync(CancellationToken cancellationToken = default)
    {
        var frame = await SendAndAwaitAsync(
            requestType: IdrmMsgType.StatsReq,
            expectedResponseTypes: [IdrmMsgType.StatsResp],
            payload: "{\"q\":\"stats\"}",
            timeout: requestOptions.StatsTimeout,
            cancellationToken).ConfigureAwait(false);
        return DeserializeRequired<IdrmStatsResponse>(frame.Payload, "stats_parse_failed");
    }

    public async Task FactoryResetAsync(CancellationToken cancellationToken = default)
    {
        _ = await SendAndAwaitAsync(
            requestType: IdrmMsgType.FactoryResetReq,
            expectedResponseTypes: [IdrmMsgType.FactoryResetResp],
            payload: "{\"reset\":1}",
            timeout: requestOptions.ConfigChunkAckTimeout,
            cancellationToken).ConfigureAwait(false);
    }

    public async Task<string> GetPresetNameAsync(CancellationToken cancellationToken = default)
    {
        var frame = await SendAndAwaitAsync(
            requestType: IdrmMsgType.PresetNameReq,
            expectedResponseTypes: [IdrmMsgType.PresetNameResp],
            payload: "{\"q\":\"name\"}",
            timeout: requestOptions.ConfigReadTimeout,
            cancellationToken).ConfigureAwait(false);
        return frame.Payload;
    }

    public async Task<IdrmMapListResponse> GetMapListAsync(CancellationToken cancellationToken = default)
    {
        const int maxAttempts = 3;
        Exception? lastException = null;

        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            try
            {
                var frame = await SendAndAwaitAsync(
                    requestType: IdrmMsgType.MapListReq,
                    expectedResponseTypes: [IdrmMsgType.MapListResp],
                    payload: "{\"q\":\"map\"}",
                    timeout: requestOptions.ConfigReadTimeout,
                    cancellationToken).ConfigureAwait(false);
                return DeserializeRequired<IdrmMapListResponse>(frame.Payload, "map_list_parse_failed");
            }
            catch (IdrmTimeoutException exception) when (attempt < maxAttempts)
            {
                lastException = exception;
                await Task.Delay(80, cancellationToken).ConfigureAwait(false);
            }
            catch (IdrmProtocolException exception) when (attempt < maxAttempts &&
                                                          exception.Message.Contains("chunk_", StringComparison.Ordinal))
            {
                lastException = exception;
                await Task.Delay(80, cancellationToken).ConfigureAwait(false);
            }
        }

        throw lastException ?? new IdrmProtocolException("map_list_failed");
    }

    public async Task<IdrmMapSelectResponse> MapSelectAsync(IdrmMapSelectRequest request, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(request);

        var payload = JsonSerializer.Serialize(new
        {
            beacon = request.Beacon,
            note = request.Note,
            ch = request.Channel,
            vel_min = request.VelocityMin,
            vel_max = request.VelocityMax,
            name = request.Name
        });

        var frame = await SendAndAwaitAsync(
            requestType: IdrmMsgType.MapSelectReq,
            expectedResponseTypes: [IdrmMsgType.MapSelectResp],
            payload: payload,
            timeout: requestOptions.ConfigChunkAckTimeout,
            cancellationToken).ConfigureAwait(false);
        return DeserializeRequired<IdrmMapSelectResponse>(frame.Payload, "map_select_parse_failed");
    }

    public async Task<IdrmSetFreqResponse> SetFrequenciesAsync(IReadOnlyCollection<ushort> frequenciesHz, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(frequenciesHz);
        if (frequenciesHz.Count == 0)
        {
            throw new ArgumentException("At least one frequency is required.", nameof(frequenciesHz));
        }

        var payload = JsonSerializer.Serialize(new
        {
            freqs = frequenciesHz
        });

        var frame = await SendAndAwaitAsync(
            requestType: IdrmMsgType.SetFreqReq,
            expectedResponseTypes: [IdrmMsgType.SetFreqResp],
            payload: payload,
            timeout: requestOptions.ConfigChunkAckTimeout,
            cancellationToken).ConfigureAwait(false);
        return DeserializeRequired<IdrmSetFreqResponse>(frame.Payload, "set_freq_parse_failed");
    }

    public async Task<IdrmSetSensitivityResponse> SetSensitivityAsync(
        byte level,
        string? filter = null,
        byte? adcDb = null,
        IReadOnlyDictionary<string, object?>? advanced = null,
        bool resetPiezoTune = false,
        CancellationToken cancellationToken = default)
    {
        var clampedLevel = Math.Clamp((int)level, 1, 20);
        var payloadModel = new Dictionary<string, object>
        {
            ["level"] = clampedLevel
        };

        if (!string.IsNullOrWhiteSpace(filter))
        {
            payloadModel["filter"] = filter.Trim().ToLowerInvariant();
        }

        if (adcDb.HasValue)
        {
            payloadModel["adc_db"] = Math.Clamp((int)adcDb.Value, 0, 11);
        }

        if (resetPiezoTune)
        {
            payloadModel["reset_pz_tune"] = 1;
        }

        if (advanced is not null)
        {
            foreach (var (key, value) in advanced)
            {
                if (string.IsNullOrWhiteSpace(key) || value is null)
                {
                    continue;
                }

                payloadModel[key] = value;
            }
        }

        var payload = JsonSerializer.Serialize(payloadModel);
        var timeout = requestOptions.ConfigChunkAckTimeout < TimeSpan.FromMilliseconds(1800)
            ? TimeSpan.FromMilliseconds(1800)
            : requestOptions.ConfigChunkAckTimeout;

        const int maxAttempts = 3;
        Exception? lastException = null;
        for (var attempt = 1; attempt <= maxAttempts; attempt++)
        {
            try
            {
                var frame = await SendAndAwaitAsync(
                    requestType: IdrmMsgType.SetSensitivityReq,
                    expectedResponseTypes: [IdrmMsgType.SetSensitivityResp],
                    payload: payload,
                    timeout: timeout,
                    cancellationToken).ConfigureAwait(false);
                return DeserializeRequired<IdrmSetSensitivityResponse>(frame.Payload, "set_sensitivity_parse_failed");
            }
            catch (IdrmTimeoutException exception) when (attempt < maxAttempts)
            {
                lastException = exception;
                await Task.Delay(80, cancellationToken).ConfigureAwait(false);
            }
            catch (IdrmProtocolException exception) when (attempt < maxAttempts &&
                                                          exception.Message.Contains("chunk_", StringComparison.Ordinal))
            {
                lastException = exception;
                await Task.Delay(80, cancellationToken).ConfigureAwait(false);
            }
        }

        throw lastException ?? new IdrmProtocolException("set_sensitivity_failed");
    }

    private async Task<JsonDocument> SendAndParseJsonAsync(
        IdrmMsgType requestType,
        IdrmMsgType expectedResponseType,
        string payload,
        TimeSpan timeout,
        CancellationToken cancellationToken)
    {
        var frame = await SendAndAwaitAsync(
            requestType,
            [expectedResponseType],
            payload,
            timeout,
            cancellationToken).ConfigureAwait(false);
        return JsonDocument.Parse(frame.Payload);
    }

    private async Task<IdrmSysExFrame> SendAndAwaitAsync(
        IdrmMsgType requestType,
        IReadOnlyCollection<IdrmMsgType> expectedResponseTypes,
        string payload,
        TimeSpan timeout,
        CancellationToken cancellationToken,
        byte chunkIndex = 0,
        byte chunkCount = 1)
    {
        ThrowIfDisposed();
        IdrmProtocolCodec.EnsureAscii(payload);

        var sequence = NextSequence();
        var request = new PendingRequest(expectedResponseTypes);
        if (!pendingBySequence.TryAdd(sequence, request))
        {
            throw new IdrmProtocolException("Failed to register pending request.");
        }

        try
        {
            var frame = new IdrmSysExFrame(
                ProtoMajor: IdrmProtocolConstants.ProtocolMajor,
                ProtoMinor: IdrmProtocolConstants.ProtocolMinor,
                Sequence: sequence,
                Type: requestType,
                ChunkIndex: chunkIndex,
                ChunkCount: chunkCount,
                Payload: payload);

            var bytes = IdrmProtocolCodec.BuildFrame(frame);
            await transport.SendAsync(Binding.OutputPortId, bytes, cancellationToken: cancellationToken).ConfigureAwait(false);

            using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            timeoutCts.CancelAfter(timeout);

            try
            {
                return await request.Completion.Task.WaitAsync(timeoutCts.Token).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (!cancellationToken.IsCancellationRequested)
            {
                throw new IdrmTimeoutException($"Timed out waiting for response {string.Join("/", expectedResponseTypes)}");
            }
        }
        finally
        {
            pendingBySequence.TryRemove(sequence, out _);
        }
    }

    private static T DeserializeRequired<T>(string payload, string errorCode)
    {
        try
        {
            var dto = JsonSerializer.Deserialize<T>(payload, JsonOptions);
            if (dto is null)
            {
                throw new IdrmProtocolException(errorCode);
            }
            return dto;
        }
        catch (JsonException exception)
        {
            throw new IdrmProtocolException($"{errorCode}: {exception.Message}");
        }
    }

    private void OnRawMessageReceived(object? sender, IdrmRawMidiMessage raw)
    {
        if (!string.Equals(raw.SourcePortId, Binding.InputPortId, StringComparison.Ordinal))
        {
            return;
        }

        if (!IdrmProtocolCodec.TryParseFrame(raw.Data, out var frame, out _))
        {
            return;
        }

        if (!pendingBySequence.TryGetValue(frame.Sequence, out var pending))
        {
            return;
        }

        if (frame.Type == IdrmMsgType.Nack)
        {
            try
            {
                var nack = DeserializeRequired<IdrmNackResponse>(frame.Payload, "nack_parse_failed");
                pending.Completion.TrySetException(new IdrmDeviceNackException(nack));
            }
            catch (Exception exception)
            {
                pending.Completion.TrySetException(exception);
            }
            return;
        }

        if (!pending.ExpectedResponseTypes.Contains(frame.Type))
        {
            return;
        }

        if (!chunkAssembler.TryAdd(raw.SourcePortId, frame, out var payload, out var chunkError))
        {
            if (!string.IsNullOrWhiteSpace(chunkError))
            {
                pending.Completion.TrySetException(new IdrmProtocolException(chunkError));
            }
            return;
        }

        if (payload is null)
        {
            return;
        }

        var assembled = frame with
        {
            ChunkIndex = 0,
            ChunkCount = 1,
            Payload = payload
        };

        pending.Completion.TrySetResult(assembled);
    }

    private byte NextSequence()
    {
        lock (sequenceLock)
        {
            var current = nextSequence;
            nextSequence = (byte)((nextSequence + 1) & 0x7F);
            return current;
        }
    }

    private void ThrowIfDisposed()
    {
        if (disposed)
        {
            throw new ObjectDisposedException(nameof(IdrmDeviceClient));
        }
    }

    public void Dispose()
    {
        if (disposed)
        {
            return;
        }

        transport.RawMessageReceived -= OnRawMessageReceived;
        disposed = true;
    }

    private sealed class PendingRequest
    {
        public PendingRequest(IReadOnlyCollection<IdrmMsgType> expectedResponseTypes)
        {
            ExpectedResponseTypes = expectedResponseTypes.ToHashSet();
            Completion = new TaskCompletionSource<IdrmSysExFrame>(TaskCreationOptions.RunContinuationsAsynchronously);
        }

        public HashSet<IdrmMsgType> ExpectedResponseTypes { get; }
        public TaskCompletionSource<IdrmSysExFrame> Completion { get; }
    }
}
