#pragma once

#include <Arduino.h>

namespace idrm {

enum class PiezoState : uint8_t {
  Idle = 0,
  Scan = 1,
  Mask = 2,
  WaitQuiet = 3,
};

enum class PiezoPreset : uint8_t {
  Default = 0,
  Soft = 1,
  HardMount = 2,
  FastRolls = 3,
};

struct PiezoTargetSnapshot {
  int16_t targetId {-1};
  float confidence {0.0f};
  float aux0 {0.0f};
  float aux1 {0.0f};
  uint32_t stableMs {0};
};

struct PiezoConfig {
  bool enabled {true};
  uint8_t presetId {static_cast<uint8_t>(PiezoPreset::Default)};
  int8_t pin {32};
  uint8_t adcAttenDb {11};
  uint16_t sampleRateHz {12000};
  float scanMs {2.5f};
  float maskMs {4.0f};
  float quietMs {1.5f};
  float thresholdFloor {28.0f};
  float thresholdOffset {12.0f};
  float noiseAlpha {0.02f};
  float noiseScale {5.5f};
  float quietThreshold {14.0f};
  float velocityPeakMin {35.0f};
  float velocityPeakRef {720.0f};
  float velocityGamma {0.78f};
  uint8_t velocityMin {1};
  uint8_t velocityMax {127};
  float baselineAlpha {0.002f};
  float envDecay {0.965f};
  uint16_t deadbandRaw {0};
  bool positiveOnly {false};
  float riseGuard {0.0f};
  bool powerTelemetryEnabled {true};
};

inline const char* piezoPresetToken(uint8_t presetId) {
  switch (static_cast<PiezoPreset>(presetId)) {
    case PiezoPreset::Soft:
      return "piezo_soft";
    case PiezoPreset::HardMount:
      return "piezo_hard_mount";
    case PiezoPreset::FastRolls:
      return "piezo_fast_rolls";
    case PiezoPreset::Default:
    default:
      return "piezo_default";
  }
}

inline void applyPiezoPreset(PiezoConfig& config, uint8_t presetId) {
  config.presetId = presetId;
  switch (static_cast<PiezoPreset>(presetId)) {
    case PiezoPreset::Soft:
      config.scanMs = 2.8f;
      config.maskMs = 4.4f;
      config.quietMs = 1.8f;
      config.thresholdFloor = 22.0f;
      config.thresholdOffset = 8.0f;
      config.noiseScale = 4.8f;
      config.velocityGamma = 0.72f;
      break;
    case PiezoPreset::HardMount:
      config.scanMs = 2.0f;
      config.maskMs = 5.2f;
      config.quietMs = 2.2f;
      config.thresholdFloor = 34.0f;
      config.thresholdOffset = 14.0f;
      config.noiseScale = 6.2f;
      config.velocityGamma = 0.86f;
      break;
    case PiezoPreset::FastRolls:
      config.scanMs = 1.8f;
      config.maskMs = 2.6f;
      config.quietMs = 1.0f;
      config.thresholdFloor = 26.0f;
      config.thresholdOffset = 10.0f;
      config.noiseScale = 5.0f;
      config.velocityGamma = 0.78f;
      break;
    case PiezoPreset::Default:
    default:
      config.scanMs = 2.5f;
      config.maskMs = 4.0f;
      config.quietMs = 1.5f;
      config.thresholdFloor = 28.0f;
      config.thresholdOffset = 12.0f;
      config.noiseScale = 5.5f;
      config.velocityGamma = 0.78f;
      break;
  }
}

struct PiezoStats {
  PiezoState state {PiezoState::Idle};
  uint16_t raw {0};
  int16_t centered {0};
  uint16_t rectified {0};
  float signal {0.0f};
  float derivative {0.0f};
  float envelope {0.0f};
  float noise {0.0f};
  float threshold {0.0f};
  uint16_t deadbandRaw {0};
  uint8_t positiveOnly {0};
  uint16_t scanPeak {0};
  uint16_t lastPeak {0};
  uint8_t lastVelocity {0};
  uint32_t hits {0};
  uint32_t retriggerRejects {0};
  uint32_t riseRejects {0};
  uint32_t quietRejects {0};
  uint32_t maskRejects {0};
  uint16_t scanAgeMs {0};
  uint16_t maskRemainingMs {0};
  uint16_t quietHoldMs {0};
};

using PiezoFreezeTargetFn = PiezoTargetSnapshot (*)(void* userData);
using PiezoCommitHitFn = bool (*)(void* userData, const PiezoTargetSnapshot& frozenTarget, uint8_t velocity, uint16_t peak);

class PiezoHitEngine {
 public:
  void reset(uint16_t baselineRaw = 2048);
  void applyConfig(const PiezoConfig& config);

  void updateSample(uint16_t raw, uint32_t nowUs, void* userData, PiezoFreezeTargetFn freezeTarget, PiezoCommitHitFn commitHit);

  const PiezoConfig& config() const;
  const PiezoStats& stats() const;
  const PiezoTargetSnapshot& frozenTarget() const;

  static const char* stateToken(PiezoState state);

 private:
  void enterState(PiezoState nextState, uint32_t nowUs);
  uint8_t mapVelocity(uint16_t peak) const;

  PiezoConfig config_ {};
  PiezoStats stats_ {};
  PiezoTargetSnapshot frozenTarget_ {};

  float baseline_ {2048.0f};
  float envelope_ {0.0f};
  float noise_ {0.0f};
  float lastSignal_ {0.0f};
  bool lastAboveThreshold_ {false};
  uint16_t scanPeak_ {0};
  uint32_t stateSinceUs_ {0};
  uint32_t scanStartUs_ {0};
  uint32_t maskUntilUs_ {0};
  uint32_t quietSinceUs_ {0};
  bool maskRejectLatched_ {false};
};

}  // namespace idrm
