#pragma once

#include <Arduino.h>

namespace idrm {

static constexpr uint8_t kProtoMajor = 1;
static constexpr uint8_t kProtoMinor = 0;
static constexpr char kProtoMagic[5] = "IDRM";
static constexpr uint8_t kSysExManufacturerDev = 0x7D;

enum class MsgType : uint8_t {
  HelloReq = 0x01,
  HelloResp = 0x02,
  GetCfgReq = 0x03,
  GetCfgResp = 0x04,
  SetCfgBegin = 0x05,
  SetCfgChunk = 0x06,
  SetCfgEnd = 0x07,
  SaveCfgReq = 0x08,
  SaveCfgResp = 0x09,
  CalibrateReq = 0x0A,
  CalibrateResp = 0x0B,
  ArmReq = 0x0C,
  ArmResp = 0x0D,
  Ping = 0x0E,
  Pong = 0x0F,
  StatsReq = 0x10,
  StatsResp = 0x11,
  FactoryResetReq = 0x12,
  FactoryResetResp = 0x13,
  Nack = 0x14,
  LogEvent = 0x15,
  PresetNameReq = 0x16,
  PresetNameResp = 0x17,
};

struct SysExFrame {
  uint8_t protoMajor {0};
  uint8_t protoMinor {0};
  uint8_t sequence {0};
  MsgType type {MsgType::Nack};
  uint8_t chunkIndex {0};
  uint8_t chunkCount {1};
  String payload {};
};

class Protocol {
 public:
  static uint8_t crc7(const uint8_t* data, size_t length);
  static uint8_t crc7(const String& text);
  static bool parseFrame(const uint8_t* data, size_t length, SysExFrame& outFrame);
  static size_t buildFrame(uint8_t sequence, MsgType type, uint8_t chunkIndex, uint8_t chunkCount,
                           const String& payload, uint8_t* outBuffer, size_t outBufferSize);
};

}  // namespace idrm
