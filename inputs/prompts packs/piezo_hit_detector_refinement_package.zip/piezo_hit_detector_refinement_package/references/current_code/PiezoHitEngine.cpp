#include "PiezoHitEngine.h"

#include <math.h>

namespace idrm {

namespace {

uint16_t clampMsFromUs(uint32_t valueUs) {
  return static_cast<uint16_t>(min<uint32_t>(65535U, (valueUs + 500U) / 1000U));
}

uint32_t toUs(float ms) {
  const float clamped = max(0.1f, ms);
  return static_cast<uint32_t>(clamped * 1000.0f);
}

}  // namespace

void PiezoHitEngine::reset(uint16_t baselineRaw) {
  baseline_ = baselineRaw;
  envelope_ = 0.0f;
  noise_ = 0.0f;
  lastSignal_ = 0.0f;
  lastAboveThreshold_ = false;
  scanPeak_ = 0;
  stateSinceUs_ = 0;
  scanStartUs_ = 0;
  maskUntilUs_ = 0;
  quietSinceUs_ = 0;
  maskRejectLatched_ = false;
  frozenTarget_ = PiezoTargetSnapshot{};
  stats_ = PiezoStats{};
  stats_.state = PiezoState::Idle;
}

void PiezoHitEngine::applyConfig(const PiezoConfig& config) {
  config_ = config;
  config_.pin = constrain(config_.pin, static_cast<int8_t>(0), static_cast<int8_t>(39));
  config_.adcAttenDb = constrain(config_.adcAttenDb, static_cast<uint8_t>(0), static_cast<uint8_t>(11));
  config_.sampleRateHz = constrain(config_.sampleRateHz, static_cast<uint16_t>(1000), static_cast<uint16_t>(20000));
  config_.scanMs = max(0.2f, config_.scanMs);
  config_.maskMs = max(0.2f, config_.maskMs);
  config_.quietMs = max(0.2f, config_.quietMs);
  config_.thresholdFloor = max(1.0f, config_.thresholdFloor);
  config_.thresholdOffset = max(0.0f, config_.thresholdOffset);
  config_.noiseAlpha = constrain(config_.noiseAlpha, 0.001f, 0.25f);
  config_.noiseScale = max(0.0f, config_.noiseScale);
  config_.quietThreshold = max(1.0f, config_.quietThreshold);
  config_.velocityPeakMin = max(0.0f, config_.velocityPeakMin);
  config_.velocityPeakRef = max(config_.velocityPeakMin + 1.0f, config_.velocityPeakRef);
  config_.velocityGamma = constrain(config_.velocityGamma, 0.2f, 3.5f);
  config_.velocityMin = constrain(config_.velocityMin, static_cast<uint8_t>(1), static_cast<uint8_t>(127));
  config_.velocityMax = constrain(config_.velocityMax, config_.velocityMin, static_cast<uint8_t>(127));
  config_.baselineAlpha = constrain(config_.baselineAlpha, 0.0001f, 0.1f);
  config_.envDecay = constrain(config_.envDecay, 0.80f, 0.9995f);
  config_.deadbandRaw = constrain(config_.deadbandRaw, static_cast<uint16_t>(0), static_cast<uint16_t>(4095));
  config_.positiveOnly = config_.positiveOnly ? true : false;
  config_.riseGuard = constrain(config_.riseGuard, 0.0f, 2048.0f);
}

void PiezoHitEngine::enterState(PiezoState nextState, uint32_t nowUs) {
  stats_.state = nextState;
  stateSinceUs_ = nowUs;
}

uint8_t PiezoHitEngine::mapVelocity(uint16_t peak) const {
  const float minPeak = config_.velocityPeakMin;
  const float refPeak = max(minPeak + 1.0f, config_.velocityPeakRef);
  const float normalized = constrain((static_cast<float>(peak) - minPeak) / (refPeak - minPeak), 0.0f, 1.0f);
  const float curved = powf(normalized, config_.velocityGamma);
  const float span = static_cast<float>(config_.velocityMax - config_.velocityMin);
  const float mapped = static_cast<float>(config_.velocityMin) + (curved * span);
  return static_cast<uint8_t>(constrain(static_cast<int>(lroundf(mapped)), 1, 127));
}

void PiezoHitEngine::updateSample(uint16_t raw, uint32_t nowUs, void* userData, PiezoFreezeTargetFn freezeTarget,
                                  PiezoCommitHitFn commitHit) {
  stats_.raw = raw;

  if (!config_.enabled) {
    enterState(PiezoState::Idle, nowUs);
    stats_.centered = 0;
    stats_.rectified = 0;
    stats_.signal = 0.0f;
    stats_.derivative = 0.0f;
    stats_.envelope = 0.0f;
    stats_.noise = noise_;
    stats_.threshold = config_.thresholdFloor;
    stats_.deadbandRaw = config_.deadbandRaw;
    stats_.positiveOnly = config_.positiveOnly ? 1 : 0;
    stats_.scanPeak = 0;
    stats_.scanAgeMs = 0;
    stats_.maskRemainingMs = 0;
    stats_.quietHoldMs = 0;
    lastSignal_ = 0.0f;
    lastAboveThreshold_ = false;
    return;
  }

  const bool allowBaselineTracking = stats_.state != PiezoState::Scan;
  if (allowBaselineTracking) {
    baseline_ += config_.baselineAlpha * (static_cast<float>(raw) - baseline_);
  }

  const float centered = static_cast<float>(raw) - baseline_;
  float signal = config_.positiveOnly ? max(0.0f, centered) : fabsf(centered);
  if (signal < static_cast<float>(config_.deadbandRaw)) {
    signal = 0.0f;
  }
  const float derivative = signal - lastSignal_;
  lastSignal_ = signal;
  envelope_ = max(signal, envelope_ * config_.envDecay);

  if (stats_.state == PiezoState::Idle || stats_.state == PiezoState::WaitQuiet) {
    noise_ += config_.noiseAlpha * (envelope_ - noise_);
  }

  const float threshold = max(config_.thresholdFloor, (noise_ * config_.noiseScale) + config_.thresholdOffset);
  const bool overThreshold = envelope_ >= threshold;

  stats_.centered = static_cast<int16_t>(constrain(static_cast<int>(lroundf(centered)), -32768, 32767));
  stats_.rectified = static_cast<uint16_t>(min<float>(65535.0f, signal));
  stats_.signal = signal;
  stats_.derivative = derivative;
  stats_.envelope = envelope_;
  stats_.noise = noise_;
  stats_.threshold = threshold;
  stats_.deadbandRaw = config_.deadbandRaw;
  stats_.positiveOnly = config_.positiveOnly ? 1 : 0;

  if (stats_.state == PiezoState::Idle) {
    const bool risingEdge = overThreshold && !lastAboveThreshold_;
    if (risingEdge) {
      if (config_.positiveOnly && derivative <= config_.riseGuard) {
        stats_.riseRejects++;
      } else {
        frozenTarget_ = freezeTarget ? freezeTarget(userData) : PiezoTargetSnapshot{};
        scanPeak_ = static_cast<uint16_t>(min<float>(65535.0f, envelope_));
        scanStartUs_ = nowUs;
        stats_.scanPeak = scanPeak_;
        enterState(PiezoState::Scan, nowUs);
        maskRejectLatched_ = false;
      }
    }
  } else if (stats_.state == PiezoState::Scan) {
    scanPeak_ = max<uint16_t>(scanPeak_, static_cast<uint16_t>(min<float>(65535.0f, envelope_)));
    stats_.scanPeak = scanPeak_;

    const uint32_t scanUs = toUs(config_.scanMs);
    if ((nowUs - scanStartUs_) >= scanUs) {
      const uint8_t velocity = mapVelocity(scanPeak_);
      bool accepted = false;
      if (commitHit && frozenTarget_.targetId >= 0) {
        accepted = commitHit(userData, frozenTarget_, velocity, scanPeak_);
      }
      if (accepted) {
        stats_.hits++;
        stats_.lastPeak = scanPeak_;
        stats_.lastVelocity = velocity;
      } else {
        stats_.retriggerRejects++;
      }
      maskUntilUs_ = nowUs + toUs(config_.maskMs);
      enterState(PiezoState::Mask, nowUs);
      quietSinceUs_ = 0;
      maskRejectLatched_ = false;
    }
  } else if (stats_.state == PiezoState::Mask) {
    if (envelope_ >= threshold && !maskRejectLatched_) {
      stats_.maskRejects++;
      maskRejectLatched_ = true;
    } else if (envelope_ < (threshold * 0.7f)) {
      maskRejectLatched_ = false;
    }

    if (nowUs >= maskUntilUs_) {
      quietSinceUs_ = 0;
      enterState(PiezoState::WaitQuiet, nowUs);
    }
  } else if (stats_.state == PiezoState::WaitQuiet) {
    if (envelope_ <= config_.quietThreshold) {
      if (quietSinceUs_ == 0) {
        quietSinceUs_ = nowUs;
      }
      if ((nowUs - quietSinceUs_) >= toUs(config_.quietMs)) {
        enterState(PiezoState::Idle, nowUs);
        scanPeak_ = 0;
        stats_.scanPeak = 0;
        quietSinceUs_ = 0;
      }
    } else {
      if (quietSinceUs_ != 0) {
        stats_.quietRejects++;
      }
      quietSinceUs_ = 0;
    }
  }

  if (stats_.state == PiezoState::Scan) {
    stats_.scanAgeMs = clampMsFromUs(nowUs - scanStartUs_);
  } else {
    stats_.scanAgeMs = 0;
  }

  if (stats_.state == PiezoState::Mask && nowUs < maskUntilUs_) {
    stats_.maskRemainingMs = clampMsFromUs(maskUntilUs_ - nowUs);
  } else {
    stats_.maskRemainingMs = 0;
  }

  if (stats_.state == PiezoState::WaitQuiet && quietSinceUs_ != 0) {
    stats_.quietHoldMs = clampMsFromUs(nowUs - quietSinceUs_);
  } else {
    stats_.quietHoldMs = 0;
  }

  lastAboveThreshold_ = overThreshold;
}

const PiezoConfig& PiezoHitEngine::config() const {
  return config_;
}

const PiezoStats& PiezoHitEngine::stats() const {
  return stats_;
}

const PiezoTargetSnapshot& PiezoHitEngine::frozenTarget() const {
  return frozenTarget_;
}

const char* PiezoHitEngine::stateToken(PiezoState state) {
  switch (state) {
    case PiezoState::Idle:
      return "idle";
    case PiezoState::Scan:
      return "scan";
    case PiezoState::Mask:
      return "mask";
    case PiezoState::WaitQuiet:
      return "wait_quiet";
    default:
      return "idle";
  }
}

}  // namespace idrm
