# Median plus deadband example

This note uses a synthetic damped positive half-wave pulse at 12 kHz sample rate.

Assumptions:
- ADC attenuation: 11 dB
- Approximate full scale: 3900 mV
- 1 raw count ~= 0.95 mV
- deadband_mv = 40 mV -> deadbandRaw ~= 42 counts
- filter mode = median3
- polarity mode = positive_only

Synthetic result:
- Raw peak 40 counts -> median peak about 32 counts -> removed by deadband
- Raw peak 50 counts -> median peak about 40 counts -> removed by deadband
- Raw peak 60 counts -> median peak about 48 counts -> survives
- Raw peak 80 counts -> median peak about 63 counts -> survives

Conclusion:
When median3 and a 40 mV deadband are combined, the low end of the dynamic range can disappear completely even though the oscilloscope still shows a legitimate pulse.
