# Piezo hit detector sensitivity refinement package

This package is the source of truth for the next Codex pass that must improve light-hit sensitivity, preserve strong-hit stability, and keep BLE MIDI transport intact.

Scope:
- firmware: `firmware/IRDrums/...` from the current piezo tuning branch
- host app: `src/App.Blazor/Pages/IrDrums.razor`, `src/InvisibleDrums.Protocol/...`, and related services in the Zyphonote repo
- protocol: keep the existing BLE MIDI SysEx transport and extend it carefully

Current user-observed problem:
- BLE transport is now stable
- the MCU scope page shows pulses
- small stick hits around 40-100 mV are still often ignored
- sensitivity tuning feels non-linear and hard to reason about
- the user wants strong hits followed immediately by quiet cymbal tapping without missed notes or false doubles

Primary intent:
1. make light hits trigger reliably
2. keep false triggers low
3. keep the tuning model explainable
4. keep the system observable through telemetry
5. keep the final design portable to the later InvisibleDrums piezo port

Read order:
1. `CHECKLIST.md`
2. `docs/01-executive-summary.md`
3. `docs/02-current-code-audit.md`
4. `docs/03-root-cause-analysis.md`
5. `docs/04-open-source-survey.md`
6. `docs/05-piezo-signal-and-drummer-behavior.md`
7. `docs/06-firmware-detector-v2-design.md`
8. `docs/07-unit-model-calibration-and-polarity.md`
9. `docs/08-wasm-ui-protocol-changes.md`
10. `docs/09-file-touch-plan.md`
11. `docs/10-acceptance-and-playtest.md`
12. `docs/11-sources-and-licensing.md`

Then execute prompts in strict order from `prompts/00-master-start.md` to `prompts/07-final-audit.md`.
