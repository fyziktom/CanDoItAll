# Checklist

## 1. Freeze the current baseline
- [ ] Copy the current firmware and WASM files into a reference folder
- [ ] Write down the current detector behavior and current defaults
- [ ] Keep BLE MIDI transport unchanged unless a detector-side change truly requires protocol extension

## 2. Fix the tuning model first
- [ ] Define canonical internal units as raw ADC counts
- [ ] Define explicit host-facing units for every tunable field
- [ ] Remove any mixed-unit ambiguity between counts and mV
- [ ] Split sample-rate control from loop-consume-budget control

## 3. Fix light-hit loss at the detector input
- [ ] Replace the current median-only attack path with an attack-preserving filter
- [ ] Remove the default dependence on `Median3NoiseGuard`
- [ ] Revisit default deadband values for light hits
- [ ] Implement polarity-aware rectification with auto-polarity support

## 4. Fix the detector state machine
- [ ] Keep scan start at threshold crossing
- [ ] Separate short mask from rearm logic
- [ ] Add hysteresis and release threshold
- [ ] Add fast-retrigger path after mask for legitimate new attacks
- [ ] Compute velocity from peak-above-threshold, not raw absolute peak

## 5. Finish calibration properly
- [ ] Implement actual quiet calibration
- [ ] Implement actual gentle/medium/hard hit capture
- [ ] Use capture percentiles to recommend deadband and thresholds
- [ ] Use capture statistics to recommend velocity curve
- [ ] Use capture data to resolve polarity when in auto mode

## 6. Improve observability
- [ ] Expose raw counts and explicit unit metadata in stats
- [ ] Add start/commit/reject reason fields
- [ ] Add calibration summaries to protocol responses
- [ ] Add host-side waveform and threshold overlays
- [ ] Add counters for mask rejects, rearm rejects, slope rejects, polarity mismatches, and clipping

## 7. Fix the WASM tuning UX
- [ ] Make every detector field unit-explicit
- [ ] Keep legacy compatibility only if it is clearly documented
- [ ] Add a guided calibration wizard
- [ ] Remove misleading static recommendations
- [ ] Show computed detector values that the firmware is actually using

## 8. Verify the result
- [ ] Light hits around the user's measured range become triggerable
- [ ] Strong hits still do not double trigger
- [ ] Strong-hit then quiet-cymbal transitions work noticeably better
- [ ] BLE note flow and mapping remain intact
- [ ] Documentation is updated
- [ ] Final audit maps every completed change back to this checklist
