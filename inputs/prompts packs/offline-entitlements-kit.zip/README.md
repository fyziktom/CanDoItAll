# OfflineEntitlements

OfflineEntitlements is a repository scaffold for a reusable .NET 10 solution that provides **offline-friendly entitlement checks, free-tier daily usage limits, premium token refresh, and installation binding** for browser-based WebAssembly apps with a companion backend.

The repository is intentionally designed as a **protocol-first, package-split architecture** so the transport contract can be reused outside ASP.NET Core if needed, while still shipping a reference implementation for Blazor WebAssembly + ASP.NET Core.

## What this repository contains

- `src/OfflineEntitlements.Protocol` — wire contracts and JSON source-generation context.
- `src/OfflineEntitlements.Core` — host-agnostic domain model, token reader, trusted clock logic, budget engine, and client orchestrator.
- `src/OfflineEntitlements.Wasm` — browser adapters for state persistence, installation identity, monotonic time, and HTTP transport.
- `src/OfflineEntitlements.AspNetCore` — reference backend services, token issuer, proof verification, and minimal API endpoint mapping.
- `samples/OfflineEntitlements.Sample.Api` — in-memory sample backend.
- `samples/OfflineEntitlements.Sample.BlazorWasm` — sample standalone Blazor WebAssembly client.
- `tests/OfflineEntitlements.Core.Tests` — starter unit tests.
- `docs/` — deep architecture analysis, threat model, protocol notes, and Codex implementation brief.
- `specs/openapi/offline-entitlements.openapi.yaml` — protocol reference.

## Why this exists

The solution is aimed at the practical product problem where:

- free users should be able to use the product offline, but only within bounded daily limits;
- premium users should be able to stay offline for multiple days and only revalidate occasionally;
- the browser client should not be trusted with secrets;
- the solution should be reusable as a library and shippable as NuGet packages.

## Non-goals

- Perfect DRM.
- Making browser-side logic uninspectable.
- Preventing a fully motivated attacker from patching client code.
- Replacing server-side abuse detection.

## Design summary

- **Premium** is enforced by a signed, time-limited offline token bound to an installation ID.
- **Free** is enforced by a local, tamper-evident usage ledger plus trusted-clock heuristics.
- **Trusted time** is derived from the last server checkpoint and a monotonic timer during the active session.
- **Refresh** uses proof-of-possession from the locally stored installation keypair.
- **Server** owns entitlements, plan definitions, signing keys, and risk policy.

## Quick build commands

```bash
dotnet restore
dotnet build OfflineEntitlements.sln -c Release
dotnet test OfflineEntitlements.sln -c Release
dotnet pack OfflineEntitlements.sln -c Release --no-build
```

## Packaging

All packable projects are SDK-style projects and are prepared for `dotnet pack`. Shared metadata lives in `Directory.Build.props`, versions in `Directory.Packages.props`, and the common NuGet README in `docs/nuget/package-readme.md`.

## Sample development keypair

The sample backend and sample client use a **development-only** P-256 keypair.

- Public key is embedded into the sample client configuration.
- Private key is stored in the sample API `appsettings.Development.json`.

Replace these values before any real deployment.

## Repository status

This repository is a **deliberate implementation scaffold**. The architecture, contracts, package structure, and the most important algorithms are laid out, but several places are still marked with `TODO` comments so Codex or a human maintainer can finish the production-grade implementation cleanly.
