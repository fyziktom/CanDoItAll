# Packaging notes

## Packaging model

Each library project is an SDK-style project and can be packed with `dotnet pack`.

Packable projects:
- `OfflineEntitlements.Protocol`
- `OfflineEntitlements.Core`
- `OfflineEntitlements.Wasm`
- `OfflineEntitlements.AspNetCore`

Non-packable projects:
- sample apps
- test projects

## Shared metadata

Common package metadata is centralized in `Directory.Build.props`.

## Shared package versions

Central package management is enabled via `Directory.Packages.props`.

## Common package README

All packable projects include `docs/nuget/package-readme.md` as `package-readme.md`.

## Suggested release workflow

```bash
dotnet restore
dotnet build OfflineEntitlements.sln -c Release
dotnet test OfflineEntitlements.sln -c Release
dotnet pack OfflineEntitlements.sln -c Release --no-build
```

## Before publishing to NuGet

Replace placeholders:

- `RepositoryUrl`
- `PackageProjectUrl`
- authors
- license metadata if desired
- sample development key material
