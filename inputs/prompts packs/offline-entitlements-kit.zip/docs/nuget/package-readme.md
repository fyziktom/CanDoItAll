# OfflineEntitlements

OfflineEntitlements provides reusable building blocks for offline-aware entitlement checks in browser-hosted .NET WebAssembly applications.

## Packages

- `OfflineEntitlements.Protocol`
- `OfflineEntitlements.Core`
- `OfflineEntitlements.Wasm`
- `OfflineEntitlements.AspNetCore`

## Highlights

- Signed offline premium tokens
- Installation binding
- Trusted-clock heuristics
- Free-tier daily usage budgets
- Browser persistence adapters
- Minimal API reference backend

## Important note

This library improves practical resistance to casual bypass, but it is **not** a DRM system. Browser-hosted client code remains inspectable and patchable.
