# Codex implementation brief

This repository is already structured as the target solution. Finish it rather than redesigning it.

## Acceptance criteria

1. The entire solution builds on .NET 10 in Release mode.
2. All public APIs have reasonable XML docs or clear naming.
3. `OfflineEntitlements.Core` has no browser-specific dependencies.
4. `OfflineEntitlements.Wasm` uses JS interop only behind focused adapter classes.
5. `OfflineEntitlements.AspNetCore` can issue and refresh signed tokens end-to-end.
6. The sample Blazor WASM app can:
   - activate as free or premium,
   - show entitlement status,
   - simulate practice usage,
   - evaluate a premium feature.
7. The sample API can:
   - resolve demo plans,
   - register installations,
   - verify refresh proof,
   - issue new tokens.
8. Unit tests cover:
   - compact token parsing,
   - token signature verification,
   - trusted clock rollback detection,
   - free daily budget enforcement,
   - access policy decisions.

## Areas intentionally left for Codex to deepen

- stricter validation and guard clauses,
- improved checkpoint signature verification,
- optional revocation support,
- richer usage checkpoint batching,
- richer sample UI,
- stronger test coverage.

## Important implementation hints

- Keep token parsing deterministic.
- Keep proof verification independent from ASP.NET auth concerns.
- Keep local state serialization explicit and versionable.
- Never assume browser persistence is infallible.
