# Protocol notes

## Endpoint group

All reference endpoints are mapped under:

```text
/api/offline-entitlements
```

## Activation

`POST /installations/activate`

Request contains:

- subject identifier (demo/sample only — real apps should derive from auth context),
- installation ID,
- device name,
- installation public JWK,
- client version.

Response contains:

- compact signed entitlement token,
- signed server checkpoint,
- refresh interval,
- warnings.

## Refresh

`POST /tokens/refresh`

Request contains:

- subject ID,
- installation ID,
- current token,
- proof payload,
- proof signature,
- suspicion codes.

Server verifies that the proof was signed by the registered installation key.

## Revalidate

`POST /tokens/revalidate`

Same concept as refresh, but usable for recovery flows after suspicious local state or token expiry.

## Usage checkpoint

`POST /usage/checkpoints`

This endpoint is optional in early phases. It lets the client publish local usage summaries so the backend gains more visibility into abuse or reporting.

## Compact token shape

The reference implementation uses a JWS-like compact shape:

```text
base64url(header).base64url(payload).base64url(signature)
```

Header fields:
- `alg`
- `typ`
- `kid`

Payload fields:
- `schemaVersion`
- `tokenId`
- `subjectId`
- `planId`
- `installationId`
- `issuedAtUtc`
- `notBeforeUtc`
- `refreshAfterUtc`
- `expiresAtUtc`
- `graceUntilUtc`
- `serverTimeUtc`
- `maxDevices`
- `features`
- `quotas`
- `scopes`

## Signed checkpoint

The signed checkpoint is intentionally small. Its job is to provide a trustworthy UTC anchor to the client.

Minimum fields:
- `serverTimeUtc`
- `issuedAtUtc`
- `expiresAtUtc`
- `signature`
- `algorithm`

## Versioning guidance

- Additive fields are preferred.
- Avoid renaming or retyping existing properties.
- Bump `schemaVersion` when semantics change materially.
- Keep old token readers tolerant where possible.
