# Security model

## Threat actors

### A. Honest user with unstable connectivity
This user is the primary UX target. The system should work smoothly for them.

### B. Curious power user
This user may inspect local storage, open developer tools, and try simple resets.

### C. Motivated attacker
This user may reverse engineer WASM, patch client logic, script storage resets, and replay requests.

The design aims to resist A and B well, slow down C meaningfully, but does not claim perfect resistance against C.

## Assets

- signing private key
- plan definitions
- device allocation policy
- active premium status
- local usage ledger integrity
- installation public key registry

## Trust boundaries

- Browser runtime: untrusted
- Browser storage: untrusted but persistent
- HTTPS transport: trusted when correctly configured
- Backend signing service: trusted
- Server-side stores: trusted

## Security controls

### Token authenticity
Premium token is signed server-side and verified client-side.

### Installation binding
Token contains installation ID and refresh requires proof signed with installation private key.

### Time bounding
Token has `refreshAfterUtc`, `expiresAtUtc`, and optional `graceUntilUtc`.

### Local tamper evidence
Usage is appended into a hash-chained ledger and linked to suspicion flags.

### Clock rollback detection
The trusted clock records the last observed local time and flags significant backwards movement.

### Abuse visibility
Backend can count devices, track last-seen times, and react to abnormal refresh patterns.

## Security limitations

- Browser code can be inspected.
- Browser code can be patched.
- Browser storage can be deleted.
- Local daily quota enforcement is therefore inherently best-effort.

## Recommended backend hardening

- store signing key outside source control;
- rotate signing keys with `kid` support;
- keep activation and refresh behind authenticated user context in real deployments;
- log installation registration and refresh anomalies;
- add rate limiting;
- add revocation support when product scale justifies it.

## Recommended client behavior on trust degradation

- prefer `read-only` over `hard failure`;
- ask for reconnect when suspicion becomes high;
- never delete user content because entitlement validation fails;
- visually separate “not licensed right now” from “data lost”.
