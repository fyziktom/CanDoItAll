# Implementation status

This repository is a **scaffold plus partial implementation**.

## Already prepared

- package structure
- solution layout
- core domain model
- transport contracts
- reference signing model
- reference endpoint mapping
- sample applications
- build and pack scripts

## Still expected from the next implementation pass

- compile-time validation on a real .NET 10 SDK machine
- tightening nullable annotations after first full build
- completing some `TODO` branches
- polishing sample UX
- expanding tests
