# Architecture deep analysis

## 1. Product problem

A WebAssembly product that works offline needs two conflicting properties:

1. the client must keep functioning without constant internet connectivity;
2. the monetization model must still enforce a difference between free and premium access.

In a browser environment, these goals are constrained by an uncomfortable truth: the client runtime belongs to the user. Therefore the architecture must avoid the fantasy of perfect client trust and instead optimize for:

- authenticity of server-issued entitlements,
- bounded offline grace periods,
- tamper evidence,
- server-assisted abuse detection,
- graceful degradation when trust weakens.

## 2. Design goals

### Must have

- Generic solution reusable outside a single product.
- Protocol contract that can be implemented by non-.NET backends later.
- Clean split between domain logic and browser-specific adapters.
- Premium mode usable offline for a bounded period, such as 7 days.
- Free mode usable offline with local daily usage limits, such as 60 minutes.
- Reasonable resistance to clock rollback and storage resets.
- NuGet-packable SDK-style projects.

### Should have

- Blazor WebAssembly reference integration.
- ASP.NET Core reference backend.
- AOT/trimming awareness.
- Unit tests for critical policy and clock logic.

### Explicit non-goals

- Perfect protection against a determined reverse engineer.
- Protecting client code from inspection.
- Storing high-value secrets in the browser.

## 3. Package split

```text
OfflineEntitlements.Protocol   -> DTOs, JSON contracts, source-generated serializers
OfflineEntitlements.Core       -> policy engine, trusted clock, token parsing, client orchestration
OfflineEntitlements.Wasm       -> IndexedDB/JS interop, monotonic time, installation identity, HTTP transport
OfflineEntitlements.AspNetCore -> signing, proof verification, plan lookup, endpoint mapping
```

This split is intentional:

- `Protocol` is the stable transport surface.
- `Core` owns the business rules and should stay host-agnostic.
- `Wasm` handles browser realities and is replaceable.
- `AspNetCore` is a reference implementation, not the only valid backend.

## 4. Core security stance

The architecture treats the browser as **tamperable but still useful**.

### What the client is allowed to decide

- local session bookkeeping,
- free-tier time consumption,
- when to ask for refresh,
- whether to warn about suspicious local state.

### What only the server decides

- who is premium,
- which features belong to which plan,
- how many devices are allowed,
- token signature authenticity,
- revocation and abuse policy.

## 5. Premium flow

### High-level flow

```mermaid
sequenceDiagram
    participant C as WASM Client
    participant B as Backend

    C->>C: Ensure installation identity exists
    C->>B: Activate installation
    B->>B: Resolve subject + plan + device policy
    B->>B: Sign entitlement token
    B-->>C: Token + signed server checkpoint
    C->>C: Store token and trusted-time baseline

    Note over C: Works offline until refresh window / expiry

    C->>B: Refresh token with proof-of-possession
    B->>B: Verify installation public key signature
    B-->>C: New token + new checkpoint
```

### Why this is robust enough

- The token is server-signed.
- The token is installation-bound.
- The token expires.
- Refresh requires proof from the installation keypair.
- The server still retains the final say.

## 6. Free-tier flow

Free enforcement is always weaker than premium license verification because the state necessarily lives on the client.

The goal is not “impossible to bypass”, but “expensive to bypass relative to the product value”.

### Local enforcement layers

1. **Trusted day boundary**
   - derive “today” from the last trusted checkpoint plus current session monotonic time.
2. **Usage ledger**
   - append-only hash chain of usage events.
3. **Rollback detection**
   - detect wall-clock rollback relative to the last observed local time.
4. **Suspicion flags**
   - suspicious state reduces trust and can require online revalidation.

### Recommended behavior on suspicion

- block sensitive premium features,
- keep read-only access where possible,
- allow the user to reconnect and recover,
- avoid destructive lockouts.

## 7. Trusted clock model

The trusted clock is intentionally not just `DateTimeOffset.UtcNow`.

It combines:

- last trusted server UTC checkpoint,
- current local wall clock,
- current monotonic session elapsed time.

The key insight is that `performance.now()` style monotonic time is useful only **within the current session**. Across restarts, the best available anchor remains the last signed server checkpoint.

Therefore the model is:

- at activation/refresh, accept a fresh signed checkpoint from the server;
- at app start, begin a new trusted session from the best known trusted baseline;
- during the session, advance time with monotonic elapsed milliseconds;
- if local wall clock appears to move backwards beyond tolerance, mark suspicion.

## 8. Installation identity

The installation identity should be generated once per browser profile / origin and reused:

- `installationId` as stable random UUID,
- ECDSA P-256 keypair,
- public JWK exported to the backend,
- private key retained locally.

The private key should ideally remain non-exportable and be used only for browser-side signatures.

## 9. Why the protocol uses asymmetric signing

Premium entitlement tokens are verified in the client. That means the verification key may safely be public, but the signing key must remain server-side only.

This leads naturally to asymmetric signing:

- backend signs with private key,
- WASM verifies with public key.

This is strictly better than a shared secret model in the browser.

## 10. Why the protocol still needs a backend registry

Purely stateless tokens are attractive, but real product needs still push some state to the backend:

- device count limits,
- suspicious refresh patterns,
- revocation,
- plan changes,
- installation public keys.

Therefore the backend is only “mostly stateless”. Token verification is local, but installation registration remains server-backed.

## 11. AOT / trimming implications

The library should remain friendly to Blazor WebAssembly publishing constraints:

- avoid reflection-based model binding in core logic,
- prefer `System.Text.Json` source generation,
- avoid dynamic type activation unless necessary,
- keep dependencies small.

## 12. Extensibility plan

The repository is designed so these can be added later without breaking the shape:

- server revocation store,
- external auth integration,
- shared-team plans,
- usage telemetry batching,
- stronger device fingerprinting,
- non-.NET backend implementations,
- MAUI / hybrid adapters that reuse the same Core package.

## 13. Bottom line

This architecture is strong where it matters:

- server authority,
- signed premium entitlements,
- bounded offline usage,
- installation proof,
- predictable recovery path.

It is intentionally honest about what cannot be made perfect in browser-hosted WebAssembly.
