using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using OfflineEntitlements.Core;
using OfflineEntitlements.Wasm;

var builder = WebAssemblyHostBuilder.CreateDefault(args);
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

builder.Services.AddScoped(_ => new HttpClient
{
    BaseAddress = new Uri(builder.HostEnvironment.BaseAddress)
});

builder.Services.AddOfflineEntitlementsWasm(
    configureCore: options =>
    {
        builder.Configuration.GetSection("OfflineEntitlementsClient").Bind(options);
    },
    configureWasm: options =>
    {
        builder.Configuration.GetSection("OfflineEntitlementsWasm").Bind(options);
    });

await builder.Build().RunAsync();
