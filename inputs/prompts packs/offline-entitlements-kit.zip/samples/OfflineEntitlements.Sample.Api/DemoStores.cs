using System.Collections.Concurrent;
using OfflineEntitlements.AspNetCore;

namespace OfflineEntitlements.Sample.Api;

public sealed class DemoPlanCatalog : IPlanCatalog
{
    private static readonly IReadOnlyDictionary<string, PlanDefinition> Plans =
        new Dictionary<string, PlanDefinition>(StringComparer.Ordinal)
        {
            ["free"] = new PlanDefinition
            {
                PlanId = "free",
                MaxDevices = 1,
                Features = new Dictionary<string, bool>(StringComparer.Ordinal)
                {
                    ["sheet-collaboration"] = false,
                    ["harmonic-assistant"] = false,
                    ["practice-mode"] = true
                },
                Quotas = new Dictionary<string, long>(StringComparer.Ordinal)
                {
                    ["practice-seconds-per-day"] = 3600
                }
            },
            ["premium"] = new PlanDefinition
            {
                PlanId = "premium",
                MaxDevices = 3,
                Features = new Dictionary<string, bool>(StringComparer.Ordinal)
                {
                    ["sheet-collaboration"] = true,
                    ["harmonic-assistant"] = true,
                    ["practice-mode"] = true
                },
                Quotas = new Dictionary<string, long>(StringComparer.Ordinal)
                {
                    ["practice-seconds-per-day"] = 86400
                }
            }
        };

    public ValueTask<PlanDefinition?> GetPlanAsync(string planId, CancellationToken cancellationToken = default)
    {
        Plans.TryGetValue(planId, out var plan);
        return ValueTask.FromResult(plan);
    }

    public ValueTask<PlanDefinition> GetDefaultFreePlanAsync(CancellationToken cancellationToken = default) =>
        ValueTask.FromResult(Plans["free"]);
}

public sealed class DemoSubjectEntitlementStore : ISubjectEntitlementStore
{
    public ValueTask<SubjectEntitlementGrant> GetGrantAsync(string subjectId, CancellationToken cancellationToken = default)
    {
        var planId = string.Equals(subjectId, "demo-premium", StringComparison.Ordinal)
            ? "premium"
            : "free";

        return ValueTask.FromResult(new SubjectEntitlementGrant
        {
            SubjectId = subjectId,
            PlanId = planId
        });
    }
}

public sealed class InMemoryInstallationRegistry : IInstallationRegistry
{
    private readonly ConcurrentDictionary<string, InstallationRecord> _records = new(StringComparer.Ordinal);

    public ValueTask RegisterOrUpdateAsync(InstallationRecord record, CancellationToken cancellationToken = default)
    {
        _records[record.InstallationId] = record;
        return ValueTask.CompletedTask;
    }

    public ValueTask<InstallationRecord?> GetAsync(string installationId, CancellationToken cancellationToken = default)
    {
        _records.TryGetValue(installationId, out var record);
        return ValueTask.FromResult(record);
    }

    public ValueTask<int> CountForSubjectAsync(string subjectId, CancellationToken cancellationToken = default)
    {
        var count = _records.Values.Count(record => string.Equals(record.SubjectId, subjectId, StringComparison.Ordinal));
        return ValueTask.FromResult(count);
    }
}

public sealed class ConsoleUsageCheckpointSink : IUsageCheckpointSink
{
    public ValueTask WriteAsync(UsageCheckpointRecord checkpoint, CancellationToken cancellationToken = default)
    {
        Console.WriteLine($"Usage checkpoint: subject={checkpoint.SubjectId}, metric={checkpoint.MetricKey}, seconds={checkpoint.ConsumedSeconds}, day={checkpoint.DayKey}");
        return ValueTask.CompletedTask;
    }
}
