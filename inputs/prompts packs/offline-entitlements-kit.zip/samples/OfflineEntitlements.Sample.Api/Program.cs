using OfflineEntitlements.AspNetCore;
using OfflineEntitlements.Sample.Api;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

builder.Services.AddSingleton<IPlanCatalog, DemoPlanCatalog>();
builder.Services.AddSingleton<ISubjectEntitlementStore, DemoSubjectEntitlementStore>();
builder.Services.AddSingleton<IInstallationRegistry, InMemoryInstallationRegistry>();
builder.Services.AddSingleton<IUsageCheckpointSink, ConsoleUsageCheckpointSink>();

builder.Services.AddOfflineEntitlementsAspNetCore(options =>
{
    builder.Configuration.GetSection("OfflineEntitlementsServer").Bind(options);
});

var app = builder.Build();

app.UseCors();
app.MapGet("/", () => Results.Ok(new
{
    Name = "OfflineEntitlements Sample API",
    DemoSubjects = new[] { "demo-free", "demo-premium" }
}));
app.MapOfflineEntitlements();

app.Run();
