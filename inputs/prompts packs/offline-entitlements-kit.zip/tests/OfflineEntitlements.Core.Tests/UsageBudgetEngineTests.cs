using OfflineEntitlements.Core;
using Xunit;

namespace OfflineEntitlements.Core.Tests;

public sealed class UsageBudgetEngineTests
{
    [Fact]
    public void ApplyUsage_TracksDailyConsumption()
    {
        var engine = new UsageBudgetEngine();
        var state = new UsageBudgetState();

        var result = engine.ApplyUsage(
            state,
            new DateTimeOffset(2026, 3, 11, 12, 0, 0, TimeSpan.Zero),
            "practice",
            TimeSpan.FromMinutes(15),
            TimeSpan.FromHours(1));

        Assert.Equal(900, result.ConsumedSeconds);
        Assert.Equal(2700, result.RemainingSeconds);
        Assert.False(result.LimitExceeded);
    }
}
