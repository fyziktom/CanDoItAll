using OfflineEntitlements.AspNetCore;
using Xunit;

namespace OfflineEntitlements.Core.Tests;

public sealed class JwkUtilitiesTests
{
    [Fact]
    public void CreateFromPublicJwk_ImportsP256Key()
    {
        const string publicJwk = "{\"key_ops\":[\"verify\"],\"ext\":true,\"kty\":\"EC\",\"x\":\"a3rhI1sTY4t_y59hWITWC-70eEDyHIf_5b7SwefB6yo\",\"y\":\"0MQJCNEDfOesqS1UciVdDL6l4vt3KjifIdxsjKNGKsI\",\"crv\":\"P-256\"}";

        using var key = JwkUtilities.CreateFromPublicJwk(publicJwk);

        Assert.NotNull(key);
    }
}
