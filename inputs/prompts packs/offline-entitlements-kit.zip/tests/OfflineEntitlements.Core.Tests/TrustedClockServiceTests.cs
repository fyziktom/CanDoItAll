using OfflineEntitlements.Core;
using Xunit;

namespace OfflineEntitlements.Core.Tests;

public sealed class TrustedClockServiceTests
{
    [Fact]
    public void Read_UsesMonotonicDeltaFromSessionStart()
    {
        var service = new TrustedClockService();
        var state = service.BeginSession(
            new TrustedTimeState
            {
                LastServerUtc = new DateTimeOffset(2026, 3, 11, 10, 0, 0, TimeSpan.Zero)
            },
            new DateTimeOffset(2026, 3, 11, 10, 0, 0, TimeSpan.Zero),
            1000,
            TimeSpan.FromMinutes(2));

        var reading = service.Read(
            state,
            new DateTimeOffset(2026, 3, 11, 9, 0, 0, TimeSpan.Zero),
            4000,
            TimeSpan.FromMinutes(2));

        Assert.Equal(new DateTimeOffset(2026, 3, 11, 10, 0, 3, TimeSpan.Zero), reading.EstimatedUtcNow);
        Assert.True(reading.IsSuspicious);
    }
}
