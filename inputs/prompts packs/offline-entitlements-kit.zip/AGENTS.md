# Repository instructions for Codex

## Goal

Finish this repository into a production-ready, packageable, trim-friendly .NET 10 library suite for offline entitlement enforcement in browser-hosted WebAssembly applications.

## Mandatory constraints

- Keep all source code comments in English.
- Keep the architecture package-split:
  - Protocol
  - Core
  - Wasm
  - AspNetCore
- Avoid reflection-heavy runtime patterns.
- Prefer `System.Text.Json` source generation over reflection-based serialization.
- Keep the client-side libraries compatible with trimming and WebAssembly AOT.
- Do not place secrets in the WASM client.
- Do not weaken the asymmetrical signing model.
- Preserve public API clarity; avoid leaking transport DTOs deep into domain code where not needed.

## Implementation priorities

1. Make the solution build cleanly on .NET 10.
2. Complete token issuance + verification.
3. Complete trusted clock + rollback detection.
4. Complete usage ledger and free-tier day-boundary logic.
5. Complete proof-of-possession refresh flow.
6. Complete sample apps.
7. Add more tests.

## Required commands before considering the work done

```bash
dotnet restore
dotnet build OfflineEntitlements.sln -c Release
dotnet test OfflineEntitlements.sln -c Release
dotnet pack OfflineEntitlements.sln -c Release --no-build
```

## Notes

- The sample apps are reference implementations, not product UI.
- Prefer clean, explicit names over clever abstractions.
- Treat browser persistence as best-effort and tamper-evident, never as truly secure.
