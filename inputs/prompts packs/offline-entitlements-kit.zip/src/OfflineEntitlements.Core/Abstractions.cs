using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.Core;

public interface IEntitlementClient
{
    Task<EntitlementStatus> BootstrapAsync(string subjectId, CancellationToken cancellationToken = default);
    Task<EntitlementStatus> TryRefreshAsync(string subjectId, CancellationToken cancellationToken = default);
    Task<EntitlementStatus> GetStatusAsync(CancellationToken cancellationToken = default);
    Task<RecordUsageResult> RecordUsageAsync(string metricKey, TimeSpan duration, CancellationToken cancellationToken = default);
    Task<AccessDecision> EvaluateAsync(AccessRequest request, CancellationToken cancellationToken = default);
    Task ResetAsync(CancellationToken cancellationToken = default);
}

public interface IEntitlementStateStore
{
    Task<EntitlementClientState?> LoadAsync(CancellationToken cancellationToken = default);
    Task SaveAsync(EntitlementClientState state, CancellationToken cancellationToken = default);
    Task ClearAsync(CancellationToken cancellationToken = default);
}

public interface IEntitlementTransport
{
    Task<ActivateInstallationResponse> ActivateInstallationAsync(ActivateInstallationRequest request, CancellationToken cancellationToken = default);
    Task<RefreshTokenResponse> RefreshTokenAsync(RefreshTokenRequest request, CancellationToken cancellationToken = default);
    Task<RevalidateResponse> RevalidateAsync(RevalidateRequest request, CancellationToken cancellationToken = default);
    Task<UsageCheckpointResponse> SubmitUsageCheckpointAsync(UsageCheckpointRequest request, CancellationToken cancellationToken = default);
}

public interface IInstallationIdentityProvider
{
    Task<InstallationIdentity> GetOrCreateAsync(CancellationToken cancellationToken = default);
    Task<string> SignAsync(string purpose, string payload, CancellationToken cancellationToken = default);
}

public interface IMonotonicClock
{
    Task<double> GetMillisecondsAsync(CancellationToken cancellationToken = default);
}

public interface IWallClock
{
    DateTimeOffset GetUtcNow();
}

public interface ITokenVerifier
{
    bool Verify(ParsedCompactToken token, string publicKeyPem);
}
