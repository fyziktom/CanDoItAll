using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;

namespace OfflineEntitlements.Core;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddOfflineEntitlementsCore(
        this IServiceCollection services,
        Action<EntitlementClientOptions>? configure = null)
    {
        services.AddOptions<EntitlementClientOptions>();

        if (configure is not null)
        {
            services.Configure(configure);
        }

        services.TryAddSingleton<CompactTokenReader>();
        services.TryAddSingleton<ITokenVerifier, EcdsaP256TokenVerifier>();
        services.TryAddSingleton<TrustedClockService>();
        services.TryAddSingleton<UsageBudgetEngine>();
        services.TryAddSingleton<AccessPolicyEngine>();
        services.TryAddScoped<IEntitlementClient, EntitlementClient>();

        return services;
    }
}
