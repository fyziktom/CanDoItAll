namespace OfflineEntitlements.Core;

public sealed class EntitlementClientOptions
{
    public string ServerSigningPublicKeyPem { get; set; } = string.Empty;
    public TimeSpan FreeDailyPracticeLimit { get; set; } = TimeSpan.FromHours(1);
    public TimeSpan FreeDailyAppLimit { get; set; } = TimeSpan.FromHours(1);
    public TimeSpan ClockRollbackTolerance { get; set; } = TimeSpan.FromMinutes(2);
    public TimeSpan ExpirationWarningWindow { get; set; } = TimeSpan.FromHours(12);
    public string PracticeMetricKey { get; set; } = "practice";
    public string AppMetricKey { get; set; } = "app";
}
