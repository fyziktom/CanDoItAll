using System.Security.Cryptography;

namespace OfflineEntitlements.Core;

public sealed class EcdsaP256TokenVerifier : ITokenVerifier
{
    public bool Verify(ParsedCompactToken token, string publicKeyPem)
    {
        if (token.SigningInputBytes.Length == 0 || token.SignatureBytes.Length == 0)
        {
            return false;
        }

        if (string.IsNullOrWhiteSpace(publicKeyPem))
        {
            return false;
        }

        using var ecdsa = ECDsa.Create();
        ecdsa.ImportFromPem(publicKeyPem);

        return ecdsa.VerifyData(
            token.SigningInputBytes,
            token.SignatureBytes,
            HashAlgorithmName.SHA256);
    }
}
