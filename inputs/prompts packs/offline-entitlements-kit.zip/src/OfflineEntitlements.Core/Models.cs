using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.Core;

public enum AccessDecisionKind
{
    Allow,
    AllowGrace,
    DenyMissingToken,
    DenyRefreshRequired,
    DenyTokenExpired,
    DenyFeatureDisabled,
    DenyFreeQuotaExceeded,
    DenyTamperDetected,
    DenyInstallationMismatch,
    DenyInvalidSignature
}

public enum SuspicionCode
{
    None = 0,
    ClockRollbackDetected = 1,
    StorageResetDetected = 2,
    TokenSignatureInvalid = 3,
    InstallationKeyUnavailable = 4,
    RefreshProofRejected = 5
}

public sealed record AccessRequest
{
    public string FeatureKey { get; init; } = string.Empty;
    public bool RequiresPremium { get; init; }
    public bool RequiresValidToken { get; init; }
    public string MetricKey { get; init; } = "app";
    public long AdditionalSecondsRequested { get; init; }
}

public sealed record AccessDecision
{
    public AccessDecisionKind Kind { get; init; }
    public bool Allowed { get; init; }
    public string Reason { get; init; } = string.Empty;
    public long RemainingFreeSeconds { get; init; }
}

public sealed class EntitlementClientState
{
    public string SubjectId { get; set; } = string.Empty;
    public string InstallationId { get; set; } = string.Empty;
    public string InstallationPublicKeyJwk { get; set; } = string.Empty;
    public string DeviceName { get; set; } = string.Empty;
    public string EntitlementToken { get; set; } = string.Empty;
    public TrustedTimeState TrustedTime { get; set; } = new();
    public UsageBudgetState UsageBudget { get; set; } = new();
    public List<UsageLedgerEntry> UsageLedger { get; set; } = new();
    public long UsageSequence { get; set; }
    public string HashChainHead { get; set; } = string.Empty;
    public List<SuspicionCode> SuspicionCodes { get; set; } = new();
}

public sealed class TrustedTimeState
{
    public DateTimeOffset? LastServerUtc { get; set; }
    public DateTimeOffset? LastObservedLocalUtc { get; set; }
    public DateTimeOffset? SessionStartTrustedUtc { get; set; }
    public double SessionStartMonotonicMilliseconds { get; set; }
    public string? LastCheckpointSignature { get; set; }
}

public sealed class UsageBudgetState
{
    public string CurrentDayKey { get; set; } = string.Empty;
    public Dictionary<string, long> ConsumedSecondsByMetric { get; set; } = new(StringComparer.Ordinal);
}

public sealed record UsageLedgerEntry
{
    public long Sequence { get; init; }
    public string MetricKey { get; init; } = string.Empty;
    public long DurationSeconds { get; init; }
    public DateTimeOffset TrustedRecordedAtUtc { get; init; }
    public string PreviousHash { get; init; } = string.Empty;
    public string Hash { get; init; } = string.Empty;
}

public sealed record InstallationIdentity
{
    public string InstallationId { get; init; } = string.Empty;
    public string PublicKeyJwk { get; init; } = string.Empty;
    public string DeviceName { get; init; } = string.Empty;
}

public sealed record ParsedCompactToken
{
    public CompactTokenHeaderDto Header { get; init; } = new();
    public EntitlementTokenPayload Payload { get; init; } = new();
    public byte[] SignatureBytes { get; init; } = Array.Empty<byte>();
    public byte[] SigningInputBytes { get; init; } = Array.Empty<byte>();
}

public sealed record EntitlementSnapshot
{
    public string TokenId { get; init; } = string.Empty;
    public string SubjectId { get; init; } = string.Empty;
    public string PlanId { get; init; } = string.Empty;
    public string InstallationId { get; init; } = string.Empty;
    public DateTimeOffset RefreshAfterUtc { get; init; }
    public DateTimeOffset ExpiresAtUtc { get; init; }
    public DateTimeOffset? GraceUntilUtc { get; init; }
    public IReadOnlyDictionary<string, bool> Features { get; init; } = new Dictionary<string, bool>(StringComparer.Ordinal);
    public IReadOnlyDictionary<string, long> Quotas { get; init; } = new Dictionary<string, long>(StringComparer.Ordinal);

    public bool HasFeature(string featureKey) =>
        Features.TryGetValue(featureKey, out var enabled) && enabled;
}

public sealed record TrustedTimeReading
{
    public DateTimeOffset EstimatedUtcNow { get; init; }
    public bool IsSuspicious { get; init; }
}

public sealed record UsageBudgetEvaluation
{
    public string DayKey { get; init; } = string.Empty;
    public long ConsumedSeconds { get; init; }
    public long RemainingSeconds { get; init; }
    public bool LimitExceeded { get; init; }
}

public sealed record RecordUsageResult
{
    public UsageLedgerEntry Entry { get; init; } = new();
    public UsageBudgetEvaluation Budget { get; init; } = new();
}

public sealed record EntitlementStatus
{
    public string SubjectId { get; init; } = string.Empty;
    public string InstallationId { get; init; } = string.Empty;
    public string PlanId { get; init; } = "free";
    public bool HasToken { get; init; }
    public bool IsSignatureValid { get; init; }
    public bool RequiresRefresh { get; init; }
    public bool IsExpired { get; init; }
    public DateTimeOffset? RefreshAfterUtc { get; init; }
    public DateTimeOffset? ExpiresAtUtc { get; init; }
    public DateTimeOffset TrustedUtcNow { get; init; }
    public IReadOnlyList<SuspicionCode> SuspicionCodes { get; init; } = Array.Empty<SuspicionCode>();
    public IReadOnlyDictionary<string, long> UsageByMetric { get; init; } = new Dictionary<string, long>(StringComparer.Ordinal);
}
