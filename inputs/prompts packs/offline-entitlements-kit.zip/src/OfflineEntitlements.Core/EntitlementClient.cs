using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Options;
using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.Core;

public sealed class EntitlementClient : IEntitlementClient
{
    private readonly EntitlementClientOptions _options;
    private readonly IEntitlementStateStore _stateStore;
    private readonly IEntitlementTransport _transport;
    private readonly IInstallationIdentityProvider _identityProvider;
    private readonly IMonotonicClock _monotonicClock;
    private readonly IWallClock _wallClock;
    private readonly CompactTokenReader _tokenReader;
    private readonly ITokenVerifier _tokenVerifier;
    private readonly TrustedClockService _trustedClockService;
    private readonly UsageBudgetEngine _usageBudgetEngine;
    private readonly AccessPolicyEngine _accessPolicyEngine;

    public EntitlementClient(
        IOptions<EntitlementClientOptions> options,
        IEntitlementStateStore stateStore,
        IEntitlementTransport transport,
        IInstallationIdentityProvider identityProvider,
        IMonotonicClock monotonicClock,
        IWallClock wallClock,
        CompactTokenReader tokenReader,
        ITokenVerifier tokenVerifier,
        TrustedClockService trustedClockService,
        UsageBudgetEngine usageBudgetEngine,
        AccessPolicyEngine accessPolicyEngine)
    {
        _options = options.Value;
        _stateStore = stateStore;
        _transport = transport;
        _identityProvider = identityProvider;
        _monotonicClock = monotonicClock;
        _wallClock = wallClock;
        _tokenReader = tokenReader;
        _tokenVerifier = tokenVerifier;
        _trustedClockService = trustedClockService;
        _usageBudgetEngine = usageBudgetEngine;
        _accessPolicyEngine = accessPolicyEngine;
    }

    public async Task<EntitlementStatus> BootstrapAsync(string subjectId, CancellationToken cancellationToken = default)
    {
        var state = await LoadOrCreateStateAsync(subjectId, cancellationToken);
        var monotonic = await _monotonicClock.GetMillisecondsAsync(cancellationToken);
        var wallClockUtc = _wallClock.GetUtcNow();

        state.TrustedTime = _trustedClockService.BeginSession(
            state.TrustedTime,
            wallClockUtc,
            monotonic,
            _options.ClockRollbackTolerance);

        if (string.IsNullOrWhiteSpace(state.EntitlementToken))
        {
            var response = await _transport.ActivateInstallationAsync(
                new ActivateInstallationRequest
                {
                    SubjectId = state.SubjectId,
                    InstallationId = state.InstallationId,
                    DeviceName = state.DeviceName,
                    PublicKeyJwk = state.InstallationPublicKeyJwk,
                    ClientVersion = "0.1.0-dev"
                },
                cancellationToken);

            state.EntitlementToken = response.EntitlementToken;
            state.TrustedTime = _trustedClockService.ApplyCheckpoint(
                state.TrustedTime,
                response.ServerCheckpoint,
                wallClockUtc,
                monotonic);
        }

        await _stateStore.SaveAsync(state, cancellationToken);
        return await GetStatusAsync(cancellationToken);
    }

    public async Task<EntitlementStatus> TryRefreshAsync(string subjectId, CancellationToken cancellationToken = default)
    {
        var state = await LoadOrCreateStateAsync(subjectId, cancellationToken);
        var proofPayload = CreateRefreshProofPayload(state);
        var proofSignature = await _identityProvider.SignAsync("refresh", proofPayload, cancellationToken);

        var response = await _transport.RefreshTokenAsync(
            new RefreshTokenRequest
            {
                SubjectId = state.SubjectId,
                InstallationId = state.InstallationId,
                CurrentEntitlementToken = state.EntitlementToken,
                ProofPayload = proofPayload,
                ProofSignature = proofSignature,
                SuspicionCodes = state.SuspicionCodes.Select(static code => code.ToString()).ToArray()
            },
            cancellationToken);

        state.EntitlementToken = response.EntitlementToken;
        state.TrustedTime = _trustedClockService.ApplyCheckpoint(
            state.TrustedTime,
            response.ServerCheckpoint,
            _wallClock.GetUtcNow(),
            await _monotonicClock.GetMillisecondsAsync(cancellationToken));

        await _stateStore.SaveAsync(state, cancellationToken);
        return await GetStatusAsync(cancellationToken);
    }

    public async Task<EntitlementStatus> GetStatusAsync(CancellationToken cancellationToken = default)
    {
        var state = await _stateStore.LoadAsync(cancellationToken) ?? new EntitlementClientState();

        var monotonic = await _monotonicClock.GetMillisecondsAsync(cancellationToken);
        var wallClockUtc = _wallClock.GetUtcNow();
        var trustedReading = _trustedClockService.Read(
            state.TrustedTime,
            wallClockUtc,
            monotonic,
            _options.ClockRollbackTolerance);

        var usage = new Dictionary<string, long>(state.UsageBudget.ConsumedSecondsByMetric, StringComparer.Ordinal);

        if (!_tokenReader.TryReadSnapshot(state.EntitlementToken, out var token) ||
            !_tokenReader.TryRead(state.EntitlementToken, out var parsed))
        {
            return new EntitlementStatus
            {
                SubjectId = state.SubjectId,
                InstallationId = state.InstallationId,
                HasToken = !string.IsNullOrWhiteSpace(state.EntitlementToken),
                PlanId = "free",
                TrustedUtcNow = trustedReading.EstimatedUtcNow,
                SuspicionCodes = state.SuspicionCodes.ToArray(),
                UsageByMetric = usage
            };
        }

        var signatureValid = _tokenVerifier.Verify(parsed, _options.ServerSigningPublicKeyPem);
        var isExpired = trustedReading.EstimatedUtcNow >= token.ExpiresAtUtc;
        var requiresRefresh = trustedReading.EstimatedUtcNow >= token.RefreshAfterUtc;

        return new EntitlementStatus
        {
            SubjectId = state.SubjectId,
            InstallationId = state.InstallationId,
            PlanId = token.PlanId,
            HasToken = true,
            IsSignatureValid = signatureValid,
            IsExpired = isExpired,
            RequiresRefresh = requiresRefresh,
            RefreshAfterUtc = token.RefreshAfterUtc,
            ExpiresAtUtc = token.ExpiresAtUtc,
            TrustedUtcNow = trustedReading.EstimatedUtcNow,
            SuspicionCodes = state.SuspicionCodes.ToArray(),
            UsageByMetric = usage
        };
    }

    public async Task<RecordUsageResult> RecordUsageAsync(string metricKey, TimeSpan duration, CancellationToken cancellationToken = default)
    {
        var state = await _stateStore.LoadAsync(cancellationToken) ?? new EntitlementClientState();

        var trustedReading = _trustedClockService.Read(
            state.TrustedTime,
            _wallClock.GetUtcNow(),
            await _monotonicClock.GetMillisecondsAsync(cancellationToken),
            _options.ClockRollbackTolerance);

        var dailyLimit = string.Equals(metricKey, _options.PracticeMetricKey, StringComparison.Ordinal)
            ? _options.FreeDailyPracticeLimit
            : _options.FreeDailyAppLimit;

        var budget = _usageBudgetEngine.ApplyUsage(
            state.UsageBudget,
            trustedReading.EstimatedUtcNow,
            metricKey,
            duration,
            dailyLimit);

        var entry = CreateLedgerEntry(state, metricKey, duration, trustedReading.EstimatedUtcNow);
        state.UsageLedger.Add(entry);
        state.HashChainHead = entry.Hash;
        state.UsageSequence = entry.Sequence;

        await _stateStore.SaveAsync(state, cancellationToken);

        return new RecordUsageResult
        {
            Entry = entry,
            Budget = budget
        };
    }

    public async Task<AccessDecision> EvaluateAsync(AccessRequest request, CancellationToken cancellationToken = default)
    {
        var state = await _stateStore.LoadAsync(cancellationToken) ?? new EntitlementClientState();

        var trustedReading = _trustedClockService.Read(
            state.TrustedTime,
            _wallClock.GetUtcNow(),
            await _monotonicClock.GetMillisecondsAsync(cancellationToken),
            _options.ClockRollbackTolerance);

        _tokenReader.TryReadSnapshot(state.EntitlementToken, out var token);
        var signatureValid = false;

        if (_tokenReader.TryRead(state.EntitlementToken, out var parsed))
        {
            signatureValid = _tokenVerifier.Verify(parsed, _options.ServerSigningPublicKeyPem);
        }

        var dailyLimit = string.Equals(request.MetricKey, _options.PracticeMetricKey, StringComparison.Ordinal)
            ? _options.FreeDailyPracticeLimit
            : _options.FreeDailyAppLimit;

        var freeBudget = _usageBudgetEngine.Evaluate(
            state.UsageBudget,
            trustedReading.EstimatedUtcNow,
            request.MetricKey,
            dailyLimit);

        return _accessPolicyEngine.Evaluate(
            request,
            token,
            signatureValid,
            trustedReading.IsSuspicious,
            freeBudget,
            trustedReading.EstimatedUtcNow);
    }

    public Task ResetAsync(CancellationToken cancellationToken = default) =>
        _stateStore.ClearAsync(cancellationToken);

    private async Task<EntitlementClientState> LoadOrCreateStateAsync(string subjectId, CancellationToken cancellationToken)
    {
        var state = await _stateStore.LoadAsync(cancellationToken) ?? new EntitlementClientState();
        var identity = await _identityProvider.GetOrCreateAsync(cancellationToken);

        state.SubjectId = string.IsNullOrWhiteSpace(subjectId) ? state.SubjectId : subjectId;
        state.InstallationId = identity.InstallationId;
        state.InstallationPublicKeyJwk = identity.PublicKeyJwk;
        state.DeviceName = identity.DeviceName;

        return state;
    }

    private static string CreateRefreshProofPayload(EntitlementClientState state)
    {
        return $"{state.SubjectId}|{state.InstallationId}|{Guid.NewGuid():N}|{DateTimeOffset.UtcNow:O}";
    }

    private static UsageLedgerEntry CreateLedgerEntry(
        EntitlementClientState state,
        string metricKey,
        TimeSpan duration,
        DateTimeOffset trustedUtc)
    {
        var sequence = state.UsageSequence + 1;
        var previousHash = state.HashChainHead;
        var payload = $"{sequence}|{metricKey}|{(long)duration.TotalSeconds}|{trustedUtc:O}|{previousHash}";
        var hash = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(payload)));

        return new UsageLedgerEntry
        {
            Sequence = sequence,
            MetricKey = metricKey,
            DurationSeconds = (long)duration.TotalSeconds,
            TrustedRecordedAtUtc = trustedUtc,
            PreviousHash = previousHash,
            Hash = hash
        };
    }
}
