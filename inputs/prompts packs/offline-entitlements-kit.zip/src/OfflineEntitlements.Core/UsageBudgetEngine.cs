namespace OfflineEntitlements.Core;

public sealed class UsageBudgetEngine
{
    public UsageBudgetEvaluation Evaluate(
        UsageBudgetState state,
        DateTimeOffset trustedUtcNow,
        string metricKey,
        TimeSpan dailyLimit)
    {
        var dayKey = trustedUtcNow.UtcDateTime.ToString("yyyy-MM-dd");
        ResetIfDayChanged(state, dayKey);

        state.ConsumedSecondsByMetric.TryGetValue(metricKey, out var consumedSeconds);
        var limitSeconds = (long)Math.Max(0, dailyLimit.TotalSeconds);
        var remaining = Math.Max(0, limitSeconds - consumedSeconds);

        return new UsageBudgetEvaluation
        {
            DayKey = dayKey,
            ConsumedSeconds = consumedSeconds,
            RemainingSeconds = remaining,
            LimitExceeded = consumedSeconds >= limitSeconds
        };
    }

    public UsageBudgetEvaluation ApplyUsage(
        UsageBudgetState state,
        DateTimeOffset trustedUtcNow,
        string metricKey,
        TimeSpan duration,
        TimeSpan dailyLimit)
    {
        var dayKey = trustedUtcNow.UtcDateTime.ToString("yyyy-MM-dd");
        ResetIfDayChanged(state, dayKey);

        state.ConsumedSecondsByMetric.TryGetValue(metricKey, out var consumedSeconds);
        consumedSeconds += (long)Math.Max(0, duration.TotalSeconds);
        state.ConsumedSecondsByMetric[metricKey] = consumedSeconds;

        var limitSeconds = (long)Math.Max(0, dailyLimit.TotalSeconds);
        var remaining = Math.Max(0, limitSeconds - consumedSeconds);

        return new UsageBudgetEvaluation
        {
            DayKey = dayKey,
            ConsumedSeconds = consumedSeconds,
            RemainingSeconds = remaining,
            LimitExceeded = consumedSeconds > limitSeconds
        };
    }

    private static void ResetIfDayChanged(UsageBudgetState state, string dayKey)
    {
        if (!string.Equals(state.CurrentDayKey, dayKey, StringComparison.Ordinal))
        {
            state.CurrentDayKey = dayKey;
            state.ConsumedSecondsByMetric.Clear();
        }
    }
}
