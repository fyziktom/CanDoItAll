namespace OfflineEntitlements.Core;

public sealed class AccessPolicyEngine
{
    public AccessDecision Evaluate(
        AccessRequest request,
        EntitlementSnapshot? token,
        bool signatureValid,
        bool trustedClockSuspicious,
        UsageBudgetEvaluation freeBudget,
        DateTimeOffset trustedUtcNow)
    {
        if (trustedClockSuspicious && request.RequiresValidToken)
        {
            return new AccessDecision
            {
                Allowed = false,
                Kind = AccessDecisionKind.DenyTamperDetected,
                Reason = "The local clock appears suspicious and this feature requires trusted state.",
                RemainingFreeSeconds = freeBudget.RemainingSeconds
            };
        }

        if (request.RequiresValidToken && token is null)
        {
            return new AccessDecision
            {
                Allowed = false,
                Kind = AccessDecisionKind.DenyMissingToken,
                Reason = "No entitlement token is available.",
                RemainingFreeSeconds = freeBudget.RemainingSeconds
            };
        }

        if (token is not null && !signatureValid)
        {
            return new AccessDecision
            {
                Allowed = false,
                Kind = AccessDecisionKind.DenyInvalidSignature,
                Reason = "The entitlement token signature is invalid.",
                RemainingFreeSeconds = freeBudget.RemainingSeconds
            };
        }

        if (token is not null && trustedUtcNow >= token.ExpiresAtUtc)
        {
            if (token.GraceUntilUtc.HasValue && trustedUtcNow < token.GraceUntilUtc.Value)
            {
                return new AccessDecision
                {
                    Allowed = true,
                    Kind = AccessDecisionKind.AllowGrace,
                    Reason = "Token is in grace period.",
                    RemainingFreeSeconds = freeBudget.RemainingSeconds
                };
            }

            return new AccessDecision
            {
                Allowed = false,
                Kind = AccessDecisionKind.DenyTokenExpired,
                Reason = "The entitlement token has expired.",
                RemainingFreeSeconds = freeBudget.RemainingSeconds
            };
        }

        if (request.RequiresPremium)
        {
            if (token is null)
            {
                return new AccessDecision
                {
                    Allowed = false,
                    Kind = AccessDecisionKind.DenyMissingToken,
                    Reason = "Premium access requires a valid entitlement token.",
                    RemainingFreeSeconds = freeBudget.RemainingSeconds
                };
            }

            if (!token.HasFeature(request.FeatureKey))
            {
                return new AccessDecision
                {
                    Allowed = false,
                    Kind = AccessDecisionKind.DenyFeatureDisabled,
                    Reason = "The current plan does not include this feature.",
                    RemainingFreeSeconds = freeBudget.RemainingSeconds
                };
            }

            return new AccessDecision
            {
                Allowed = true,
                Kind = AccessDecisionKind.Allow,
                Reason = "Premium feature allowed by token.",
                RemainingFreeSeconds = freeBudget.RemainingSeconds
            };
        }

        if (freeBudget.LimitExceeded)
        {
            return new AccessDecision
            {
                Allowed = false,
                Kind = AccessDecisionKind.DenyFreeQuotaExceeded,
                Reason = "The free daily usage budget has been exhausted.",
                RemainingFreeSeconds = 0
            };
        }

        return new AccessDecision
        {
            Allowed = true,
            Kind = AccessDecisionKind.Allow,
            Reason = "Free-tier access is allowed.",
            RemainingFreeSeconds = freeBudget.RemainingSeconds
        };
    }
}
