using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.Core;

public sealed class TrustedClockService
{
    public TrustedTimeState BeginSession(
        TrustedTimeState? existingState,
        DateTimeOffset wallClockUtc,
        double monotonicMilliseconds,
        TimeSpan rollbackTolerance)
    {
        var state = existingState ?? new TrustedTimeState();

        if (state.LastObservedLocalUtc.HasValue &&
            wallClockUtc + rollbackTolerance < state.LastObservedLocalUtc.Value)
        {
            // TODO: Consider escalating repeated rollback events into stronger recovery mode.
        }

        state.LastObservedLocalUtc = wallClockUtc;
        state.SessionStartTrustedUtc = state.LastServerUtc ?? wallClockUtc;
        state.SessionStartMonotonicMilliseconds = monotonicMilliseconds;

        return state;
    }

    public TrustedTimeState ApplyCheckpoint(
        TrustedTimeState? existingState,
        SignedServerCheckpointDto checkpoint,
        DateTimeOffset wallClockUtc,
        double monotonicMilliseconds)
    {
        var state = existingState ?? new TrustedTimeState();
        state.LastServerUtc = checkpoint.ServerTimeUtc;
        state.LastObservedLocalUtc = wallClockUtc;
        state.SessionStartTrustedUtc = checkpoint.ServerTimeUtc;
        state.SessionStartMonotonicMilliseconds = monotonicMilliseconds;
        state.LastCheckpointSignature = checkpoint.Signature;
        return state;
    }

    public TrustedTimeReading Read(
        TrustedTimeState? state,
        DateTimeOffset wallClockUtc,
        double monotonicMilliseconds,
        TimeSpan rollbackTolerance)
    {
        if (state is null || !state.SessionStartTrustedUtc.HasValue)
        {
            return new TrustedTimeReading
            {
                EstimatedUtcNow = wallClockUtc,
                IsSuspicious = false
            };
        }

        var suspicious = state.LastObservedLocalUtc.HasValue &&
                         wallClockUtc + rollbackTolerance < state.LastObservedLocalUtc.Value;

        var elapsed = monotonicMilliseconds - state.SessionStartMonotonicMilliseconds;
        if (elapsed < 0)
        {
            elapsed = 0;
        }

        var estimated = state.SessionStartTrustedUtc.Value.AddMilliseconds(elapsed);

        if (state.LastServerUtc.HasValue && estimated < state.LastServerUtc.Value)
        {
            estimated = state.LastServerUtc.Value;
        }

        return new TrustedTimeReading
        {
            EstimatedUtcNow = estimated,
            IsSuspicious = suspicious
        };
    }
}
