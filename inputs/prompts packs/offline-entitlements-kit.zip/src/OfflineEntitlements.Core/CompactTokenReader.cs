using System.Text;
using System.Text.Json;
using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.Core;

public sealed class CompactTokenReader
{
    public bool TryRead(string compactToken, out ParsedCompactToken token)
    {
        token = new ParsedCompactToken();

        if (string.IsNullOrWhiteSpace(compactToken))
        {
            return false;
        }

        var parts = compactToken.Split('.');
        if (parts.Length != 3)
        {
            return false;
        }

        try
        {
            var headerJson = Encoding.UTF8.GetString(Base64Url.Decode(parts[0]));
            var payloadJson = Encoding.UTF8.GetString(Base64Url.Decode(parts[1]));
            var signatureBytes = Base64Url.Decode(parts[2]);

            var header = JsonSerializer.Deserialize(headerJson, ProtocolJsonContext.Default.CompactTokenHeaderDto);
            var payload = JsonSerializer.Deserialize(payloadJson, ProtocolJsonContext.Default.EntitlementTokenPayload);

            if (header is null || payload is null)
            {
                return false;
            }

            token = new ParsedCompactToken
            {
                Header = header,
                Payload = payload,
                SignatureBytes = signatureBytes,
                SigningInputBytes = Encoding.UTF8.GetBytes($"{parts[0]}.{parts[1]}")
            };

            return true;
        }
        catch
        {
            return false;
        }
    }

    public bool TryReadSnapshot(string compactToken, out EntitlementSnapshot snapshot)
    {
        snapshot = new EntitlementSnapshot();

        if (!TryRead(compactToken, out var token))
        {
            return false;
        }

        snapshot = new EntitlementSnapshot
        {
            TokenId = token.Payload.TokenId,
            SubjectId = token.Payload.SubjectId,
            PlanId = token.Payload.PlanId,
            InstallationId = token.Payload.InstallationId,
            RefreshAfterUtc = token.Payload.RefreshAfterUtc,
            ExpiresAtUtc = token.Payload.ExpiresAtUtc,
            GraceUntilUtc = token.Payload.GraceUntilUtc,
            Features = new Dictionary<string, bool>(token.Payload.Features, StringComparer.Ordinal),
            Quotas = new Dictionary<string, long>(token.Payload.Quotas, StringComparer.Ordinal)
        };

        return true;
    }
}
