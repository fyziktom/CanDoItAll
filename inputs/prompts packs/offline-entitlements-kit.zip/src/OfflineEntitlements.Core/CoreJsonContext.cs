using System.Text.Json.Serialization;

namespace OfflineEntitlements.Core;

[JsonSerializable(typeof(EntitlementClientState))]
[JsonSerializable(typeof(TrustedTimeState))]
[JsonSerializable(typeof(UsageBudgetState))]
[JsonSerializable(typeof(UsageLedgerEntry))]
[JsonSerializable(typeof(List<UsageLedgerEntry>))]
[JsonSerializable(typeof(List<SuspicionCode>))]
[JsonSerializable(typeof(Dictionary<string, long>))]
[JsonSourceGenerationOptions(WriteIndented = false)]
public partial class CoreJsonContext : JsonSerializerContext
{
}
