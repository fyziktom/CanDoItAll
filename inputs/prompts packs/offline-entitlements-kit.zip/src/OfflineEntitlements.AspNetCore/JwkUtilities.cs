using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using OfflineEntitlements.Core;

namespace OfflineEntitlements.AspNetCore;

public static class JwkUtilities
{
    public static ECDsa CreateFromPublicJwk(string publicJwkJson)
    {
        using var document = JsonDocument.Parse(publicJwkJson);
        var root = document.RootElement;

        var x = root.GetProperty("x").GetString() ?? string.Empty;
        var y = root.GetProperty("y").GetString() ?? string.Empty;

        var parameters = new ECParameters
        {
            Curve = ECCurve.NamedCurves.nistP256,
            Q = new ECPoint
            {
                X = Base64Url.Decode(x),
                Y = Base64Url.Decode(y)
            }
        };

        var ecdsa = ECDsa.Create();
        ecdsa.ImportParameters(parameters);
        return ecdsa;
    }

    public static bool VerifyProof(string publicJwkJson, string purpose, string payload, string signatureBase64Url)
    {
        using var ecdsa = CreateFromPublicJwk(publicJwkJson);
        var signatureBytes = Base64Url.Decode(signatureBase64Url);
        var bytes = Encoding.UTF8.GetBytes($"{purpose}|{payload}");

        return ecdsa.VerifyData(bytes, signatureBytes, HashAlgorithmName.SHA256);
    }
}
