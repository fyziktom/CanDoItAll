using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace OfflineEntitlements.AspNetCore;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddOfflineEntitlementsAspNetCore(
        this IServiceCollection services,
        Action<ServerEntitlementOptions>? configure = null)
    {
        services.AddOptions<ServerEntitlementOptions>();

        if (configure is not null)
        {
            services.Configure(configure);
        }

        services.TryAddSingleton<EcdsaTokenIssuer>();
        services.TryAddScoped<EntitlementApplicationService>();

        return services;
    }
}
