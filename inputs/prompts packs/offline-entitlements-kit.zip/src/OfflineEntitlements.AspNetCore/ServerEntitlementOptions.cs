namespace OfflineEntitlements.AspNetCore;

public sealed class ServerEntitlementOptions
{
    public string Issuer { get; set; } = "offline-entitlements";
    public string KeyId { get; set; } = "dev-p256";
    public string PrivateSigningKeyPem { get; set; } = string.Empty;
    public TimeSpan RefreshInterval { get; set; } = TimeSpan.FromDays(7);
    public TimeSpan TokenLifetime { get; set; } = TimeSpan.FromDays(8);
    public TimeSpan GracePeriod { get; set; } = TimeSpan.FromHours(12);
}
