using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.AspNetCore;

public static class EndpointRouteBuilderExtensions
{
    public static IEndpointRouteBuilder MapOfflineEntitlements(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/offline-entitlements");

        group.MapPost("/installations/activate", async (
            ActivateInstallationRequest request,
            EntitlementApplicationService service,
            CancellationToken cancellationToken) =>
        {
            try
            {
                return Results.Ok(await service.ActivateInstallationAsync(request, cancellationToken));
            }
            catch (InvalidOperationException exception)
            {
                return Results.BadRequest(new ProblemDetails
                {
                    Title = "Activation failed",
                    Detail = exception.Message
                });
            }
        });

        group.MapPost("/tokens/refresh", async (
            RefreshTokenRequest request,
            EntitlementApplicationService service,
            CancellationToken cancellationToken) =>
        {
            try
            {
                return Results.Ok(await service.RefreshTokenAsync(request, cancellationToken));
            }
            catch (InvalidOperationException exception)
            {
                return Results.BadRequest(new ProblemDetails
                {
                    Title = "Refresh failed",
                    Detail = exception.Message
                });
            }
        });

        group.MapPost("/tokens/revalidate", async (
            RevalidateRequest request,
            EntitlementApplicationService service,
            CancellationToken cancellationToken) =>
        {
            try
            {
                return Results.Ok(await service.RevalidateAsync(request, cancellationToken));
            }
            catch (InvalidOperationException exception)
            {
                return Results.BadRequest(new ProblemDetails
                {
                    Title = "Revalidation failed",
                    Detail = exception.Message
                });
            }
        });

        group.MapPost("/usage/checkpoints", async (
            UsageCheckpointRequest request,
            EntitlementApplicationService service,
            CancellationToken cancellationToken) =>
        {
            return Results.Ok(await service.SubmitUsageCheckpointAsync(request, cancellationToken));
        });

        return endpoints;
    }
}
