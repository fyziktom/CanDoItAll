using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using OfflineEntitlements.Core;
using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.AspNetCore;

public sealed class EcdsaTokenIssuer
{
    private readonly ServerEntitlementOptions _options;

    public EcdsaTokenIssuer(IOptions<ServerEntitlementOptions> options)
    {
        _options = options.Value;
    }

    public string IssueToken(EntitlementTokenPayload payload)
    {
        var header = new CompactTokenHeaderDto
        {
            Algorithm = "ES256",
            Type = "oet+jws",
            KeyId = _options.KeyId
        };

        var headerJson = JsonSerializer.SerializeToUtf8Bytes(header, ProtocolJsonContext.Default.CompactTokenHeaderDto);
        var payloadJson = JsonSerializer.SerializeToUtf8Bytes(payload, ProtocolJsonContext.Default.EntitlementTokenPayload);

        var headerSegment = Base64Url.Encode(headerJson);
        var payloadSegment = Base64Url.Encode(payloadJson);
        var signingInputBytes = Encoding.UTF8.GetBytes($"{headerSegment}.{payloadSegment}");

        using var ecdsa = ECDsa.Create();
        ecdsa.ImportFromPem(_options.PrivateSigningKeyPem);
        var signature = ecdsa.SignData(signingInputBytes, HashAlgorithmName.SHA256);

        return $"{headerSegment}.{payloadSegment}.{Base64Url.Encode(signature)}";
    }

    public SignedServerCheckpointDto IssueCheckpoint(DateTimeOffset serverTimeUtc)
    {
        var issuedAtUtc = DateTimeOffset.UtcNow;
        var expiresAtUtc = issuedAtUtc.AddMinutes(15);
        var payload = $"{serverTimeUtc:O}|{issuedAtUtc:O}|{expiresAtUtc:O}";
        var signatureBytes = SignUtf8(payload);

        return new SignedServerCheckpointDto
        {
            ServerTimeUtc = serverTimeUtc,
            IssuedAtUtc = issuedAtUtc,
            ExpiresAtUtc = expiresAtUtc,
            Algorithm = "ES256",
            Signature = Base64Url.Encode(signatureBytes)
        };
    }

    private byte[] SignUtf8(string payload)
    {
        using var ecdsa = ECDsa.Create();
        ecdsa.ImportFromPem(_options.PrivateSigningKeyPem);
        return ecdsa.SignData(Encoding.UTF8.GetBytes(payload), HashAlgorithmName.SHA256);
    }
}
