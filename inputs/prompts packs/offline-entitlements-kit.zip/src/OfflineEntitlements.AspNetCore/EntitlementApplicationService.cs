using Microsoft.Extensions.Options;
using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.AspNetCore;

public sealed class EntitlementApplicationService
{
    private readonly ISubjectEntitlementStore _subjectEntitlementStore;
    private readonly IPlanCatalog _planCatalog;
    private readonly IInstallationRegistry _installationRegistry;
    private readonly IUsageCheckpointSink _usageCheckpointSink;
    private readonly ServerEntitlementOptions _options;
    private readonly EcdsaTokenIssuer _tokenIssuer;

    public EntitlementApplicationService(
        ISubjectEntitlementStore subjectEntitlementStore,
        IPlanCatalog planCatalog,
        IInstallationRegistry installationRegistry,
        IUsageCheckpointSink usageCheckpointSink,
        IOptions<ServerEntitlementOptions> options,
        EcdsaTokenIssuer tokenIssuer)
    {
        _subjectEntitlementStore = subjectEntitlementStore;
        _planCatalog = planCatalog;
        _installationRegistry = installationRegistry;
        _usageCheckpointSink = usageCheckpointSink;
        _options = options.Value;
        _tokenIssuer = tokenIssuer;
    }

    public async Task<ActivateInstallationResponse> ActivateInstallationAsync(
        ActivateInstallationRequest request,
        CancellationToken cancellationToken = default)
    {
        var grant = await _subjectEntitlementStore.GetGrantAsync(request.SubjectId, cancellationToken);
        var plan = await ResolvePlanAsync(grant.PlanId, cancellationToken);
        var existingInstallation = await _installationRegistry.GetAsync(request.InstallationId, cancellationToken);

        if (existingInstallation is null)
        {
            var activeDevices = await _installationRegistry.CountForSubjectAsync(request.SubjectId, cancellationToken);

            if (activeDevices >= plan.MaxDevices)
            {
                throw new InvalidOperationException("The device limit for this plan has been reached.");
            }
        }

        await _installationRegistry.RegisterOrUpdateAsync(
            new InstallationRecord
            {
                InstallationId = request.InstallationId,
                SubjectId = request.SubjectId,
                DeviceName = request.DeviceName,
                PublicKeyJwk = request.PublicKeyJwk,
                LastSeenUtc = DateTimeOffset.UtcNow
            },
            cancellationToken);

        var issued = IssueEntitlement(request.SubjectId, request.InstallationId, plan);

        return new ActivateInstallationResponse
        {
            EntitlementToken = issued.Token,
            ServerCheckpoint = issued.Checkpoint,
            RefreshIntervalMinutes = (int)_options.RefreshInterval.TotalMinutes,
            Warnings = Array.Empty<string>()
        };
    }

    public async Task<RefreshTokenResponse> RefreshTokenAsync(
        RefreshTokenRequest request,
        CancellationToken cancellationToken = default)
    {
        var installation = await _installationRegistry.GetAsync(request.InstallationId, cancellationToken)
            ?? throw new InvalidOperationException("Installation not found.");

        if (!string.Equals(installation.SubjectId, request.SubjectId, StringComparison.Ordinal))
        {
            throw new InvalidOperationException("Subject mismatch.");
        }

        if (!JwkUtilities.VerifyProof(installation.PublicKeyJwk, "refresh", request.ProofPayload, request.ProofSignature))
        {
            throw new InvalidOperationException("Refresh proof is invalid.");
        }

        var grant = await _subjectEntitlementStore.GetGrantAsync(request.SubjectId, cancellationToken);
        var plan = await ResolvePlanAsync(grant.PlanId, cancellationToken);
        var issued = IssueEntitlement(request.SubjectId, request.InstallationId, plan);

        await _installationRegistry.RegisterOrUpdateAsync(
            installation with { LastSeenUtc = DateTimeOffset.UtcNow },
            cancellationToken);

        return new RefreshTokenResponse
        {
            EntitlementToken = issued.Token,
            ServerCheckpoint = issued.Checkpoint,
            Warnings = Array.Empty<string>()
        };
    }

    public async Task<RevalidateResponse> RevalidateAsync(
        RevalidateRequest request,
        CancellationToken cancellationToken = default)
    {
        var installation = await _installationRegistry.GetAsync(request.InstallationId, cancellationToken)
            ?? throw new InvalidOperationException("Installation not found.");

        if (!JwkUtilities.VerifyProof(installation.PublicKeyJwk, "revalidate", request.ProofPayload, request.ProofSignature))
        {
            throw new InvalidOperationException("Revalidation proof is invalid.");
        }

        var grant = await _subjectEntitlementStore.GetGrantAsync(request.SubjectId, cancellationToken);
        var plan = await ResolvePlanAsync(grant.PlanId, cancellationToken);
        var issued = IssueEntitlement(request.SubjectId, request.InstallationId, plan);

        return new RevalidateResponse
        {
            EntitlementToken = issued.Token,
            ServerCheckpoint = issued.Checkpoint,
            Warnings = Array.Empty<string>()
        };
    }

    public async Task<UsageCheckpointResponse> SubmitUsageCheckpointAsync(
        UsageCheckpointRequest request,
        CancellationToken cancellationToken = default)
    {
        await _usageCheckpointSink.WriteAsync(
            new UsageCheckpointRecord
            {
                SubjectId = request.SubjectId,
                InstallationId = request.InstallationId,
                MetricKey = request.MetricKey,
                ConsumedSeconds = request.ConsumedSeconds,
                DayKey = request.DayKey,
                SuspicionCodes = request.SuspicionCodes
            },
            cancellationToken);

        return new UsageCheckpointResponse
        {
            AcceptedAtUtc = DateTimeOffset.UtcNow,
            ServerCheckpoint = _tokenIssuer.IssueCheckpoint(DateTimeOffset.UtcNow)
        };
    }

    private async Task<PlanDefinition> ResolvePlanAsync(string planId, CancellationToken cancellationToken)
    {
        var plan = await _planCatalog.GetPlanAsync(planId, cancellationToken);
        if (plan is not null)
        {
            return plan;
        }

        return await _planCatalog.GetDefaultFreePlanAsync(cancellationToken);
    }

    private IssuedEntitlement IssueEntitlement(string subjectId, string installationId, PlanDefinition plan)
    {
        var now = DateTimeOffset.UtcNow;

        var payload = new EntitlementTokenPayload
        {
            SchemaVersion = 1,
            TokenId = Guid.NewGuid().ToString("N"),
            SubjectId = subjectId,
            PlanId = plan.PlanId,
            InstallationId = installationId,
            IssuedAtUtc = now,
            NotBeforeUtc = now,
            RefreshAfterUtc = now.Add(_options.RefreshInterval),
            ExpiresAtUtc = now.Add(_options.TokenLifetime),
            GraceUntilUtc = now.Add(_options.TokenLifetime).Add(_options.GracePeriod),
            ServerTimeUtc = now,
            MaxDevices = plan.MaxDevices,
            Features = new Dictionary<string, bool>(plan.Features, StringComparer.Ordinal),
            Quotas = new Dictionary<string, long>(plan.Quotas, StringComparer.Ordinal),
            Scopes = Array.Empty<string>()
        };

        return new IssuedEntitlement
        {
            Token = _tokenIssuer.IssueToken(payload),
            Checkpoint = _tokenIssuer.IssueCheckpoint(now)
        };
    }
}
