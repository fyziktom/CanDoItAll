namespace OfflineEntitlements.AspNetCore;

public interface IPlanCatalog
{
    ValueTask<PlanDefinition?> GetPlanAsync(string planId, CancellationToken cancellationToken = default);
    ValueTask<PlanDefinition> GetDefaultFreePlanAsync(CancellationToken cancellationToken = default);
}

public interface ISubjectEntitlementStore
{
    ValueTask<SubjectEntitlementGrant> GetGrantAsync(string subjectId, CancellationToken cancellationToken = default);
}

public interface IInstallationRegistry
{
    ValueTask RegisterOrUpdateAsync(InstallationRecord record, CancellationToken cancellationToken = default);
    ValueTask<InstallationRecord?> GetAsync(string installationId, CancellationToken cancellationToken = default);
    ValueTask<int> CountForSubjectAsync(string subjectId, CancellationToken cancellationToken = default);
}

public interface IUsageCheckpointSink
{
    ValueTask WriteAsync(UsageCheckpointRecord checkpoint, CancellationToken cancellationToken = default);
}
