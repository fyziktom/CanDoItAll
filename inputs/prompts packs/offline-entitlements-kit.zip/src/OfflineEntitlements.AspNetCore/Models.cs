using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.AspNetCore;

public sealed record PlanDefinition
{
    public string PlanId { get; init; } = "free";
    public Dictionary<string, bool> Features { get; init; } = new(StringComparer.Ordinal);
    public Dictionary<string, long> Quotas { get; init; } = new(StringComparer.Ordinal);
    public int MaxDevices { get; init; } = 1;
}

public sealed record SubjectEntitlementGrant
{
    public string SubjectId { get; init; } = string.Empty;
    public string PlanId { get; init; } = "free";
}

public sealed record InstallationRecord
{
    public string InstallationId { get; init; } = string.Empty;
    public string SubjectId { get; init; } = string.Empty;
    public string DeviceName { get; init; } = string.Empty;
    public string PublicKeyJwk { get; init; } = string.Empty;
    public DateTimeOffset LastSeenUtc { get; init; }
}

public sealed record UsageCheckpointRecord
{
    public string SubjectId { get; init; } = string.Empty;
    public string InstallationId { get; init; } = string.Empty;
    public string MetricKey { get; init; } = string.Empty;
    public long ConsumedSeconds { get; init; }
    public string DayKey { get; init; } = string.Empty;
    public IReadOnlyList<string> SuspicionCodes { get; init; } = Array.Empty<string>();
}

public sealed record IssuedEntitlement
{
    public string Token { get; init; } = string.Empty;
    public SignedServerCheckpointDto Checkpoint { get; init; } = new();
}
