using System.Text.Json;
using Microsoft.JSInterop;
using OfflineEntitlements.Core;

namespace OfflineEntitlements.Wasm;

public sealed class BrowserStateStore : IEntitlementStateStore, IAsyncDisposable
{
    private readonly IJSRuntime _jsRuntime;
    private readonly WasmEntitlementOptions _options;
    private Task<IJSObjectReference>? _moduleTask;

    public BrowserStateStore(IJSRuntime jsRuntime, Microsoft.Extensions.Options.IOptions<WasmEntitlementOptions> options)
    {
        _jsRuntime = jsRuntime;
        _options = options.Value;
    }

    public async Task<EntitlementClientState?> LoadAsync(CancellationToken cancellationToken = default)
    {
        var module = await GetModuleAsync();
        var json = await module.InvokeAsync<string?>("readState", cancellationToken);

        if (string.IsNullOrWhiteSpace(json))
        {
            return null;
        }

        return JsonSerializer.Deserialize(json, CoreJsonContext.Default.EntitlementClientState);
    }

    public async Task SaveAsync(EntitlementClientState state, CancellationToken cancellationToken = default)
    {
        var module = await GetModuleAsync();
        var json = JsonSerializer.Serialize(state, CoreJsonContext.Default.EntitlementClientState);
        await module.InvokeVoidAsync("writeState", cancellationToken, json);
    }

    public async Task ClearAsync(CancellationToken cancellationToken = default)
    {
        var module = await GetModuleAsync();
        await module.InvokeVoidAsync("clearState", cancellationToken);
    }

    public async ValueTask DisposeAsync()
    {
        if (_moduleTask is not null)
        {
            var module = await _moduleTask;
            await module.DisposeAsync();
        }
    }

    private Task<IJSObjectReference> GetModuleAsync() =>
        _moduleTask ??= _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import",
            _options.BrowserModulePath).AsTask();
}
