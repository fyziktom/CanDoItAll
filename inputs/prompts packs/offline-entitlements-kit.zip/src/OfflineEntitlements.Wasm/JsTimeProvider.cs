using Microsoft.JSInterop;
using OfflineEntitlements.Core;

namespace OfflineEntitlements.Wasm;

public sealed class BrowserClock : IMonotonicClock, IWallClock, IAsyncDisposable
{
    private readonly IJSRuntime _jsRuntime;
    private readonly WasmEntitlementOptions _options;
    private Task<IJSObjectReference>? _moduleTask;

    public BrowserClock(IJSRuntime jsRuntime, Microsoft.Extensions.Options.IOptions<WasmEntitlementOptions> options)
    {
        _jsRuntime = jsRuntime;
        _options = options.Value;
    }

    public async Task<double> GetMillisecondsAsync(CancellationToken cancellationToken = default)
    {
        var module = await GetModuleAsync();
        return await module.InvokeAsync<double>("getMonotonicMilliseconds", cancellationToken);
    }

    public DateTimeOffset GetUtcNow() => DateTimeOffset.UtcNow;

    public async ValueTask DisposeAsync()
    {
        if (_moduleTask is not null)
        {
            var module = await _moduleTask;
            await module.DisposeAsync();
        }
    }

    private Task<IJSObjectReference> GetModuleAsync() =>
        _moduleTask ??= _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import",
            _options.BrowserModulePath).AsTask();
}
