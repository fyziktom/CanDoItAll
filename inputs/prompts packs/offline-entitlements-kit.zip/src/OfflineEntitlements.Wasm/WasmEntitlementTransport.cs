using System.Net.Http.Json;
using OfflineEntitlements.Core;
using OfflineEntitlements.Protocol;

namespace OfflineEntitlements.Wasm;

public sealed class WasmEntitlementTransport : IEntitlementTransport
{
    private readonly HttpClient _httpClient;
    private readonly WasmEntitlementOptions _options;

    public WasmEntitlementTransport(HttpClient httpClient, Microsoft.Extensions.Options.IOptions<WasmEntitlementOptions> options)
    {
        _httpClient = httpClient;
        _options = options.Value;
    }

    public async Task<ActivateInstallationResponse> ActivateInstallationAsync(ActivateInstallationRequest request, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.PostAsJsonAsync(BuildUri("installations/activate"), request, ProtocolJsonContext.Default.ActivateInstallationRequest, cancellationToken);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync(ProtocolJsonContext.Default.ActivateInstallationResponse, cancellationToken))!;
    }

    public async Task<RefreshTokenResponse> RefreshTokenAsync(RefreshTokenRequest request, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.PostAsJsonAsync(BuildUri("tokens/refresh"), request, ProtocolJsonContext.Default.RefreshTokenRequest, cancellationToken);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync(ProtocolJsonContext.Default.RefreshTokenResponse, cancellationToken))!;
    }

    public async Task<RevalidateResponse> RevalidateAsync(RevalidateRequest request, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.PostAsJsonAsync(BuildUri("tokens/revalidate"), request, ProtocolJsonContext.Default.RevalidateRequest, cancellationToken);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync(ProtocolJsonContext.Default.RevalidateResponse, cancellationToken))!;
    }

    public async Task<UsageCheckpointResponse> SubmitUsageCheckpointAsync(UsageCheckpointRequest request, CancellationToken cancellationToken = default)
    {
        var response = await _httpClient.PostAsJsonAsync(BuildUri("usage/checkpoints"), request, ProtocolJsonContext.Default.UsageCheckpointRequest, cancellationToken);
        response.EnsureSuccessStatusCode();
        return (await response.Content.ReadFromJsonAsync(ProtocolJsonContext.Default.UsageCheckpointResponse, cancellationToken))!;
    }

    private string BuildUri(string relativePath) =>
        $"{_options.ApiBasePath.TrimEnd('/')}/{relativePath}";
}
