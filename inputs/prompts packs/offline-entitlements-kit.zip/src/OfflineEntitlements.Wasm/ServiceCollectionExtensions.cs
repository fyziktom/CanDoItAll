using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using OfflineEntitlements.Core;

namespace OfflineEntitlements.Wasm;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddOfflineEntitlementsWasm(
        this IServiceCollection services,
        Action<EntitlementClientOptions>? configureCore = null,
        Action<WasmEntitlementOptions>? configureWasm = null)
    {
        services.AddOfflineEntitlementsCore(configureCore);
        services.AddOptions<WasmEntitlementOptions>();

        if (configureWasm is not null)
        {
            services.Configure(configureWasm);
        }

        services.TryAddScoped<BrowserStateStore>();
        services.TryAddScoped<IEntitlementStateStore>(static sp => sp.GetRequiredService<BrowserStateStore>());

        services.TryAddScoped<BrowserInstallationIdentityProvider>();
        services.TryAddScoped<IInstallationIdentityProvider>(static sp => sp.GetRequiredService<BrowserInstallationIdentityProvider>());

        services.TryAddScoped<BrowserClock>();
        services.TryAddScoped<IMonotonicClock>(static sp => sp.GetRequiredService<BrowserClock>());
        services.TryAddScoped<IWallClock>(static sp => sp.GetRequiredService<BrowserClock>());

        services.TryAddScoped<IEntitlementTransport, WasmEntitlementTransport>();

        return services;
    }
}
