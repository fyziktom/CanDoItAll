namespace OfflineEntitlements.Wasm;

public sealed class WasmEntitlementOptions
{
    public string ApiBasePath { get; set; } = "api/offline-entitlements";
    public string BrowserModulePath { get; set; } = "./_content/OfflineEntitlements.Wasm/offlineEntitlements.js";
}
