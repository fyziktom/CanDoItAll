using Microsoft.JSInterop;
using OfflineEntitlements.Core;

namespace OfflineEntitlements.Wasm;

public sealed class BrowserInstallationIdentityProvider : IInstallationIdentityProvider, IAsyncDisposable
{
    private readonly IJSRuntime _jsRuntime;
    private readonly WasmEntitlementOptions _options;
    private Task<IJSObjectReference>? _moduleTask;

    public BrowserInstallationIdentityProvider(IJSRuntime jsRuntime, Microsoft.Extensions.Options.IOptions<WasmEntitlementOptions> options)
    {
        _jsRuntime = jsRuntime;
        _options = options.Value;
    }

    public async Task<InstallationIdentity> GetOrCreateAsync(CancellationToken cancellationToken = default)
    {
        var module = await GetModuleAsync();
        var dto = await module.InvokeAsync<InstallationIdentityDto>("ensureInstallationIdentity", cancellationToken);

        return new InstallationIdentity
        {
            InstallationId = dto.InstallationId,
            PublicKeyJwk = dto.PublicKeyJwk,
            DeviceName = dto.DeviceName
        };
    }

    public async Task<string> SignAsync(string purpose, string payload, CancellationToken cancellationToken = default)
    {
        var module = await GetModuleAsync();
        return await module.InvokeAsync<string>("signInstallationPayload", cancellationToken, purpose, payload);
    }

    public async ValueTask DisposeAsync()
    {
        if (_moduleTask is not null)
        {
            var module = await _moduleTask;
            await module.DisposeAsync();
        }
    }

    private Task<IJSObjectReference> GetModuleAsync() =>
        _moduleTask ??= _jsRuntime.InvokeAsync<IJSObjectReference>(
            "import",
            _options.BrowserModulePath).AsTask();

    public sealed record InstallationIdentityDto
    {
        public string InstallationId { get; init; } = string.Empty;
        public string PublicKeyJwk { get; init; } = string.Empty;
        public string DeviceName { get; init; } = string.Empty;
    }
}
