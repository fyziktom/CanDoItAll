const databaseName = "offline-entitlements";
const databaseVersion = 1;
const stateStoreName = "state";
const keyStoreName = "keys";
const stateKey = "client-state";
const identityKey = "installation-identity";

async function openDatabase() {
  return await new Promise((resolve, reject) => {
    const request = indexedDB.open(databaseName, databaseVersion);

    request.onupgradeneeded = () => {
      const db = request.result;

      if (!db.objectStoreNames.contains(stateStoreName)) {
        db.createObjectStore(stateStoreName);
      }

      if (!db.objectStoreNames.contains(keyStoreName)) {
        db.createObjectStore(keyStoreName);
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

async function getValue(storeName, key) {
  const db = await openDatabase();

  return await new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, "readonly");
    const store = transaction.objectStore(storeName);
    const request = store.get(key);

    request.onsuccess = () => resolve(request.result ?? null);
    request.onerror = () => reject(request.error);
  });
}

async function setValue(storeName, key, value) {
  const db = await openDatabase();

  return await new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, "readwrite");
    const store = transaction.objectStore(storeName);
    const request = store.put(value, key);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

async function deleteValue(storeName, key) {
  const db = await openDatabase();

  return await new Promise((resolve, reject) => {
    const transaction = db.transaction(storeName, "readwrite");
    const store = transaction.objectStore(storeName);
    const request = store.delete(key);

    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

function bytesToBase64Url(bytes) {
  const binary = Array.from(bytes, value => String.fromCharCode(value)).join("");
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

function encodeUtf8(value) {
  return new TextEncoder().encode(value);
}

function projectIdentity(identity) {
  return {
    installationId: identity.installationId,
    deviceName: identity.deviceName,
    publicKeyJwk: identity.publicKeyJwk
  };
}

async function ensurePersistentStorage() {
  if (navigator.storage && navigator.storage.persist) {
    try {
      await navigator.storage.persist();
    } catch {
      // Best effort only.
    }
  }
}

async function createIdentity() {
  const keyPair = await crypto.subtle.generateKey(
    {
      name: "ECDSA",
      namedCurve: "P-256"
    },
    true,
    ["sign", "verify"]);

  const publicJwk = await crypto.subtle.exportKey("jwk", keyPair.publicKey);

  return {
    installationId: crypto.randomUUID(),
    deviceName: navigator.userAgent,
    publicKeyJwk: JSON.stringify(publicJwk),
    privateKey: keyPair.privateKey,
    publicKey: keyPair.publicKey
  };
}

export async function readState() {
  return await getValue(stateStoreName, stateKey);
}

export async function writeState(json) {
  await ensurePersistentStorage();
  await setValue(stateStoreName, stateKey, json);
}

export async function clearState() {
  await deleteValue(stateStoreName, stateKey);
}

export function getMonotonicMilliseconds() {
  return performance.now();
}

export async function ensureInstallationIdentity() {
  await ensurePersistentStorage();

  let identity = await getValue(keyStoreName, identityKey);
  if (!identity) {
    identity = await createIdentity();
    await setValue(keyStoreName, identityKey, identity);
  }

  return projectIdentity(identity);
}

export async function signInstallationPayload(purpose, payload) {
  let identity = await getValue(keyStoreName, identityKey);

  if (!identity) {
    identity = await createIdentity();
    await setValue(keyStoreName, identityKey, identity);
  }

  const privateKey = identity.privateKey;
  if (!privateKey) {
    throw new Error("Installation private key is unavailable.");
  }

  const data = encodeUtf8(`${purpose}|${payload}`);

  const signature = await crypto.subtle.sign(
    {
      name: "ECDSA",
      hash: { name: "SHA-256" }
    },
    privateKey,
    data);

  return bytesToBase64Url(new Uint8Array(signature));
}
