using System.Text.Json.Serialization;

namespace OfflineEntitlements.Protocol;

public sealed record CompactTokenHeaderDto
{
    [JsonPropertyName("alg")]
    public string Algorithm { get; init; } = "ES256";

    [JsonPropertyName("typ")]
    public string Type { get; init; } = "oet+jws";

    [JsonPropertyName("kid")]
    public string KeyId { get; init; } = "default";
}

public sealed record FeatureGrantDto
{
    public string Key { get; init; } = string.Empty;
    public bool Enabled { get; init; }
}

public sealed record QuotaGrantDto
{
    public string Key { get; init; } = string.Empty;
    public long Amount { get; init; }
}

public sealed record SignedServerCheckpointDto
{
    public DateTimeOffset ServerTimeUtc { get; init; }
    public DateTimeOffset IssuedAtUtc { get; init; }
    public DateTimeOffset ExpiresAtUtc { get; init; }
    public string Algorithm { get; init; } = "ES256";
    public string Signature { get; init; } = string.Empty;
}

public sealed record ActivateInstallationRequest
{
    public string SubjectId { get; init; } = string.Empty;
    public string InstallationId { get; init; } = string.Empty;
    public string DeviceName { get; init; } = string.Empty;
    public string PublicKeyJwk { get; init; } = string.Empty;
    public string ClientVersion { get; init; } = string.Empty;
}

public sealed record ActivateInstallationResponse
{
    public string EntitlementToken { get; init; } = string.Empty;
    public SignedServerCheckpointDto ServerCheckpoint { get; init; } = new();
    public int RefreshIntervalMinutes { get; init; }
    public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();
}

public sealed record RefreshTokenRequest
{
    public string SubjectId { get; init; } = string.Empty;
    public string InstallationId { get; init; } = string.Empty;
    public string CurrentEntitlementToken { get; init; } = string.Empty;
    public string ProofPayload { get; init; } = string.Empty;
    public string ProofSignature { get; init; } = string.Empty;
    public IReadOnlyList<string> SuspicionCodes { get; init; } = Array.Empty<string>();
}

public sealed record RefreshTokenResponse
{
    public string EntitlementToken { get; init; } = string.Empty;
    public SignedServerCheckpointDto ServerCheckpoint { get; init; } = new();
    public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();
}

public sealed record RevalidateRequest
{
    public string SubjectId { get; init; } = string.Empty;
    public string InstallationId { get; init; } = string.Empty;
    public string ProofPayload { get; init; } = string.Empty;
    public string ProofSignature { get; init; } = string.Empty;
}

public sealed record RevalidateResponse
{
    public string EntitlementToken { get; init; } = string.Empty;
    public SignedServerCheckpointDto ServerCheckpoint { get; init; } = new();
    public IReadOnlyList<string> Warnings { get; init; } = Array.Empty<string>();
}

public sealed record UsageCheckpointRequest
{
    public string SubjectId { get; init; } = string.Empty;
    public string InstallationId { get; init; } = string.Empty;
    public string MetricKey { get; init; } = string.Empty;
    public long ConsumedSeconds { get; init; }
    public string DayKey { get; init; } = string.Empty;
    public IReadOnlyList<string> SuspicionCodes { get; init; } = Array.Empty<string>();
}

public sealed record UsageCheckpointResponse
{
    public DateTimeOffset AcceptedAtUtc { get; init; }
    public SignedServerCheckpointDto? ServerCheckpoint { get; init; }
}

public sealed record EntitlementTokenPayload
{
    public int SchemaVersion { get; init; } = 1;
    public string TokenId { get; init; } = string.Empty;
    public string SubjectId { get; init; } = string.Empty;
    public string PlanId { get; init; } = "free";
    public string InstallationId { get; init; } = string.Empty;
    public DateTimeOffset IssuedAtUtc { get; init; }
    public DateTimeOffset NotBeforeUtc { get; init; }
    public DateTimeOffset RefreshAfterUtc { get; init; }
    public DateTimeOffset ExpiresAtUtc { get; init; }
    public DateTimeOffset? GraceUntilUtc { get; init; }
    public DateTimeOffset ServerTimeUtc { get; init; }
    public int MaxDevices { get; init; } = 1;
    public Dictionary<string, bool> Features { get; init; } = new(StringComparer.Ordinal);
    public Dictionary<string, long> Quotas { get; init; } = new(StringComparer.Ordinal);
    public IReadOnlyList<string> Scopes { get; init; } = Array.Empty<string>();
}
