using System.Text.Json.Serialization;

namespace OfflineEntitlements.Protocol;

[JsonSerializable(typeof(CompactTokenHeaderDto))]
[JsonSerializable(typeof(ActivateInstallationRequest))]
[JsonSerializable(typeof(ActivateInstallationResponse))]
[JsonSerializable(typeof(RefreshTokenRequest))]
[JsonSerializable(typeof(RefreshTokenResponse))]
[JsonSerializable(typeof(RevalidateRequest))]
[JsonSerializable(typeof(RevalidateResponse))]
[JsonSerializable(typeof(UsageCheckpointRequest))]
[JsonSerializable(typeof(UsageCheckpointResponse))]
[JsonSerializable(typeof(EntitlementTokenPayload))]
[JsonSerializable(typeof(SignedServerCheckpointDto))]
[JsonSerializable(typeof(Dictionary<string, bool>))]
[JsonSerializable(typeof(Dictionary<string, long>))]
[JsonSerializable(typeof(List<string>))]
[JsonSourceGenerationOptions(WriteIndented = false)]
public partial class ProtocolJsonContext : JsonSerializerContext
{
}
