# Current Repo Audit

This document summarizes what was found in the two reviewed repositories and how each should influence the implementation.

## A. `BlazorSoundSpectralAnalysis - kopie`

### Solution intent

The included architecture note already says the first goal is a **reliable demo and reusable libraries**, not a production-grade note recognizer. That matches the code.

### Useful parts already present

#### 1. Pure C# DSP core
Relevant area:
- `src/BlazorSoundSpectralAnalysis.Analysis`

Important files and concepts:
- `Configuration/AudioAnalysisSettings.cs`
- `Models/SpectralAnalysisModels.cs`
- `Services/AudioAnalysisService.cs`
- `Services/SyntheticPianoClipFactory.cs`

What is already implemented:
- preprocessing pipeline
- STFT / FFT
- configurable windowing
- spectrogram generation
- peak picking in dB space
- quadratic peak interpolation
- harmonic clustering
- tone-track linking across frames
- synthetic piano-like fixture generation

Why this matters:
- the architecture is already separated enough to extract ideas into a new reusable core
- it is written in C#, which is appropriate for Blazor WASM

#### 2. Browser capture and file decode
Relevant area:
- `src/BlazorSoundSpectralAnalysis.BrowserAudio`

Important files:
- `BrowserAudioService.cs`
- `wwwroot/browserAudioCapture.js`
- `wwwroot/microphoneCaptureProcessor.js`

What is already implemented:
- `getUserMedia` microphone access
- `AudioWorklet`-based capture instead of `MediaRecorder`
- browser-side audio file decode
- disabled browser audio processing flags:
  - `echoCancellation: false`
  - `noiseSuppression: false`
  - `autoGainControl: false`

Why this matters:
- this is the correct browser-side acquisition direction for note detection
- the JS code is simple enough to adapt into Zyphonote

#### 3. Visualization workbench
Relevant area:
- `src/BlazorSoundSpectralAnalysis.Visualization`
- demo page in `src/BlazorSoundSpectralAnalysis.Demo`

What exists:
- canvas spectrogram
- per-stage spectrogram display
- frame inspector
- synthetic scenario selection
- parameter sliders for experimentation

Why this matters:
- the current demo is already an excellent reference for a future "piano detection lab"

### Main limitations of the current spectral demo

These are not code-quality problems. They are scope gaps.

1. It is **frame-centric** rather than **note-state-centric**.
2. It lacks a dedicated onset model.
3. It does not model sustain-pedal behavior.
4. It does not estimate piano-specific inharmonicity.
5. It does not keep separate attack/sustain evidence for each note.
6. It has no plug-in architecture for multiple competing detectors.
7. It does not benchmark multiple methods on the same clip.
8. It does not bridge directly into harmonic recognition already present in Zyphonote.

### Conclusion for this repo

**Recommendation: reuse ideas and selected code patterns, but do not make this repository the main destination.**

It should be treated as:
- a donor for STFT, preprocessing, and browser capture ideas
- a donor for a visual analysis-workbench mindset
- a donor for synthetic fixture patterns

It should **not** be treated as the final application shell.

## B. `zyphonote-feature-harmonic-assistant-wow-canvas-and-scoring`

### Solution intent

This is clearly the product-facing repository. It already contains:
- standalone Blazor WebAssembly PWA
- music-theory core
- realtime harmonic analysis
- MIDI integration
- session services
- offline application structure

### Useful parts already present

#### 1. Music theory core
Relevant area:
- `src/MusicTheory.Core`

High-value files:
- `Models/NotePitch.cs`
- `Theory/PitchMath.cs`
- `Recognition/ChordRecognitionEngine.cs`
- `Recognition/ChordRecognitionTemplateLibrary.cs`
- `Theory/ChordVoicingAnalyzer.cs`

What exists:
- pitch-class math
- note naming and enharmonic preference
- chord-template scoring
- voicing/bass/inversion analysis
- progression/harmony utilities

Why this matters:
- audio detection does not need to reinvent note and chord logic
- detected note evidence can feed directly into the existing theory stack

#### 2. Realtime note/chord state machinery
Relevant area:
- `src/MusicTheory.Core/Recognition`

High-value files:
- `RealtimeNoteScoreTracker.cs`
- `RealtimeNoteScoreOptions.cs`
- `RealtimeChordWindowDetector.cs`
- `RealtimeChordDetectionService.cs`

What exists:
- decaying note scores
- sustain-aware note handling
- chord windowing
- confidence-based chord inference

Why this matters:
- audio note events can be translated into the same event flow currently used for MIDI
- this is exactly the right place to bridge audio-derived note events into harmony detection

#### 3. Session/service pattern
Relevant area:
- `src/App.Blazor/Services`

High-value file:
- `RealtimeChordDetectionSessionService.cs`

Why this matters:
- this is the best pattern to imitate for an audio session service:
  - capture source
  - detector state
  - score tracker
  - debounce/evaluate
  - publish UI snapshots

#### 4. PWA host
Relevant area:
- `src/App.Web`

What exists:
- standalone WASM host
- manifest
- service worker
- PWA packaging

Why this matters:
- the audio detector should live inside this app shell

### Conclusion for this repo

**Recommendation: this is the implementation target.**

The new audio subsystem should be added here, with a structure parallel to the existing domain-driven modules.

## Final audit decision

### Build target
Implement the new work in the Zyphonote repository.

### Reference donor
Use the spectral demo as a donor/reference for:
- preprocessing concepts
- STFT concepts
- browser capture concepts
- spectrogram UI concepts
- synthetic fixture ideas

### Product integration
Use Zyphonote for:
- main app hosting
- offline PWA behavior
- note/chord interpretation
- storage/session patterns
- user-facing experiment and comparison UI
