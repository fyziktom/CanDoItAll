# Target Repo Placement

This document proposes a concrete home for the new subsystem inside the Zyphonote repository.

## Proposed new projects

### 1. `src/MusicAudioAnalysis.Core`
Purpose:
- pure C# audio analysis logic
- no browser dependency
- no Blazor dependency
- no mandatory dependency on Zyphonote theory code

Suggested folders:
- `Audio/`
- `Transforms/`
- `Features/`
- `Detectors/`
- `Tracking/`
- `Fusion/`
- `Evaluation/`
- `Fixtures/`
- `Configuration/`
- `Models/`

### 2. `src/MusicAudioAnalysis.Browser`
Purpose:
- browser microphone and file decode integration
- JS interop boundary
- IndexedDB-oriented recording storage helpers if needed

Suggested folders:
- `Interop/`
- `Services/`
- `wwwroot/`

### 3. `tests/MusicAudioAnalysis.Tests`
Purpose:
- deterministic transform tests
- detector tests
- tracker tests
- fixture-based regression tests
- performance smoke tests

## Proposed integration inside existing projects

### `src/App.Blazor`
Add:
- `Pages/PianoAudioLab.razor`
- `Services/PianoAudioDetectionSessionService.cs`
- `Services/PianoAudioComparisonService.cs`
- `Models/PianoAudioLabState.cs`
- components under `Components/Audio/`

### `src/App.Web`
Use for:
- route hosting
- PWA offline caching
- static asset hosting
- service worker participation

## Recommended dependency direction

```text
App.Web
  -> App.Blazor
      -> MusicAudioAnalysis.Browser
      -> MusicAudioAnalysis.Core
      -> MusicTheory.Core

MusicAudioAnalysis.Browser
  -> MusicAudioAnalysis.Core

MusicAudioAnalysis.Core
  -> (no browser/UI dependencies)
```

## Why keep `MusicAudioAnalysis.Core` independent from `MusicTheory.Core`

This keeps the low-level DSP layer reusable and easier to test.

The bridge from note evidence to harmonic interpretation belongs one layer higher:
- either in `App.Blazor`
- or in a small adapter namespace that references both libraries

## Suggested namespaces

- `MusicAudioAnalysis.Core.*`
- `MusicAudioAnalysis.Browser.*`
- `App.Blazor.Services.Audio.*`
- `App.Blazor.Components.Audio.*`

## Suggested first page route

- `/piano-audio-lab`

This makes the feature explicitly experimental and discoverable without colliding with current pages.
