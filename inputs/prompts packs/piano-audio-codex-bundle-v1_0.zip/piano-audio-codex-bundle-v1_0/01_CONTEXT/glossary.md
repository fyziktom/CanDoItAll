# Glossary

- **STFT**: Short-Time Fourier Transform. Converts short overlapping windows of audio into a time-frequency representation.
- **CQT**: Constant-Q Transform. A transform whose frequency bins are geometrically spaced, which aligns better with musical pitch spacing.
- **Onset**: The start of a note event.
- **Offset**: The end of a note event.
- **Frame**: One analysis step in time, usually one STFT or CQT column.
- **Hop size**: Number of samples between adjacent frames.
- **Spectral flux**: A common onset feature measuring positive change in spectral energy across frames.
- **F0**: Fundamental frequency of a note.
- **Partial**: One harmonic or inharmonic component belonging to a tone.
- **Inharmonicity**: Deviation of piano partials from exact integer multiples of the fundamental.
- **Activation map**: Per-note score over time indicating how active each piano key appears to be.
- **Template matching**: Comparing observed spectrum to precomputed note templates.
- **NMF**: Non-negative Matrix Factorization. Approximates a spectrogram as spectral templates times time-varying activations.
- **State tracker**: Logic that converts raw per-frame activations into note states such as off, attack, active, sustained, and release.
- **Fusion**: Combining outputs from several detection methods into a stronger final estimate.
- **Retrospective correction window**: A short look-back buffer used to refine decisions after a small delay.
