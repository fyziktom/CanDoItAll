# Constraints and Non-Goals

## Hard constraints

### 1. Must run in Blazor WebAssembly
Implications:
- keep hot-path code in efficient C#
- avoid very chatty JS interop
- avoid server-only assumptions
- prefer deterministic algorithms and bounded memory

### 2. Must work offline as a PWA
Implications:
- microphone capture must work without backend services
- detector configuration, fixtures, and recent recordings should be available offline
- no online model download requirement
- no cloud processing requirement

### 3. Focus on piano first
Implications:
- detector design may exploit piano acoustics
- note range is fixed to 88 keys
- inharmonicity and sustain behavior matter
- method evaluation should prioritize piano-specific cases

### 4. Must support method comparison
Implications:
- a single monolithic detector is the wrong architecture
- all detectors should expose a common interface
- comparison UI should show per-method outputs and metrics

### 5. Must be testable with real microphone input
Implications:
- the system should accept live mic, uploaded file, and deterministic fixture data
- it should expose enough debug information to understand errors

## Performance constraints

The system should target a practical real-time budget on a normal laptop browser.

Reasonable design assumptions:
- sample rate: 22050 Hz or 24000 Hz default
- hop size: 256 or 512 samples
- FFT size: 2048 to 4096 in baseline methods
- per-frame detector work should avoid heavy allocation
- use `ArrayPool<T>`, `Span<T>`, and precomputed kernels where beneficial

## Product constraints

- Do not break existing Zyphonote features.
- Do not force all users into audio mode.
- Keep audio functionality as an additive module/page.
- Keep detector settings serializable so presets can be stored.

## Non-goals for v1

These are explicitly out of scope for the first implementation wave:

1. Universal transcription for all instruments
2. Perfect score engraving
3. Large neural models downloaded at runtime
4. Server-side inference
5. Sample-accurate pedal transcription
6. Full teacher-grade performance assessment
7. Poly-instrument source separation
8. SharedArrayBuffer as a hard deployment dependency

## Recommended scope boundary

The first strong milestone is:

- microphone/file piano audio
- robust note-event detection
- decent sustain likelihood estimation
- compare 3 classical methods plus a fusion mode
- feed note events into Zyphonote harmony analysis
- provide metrics and manual test workflow

If that works reliably, then add:
- optional NMF experiment
- optional native WASM dependency exploration
- richer pedal modeling
- lightweight learning-based correction later
