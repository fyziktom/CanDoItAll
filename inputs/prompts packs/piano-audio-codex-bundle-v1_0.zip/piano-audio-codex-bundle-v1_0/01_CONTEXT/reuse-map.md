# Reuse Map

This document maps reviewed source assets to their recommended fate in the new implementation.

## A. Spectral demo → new Zyphonote audio subsystem

| Source path | Role today | Recommended action | Why |
|---|---|---|---|
| `BlazorSoundSpectralAnalysis.Analysis/Configuration/AudioAnalysisSettings.cs` | DSP settings model | **Adapt** | Good starting point, but must be split into transform, onset, detector, tracker, and comparison options |
| `BlazorSoundSpectralAnalysis.Analysis/Models/SpectralAnalysisModels.cs` | Core models | **Adapt selectively** | Spectrogram and peak models are useful; `ToneTrack` is not enough as the final piano note state model |
| `BlazorSoundSpectralAnalysis.Analysis/Services/AudioAnalysisService.cs` | All-in-one pipeline | **Reference only** | Good prototype, but target system needs pluggable stages and multiple detector methods |
| `SyntheticPianoClipFactory.cs` | Deterministic fixtures | **Adapt and expand** | Good for baseline tests; needs repeated-note, pedal, and inharmonic variants |
| `BrowserAudioService.cs` | Browser capture/file decode | **Adapt** | Good architecture; should be moved into Zyphonote-specific browser/audio module |
| `browserAudioCapture.js` | `getUserMedia` + `AudioWorklet` | **Adapt** | Strong starting point |
| `microphoneCaptureProcessor.js` | Worklet processor | **Adapt** | Fine baseline; later extend for chunk batching/diagnostics |
| `SpectrogramCanvas.razor` | Visualization | **Reference and partially adapt** | Rebuild as part of the new audio lab page, but keep the canvas-first idea |
| Demo `Home.razor` | Analysis workbench | **Reference only** | Useful UI concept, but target UX should fit Zyphonote conventions |

## B. Zyphonote → direct integration candidates

| Source path | Role today | Recommended action | Why |
|---|---|---|---|
| `MusicTheory.Core/Theory/PitchMath.cs` | Pitch-class utilities | **Reuse directly** | Already central and trustworthy |
| `MusicTheory.Core/Models/NotePitch.cs` | Note domain model | **Reuse directly** | Good symbolic layer once MIDI-like notes exist |
| `MusicTheory.Core/Recognition/RealtimeNoteScoreTracker.cs` | Decaying note score model | **Reuse directly via adapter** | Perfect for audio-to-theory bridge |
| `MusicTheory.Core/Recognition/RealtimeChordWindowDetector.cs` | Stable chord windowing | **Reuse directly via adapter** | Audio note events can feed this exactly like MIDI events |
| `MusicTheory.Core/Recognition/RealtimeChordDetectionService.cs` | Chord inference | **Reuse directly** | No need to duplicate harmony logic |
| `MusicTheory.Core/Recognition/ChordRecognitionEngine.cs` | Chord scoring engine | **Reuse directly** | Existing feature advantage |
| `MusicTheory.Core/Theory/ChordVoicingAnalyzer.cs` | Bass/inversion/slash analysis | **Reuse directly** | Useful once note events are stable |
| `App.Blazor/Services/RealtimeChordDetectionSessionService.cs` | Service pattern | **Imitate** | Best template for `PianoAudioDetectionSessionService` |
| `App.Web` PWA shell | Product host | **Reuse directly** | This is the correct product surface |

## C. Things that should not be copied blindly

1. **The current all-in-one analysis service**
   - Replace with stage interfaces and method plug-ins.

2. **Single detector assumption**
   - The new system must support multiple methods and side-by-side comparison.

3. **Only harmonic clusters and frame tracks**
   - The target system needs actual note events with onset/hold/release semantics.

4. **Synthetic piano fixtures with simple harmonic envelope only**
   - Keep them, but add more realistic scenarios:
     - repeated same note
     - soft vs loud
     - attack-only fragments
     - sustain tail
     - room noise
     - overlapping notes
     - simple pedal-likelihood cases

## D. Proposed new project structure inside Zyphonote

Recommended additions:

- `src/MusicAudioAnalysis.Core`
- `src/MusicAudioAnalysis.Browser`
- `tests/MusicAudioAnalysis.Tests`

Recommended product integration points:

- `src/App.Blazor/Services/PianoAudioDetectionSessionService.cs`
- `src/App.Blazor/Pages/PianoAudioLab.razor`
- optional components under `src/App.Blazor/Components/Audio/*`

## E. High-level migration rule

**Import concepts, not accidental structure.**

The spectral demo is a prototype and workbench.
Zyphonote is the product host.
The new subsystem should keep the strong parts of both, but be cleanly structured around:
- transforms
- features
- detectors
- tracking
- fusion
- theory bridge
- evaluation
