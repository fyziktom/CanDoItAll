# Sequence Diagrams

## Live microphone flow

```mermaid
sequenceDiagram
    participant User
    participant UI as PianoAudioLab
    participant Browser as PianoAudioCaptureService
    participant Worklet as AudioWorklet
    participant Core as Analysis Pipeline
    participant Tracker as NoteStateTracker
    participant Theory as Theory Bridge

    User->>UI: Start capture
    UI->>Browser: StartMicrophoneCaptureAsync
    Browser->>Worklet: create AudioWorkletNode
    Worklet-->>Browser: PCM chunks
    Browser-->>UI: PCM blocks
    UI->>Core: Append and analyze
    Core->>Tracker: Note activations
    Tracker-->>UI: Note events / active notes
    Tracker->>Theory: Note events
    Theory-->>UI: Chord candidates
```

## Offline comparison flow

```mermaid
sequenceDiagram
    participant User
    participant UI as PianoAudioLab
    participant Harness as Benchmark Harness
    participant D1 as Harmonic
    participant D2 as CQT
    participant D3 as Template
    participant F as Fusion

    User->>UI: Select clip and methods
    UI->>Harness: Run benchmark pack
    Harness->>D1: Analyze clip
    Harness->>D2: Analyze clip
    Harness->>D3: Analyze clip
    Harness->>F: Analyze clip
    D1-->>Harness: Note events + metrics
    D2-->>Harness: Note events + metrics
    D3-->>Harness: Note events + metrics
    F-->>Harness: Note events + metrics
    Harness-->>UI: Comparison results
```
