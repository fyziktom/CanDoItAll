# Codex Run Notes Template

Use this file while executing the prompt sequence.

## Environment
- OS:
- Browser:
- .NET SDK:
- Repo commit:

## Completed prompts
- [ ] 01
- [ ] 02
- [ ] 03
- [ ] 04
- [ ] 05
- [ ] 06
- [ ] 07
- [ ] 08
- [ ] 09
- [ ] 10
- [ ] 11
- [ ] 12
- [ ] 13

## Build/test notes

### Prompt 01
- build result:
- notes:

### Prompt 02
- build result:
- manual mic result:
- notes:

### Prompt 03
- test result:
- notes:

### Prompt 04
- test result:
- notes:

### Prompt 05
- test result:
- notes:

### Prompt 06
- test result:
- notes:

### Prompt 07
- test result:
- notes:

### Prompt 08
- test result:
- notes:

### Prompt 09
- manual UI notes:

### Prompt 10
- benchmark notes:

### Prompt 11
- perf notes:

### Prompt 12
- experiment notes:

### Prompt 13
- final validation notes:
