# WASM / Blazor / PWA Design Notes

This document translates the algorithm work into browser and runtime realities.

## 1. Browser audio capture

Recommended browser capture path:
- `getUserMedia`
- `AudioContext`
- `AudioWorklet`
- chunked PCM transfer to .NET

Why:
- keeps capture near real-time
- avoids the timing drift and container overhead of `MediaRecorder`
- supports analysis-ready PCM

Implementation guidance:
- disable browser voice-processing features where possible
- keep capture mono
- batch frames into moderate chunks before crossing into .NET
- avoid per-sample interop

## 2. Interop strategy

General rule:
- do not use JS interop in the per-sample hot path
- cross the boundary in chunks or commands only

Preferred design:
- JS owns microphone stream and worklet lifecycle
- JS posts chunked PCM blocks
- .NET receives blocks and pushes them into the analysis pipeline

Optional optimization:
- if the project already standardizes around it, consider `JSImport` / `JSExport` for performance-sensitive client-only interop
- do not make this a mandatory first-step dependency if it complicates the initial scaffold

## 3. Offline PWA considerations

Offline success requires:
- all app binaries cached by the service worker
- static detector assets cached
- template packs and fixtures shipped locally or stored locally
- detector presets and recent recordings stored client-side

What should be stored locally:
- detector presets
- manual test logs
- recent microphone captures or excerpts
- fixture metadata
- benchmark results

## 4. Runtime performance guidance

Hot-path rules:
- no LINQ in the innermost loops
- avoid allocations in frame processing
- use reusable buffers and `ArrayPool<T>`
- precompute windows, kernels, note frequencies, and band maps
- reuse transform output buffers where possible

Potential project toggles:
- `<WasmEnableSIMD>true</WasmEnableSIMD>` for performance-sensitive builds
- optional `<RunAOTCompilation>true</RunAOTCompilation>` for release benchmarking builds

Recommended practice:
- keep Development builds easy to iterate
- keep AOT as a release/benchmark profile, not the only supported workflow

## 5. SharedArrayBuffer and worker isolation

Do not make SharedArrayBuffer or strict cross-origin isolation mandatory for v1.

Reason:
- it complicates deployment
- it is unnecessary for the first solid detector lab
- the chunked AudioWorklet path is enough to begin

You can revisit this later if:
- profiling shows .NET-side copy cost is a real bottleneck
- you want deeper worker or native-WASM strategies

## 6. Recommended sample rates

Default:
- 22050 Hz or 24000 Hz

Why:
- reduces CPU cost
- still covers piano fundamentals and useful lower partials
- enough for most note-detection tasks

Optional high-quality preset:
- 44100 Hz when benchmarking or when template resolution needs it

## 7. Recommended transform presets

### Low-latency baseline
- sample rate: 22050
- FFT: 2048
- hop: 256

### Balanced piano preset
- sample rate: 22050 or 24000
- FFT: 4096
- hop: 512

### High-detail offline comparison
- sample rate: 44100
- FFT: 4096 or 8192
- hop: 512 or 1024

## 8. UI design principle

The page should clearly distinguish:

- source:
  - mic
  - upload
  - fixture
- method:
  - harmonic
  - CQT
  - template
  - fusion
  - optional NMF
- mode:
  - live
  - replay
  - offline batch compare

This prevents confusion between capture problems and detector problems.
