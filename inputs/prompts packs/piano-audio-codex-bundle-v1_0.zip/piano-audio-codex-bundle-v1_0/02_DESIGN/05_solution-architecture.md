# Solution Architecture

## Overview

The target system should be organized as a shared analysis pipeline with pluggable detectors.

```text
Microphone / File / Fixture
        |
        v
MusicAudioAnalysis.Browser
        |
        v
PCM block stream
        |
        v
MusicAudioAnalysis.Core
  - preprocessing
  - transforms (STFT / CQT)
  - onset features
  - detector methods
  - note-state tracker
  - sustain estimator
  - optional fusion
        |
        v
Note events + note activations + debug artifacts
        |
        v
App.Blazor audio session services
        |
        +--> PianoAudioLab UI
        |
        +--> adapter to RealtimeMidiEvent / RealtimeNoteScoreTracker
        |
        v
MusicTheory.Core harmonic interpretation
```

## Core subsystem modules

### A. Input and buffering
Responsibilities:
- append PCM blocks
- resample if necessary
- expose analysis windows/hops
- maintain small retrospective buffer

### B. Transform engine
Responsibilities:
- STFT
- optional CQT
- cached windows and kernels
- reusable frame outputs

### C. Feature engine
Responsibilities:
- spectral flux
- energy envelope
- band energy
- optional spectral centroid and harmonic ratio

### D. Detector methods
Responsibilities:
- produce per-note hypotheses or activations
- remain stateless or minimally stateful at method level
- avoid owning UI or harmony logic

Methods:
- harmonic summation
- CQT activation
- template matching
- optional constrained NMF
- fusion

### E. Note-state tracker
Responsibilities:
- consume per-note evidence over time
- convert evidence into note events and current note states
- estimate velocity-like strength
- separate attack/hold/release/tail

### F. Sustain / pedal estimator
Responsibilities:
- estimate whether long tails are expected
- provide global and per-note sustain likelihood

### G. Theory bridge
Responsibilities:
- turn note events into `RealtimeMidiEvent`-like flow
- feed existing Zyphonote note/chord state machinery
- keep audio detector and harmony logic loosely coupled

### H. Evaluation and metrics
Responsibilities:
- compare methods on identical input
- compute event-level metrics
- log timing and allocations
- support regression tests

## Why this architecture is better than a single analysis service

Because it lets you:
- compare methods fairly
- reuse transforms and trackers
- test individual pieces
- keep browser integration separate from DSP
- avoid locking the whole product into one experimental choice
