# Storage and Offline Strategy

## What should be available offline

The detector lab should continue to function without network access after installation.

Recommended offline assets:
- app binaries
- JS worklet files
- built-in fixtures metadata
- built-in lightweight template packs
- detector preset defaults
- stored user recordings and benchmark results

## Local storage categories

### 1. Presets
Store:
- detector settings
- comparison sets
- selected piano profile or template pack

### 2. Captures
Store:
- short microphone recordings
- imported file metadata
- optional derived transforms for recent sessions

### 3. Benchmarks
Store:
- method run summaries
- metric snapshots
- timestamps
- app version and preset hash

### 4. Manual evaluation notes
Store:
- user comments
- microphone placement
- piano identity
- environment notes

## Suggested storage technology

- lightweight app settings: browser local storage or existing settings service
- larger binary/test assets: IndexedDB

## Offline-safe template strategy

For v1, template packs should be:
- shipped with the app
- or created locally from included fixtures
- or imported by the user from local files

Do not require network fetching of templates.

## Service worker considerations

Whenever new detector assets are added:
- ensure they are included in the app's static asset pipeline
- confirm they are cached correctly by the PWA service worker
- test airplane-mode reload after at least one successful online load

## Recommended retention policy

Avoid uncontrolled growth.

Keep:
- preset history small
- microphone recordings capped or manually deletable
- benchmark runs summarized and optionally purgeable
