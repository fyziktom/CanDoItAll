# UI Lab Design

The first user-facing surface should be a **Piano Audio Lab** page.

## Page goals

The page should let you:
- capture microphone audio
- load a local audio file
- select deterministic fixtures
- select one or more detector methods
- compare outputs
- inspect spectrogram and note roll
- send results into Zyphonote harmonic interpretation
- store local test runs

## Recommended layout

### Top control bar
- source selector: mic / file / fixture
- detector preset selector
- compare mode toggle
- live vs replay mode
- start / stop / analyze controls

### Left settings panel
Grouped sections:
- capture settings
- transform settings
- onset settings
- detector settings
- tracker settings
- fusion settings
- theory bridge settings

### Main center area
Tabs or stacked sections:
- waveform
- spectrogram
- note activation heatmap
- piano-roll note events
- method comparison table

### Right insight panel
- active note snapshot
- chord / harmony interpretation
- top candidate methods
- confidence and warnings
- performance stats

## Comparison modes

### Single-method debug
Best for detailed tuning.

### Side-by-side comparison
Run the same clip through several methods and show:
- note-event counts
- onset precision/recall
- false positives
- runtime cost
- confidence distributions

### Offline benchmark compare
Run a scenario pack and summarize results.

## Critical UX detail

Always make the current page state obvious:
- selected source
- selected method(s)
- whether shown data is live, replay, or offline batch
- whether theory bridge is on or off

This avoids mixing detector bugs with playback or storage confusion.

## Minimal v1 visualizations

1. Spectrogram with note-event overlays
2. Piano-roll event view
3. Onset curve
4. Per-note activation strip or heatmap
5. Chord interpretation summary

## Nice-to-have later

- alignment between microphone playback cursor and note roll
- manual relabeling helpers
- export to JSON/MIDI comparison pack
- saved comparison sessions
