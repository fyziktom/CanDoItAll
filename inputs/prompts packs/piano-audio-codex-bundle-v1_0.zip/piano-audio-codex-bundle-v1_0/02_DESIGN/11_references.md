# References

These references are the main conceptual background for the bundle.

## Browser / Blazor / PWA

1. Microsoft Learn — **ASP.NET Core Blazor JS interop performance best practices**
2. Microsoft Learn — **JavaScript JSImport/JSExport interop with ASP.NET Core Blazor**
3. Microsoft Learn — **ASP.NET Core Blazor Progressive Web Application (PWA)**
4. Microsoft Learn — **ASP.NET Core Blazor WebAssembly runtime performance**
5. Microsoft Learn — **ASP.NET Core Blazor WebAssembly build tools and ahead-of-time (AOT) compilation**
6. MDN — **Background audio processing using AudioWorklet**
7. W3C — **Web Audio API 1.1**

## Audio / MIR / transcription

1. Bello et al. — **A Tutorial on Onset Detection in Music Signals**
2. Brown — **Calculation of a constant Q spectral transform**
3. Klapuri — **Multiple Fundamental Frequency Estimation by Summing Harmonic Amplitudes**
4. Benetos et al. — **Automatic Music Transcription: An Overview**
5. Cheng et al. — **An Attack/Decay Model for Piano Transcription**
6. Rigaud et al. — **A Parametric Model and Estimation Techniques for the Inharmonicity and Tuning of the Piano**
7. Benetos and Dixon — **Multiple-instrument polyphonic music transcription using a temporally constrained shift-invariant model**
8. Reis et al. — **Automatic Transcription of Polyphonic Piano Music Using Genetic Algorithms, Adaptive Spectral Envelope Modeling, and Dynamic Noise Level Estimation**

## Why these references matter

- Bello: onset layer design
- Brown: CQT rationale
- Klapuri: harmonic-summation family
- Benetos overview: overall AMT design framing
- Cheng: piano attack/decay modeling
- Rigaud: piano inharmonicity modeling
- Benetos/Dixon and related NMF work: dictionary/temporal modeling
