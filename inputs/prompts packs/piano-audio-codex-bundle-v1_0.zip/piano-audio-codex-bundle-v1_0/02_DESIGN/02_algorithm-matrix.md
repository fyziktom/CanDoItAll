# Algorithm Matrix

This matrix compares the detector families that should be implemented or at least scaffolded.

| Method | What it does | Strengths | Weaknesses | WASM fit | Explainability | Recommended role |
|---|---|---|---|---|---|---|
| STFT + peak picking + harmonic clustering | Finds peaks and groups them by candidate fundamentals | Simple, already partly present, easy to debug | Weak on dense piano passages, limited note-state semantics | Excellent | High | Historical reference and early baseline |
| STFT + harmonic summation + onset + note states | Scores all 88 notes each frame and tracks them over time | Strong baseline, explainable, fast, good piano fit | Needs careful tuning for overlaps and inharmonicity | Excellent | High | **Primary baseline** |
| CQT activation detector | Uses pitch-aligned bins for note activation | Musical frequency layout, often cleaner note map | More complex implementation than STFT | Good | High | **Primary comparison method** |
| Piano template matching | Matches observed spectrum against note templates | Very strong for piano, especially with attack/sustain templates | Needs template management and normalization | Good | High | **Best classical practical contender** |
| Constrained NMF | Explains spectrogram as note templates × activations | Handles overlap well, strong classical benchmark | Heavier CPU cost, harder online implementation | Medium | Medium-high | Optional advanced experiment |
| pYIN / monophonic pitch | Monophonic fundamental tracking | Great for melody or single notes | Wrong target for dense piano polyphony | Good | High | Optional utility, not primary |
| Pure chroma-based chord inference | Estimates pitch classes only | Useful for harmony, robust to octave ambiguity | Loses note and onset detail | Excellent | Medium | Downstream helper, not note detector |
| Theory-only correction | Uses harmony rules to reshape output | Great for ranking ambiguous outputs | Dangerous if used too early | Excellent | Medium | Post-detection helper only |

## Recommended implementation order

1. STFT + onset + harmonic summation + state tracker
2. CQT activation detector
3. Piano template matching
4. Fusion of the above
5. Optional constrained NMF

## Default ranking expectation

For real piano in this product context, the expected quality order is:

1. Piano template matching + onset + state tracker
2. Fusion detector
3. CQT activation detector
4. Harmonic summation baseline
5. Optional constrained NMF may outperform some cases, but only if optimized and tuned well enough

## Why the harmonic summation baseline still matters

Even if template matching wins, harmonic summation is still essential because it:
- provides a clean reference method
- is easier to reason about during debugging
- helps isolate whether failures come from transform, onset, or template strategy
- can act as one vote inside fusion

## Why NMF is not first

NMF is powerful, but for a WASM-first experiment system it should come later because:
- tuning and convergence details can consume a lot of time
- it is easier to compare against once simpler methods already exist
- template matching and harmonic summation give immediate practical value
