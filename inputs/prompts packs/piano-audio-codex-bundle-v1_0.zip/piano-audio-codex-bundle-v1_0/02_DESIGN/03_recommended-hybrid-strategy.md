# Recommended Hybrid Strategy

This document describes the recommended detector strategy for the first serious implementation.

## Summary

Do **not** search for one magical algorithm.

Build a **detector lab** with several methods sharing the same:
- input blocks
- transform results
- note-state tracker contract
- evaluation harness
- UI comparison surface

Then promote the best detector or fusion as the default preset.

## Detector stack to implement

### Method A — Harmonic summation baseline
Use:
- STFT
- spectral flux onset
- 88-note salience map
- per-note state tracker
- sustain likelihood heuristic

Use this to:
- validate the pipeline
- establish real-time baseline performance
- provide explainable debugging evidence

### Method B — CQT activation detector
Use:
- CQT magnitude
- octave-normalized smoothing
- note activation map
- per-note state tracker

Use this to:
- compare pitch-aligned transform behavior against STFT
- see whether musical frequency spacing reduces octave or neighbor-note confusion

### Method C — Piano template matching
Use:
- STFT or CQT front-end
- note templates per key
- attack vs sustain templates
- cosine similarity or normalized correlation
- onset-guided note tracker

Use this to:
- push practical classical accuracy for piano
- exploit piano-specific timbral structure

### Method D — Fusion
Use:
- weighted merge of Methods A, B, and C
- confidence normalization
- note-state tracker support
- theory-friendly confidence output

Use this to:
- improve robustness
- suppress single-method failure modes

### Method E — Optional constrained NMF
Use:
- fixed dictionary of note templates
- activations updated in short windows
- batch or semi-online comparison mode

Use this to:
- explore the upper end of classical piano models
- provide a serious optional benchmark

## Recommended default preset

The default user-facing preset should eventually be:

**Fusion detector**
- onset source: spectral flux
- activation sources: harmonic summation + template matching
- optional CQT vote for ambiguity reduction
- note state tracker with small retrospective correction
- theory bridge enabled for interpretation, not for raw note generation

Why:
- keeps explainability
- remains modular
- handles diverse piano cases better than one source alone

## Where the music-theory engine fits

The theory engine should receive:
- note on/off events
- note confidences
- note durations or current state
- optional sustain likelihood

It should **not** be the first stage that decides whether a note exists.

Correct use:
- rank ambiguous outputs
- stabilize chord interpretations
- reject musically impossible transient combinations when the detector confidence is already weak

Incorrect use:
- invent notes that audio evidence never supported
- overwrite strong audio evidence because a chord label looks nicer

## Recommended tracker behavior

Each note `0..87` should have a state model:

- `Off`
- `AttackCandidate`
- `Active`
- `Sustained`
- `Release`

Suggested evidence inputs:
- onset evidence
- activation strength
- trend slope
- release evidence
- tail likelihood
- conflict from neighboring note hypotheses

Suggested outputs:
- note-on event
- note-off event
- per-note current confidence
- velocity-like estimate
- sustain-like estimate

## Why this hybrid strategy is appropriate for WASM

Because the heavy complexity is spread across modular parts:
- transforms are shared
- note tracking is shared
- UI and evaluation are shared
- only the activation estimator changes per method

This means you can compare methods without rewriting the whole app.
