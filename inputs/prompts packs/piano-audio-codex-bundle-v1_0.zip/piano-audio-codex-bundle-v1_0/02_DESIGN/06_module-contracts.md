# Module Contracts

This document defines the key interfaces that Codex should implement.

## 1. Audio input contracts

Core should receive normalized PCM blocks, not browser-specific handles.

Suggested contracts:
- `PcmBlock`
- `AudioSourceDescriptor`
- `IAudioBlockStream`

## 2. Transform contracts

Suggested contracts:
- `IFrameTransform`
- `TransformFrame`
- `TransformKind`

Notes:
- one input PCM stream may feed several transforms
- transforms should be reusable by multiple detectors
- do not recompute the same STFT twice for two methods if settings match

## 3. Feature contracts

Suggested contracts:
- `IOnsetDetector`
- `OnsetFrame`
- `IFeatureExtractor`

Notes:
- onset evidence should be method-agnostic where possible
- keep feature extraction isolated from note-state logic

## 4. Detector method contracts

Suggested contracts:
- `INoteDetectorMethod`
- `DetectorContext`
- `DetectorFrameInput`
- `DetectorFrameOutput`

Each method should expose:
- identifier
- display name
- transform requirements
- reset hook
- per-frame processing hook

Each frame output should contain:
- note activations
- note hypotheses
- method confidence summary
- debug evidence handles

## 5. Note tracker contracts

Suggested contracts:
- `INoteStateTracker`
- `TrackedNoteState`
- `NoteEvent`
- `TrackerFrameResult`

Responsibilities:
- receive method output plus onset/sustain hints
- emit note on/off events
- maintain current active notes snapshot

## 6. Fusion contracts

Suggested contracts:
- `IDetectorFusionStrategy`
- `FusionInputFrame`
- `FusionOutputFrame`

Responsibilities:
- normalize scores from different methods
- merge note hypotheses
- expose attribution for debugging

## 7. Theory bridge contracts

Suggested contracts:
- `IAudioTheoryBridge`
- `TheoryBridgeSnapshot`

Responsibilities:
- convert note events into the same semantic flow expected by Zyphonote recognition services
- keep timestamps and confidence

## 8. Evaluation contracts

Suggested contracts:
- `IDetectorBenchmarkHarness`
- `BenchmarkScenario`
- `BenchmarkRunResult`
- `DetectorMetricSet`

Responsibilities:
- run one clip through one or more methods
- capture CPU time, allocations, and note metrics
- support deterministic fixture tests
