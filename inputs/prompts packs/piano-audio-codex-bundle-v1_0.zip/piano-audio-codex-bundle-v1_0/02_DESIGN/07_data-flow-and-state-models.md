# Data Flow and State Models

## 1. Frame-level data flow

```text
PCM block
  -> resampler / normalizer
  -> ring buffer
  -> transform frame(s)
  -> onset feature(s)
  -> detector method output(s)
  -> note-state tracker
  -> note events + active note snapshot
  -> theory bridge
  -> UI / metrics / logs
```

## 2. Per-note tracker state machine

Recommended states:

- `Off`
- `AttackCandidate`
- `Active`
- `Sustained`
- `Release`

### Transition ideas

#### Off -> AttackCandidate
Conditions:
- onset evidence rises
- note activation crosses entry threshold
- neighboring conflict is acceptable

#### AttackCandidate -> Active
Conditions:
- activation remains above confirmation threshold
- evidence persists for minimum frames
- attack looks real, not single-frame noise

#### Active -> Sustained
Conditions:
- onset evidence falls
- activation remains above sustain threshold
- tail trend is consistent with hold or pedal-like decay

#### Active/Sustained -> Release
Conditions:
- activation falls below release threshold
- negative trend remains stable
- no fresh onset evidence for the same note

#### Release -> Off
Conditions:
- activation reaches floor for long enough
- no revival from resonance or repeated onset

## 3. Repeated-note handling

Repeated piano notes are important and should be explicit.

Suggested rule:
- if the same note receives strong fresh onset evidence while already active,
  generate a new `NoteOn` and either:
  - end the old note immediately, or
  - split into overlapping logical events with tracker-defined policy

For piano UX, most cases will be simpler if the old note is closed and the new attack starts a fresh event.

## 4. Sustain / tail modeling

Per-note fields worth keeping:
- current activation
- smoothed activation
- attack evidence
- release evidence
- last onset timestamp
- peak activation
- decay slope
- sustain likelihood
- frames since last confirmation

Global sustain fields worth keeping:
- estimated pedal likelihood
- number of long-lived tails
- background resonance index

## 5. Short retrospective correction

Keep a small frame history to support:
- onset time refinement
- note split refinement
- false-positive suppression
- event duration adjustment

Recommended modes:
- real-time mode: minimal look-back
- compare/offline mode: larger look-back allowed

## 6. Theory bridge timing

The theory bridge should consume stable note events or active-note snapshots, not raw frame activations.

Recommended cadence:
- update theory bridge on note events immediately
- optionally debounce chord interpretation similarly to the existing realtime MIDI session pattern

## 7. Data products the UI should show

### Raw-ish debug
- waveform excerpt
- spectrogram
- onset curve
- per-note activation heatmap

### Tracker/debug
- current active notes
- note states
- note event list
- sustain likelihood
- detector confidence

### Music-theory output
- pitch-class weights
- chord candidates
- bass / inversion
- scale context if available
