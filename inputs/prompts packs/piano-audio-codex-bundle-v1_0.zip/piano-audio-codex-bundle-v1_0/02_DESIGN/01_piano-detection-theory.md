# Piano Detection Theory

This section summarizes the most relevant classical signal-processing ideas for converting piano audio into note events.

## 1. Why piano is hard

Piano transcription is easier than arbitrary polyphonic audio in one sense: the pitch range and instrument family are known.

It is also hard because piano tones have:
- strong transients
- many overlapping harmonics
- weak or missing fundamentals in some regions
- note-dependent decay behavior
- inharmonicity due to stiff strings
- sympathetic resonance and pedal interaction
- repeated-note cases where a new onset happens before the previous tail fully disappears

A reliable piano detector therefore cannot rely on a single simple rule such as:
- strongest peak = note
- nearest FFT bin = note
- per-frame threshold = onset

It needs a **multi-layer interpretation**:
1. time-frequency transform
2. onset evidence
3. note activation estimate
4. per-note state tracking
5. optional sustain / pedal likelihood
6. short retrospective correction
7. optional music-theory interpretation layer

## 2. Transform choice

### STFT
Strengths:
- simple
- fast
- easy to reason about
- good for onset detection and harmonic evidence

Weaknesses:
- linear frequency spacing is not ideal for music
- fixed window creates a time/frequency tradeoff
- wide piano range often benefits from multiple resolutions

STFT is still an excellent baseline.

### CQT
Strengths:
- bins align more naturally with musical pitch spacing
- better pitch-oriented view of piano keys
- often easier for note activation mapping

Weaknesses:
- more involved implementation
- careful kernel precomputation needed for WASM efficiency
- time resolution varies with frequency

CQT is a very good second method for a piano-focused system.

## 3. Onset detection

Reliable note detection needs a dedicated onset layer.

Useful classical onset features:
- spectral flux
- broadband energy rise
- high-frequency content
- phase deviation
- weighted combination of several features

For piano, spectral flux is especially effective because the hammer attack causes a clear positive spectral change.

Recommended practical approach:
- compute spectral flux on the main transform
- smooth it slightly
- use an adaptive threshold
- keep a local-peak detector
- record onset evidence both globally and per-note region

The onset detector should not directly output notes.
It should provide evidence that the note tracker can use.

## 4. Harmonic summation / multi-F0 salience

A strong classical family for polyphonic note estimation is:
- generate a score for each candidate F0
- sum evidence from its partials
- weight lower partials more heavily
- allow some missing partials

For piano this works well when adapted to:
- 88 fixed note candidates
- note-dependent search bands
- inharmonicity tolerance
- missing-fundamental tolerance in lower notes

A practical piano salience function for note `n` can combine:
- energy near expected fundamental
- energy near harmonic partials
- penalty for unexplained competing energy
- per-register weights
- optional onset bonus

This is the best first baseline because it is:
- explainable
- fast
- testable
- easy to compare against more advanced methods

## 5. Template matching

Template matching compares the observed spectral shape with stored note templates.

Two important variants for piano:

### A. Theoretical harmonic templates
Build templates from:
- fundamental
- harmonic or weakly inharmonic partials
- amplitude decay curve by partial order

Pros:
- easy to generate
- no dataset required

Cons:
- less faithful to a specific piano and recording chain

### B. Empirical piano templates
Build templates from:
- isolated recordings of piano notes
- optionally separate attack and sustain templates

Pros:
- much stronger for real piano timbre
- better handling of instrument-specific spectral color

Cons:
- requires a template pack
- needs normalization and tuning strategy

For this project, empirical templates are worth supporting because:
- piano is the main target
- offline template packs are feasible
- attack/sustain templates fit classical methods well

## 6. NMF and attack/decay modeling

NMF is a classical and still very relevant method for piano transcription.

Idea:
- represent the spectrogram as a non-negative dictionary `W` times activations `H`
- each note can have one or more templates:
  - attack
  - sustain
  - optional release/noise component

Why it helps:
- multiple simultaneous notes can be explained as additive components
- attack and sustain can be separated
- piano-specific acoustics can be modeled explicitly

Why it is not the first baseline in WASM:
- implementation is heavier
- online operation is trickier
- optimization steps can be CPU-expensive

Recommended role:
- optional experiment tier
- likely windowed or semi-online rather than pure low-latency baseline
- useful as an upper classical benchmark

## 7. Piano inharmonicity

Real piano partials are not at exact integer multiples of the fundamental.

This matters because:
- exact harmonic matching will drift
- high-register notes and some mid/low partials can be mis-scored
- template matching often beats naive harmonic models partly for this reason

Minimum practical response:
- use broader tolerance bands that vary by register and harmonic order

Better response:
- estimate or configure a note/register-specific inharmonicity coefficient
- shift expected partial locations accordingly

Recommended for v1:
- start with tolerance bands
- add optional inharmonicity correction parameter per octave/register
- support empirical templates where possible

## 8. Sustain pedal and resonance

The sustain pedal changes note behavior in ways visible in both time and spectrum:
- longer decay
- denser spectral tail
- resonance on unstruck strings
- tones remain audible after key release

Direct pedal transcription is hard, but a useful first step is **sustain likelihood estimation**.

Recommended output:
- per-note `sustainLike` or `tailLikely`
- global `pedalLikely`
- not a hard binary ground truth claim unless evidence is strong

This information should help the note-state tracker decide whether a tail is:
- normal decay
- sustained resonance
- new onset
- false carry-over

## 9. Why note tracking matters more than frame classification

A frame classifier may say:
- note 60 active
- note 64 active
- note 67 active

But the actual product needs:
- onset time
- duration
- confidence
- repeated note separation
- sustain awareness

Therefore each piano note should be tracked through states such as:
- Off
- AttackCandidate
- Active
- Sustained
- Release

This state machine is the bridge between raw audio evidence and usable note events.

## 10. Retrospective correction window

Pure zero-lookahead decisions are fragile.

A short look-back buffer of roughly 100 to 400 ms can improve:
- onset placement
- attack/sustain disambiguation
- repeated-note detection
- noisy-frame rejection

The UI should expose whether a method is:
- low-latency online
- online with short retrospective correction
- batch/offline

This makes comparisons honest.

## 11. Recommended theoretical conclusion

For this project, the strongest classical stack is:

1. robust transform layer:
   - STFT baseline
   - CQT alternative
2. onset layer:
   - spectral flux + adaptive threshold
3. note activation layer:
   - harmonic summation
   - template matching
   - optional NMF
4. per-note state tracker:
   - attack / sustain / release logic
5. short retrospective smoothing
6. optional theory-layer correction and interpretation

That is the design center for the implementation prompts.
