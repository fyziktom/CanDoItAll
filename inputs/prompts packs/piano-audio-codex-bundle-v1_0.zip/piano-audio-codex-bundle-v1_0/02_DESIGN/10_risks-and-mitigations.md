# Risks and Mitigations

## 1. Browser microphone processing still alters signal
Risk:
- some platforms may still color the signal despite requested flags

Mitigation:
- expose capture diagnostics
- log actual sample rate
- encourage external mic or wired headphones when testing
- compare mic capture against uploaded file of the same passage

## 2. Room acoustics cause resonance and false notes
Risk:
- strong room reflections can create misleading tails

Mitigation:
- support close-mic testing
- include a noise floor and tail confidence visualization
- compare dry uploaded file against room mic capture

## 3. Repeated notes merge incorrectly
Risk:
- same-note retriggering is a classic piano failure mode

Mitigation:
- explicit repeated-note policy in tracker
- short retrospective correction window
- track onset evidence separately from sustain evidence

## 4. Low notes produce weak fundamentals
Risk:
- naive peak matching misses bass notes

Mitigation:
- harmonic summation with missing-fundamental tolerance
- lower-register weighting
- empirical templates for bass notes

## 5. High CPU in WASM
Risk:
- transform and detector comparisons may overload weaker devices

Mitigation:
- detector presets by performance tier
- shared transforms
- buffer reuse
- optional AOT benchmark build
- method comparison only on replay/batch when necessary

## 6. NMF takes too much time
Risk:
- optional advanced method may harm the overall product if treated as default

Mitigation:
- keep NMF behind experiment flag
- allow offline-only or replay-only mode first
- never block the baseline detector on NMF readiness

## 7. Theory layer over-corrects the audio
Risk:
- harmony inference may hide true audio detector failures

Mitigation:
- keep raw detector output visible
- allow theory bridge toggle
- log whether a note survived because of raw evidence or downstream ranking

## 8. UI complexity becomes overwhelming
Risk:
- too many knobs make the lab hard to use

Mitigation:
- include a few strong presets
- separate advanced tuning from common controls
- preserve a clear default comparison path
