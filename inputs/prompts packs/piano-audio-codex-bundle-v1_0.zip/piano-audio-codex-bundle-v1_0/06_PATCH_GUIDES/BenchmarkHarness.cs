using MusicAudioAnalysis.Core.Models;

namespace MusicAudioAnalysis.Core.Evaluation;

public sealed record ReferenceNoteEvent(
    int MidiNote,
    double OnsetMs,
    double OffsetMs);

public sealed record BenchmarkScenario(
    string Id,
    int SampleRate,
    float[] Samples,
    IReadOnlyList<ReferenceNoteEvent> ReferenceEvents);

public sealed record DetectorMetricSet(
    string MethodId,
    int PredictedEvents,
    int MatchedEvents,
    int FalsePositives,
    int FalseNegatives,
    double OnsetF1,
    double NoteF1,
    double RuntimeMs);

public sealed class DetectorBenchmarkHarness
{
    public DetectorMetricSet Evaluate(
        string methodId,
        IReadOnlyList<NoteEvent> predicted,
        IReadOnlyList<ReferenceNoteEvent> reference,
        double runtimeMs)
    {
        var matched = 0;
        var used = new HashSet<int>();

        foreach (var noteEvent in predicted.Where(static item => item.EventType == NoteEventType.NoteOn))
        {
            for (var i = 0; i < reference.Count; i++)
            {
                if (used.Contains(i))
                {
                    continue;
                }

                var expected = reference[i];
                if (expected.MidiNote == noteEvent.MidiNote &&
                    Math.Abs(expected.OnsetMs - noteEvent.TimestampMs) <= 80)
                {
                    used.Add(i);
                    matched++;
                    break;
                }
            }
        }

        var predictedOnsets = predicted.Count(static item => item.EventType == NoteEventType.NoteOn);
        var falsePositives = Math.Max(0, predictedOnsets - matched);
        var falseNegatives = Math.Max(0, reference.Count - matched);

        var precision = predictedOnsets == 0 ? 0 : (double)matched / predictedOnsets;
        var recall = reference.Count == 0 ? 0 : (double)matched / reference.Count;
        var f1 = (precision + recall) <= 0 ? 0 : (2 * precision * recall) / (precision + recall);

        return new DetectorMetricSet(
            MethodId: methodId,
            PredictedEvents: predictedOnsets,
            MatchedEvents: matched,
            FalsePositives: falsePositives,
            FalseNegatives: falseNegatives,
            OnsetF1: f1,
            NoteF1: f1,
            RuntimeMs: runtimeMs);
    }
}
