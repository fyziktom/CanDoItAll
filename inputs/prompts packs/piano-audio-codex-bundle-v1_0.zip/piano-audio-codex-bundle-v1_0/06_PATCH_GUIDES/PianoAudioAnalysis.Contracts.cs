using System.Collections.Immutable;

namespace MusicAudioAnalysis.Core.Models;

public enum DetectorMethodKind
{
    HarmonicSummation = 0,
    CqtActivation = 1,
    PianoTemplateMatching = 2,
    ConstrainedNmf = 3,
    Fusion = 4
}

public enum NoteEventType
{
    NoteOn = 0,
    NoteOff = 1
}

public enum TrackedNotePhase
{
    Off = 0,
    AttackCandidate = 1,
    Active = 2,
    Sustained = 3,
    Release = 4
}

public readonly record struct PcmBlock(
    double TimestampMs,
    int SampleRate,
    ReadOnlyMemory<float> Samples);

public sealed record TransformFrame(
    int FrameIndex,
    double TimestampMs,
    int SampleRate,
    int FftSize,
    int HopSize,
    ImmutableArray<float> Magnitude,
    ImmutableArray<float> Decibels);

public sealed record OnsetFrame(
    int FrameIndex,
    double TimestampMs,
    double Flux,
    double SmoothedFlux,
    double AdaptiveThreshold,
    bool IsOnsetPeak);

public sealed record NoteActivation(
    int MidiNote,
    double Activation,
    double OnsetEvidence,
    double HarmonicEvidence,
    double TemplateEvidence,
    double ReleaseEvidence,
    bool AttackLikely,
    bool ReleaseLikely,
    string? DebugLabel = null);

public sealed record DetectorFrameOutput(
    DetectorMethodKind MethodKind,
    int FrameIndex,
    double TimestampMs,
    ImmutableArray<NoteActivation> Activations,
    double MethodConfidence,
    string? DebugSummary = null);

public sealed record NoteEvent(
    NoteEventType EventType,
    int MidiNote,
    double TimestampMs,
    double Confidence,
    double VelocityLike,
    DetectorMethodKind SourceMethod,
    string? Reason = null);

public sealed record TrackedNoteSnapshot(
    int MidiNote,
    TrackedNotePhase Phase,
    double Activation,
    double SmoothedActivation,
    double Confidence,
    double SustainLikelihood,
    double LastOnsetTimestampMs,
    double PeakActivation);

public sealed record TrackerFrameResult(
    int FrameIndex,
    double TimestampMs,
    ImmutableArray<NoteEvent> NewEvents,
    ImmutableArray<TrackedNoteSnapshot> ActiveNotes,
    double GlobalSustainLikelihood);

public sealed record DetectorFrameInput(
    TransformFrame PrimaryTransform,
    OnsetFrame? OnsetFrame,
    IReadOnlyDictionary<string, object?> SharedArtifacts);

public interface INoteDetectorMethod
{
    string Id { get; }
    string DisplayName { get; }
    DetectorMethodKind MethodKind { get; }

    void Reset();

    DetectorFrameOutput ProcessFrame(DetectorFrameInput input);
}

public interface IOnsetDetector
{
    void Reset();

    OnsetFrame ProcessFrame(TransformFrame frame);
}

public interface INoteStateTracker
{
    void Reset();

    TrackerFrameResult ProcessFrame(
        DetectorMethodKind sourceMethod,
        int frameIndex,
        double timestampMs,
        ReadOnlySpan<NoteActivation> activations,
        double globalSustainLikelihood);
}
