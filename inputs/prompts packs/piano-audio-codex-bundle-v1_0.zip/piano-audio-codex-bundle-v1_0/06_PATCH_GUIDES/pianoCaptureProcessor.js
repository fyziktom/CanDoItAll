class PianoCaptureProcessor extends AudioWorkletProcessor {
  process(inputs, outputs) {
    const input = inputs[0]?.[0];
    const output = outputs[0]?.[0];

    if (output) {
      output.fill(0);
    }

    if (!input) {
      return true;
    }

    const chunk = new Float32Array(input.length);
    chunk.set(input);

    this.port.postMessage({
      type: "chunk",
      samples: chunk
    });

    return true;
  }
}

registerProcessor("piano-capture-processor", PianoCaptureProcessor);
