using System.Collections.Immutable;
using MusicAudioAnalysis.Core.Configuration;
using MusicAudioAnalysis.Core.Models;

namespace MusicAudioAnalysis.Core.Detectors;

public sealed class PianoTemplateMatchingDetector(TemplateMatchingOptions options) : INoteDetectorMethod
{
    private readonly TemplateMatchingOptions options = options;
    private readonly Dictionary<int, float[]> sustainTemplates = new();
    private readonly Dictionary<int, float[]> attackTemplates = new();

    public string Id => "piano-template";
    public string DisplayName => "Piano Template Matching";
    public DetectorMethodKind MethodKind => DetectorMethodKind.PianoTemplateMatching;

    public void Reset()
    {
    }

    public void LoadTemplate(int midiNote, float[] sustainTemplate, float[]? attackTemplate = null)
    {
        sustainTemplates[midiNote] = sustainTemplate;
        if (attackTemplate is not null)
        {
            attackTemplates[midiNote] = attackTemplate;
        }
    }

    public DetectorFrameOutput ProcessFrame(DetectorFrameInput input)
    {
        var frame = input.PrimaryTransform;
        var onset = input.OnsetFrame;
        var activations = ImmutableArray.CreateBuilder<NoteActivation>(88);

        for (var midi = 21; midi <= 108; midi++)
        {
            if (!sustainTemplates.TryGetValue(midi, out var sustainTemplate))
            {
                continue;
            }

            var sustainSimilarity = CosineSimilarity(frame.Magnitude.AsSpan(), sustainTemplate);
            var attackSimilarity = attackTemplates.TryGetValue(midi, out var attackTemplate)
                ? CosineSimilarity(frame.Magnitude.AsSpan(), attackTemplate)
                : sustainSimilarity;

            var onsetBoost = (onset?.IsOnsetPeak ?? false) ? 0.05 : 0;
            var activation = Math.Max(sustainSimilarity, attackSimilarity + onsetBoost);

            activations.Add(new NoteActivation(
                MidiNote: midi,
                Activation: activation,
                OnsetEvidence: onset?.SmoothedFlux ?? 0,
                HarmonicEvidence: 0,
                TemplateEvidence: Math.Max(sustainSimilarity, attackSimilarity),
                ReleaseEvidence: 0,
                AttackLikely: attackSimilarity >= options.SimilarityEntryThreshold && (onset?.IsOnsetPeak ?? false),
                ReleaseLikely: sustainSimilarity < options.SimilaritySustainThreshold,
                DebugLabel: $"Sustain={sustainSimilarity:F3}; Attack={attackSimilarity:F3}"));
        }

        var array = activations.ToImmutable();
        return new DetectorFrameOutput(
            MethodKind: MethodKind,
            FrameIndex: frame.FrameIndex,
            TimestampMs: frame.TimestampMs,
            Activations: array,
            MethodConfidence: array.Length == 0 ? 0 : array.Max(static item => item.Activation),
            DebugSummary: $"Template pack: {options.TemplatePackId}");
    }

    private static double CosineSimilarity(ReadOnlySpan<float> frameMagnitude, ReadOnlySpan<float> template)
    {
        var count = Math.Min(frameMagnitude.Length, template.Length);
        double dot = 0;
        double normA = 0;
        double normB = 0;

        for (var i = 0; i < count; i++)
        {
            dot += frameMagnitude[i] * template[i];
            normA += frameMagnitude[i] * frameMagnitude[i];
            normB += template[i] * template[i];
        }

        if (normA <= 0 || normB <= 0)
        {
            return 0;
        }

        return dot / (Math.Sqrt(normA) * Math.Sqrt(normB));
    }
}
