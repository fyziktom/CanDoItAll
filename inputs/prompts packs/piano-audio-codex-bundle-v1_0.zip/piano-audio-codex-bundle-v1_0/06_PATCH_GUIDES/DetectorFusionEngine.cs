using System.Collections.Immutable;
using MusicAudioAnalysis.Core.Configuration;
using MusicAudioAnalysis.Core.Models;

namespace MusicAudioAnalysis.Core.Fusion;

public sealed class WeightedDetectorFusion(FusionOptions options)
{
    private readonly FusionOptions options = options;

    public DetectorFrameOutput Merge(
        int frameIndex,
        double timestampMs,
        DetectorFrameOutput? harmonic,
        DetectorFrameOutput? cqt,
        DetectorFrameOutput? template)
    {
        var map = new Dictionary<int, MutableActivation>();

        Merge(map, harmonic, options.HarmonicWeight);
        Merge(map, cqt, options.CqtWeight);
        Merge(map, template, options.TemplateWeight);

        var builder = ImmutableArray.CreateBuilder<NoteActivation>(map.Count);
        foreach (var pair in map.OrderBy(static pair => pair.Key))
        {
            var activation = pair.Value;
            if (activation.WeightSum <= 0)
            {
                continue;
            }

            var merged = activation.Score / activation.WeightSum;
            if (merged < options.MinimumMergedConfidence)
            {
                continue;
            }

            builder.Add(new NoteActivation(
                MidiNote: pair.Key,
                Activation: merged,
                OnsetEvidence: activation.OnsetEvidence / activation.WeightSum,
                HarmonicEvidence: activation.HarmonicEvidence / activation.WeightSum,
                TemplateEvidence: activation.TemplateEvidence / activation.WeightSum,
                ReleaseEvidence: 0,
                AttackLikely: activation.AttackVote > 0,
                ReleaseLikely: activation.ReleaseVote > activation.AttackVote,
                DebugLabel: activation.Debug));
        }

        var array = builder.ToImmutable();
        return new DetectorFrameOutput(
            MethodKind: DetectorMethodKind.Fusion,
            FrameIndex: frameIndex,
            TimestampMs: timestampMs,
            Activations: array,
            MethodConfidence: array.Length == 0 ? 0 : array.Max(static item => item.Activation),
            DebugSummary: "Weighted detector fusion");
    }

    private static void Merge(
        Dictionary<int, MutableActivation> map,
        DetectorFrameOutput? frameOutput,
        double weight)
    {
        if (frameOutput is null || weight <= 0)
        {
            return;
        }

        foreach (var note in frameOutput.Activations)
        {
            if (!map.TryGetValue(note.MidiNote, out var target))
            {
                target = new MutableActivation();
                map[note.MidiNote] = target;
            }

            target.Score += note.Activation * weight;
            target.OnsetEvidence += note.OnsetEvidence * weight;
            target.HarmonicEvidence += note.HarmonicEvidence * weight;
            target.TemplateEvidence += note.TemplateEvidence * weight;
            target.WeightSum += weight;
            target.AttackVote += note.AttackLikely ? weight : 0;
            target.ReleaseVote += note.ReleaseLikely ? weight : 0;
            target.Debug = frameOutput.MethodKind.ToString();
        }
    }

    private sealed class MutableActivation
    {
        public double Score { get; set; }
        public double OnsetEvidence { get; set; }
        public double HarmonicEvidence { get; set; }
        public double TemplateEvidence { get; set; }
        public double WeightSum { get; set; }
        public double AttackVote { get; set; }
        public double ReleaseVote { get; set; }
        public string Debug { get; set; } = string.Empty;
    }
}
