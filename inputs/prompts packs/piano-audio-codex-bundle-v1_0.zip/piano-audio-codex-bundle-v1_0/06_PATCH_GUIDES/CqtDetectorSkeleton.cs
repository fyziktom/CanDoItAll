using System.Collections.Immutable;
using MusicAudioAnalysis.Core.Configuration;
using MusicAudioAnalysis.Core.Models;

namespace MusicAudioAnalysis.Core.Detectors;

public sealed class CqtActivationDetector(CqtOptions options) : INoteDetectorMethod
{
    private readonly CqtOptions options = options;
    private readonly double[] noteFrequencies = BuildPianoFrequencyTable();

    public string Id => "cqt-activation";
    public string DisplayName => "CQT Activation";
    public DetectorMethodKind MethodKind => DetectorMethodKind.CqtActivation;

    public void Reset()
    {
    }

    public DetectorFrameOutput ProcessFrame(DetectorFrameInput input)
    {
        var frame = input.PrimaryTransform;
        var onset = input.OnsetFrame;
        var activations = ImmutableArray.CreateBuilder<NoteActivation>(88);

        for (var midi = 21; midi <= 108; midi++)
        {
            var noteFrequency = noteFrequencies[midi];

            // This is intentionally a skeleton.
            // Codex should replace this with a real CQT bin or kernel mapping.
            var proxyEnergy = EstimateLogSpacedBandEnergy(frame, noteFrequency);
            var activation = proxyEnergy + ((onset?.IsOnsetPeak ?? false) ? 0.05 : 0);

            activations.Add(new NoteActivation(
                MidiNote: midi,
                Activation: activation,
                OnsetEvidence: onset?.SmoothedFlux ?? 0,
                HarmonicEvidence: proxyEnergy,
                TemplateEvidence: 0,
                ReleaseEvidence: 0,
                AttackLikely: activation >= 0.20 && (onset?.IsOnsetPeak ?? false),
                ReleaseLikely: activation < 0.08,
                DebugLabel: "CQT proxy"));
        }

        var array = activations.ToImmutable();
        return new DetectorFrameOutput(
            MethodKind: MethodKind,
            FrameIndex: frame.FrameIndex,
            TimestampMs: frame.TimestampMs,
            Activations: array,
            MethodConfidence: array.Length == 0 ? 0 : array.Max(static item => item.Activation),
            DebugSummary: "Replace proxy with true CQT implementation");
    }

    private static double EstimateLogSpacedBandEnergy(TransformFrame frame, double centerFrequencyHz)
    {
        var binWidth = (double)frame.SampleRate / frame.FftSize;
        var minHz = centerFrequencyHz / Math.Pow(2, 1d / 36d);
        var maxHz = centerFrequencyHz * Math.Pow(2, 1d / 36d);

        var minBin = Math.Max(0, (int)Math.Floor(minHz / binWidth));
        var maxBin = Math.Min(frame.Magnitude.Length - 1, (int)Math.Ceiling(maxHz / binWidth));

        double sum = 0;
        for (var bin = minBin; bin <= maxBin; bin++)
        {
            sum += frame.Magnitude[bin];
        }

        return sum;
    }

    private static double[] BuildPianoFrequencyTable()
    {
        var table = new double[128];
        for (var midi = 0; midi < table.Length; midi++)
        {
            table[midi] = 440.0 * Math.Pow(2, (midi - 69) / 12d);
        }

        return table;
    }
}
