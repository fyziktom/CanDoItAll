using MusicAudioAnalysis.Core.Configuration;
using MusicAudioAnalysis.Core.Models;

namespace MusicAudioAnalysis.Core.Features;

public sealed class SpectralFluxOnsetDetector(OnsetOptions options) : IOnsetDetector
{
    private readonly OnsetOptions options = options;
    private float[]? previousMagnitude;
    private readonly Queue<double> fluxHistory = new();

    public void Reset()
    {
        previousMagnitude = null;
        fluxHistory.Clear();
    }

    public OnsetFrame ProcessFrame(TransformFrame frame)
    {
        var magnitude = frame.Magnitude;
        if (previousMagnitude is null || previousMagnitude.Length != magnitude.Length)
        {
            previousMagnitude = magnitude.ToArray();
            return new OnsetFrame(frame.FrameIndex, frame.TimestampMs, 0, 0, 0, false);
        }

        double flux = 0;
        for (var i = 0; i < magnitude.Length; i++)
        {
            var delta = magnitude[i] - previousMagnitude[i];
            if (delta > 0)
            {
                flux += delta;
            }
        }

        Array.Copy(magnitude.AsSpan().ToArray(), previousMagnitude, magnitude.Length);

        fluxHistory.Enqueue(flux);
        while (fluxHistory.Count > Math.Max(4, options.AdaptiveWindowFrames))
        {
            fluxHistory.Dequeue();
        }

        var history = fluxHistory.ToArray();
        var average = history.Length == 0 ? 0 : history.Average();
        var threshold = average + options.FluxThresholdBias;
        var smoothed = history.Length <= 1 ? flux : history.Skip(Math.Max(0, history.Length - 3)).Average();
        var isPeak = smoothed >= threshold && smoothed >= options.PeakThreshold;

        return new OnsetFrame(
            FrameIndex: frame.FrameIndex,
            TimestampMs: frame.TimestampMs,
            Flux: flux,
            SmoothedFlux: smoothed,
            AdaptiveThreshold: threshold,
            IsOnsetPeak: isPeak);
    }
}
