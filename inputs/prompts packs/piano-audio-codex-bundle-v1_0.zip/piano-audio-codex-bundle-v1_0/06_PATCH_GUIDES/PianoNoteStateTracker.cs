using System.Collections.Immutable;
using MusicAudioAnalysis.Core.Configuration;
using MusicAudioAnalysis.Core.Models;

namespace MusicAudioAnalysis.Core.Tracking;

public sealed class PianoNoteStateTracker(NoteTrackerOptions options) : INoteStateTracker
{
    private readonly NoteTrackerOptions options = options;
    private readonly TrackedState[] states = Enumerable.Range(0, 128)
        .Select(_ => new TrackedState())
        .ToArray();

    public void Reset()
    {
        foreach (var state in states)
        {
            state.Reset();
        }
    }

    public TrackerFrameResult ProcessFrame(
        DetectorMethodKind sourceMethod,
        int frameIndex,
        double timestampMs,
        ReadOnlySpan<NoteActivation> activations,
        double globalSustainLikelihood)
    {
        var newEvents = ImmutableArray.CreateBuilder<NoteEvent>();
        var activeNotes = ImmutableArray.CreateBuilder<TrackedNoteSnapshot>();

        foreach (ref readonly var activation in activations)
        {
            if (activation.MidiNote < 0 || activation.MidiNote >= states.Length)
            {
                continue;
            }

            var state = states[activation.MidiNote];
            state.LastActivation = activation.Activation;
            state.SmoothedActivation = (state.SmoothedActivation * 0.7) + (activation.Activation * 0.3);
            state.Confidence = Math.Max(state.Confidence * 0.92, activation.Activation);
            state.SustainLikelihood = Math.Max(globalSustainLikelihood, state.SustainLikelihood * 0.92);

            switch (state.Phase)
            {
                case TrackedNotePhase.Off:
                    if (activation.AttackLikely && activation.Activation >= options.AttackEntryThreshold)
                    {
                        state.Phase = TrackedNotePhase.AttackCandidate;
                        state.AttackFrames = 1;
                        state.LastOnsetTimestampMs = timestampMs;
                        state.PeakActivation = activation.Activation;
                    }
                    break;

                case TrackedNotePhase.AttackCandidate:
                    state.AttackFrames++;
                    state.PeakActivation = Math.Max(state.PeakActivation, activation.Activation);

                    if (activation.Activation >= options.AttackConfirmThreshold &&
                        state.AttackFrames >= options.MinimumAttackFrames)
                    {
                        state.Phase = TrackedNotePhase.Active;
                        newEvents.Add(new NoteEvent(
                            NoteEventType.NoteOn,
                            activation.MidiNote,
                            timestampMs,
                            state.Confidence,
                            state.PeakActivation,
                            sourceMethod,
                            "Attack confirmed"));
                    }
                    else if (activation.Activation < options.ReleaseThreshold)
                    {
                        state.Reset();
                    }
                    break;

                case TrackedNotePhase.Active:
                case TrackedNotePhase.Sustained:
                    state.PeakActivation = Math.Max(state.PeakActivation, activation.Activation);

                    if (activation.AttackLikely && activation.Activation >= options.AttackConfirmThreshold)
                    {
                        newEvents.Add(new NoteEvent(
                            NoteEventType.NoteOff,
                            activation.MidiNote,
                            timestampMs,
                            state.Confidence,
                            state.PeakActivation,
                            sourceMethod,
                            "Retrigger split"));
                        state.Reset();
                        state.Phase = TrackedNotePhase.AttackCandidate;
                        state.AttackFrames = 1;
                        state.LastOnsetTimestampMs = timestampMs;
                        state.PeakActivation = activation.Activation;
                        break;
                    }

                    if (activation.Activation >= options.SustainThreshold)
                    {
                        state.Phase = state.SustainLikelihood >= 0.4
                            ? TrackedNotePhase.Sustained
                            : TrackedNotePhase.Active;
                        state.ReleaseFrames = 0;
                    }
                    else
                    {
                        state.Phase = TrackedNotePhase.Release;
                        state.ReleaseFrames = 1;
                    }
                    break;

                case TrackedNotePhase.Release:
                    if (activation.Activation >= options.SustainThreshold)
                    {
                        state.Phase = TrackedNotePhase.Active;
                        state.ReleaseFrames = 0;
                    }
                    else
                    {
                        state.ReleaseFrames++;
                        if (state.ReleaseFrames >= options.MinimumReleaseFrames)
                        {
                            newEvents.Add(new NoteEvent(
                                NoteEventType.NoteOff,
                                activation.MidiNote,
                                timestampMs,
                                state.Confidence,
                                state.PeakActivation,
                                sourceMethod,
                                "Release confirmed"));
                            state.Reset();
                        }
                    }
                    break;
            }
        }

        for (var midi = 21; midi <= 108; midi++)
        {
            var state = states[midi];
            if (state.Phase is TrackedNotePhase.Off)
            {
                continue;
            }

            activeNotes.Add(new TrackedNoteSnapshot(
                MidiNote: midi,
                Phase: state.Phase,
                Activation: state.LastActivation,
                SmoothedActivation: state.SmoothedActivation,
                Confidence: state.Confidence,
                SustainLikelihood: state.SustainLikelihood,
                LastOnsetTimestampMs: state.LastOnsetTimestampMs,
                PeakActivation: state.PeakActivation));
        }

        return new TrackerFrameResult(
            FrameIndex: frameIndex,
            TimestampMs: timestampMs,
            NewEvents: newEvents.ToImmutable(),
            ActiveNotes: activeNotes.ToImmutable(),
            GlobalSustainLikelihood: globalSustainLikelihood);
    }

    private sealed class TrackedState
    {
        public TrackedNotePhase Phase { get; set; }
        public double LastActivation { get; set; }
        public double SmoothedActivation { get; set; }
        public double Confidence { get; set; }
        public double SustainLikelihood { get; set; }
        public double LastOnsetTimestampMs { get; set; }
        public double PeakActivation { get; set; }
        public int AttackFrames { get; set; }
        public int ReleaseFrames { get; set; }

        public void Reset()
        {
            Phase = TrackedNotePhase.Off;
            LastActivation = 0;
            SmoothedActivation = 0;
            Confidence = 0;
            SustainLikelihood = 0;
            LastOnsetTimestampMs = 0;
            PeakActivation = 0;
            AttackFrames = 0;
            ReleaseFrames = 0;
        }
    }
}
