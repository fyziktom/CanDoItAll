namespace MusicAudioAnalysis.Core.Configuration;

public sealed record PianoDetectorOptions(
    AudioPreprocessingOptions Preprocessing,
    StftOptions Stft,
    CqtOptions Cqt,
    OnsetOptions Onset,
    HarmonicSummationOptions Harmonic,
    TemplateMatchingOptions TemplateMatching,
    NmfOptions Nmf,
    NoteTrackerOptions Tracker,
    FusionOptions Fusion)
{
    public static PianoDetectorOptions CreateDefault() => new(
        Preprocessing: new AudioPreprocessingOptions(),
        Stft: new StftOptions(),
        Cqt: new CqtOptions(),
        Onset: new OnsetOptions(),
        Harmonic: new HarmonicSummationOptions(),
        TemplateMatching: new TemplateMatchingOptions(),
        Nmf: new NmfOptions(),
        Tracker: new NoteTrackerOptions(),
        Fusion: new FusionOptions());
}

public sealed record AudioPreprocessingOptions(
    bool ConvertToMono = true,
    bool RemoveDcOffset = true,
    bool ApplyHighPass = true,
    double HighPassCutoffHz = 30,
    bool Normalize = true,
    int TargetSampleRate = 22050);

public sealed record StftOptions(
    int FftSize = 4096,
    int HopSize = 512,
    double MinimumFrequencyHz = 27.5,
    double MaximumFrequencyHz = 5000,
    bool UseHannWindow = true);

public sealed record CqtOptions(
    int BinsPerOctave = 36,
    int MinimumMidiNote = 21,
    int MaximumMidiNote = 108,
    int KernelFftSize = 4096);

public sealed record OnsetOptions(
    int SmoothingRadius = 2,
    double FluxThresholdBias = 0.02,
    double PeakThreshold = 0.08,
    int AdaptiveWindowFrames = 12);

public sealed record HarmonicSummationOptions(
    int MaximumHarmonicOrder = 8,
    bool AllowMissingFundamental = true,
    double BandToleranceCents = 30,
    double EntryThreshold = 0.22,
    double SustainThreshold = 0.11);

public sealed record TemplateMatchingOptions(
    bool EnableAttackTemplates = true,
    double SimilarityEntryThreshold = 0.70,
    double SimilaritySustainThreshold = 0.55,
    string TemplatePackId = "builtin-theoretical");

public sealed record NmfOptions(
    bool Enabled = false,
    int IterationsPerWindow = 10,
    int WindowFrameCount = 24,
    double ActivationFloor = 0.02);

public sealed record NoteTrackerOptions(
    double AttackEntryThreshold = 0.22,
    double AttackConfirmThreshold = 0.28,
    double SustainThreshold = 0.10,
    double ReleaseThreshold = 0.05,
    int MinimumAttackFrames = 2,
    int MinimumReleaseFrames = 2,
    int RetrospectiveFrameWindow = 6);

public sealed record FusionOptions(
    double HarmonicWeight = 0.34,
    double CqtWeight = 0.26,
    double TemplateWeight = 0.40,
    double MinimumMergedConfidence = 0.18);
