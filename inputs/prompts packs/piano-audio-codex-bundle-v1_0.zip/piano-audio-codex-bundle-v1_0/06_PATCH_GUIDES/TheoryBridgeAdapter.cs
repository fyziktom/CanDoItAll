using MusicTheory.Core.Recognition;

namespace App.Blazor.Services.Audio;

public sealed class AudioTheoryBridgeAdapter(
    RealtimeChordWindowDetector chordWindowDetector,
    RealtimeNoteScoreTracker noteScoreTracker,
    RealtimeChordDetectionService chordDetectionService)
{
    private readonly RealtimeChordWindowDetector chordWindowDetector = chordWindowDetector;
    private readonly RealtimeNoteScoreTracker noteScoreTracker = noteScoreTracker;
    private readonly RealtimeChordDetectionService chordDetectionService = chordDetectionService;

    public void Reset()
    {
        chordWindowDetector.Reset();
        noteScoreTracker.Reset();
    }

    public void ApplyAudioNoteEvent(int midiNote, bool isNoteOn, double timestampMs, int velocityLike)
    {
        var midiEvent = isNoteOn
            ? RealtimeMidiEvent.NoteOn(midiNote, velocityLike, timestampMs)
            : RealtimeMidiEvent.NoteOff(midiNote, 0, timestampMs);

        chordWindowDetector.Apply(midiEvent);
        noteScoreTracker.Apply(midiEvent);
    }

    public void ApplySustainLikelihood(bool sustainLikely, double timestampMs)
    {
        var midiEvent = RealtimeMidiEvent.Sustain(sustainLikely, timestampMs);
        chordWindowDetector.Apply(midiEvent);
        noteScoreTracker.Apply(midiEvent);
    }

    public RealtimeChordDetectionResult Evaluate(double nowMs, RealtimeChordDetectionOptions options)
    {
        var snapshot = chordWindowDetector.GetSnapshot(nowMs);
        var scoreSnapshot = noteScoreTracker.GetSnapshot(nowMs);
        return chordDetectionService.Detect(snapshot, scoreSnapshot, options);
    }
}
