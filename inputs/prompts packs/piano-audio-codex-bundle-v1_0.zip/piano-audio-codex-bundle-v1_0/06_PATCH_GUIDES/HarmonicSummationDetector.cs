using System.Collections.Immutable;
using MusicAudioAnalysis.Core.Configuration;
using MusicAudioAnalysis.Core.Models;

namespace MusicAudioAnalysis.Core.Detectors;

public sealed class HarmonicSummationDetector(HarmonicSummationOptions options) : INoteDetectorMethod
{
    private readonly HarmonicSummationOptions options = options;
    private readonly double[] noteFrequencies = BuildPianoFrequencyTable();

    public string Id => "harmonic-summation";
    public string DisplayName => "Harmonic Summation";
    public DetectorMethodKind MethodKind => DetectorMethodKind.HarmonicSummation;

    public void Reset()
    {
    }

    public DetectorFrameOutput ProcessFrame(DetectorFrameInput input)
    {
        var frame = input.PrimaryTransform;
        var onset = input.OnsetFrame;
        var activations = ImmutableArray.CreateBuilder<NoteActivation>(88);

        for (var midi = 21; midi <= 108; midi++)
        {
            var f0 = noteFrequencies[midi];
            var harmonicScore = 0.0;
            var weightTotal = 0.0;

            for (var order = 1; order <= options.MaximumHarmonicOrder; order++)
            {
                var partialFrequency = f0 * order;
                var weight = 1.0 / order;
                var bandEnergy = SumBandEnergy(
                    frame,
                    partialFrequency,
                    options.BandToleranceCents * (1.0 + ((order - 1) * 0.1)));

                if (order == 1 && options.AllowMissingFundamental && bandEnergy < 1e-5)
                {
                    weight *= 0.35;
                }

                harmonicScore += bandEnergy * weight;
                weightTotal += weight;
            }

            var normalized = weightTotal <= 0 ? 0 : harmonicScore / weightTotal;
            var onsetBoost = onset is not null && onset.IsOnsetPeak ? Math.Min(0.25, onset.SmoothedFlux * 0.05) : 0;
            var activation = normalized + onsetBoost;

            activations.Add(new NoteActivation(
                MidiNote: midi,
                Activation: activation,
                OnsetEvidence: onset?.SmoothedFlux ?? 0,
                HarmonicEvidence: normalized,
                TemplateEvidence: 0,
                ReleaseEvidence: 0,
                AttackLikely: activation >= options.EntryThreshold && (onset?.IsOnsetPeak ?? false),
                ReleaseLikely: activation < options.SustainThreshold,
                DebugLabel: $"F0={f0:F2}Hz"));
        }

        var array = activations.ToImmutable();
        var methodConfidence = array.Length == 0 ? 0 : array.Max(static item => item.Activation);

        return new DetectorFrameOutput(
            MethodKind: MethodKind,
            FrameIndex: frame.FrameIndex,
            TimestampMs: frame.TimestampMs,
            Activations: array,
            MethodConfidence: methodConfidence,
            DebugSummary: "88-note harmonic summation");
    }

    private static double SumBandEnergy(TransformFrame frame, double centerFrequencyHz, double toleranceCents)
    {
        var binWidth = (double)frame.SampleRate / frame.FftSize;
        var halfRatio = Math.Pow(2, toleranceCents / 1200d);
        var minHz = centerFrequencyHz / halfRatio;
        var maxHz = centerFrequencyHz * halfRatio;

        var minBin = Math.Max(0, (int)Math.Floor(minHz / binWidth));
        var maxBin = Math.Min(frame.Magnitude.Length - 1, (int)Math.Ceiling(maxHz / binWidth));

        double sum = 0;
        for (var bin = minBin; bin <= maxBin; bin++)
        {
            sum += frame.Magnitude[bin];
        }

        return sum;
    }

    private static double[] BuildPianoFrequencyTable()
    {
        var table = new double[128];
        for (var midi = 0; midi < table.Length; midi++)
        {
            table[midi] = 440.0 * Math.Pow(2, (midi - 69) / 12d);
        }

        return table;
    }
}
