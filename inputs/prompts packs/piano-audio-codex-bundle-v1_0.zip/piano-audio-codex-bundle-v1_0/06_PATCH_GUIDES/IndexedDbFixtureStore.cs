namespace App.Blazor.Services.Audio;

public sealed record StoredAudioClip(
    string Id,
    string Name,
    int SampleRate,
    float[] Samples,
    DateTimeOffset CreatedAtUtc,
    string SourceKind);

public interface IAudioClipStore
{
    Task SaveAsync(StoredAudioClip clip, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<StoredAudioClip>> ListAsync(CancellationToken cancellationToken = default);
    Task<StoredAudioClip?> GetAsync(string id, CancellationToken cancellationToken = default);
    Task DeleteAsync(string id, CancellationToken cancellationToken = default);
}
