using Microsoft.JSInterop;

namespace MusicAudioAnalysis.Browser.Services;

public sealed class PianoAudioCaptureService(IJSRuntime jsRuntime) : IAsyncDisposable
{
    private readonly IJSRuntime jsRuntime = jsRuntime;
    private IJSObjectReference? module;
    private string recorderId = Guid.NewGuid().ToString("N");

    public async Task InitializeAsync()
    {
        module ??= await jsRuntime.InvokeAsync<IJSObjectReference>(
            "import",
            "./_content/MusicAudioAnalysis.Browser/pianoAudioCapture.js");
    }

    public async Task<CaptureCapabilitiesDto> GetCapabilitiesAsync()
    {
        await InitializeAsync();
        return await module!.InvokeAsync<CaptureCapabilitiesDto>("getCapabilities");
    }

    public async Task<CaptureStartResultDto> StartMicrophoneCaptureAsync(int desiredSampleRate)
    {
        await InitializeAsync();
        return await module!.InvokeAsync<CaptureStartResultDto>(
            "startMicrophoneCapture",
            recorderId,
            desiredSampleRate);
    }

    public async Task<CaptureStopResultDto> StopMicrophoneCaptureAsync()
    {
        await InitializeAsync();
        return await module!.InvokeAsync<CaptureStopResultDto>(
            "stopMicrophoneCapture",
            recorderId);
    }

    public async Task<CaptureStopResultDto> DecodeAudioFileAsync(byte[] bytes)
    {
        await InitializeAsync();
        return await module!.InvokeAsync<CaptureStopResultDto>("decodeAudioFile", bytes);
    }

    public async ValueTask DisposeAsync()
    {
        if (module is null)
        {
            return;
        }

        try
        {
            await module.DisposeAsync();
        }
        catch
        {
        }
    }
}

public sealed record CaptureCapabilitiesDto(
    bool CanRecord,
    bool CanDecodeAudioFiles,
    bool HasAudioWorklet,
    string? Message);

public sealed record CaptureStartResultDto(
    int SampleRate,
    int ChannelCount);

public sealed record CaptureStopResultDto(
    int SampleRate,
    int ChannelCount,
    float[] Samples);
