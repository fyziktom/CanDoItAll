const recorders = new Map();

function getAudioContextCtor() {
  return window.AudioContext || window.webkitAudioContext || null;
}

function getRecorder(recorderId) {
  const recorder = recorders.get(recorderId);
  if (!recorder) {
    throw new Error(`Recorder '${recorderId}' was not found.`);
  }

  return recorder;
}

function mergeChunks(chunks) {
  const totalLength = chunks.reduce((sum, item) => sum + item.length, 0);
  const merged = new Float32Array(totalLength);
  let offset = 0;

  for (const chunk of chunks) {
    merged.set(chunk, offset);
    offset += chunk.length;
  }

  return merged;
}

async function cleanupRecorder(recorderId) {
  const recorder = recorders.get(recorderId);
  if (!recorder) {
    return;
  }

  try {
    recorder.worklet.port.onmessage = null;
    recorder.source.disconnect();
    recorder.worklet.disconnect();
    recorder.mutedGain.disconnect();

    for (const track of recorder.stream.getTracks()) {
      track.stop();
    }

    await recorder.audioContext.close();
  } finally {
    recorders.delete(recorderId);
  }
}

export async function getCapabilities() {
  const audioContextCtor = getAudioContextCtor();
  const hasMediaDevices = Boolean(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  const hasAudioWorklet = Boolean(audioContextCtor && audioContextCtor.prototype && "audioWorklet" in audioContextCtor.prototype);

  if (!audioContextCtor) {
    return {
      canRecord: false,
      canDecodeAudioFiles: false,
      hasAudioWorklet: false,
      message: "The browser does not expose the Web Audio API."
    };
  }

  return {
    canRecord: hasMediaDevices && hasAudioWorklet,
    canDecodeAudioFiles: true,
    hasAudioWorklet,
    message: hasMediaDevices
      ? "Microphone capture is available."
      : "Microphone capture is unavailable in this browser."
  };
}

export async function startMicrophoneCapture(recorderId, desiredSampleRate) {
  const audioContextCtor = getAudioContextCtor();
  if (!audioContextCtor) {
    throw new Error("Web Audio API is not available.");
  }

  const stream = await navigator.mediaDevices.getUserMedia({
    audio: {
      channelCount: 1,
      echoCancellation: false,
      noiseSuppression: false,
      autoGainControl: false
    }
  });

  const audioContext = desiredSampleRate > 0
    ? new audioContextCtor({ sampleRate: desiredSampleRate })
    : new audioContextCtor();

  await audioContext.audioWorklet.addModule(new URL("./pianoCaptureProcessor.js", import.meta.url));

  const source = audioContext.createMediaStreamSource(stream);
  const worklet = new AudioWorkletNode(audioContext, "piano-capture-processor", {
    numberOfInputs: 1,
    numberOfOutputs: 1,
    outputChannelCount: [1]
  });

  const mutedGain = audioContext.createGain();
  mutedGain.gain.value = 0;

  const chunks = [];
  worklet.port.onmessage = (event) => {
    if (event.data?.type === "chunk" && event.data.samples) {
      chunks.push(new Float32Array(event.data.samples));
    }
  };

  source.connect(worklet);
  worklet.connect(mutedGain);
  mutedGain.connect(audioContext.destination);

  await audioContext.resume();

  recorders.set(recorderId, {
    audioContext,
    stream,
    source,
    worklet,
    mutedGain,
    chunks
  });

  return {
    sampleRate: audioContext.sampleRate,
    channelCount: 1
  };
}

export async function stopMicrophoneCapture(recorderId) {
  const recorder = getRecorder(recorderId);
  const samples = mergeChunks(recorder.chunks);

  const result = {
    sampleRate: recorder.audioContext.sampleRate,
    channelCount: 1,
    samples: Array.from(samples)
  };

  await cleanupRecorder(recorderId);
  return result;
}

export async function decodeAudioFile(fileBytes) {
  const audioContextCtor = getAudioContextCtor();
  if (!audioContextCtor) {
    throw new Error("Web Audio API is not available.");
  }

  const audioContext = new audioContextCtor();
  try {
    const arrayBuffer = fileBytes.buffer.slice(
      fileBytes.byteOffset,
      fileBytes.byteOffset + fileBytes.byteLength);

    const audioBuffer = await audioContext.decodeAudioData(arrayBuffer.slice(0));
    const output = new Float32Array(audioBuffer.length);

    for (let channelIndex = 0; channelIndex < audioBuffer.numberOfChannels; channelIndex += 1) {
      const channel = audioBuffer.getChannelData(channelIndex);
      for (let sampleIndex = 0; sampleIndex < output.length; sampleIndex += 1) {
        output[sampleIndex] += channel[sampleIndex] / audioBuffer.numberOfChannels;
      }
    }

    return {
      sampleRate: audioBuffer.sampleRate,
      channelCount: 1,
      samples: Array.from(output)
    };
  } finally {
    await audioContext.close();
  }
}
