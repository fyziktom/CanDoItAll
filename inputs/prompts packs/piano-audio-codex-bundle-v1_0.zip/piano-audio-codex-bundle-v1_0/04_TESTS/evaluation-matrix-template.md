# Evaluation Matrix Template

Use this table when comparing methods manually.

| Session | Clip | Method | Preset | Correct notes | Extra notes | Missed notes | Repeated note quality | Sustain handling | Runtime feel | Overall |
|---|---|---|---|---:|---:|---:|---|---|---|---|
| Example | real-phrase-01 | Harmonic | Balanced |  |  |  |  |  |  |  |
| Example | real-phrase-01 | CQT | Balanced |  |  |  |  |  |  |  |
| Example | real-phrase-01 | Template | PianoTemplate |  |  |  |  |  |  |  |
| Example | real-phrase-01 | Fusion | Default |  |  |  |  |  |  |  |

Freeform notes:
- microphone placement:
- piano:
- browser/device:
- detector observations:
