# Tests and Benchmarking

This folder defines how the new piano audio subsystem should be tested.

The testing strategy must cover four layers:

1. **Transform correctness**
   - STFT / CQT / preprocessing sanity
2. **Detector correctness**
   - note activation, onsets, and note events on deterministic fixtures
3. **Integration correctness**
   - bridge from audio events into Zyphonote harmony recognition
4. **Performance practicality**
   - runtime and allocation behavior in WASM-friendly conditions

The benchmark harness should be treated as part of the product, not an afterthought.
It is the mechanism that lets you compare methods honestly.
