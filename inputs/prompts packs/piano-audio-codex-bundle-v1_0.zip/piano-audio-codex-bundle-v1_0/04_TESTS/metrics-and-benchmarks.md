# Metrics and Benchmarks

## Event-level metrics

### Note event precision / recall / F1
Match predicted and reference note events using tolerances:
- pitch must match exactly
- onset tolerance configurable
- offset tolerance configurable or relaxed for sustain-heavy cases

### Onset precision / recall / F1
This often reveals problems earlier than full note metrics.

### Octave error rate
Count cases where pitch class is correct but octave is wrong.

### Duplicate onset rate
Important for repeated-note handling and attack instability.

### Tail confusion proxy
A pragmatic metric for sustain behavior:
- notes that remain active much longer than reference without strong sustain evidence

## Runtime metrics

Capture at minimum:
- total analysis time
- transform time
- detector time
- tracker time
- theory-bridge time
- allocations if measurable
- audio seconds processed per wall-clock second

## Comparison dimensions

Track results by:
- detector method
- preset
- source type
- sample rate
- browser/device if recorded manually
- synthetic vs real fixture

## Suggested report format

For each run:
- clip id
- method id
- preset id
- notes predicted
- notes matched
- false positives
- false negatives
- onset F1
- note F1
- runtime
- comments / environment
