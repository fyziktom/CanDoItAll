# Manual Real Piano Test Protocol

Use this protocol when testing with a real piano and microphone.

## Setup

Record the following metadata before testing:
- date
- browser
- device
- microphone
- piano type if known
- mic placement
- sample rate
- detector preset

## Test 1 — Isolated notes
Play:
- one note in bass
- one in low-mid
- one in center
- one in upper-mid
- one in high register

For each:
- soft
- medium
- loud

Observe:
- correct pitch
- onset responsiveness
- false neighbor notes
- tail behavior

## Test 2 — Simple chords
Play:
- major triad
- minor triad
- octave
- close cluster if relevant

Observe:
- missing notes
- octave confusion
- excessive extra notes
- chord interpretation quality

## Test 3 — Repeated notes
Play:
- same note repeated slowly
- same note repeated faster
- same note repeated with partial overlap

Observe:
- merged events
- duplicate false onsets
- missed retriggers

## Test 4 — Staccato vs legato
Play the same short phrase twice:
- staccato
- legato

Observe:
- release timing quality
- sustained tails
- phrase stability

## Test 5 — Sustain pedal
Play:
- chord without pedal
- same chord with pedal
- simple progression with pedal

Observe:
- tail length
- spurious continued notes
- pedal-likelihood indication if implemented

## Test 6 — Short musical phrase
Play a very short real phrase that you can repeat consistently.

Compare methods:
- harmonic
- CQT
- template
- fusion
- optional NMF

Log:
- best method
- worst method
- what failed
- confidence vs reality

## After each session

Store:
- recording id
- notes
- screenshots if useful
- detector preset
- manual comments
