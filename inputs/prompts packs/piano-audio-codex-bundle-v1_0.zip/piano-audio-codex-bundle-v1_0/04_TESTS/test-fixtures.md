# Test Fixtures

## A. Deterministic synthetic fixtures

These should exist first because they are easy to reproduce.

Minimum set:
1. isolated note per octave
2. soft isolated note per octave
3. octave interval
4. perfect fifth
5. major triad
6. minor triad
7. arpeggiated triad
8. repeated same note with clear gap
9. repeated same note with short overlap/tail
10. simple sustain-like tail case
11. short phrase with silence before and after

## B. Semi-synthetic fixtures

Create by mixing or shaping isolated-note building blocks:
- overlapped dyads
- repeated-note passages
- varied attack strength
- fixed room-noise overlay

## C. Real piano fixtures

At minimum collect:
- close-mic isolated notes
- close-mic major/minor triads
- repeated notes
- staccato phrase
- legato phrase
- sustain pedal simple example
- short real musical phrase

Store metadata:
- piano identity if known
- microphone placement
- distance
- room notes
- sample rate
- whether pedal was used

## D. Annotation format

Recommended fields:
- clip id
- sample rate
- source type
- reference note events:
  - midi note
  - onset ms
  - offset ms
  - optional velocity-like value
  - optional sustain flag

## E. Fixture progression

Phase 1:
- deterministic synthetic only

Phase 2:
- semi-synthetic edge cases

Phase 3:
- real piano manual pack
