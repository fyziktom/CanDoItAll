# Performance Checklist

- [ ] No obvious per-frame LINQ allocations in hot path
- [ ] Shared transforms reused in compare mode
- [ ] Reusable buffers in transforms and detectors
- [ ] Timing instrumentation visible or logged
- [ ] Compare mode remains usable on a normal laptop
- [ ] Default preset is not unreasonably heavy
- [ ] Experimental NMF mode is clearly labeled heavier
- [ ] Optional SIMD / AOT notes documented
