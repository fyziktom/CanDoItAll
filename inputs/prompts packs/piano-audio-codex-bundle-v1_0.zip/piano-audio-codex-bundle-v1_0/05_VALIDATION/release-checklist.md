# Release Checklist

- [ ] Build passes
- [ ] Tests pass
- [ ] Docs under `docs/audio/` are updated
- [ ] Feature route works in browser
- [ ] Offline reload checked
- [ ] Template/static assets included in publish output
- [ ] Worklet assets included in publish output
- [ ] Experimental features are labeled experimental
- [ ] Final validation report created
