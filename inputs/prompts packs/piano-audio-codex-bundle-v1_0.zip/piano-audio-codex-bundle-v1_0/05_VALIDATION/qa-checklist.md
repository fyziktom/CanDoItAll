# QA Checklist

## General
- [ ] Page loads without console errors
- [ ] Route is discoverable
- [ ] Detector presets load correctly

## Microphone mode
- [ ] Can start capture
- [ ] Can stop capture
- [ ] Shows actual sample rate
- [ ] Shows audio arriving
- [ ] No frozen UI during short tests

## File mode
- [ ] Can import local audio file
- [ ] Metadata shown correctly
- [ ] Analysis can be replayed repeatedly

## Detector comparison
- [ ] At least 3 methods selectable
- [ ] Same clip can be compared across methods
- [ ] Metrics are shown
- [ ] Raw note events are visible
- [ ] Harmony output is visible

## Edge cases
- [ ] Silence does not create many false notes
- [ ] Repeated notes are not always merged
- [ ] Sustain-heavy passage does not explode into nonsense
- [ ] High notes and low notes both work at least minimally

## Offline
- [ ] After install and first load, app can reopen offline
- [ ] Audio lab route still loads offline
- [ ] Local presets remain available offline
