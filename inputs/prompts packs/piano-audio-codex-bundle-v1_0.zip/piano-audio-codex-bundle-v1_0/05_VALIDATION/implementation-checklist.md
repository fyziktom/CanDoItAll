# Implementation Checklist

## Core architecture
- [ ] New audio projects added to solution
- [ ] DSP core separated from browser interop
- [ ] Detector interface exists
- [ ] Shared tracker exists
- [ ] Shared benchmark harness exists

## Capture and offline
- [ ] Microphone capture works
- [ ] File decode works
- [ ] Local storage for recordings/presets exists
- [ ] PWA still loads offline after first install

## Methods
- [ ] Harmonic summation method
- [ ] CQT method
- [ ] Template method
- [ ] Fusion method
- [ ] Optional NMF method clearly marked experimental

## Product integration
- [ ] Audio lab page exists
- [ ] Theory bridge exists
- [ ] Raw detector output visible
- [ ] Harmonic interpretation visible

## Testing
- [ ] Transform tests
- [ ] Detector tests
- [ ] Tracker tests
- [ ] Harmony bridge tests
- [ ] Benchmark harness tests
