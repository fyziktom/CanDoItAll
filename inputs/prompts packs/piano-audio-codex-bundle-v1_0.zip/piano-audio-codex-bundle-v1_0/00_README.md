# Piano Audio Detection for Zyphonote — Codex Automation Bundle (v1.0)

This bundle is a complete implementation pack for adding **offline piano note detection from microphone/file audio** to the Zyphonote Blazor WebAssembly PWA.

It was prepared after reviewing:

- `BlazorSoundSpectralAnalysis - kopie`
- `zyphonote-feature-harmonic-assistant-wow-canvas-and-scoring`

## Intent

Build a **modular, experiment-friendly piano detector lab** that can compare several classical DSP-based note detection methods inside **Blazor WebAssembly**, work **offline as a PWA**, and bridge into the existing Zyphonote music-theory stack for chord and harmonic interpretation.

The bundle is intentionally implementation-oriented. It contains:

- repo audit and reuse map
- piano detection theory and method comparison
- target architecture for WASM/PWA
- code scaffolding and patch guides
- test plans, validation checklists, and performance guardrails
- a sequence of Codex prompts that should be executed in order

## Key decisions

1. **Implement inside the Zyphonote repository** rather than extending the separate spectral demo as the main product surface.
2. **Treat the current spectral demo as a reference donor**, not as the final architecture.
3. **Focus on piano first**:
   - 88-note activation map
   - onset + sustain + release tracking
   - sustain-pedal likelihood estimation
   - short retrospective correction window
4. **Keep multiple detectors pluggable**:
   - Harmonic summation baseline
   - CQT activation detector
   - Piano template matching
   - Optional constrained NMF experiment
   - Fusion layer for comparison
5. **Reuse Zyphonote theory after note evidence exists**, not as a replacement for low-level audio detection.

## What I reviewed in the current codebase

### From the spectral demo

Strong reusable ideas:
- pure C# preprocessing and STFT pipeline
- peak picking and harmonic clustering
- tone-track visualization/workbench
- browser microphone capture through `getUserMedia` + `AudioWorklet`
- deterministic synthetic piano-like clips and basic tests

Main gaps for robust piano transcription:
- no dedicated onset/offset detector
- no per-note piano state machine
- no pedal/sustain estimator
- no inharmonicity-aware piano templates
- no detector plug-in system
- no multi-method benchmark harness
- no strong bridge into harmonic interpretation

### From Zyphonote

Strong reusable assets:
- pitch-class / note-name / interval domain model
- chord recognition engine and voicing analysis
- realtime note score tracker
- realtime chord window detector
- sustain-aware MIDI note tracking
- existing Blazor WASM PWA shell
- existing IndexedDB storage pattern
- existing Codex bundle style and workflow

## Important limitation

I could inspect the repositories thoroughly, but I **could not run `dotnet build` or `dotnet test` in this environment because the .NET SDK is not available here**. The bundle therefore gives Codex very explicit build/test gates, but the actual compile validation must happen in your target environment.

## Human usage

1. Give Codex the **START PROMPT** below.
2. Ensure Codex works inside the **Zyphonote repository**, not inside the standalone spectral demo repository.
3. Make Codex execute the files in `/03_CODEX_PROMPTS` in numeric order.
4. Validate with `/05_VALIDATION/*.md`.
5. Use `/04_TESTS/manual-real-piano-test-protocol.md` to test with a real piano and compare methods.

## START PROMPT

START PROMPT (Codex)

You are Codex. Implement a modular offline piano note-detection subsystem inside the Zyphonote repository.

Primary goals:
- Add microphone/file audio piano detection to the standalone Blazor WebAssembly PWA.
- Keep the app offline-capable as a PWA.
- Keep the hot-path DSP in pure C# where possible.
- Support multiple detector methods that can be selected and compared:
  - Harmonic summation baseline
  - CQT activation detector
  - Piano template matching detector
  - Optional constrained NMF experiment
  - Fusion detector
- Bridge note events into the existing Zyphonote harmonic analysis stack.
- Add an experiment UI page for detector comparison, spectrograms, note roll, and metrics.
- Add tests, fixtures, performance instrumentation, and validation docs.

Hard rules:
- Follow `/03_CODEX_PROMPTS` in numeric order. Do not skip steps.
- Keep all code comments in English.
- Prefer small, compilable checkpoints.
- After each step, run build/tests relevant to the modified projects.
- Do not remove working Zyphonote features.
- Do not introduce any mandatory network dependency or cloud service.
- Do not make SharedArrayBuffer or worker-isolation a hard requirement.
- Keep detector methods pluggable behind interfaces.
- Keep one comparison page where multiple methods can be run against the same input.
- When in doubt, preserve explainability over opaque heuristics.

Start:
1. Read `/00_README.md` fully.
2. Read everything in `/01_CONTEXT` and `/02_DESIGN`.
3. Execute `/03_CODEX_PROMPTS/01_...` through the final prompt in order.
4. Update the progress checklist in `/00_README.md` after each prompt.

## Progress Checklist

- [ ] 01 Repo audit confirmation and solution scaffold
- [ ] 02 Browser audio capture and offline fixture storage
- [ ] 03 STFT / spectrogram core brought into Zyphonote
- [ ] 04 Onset detection and note state tracker
- [ ] 05 Harmonic summation piano detector
- [ ] 06 CQT activation detector
- [ ] 07 Piano template matching detector
- [ ] 08 Detector fusion and theory bridge
- [ ] 09 Piano audio lab UI
- [ ] 10 Fixtures, metrics, and benchmark harness
- [ ] 11 WASM performance pass
- [ ] 12 Optional constrained NMF experiment
- [ ] 13 Final validation and cleanup

## Final target summary

After the prompt sequence, Zyphonote should have:

- a new audio-analysis subsystem
- browser microphone/file capture for piano analysis
- detector presets and per-method tuning
- side-by-side method comparison
- note-event output with confidence and sustain likelihood
- harmony interpretation through the existing theory engine
- offline PWA behavior
- real-piano test workflow
- regression tests and validation checklists
