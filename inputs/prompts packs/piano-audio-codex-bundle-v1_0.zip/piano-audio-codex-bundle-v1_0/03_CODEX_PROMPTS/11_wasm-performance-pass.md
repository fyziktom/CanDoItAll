# 11 — WASM performance pass

Goal:
Make the detector lab practical in the browser.

Tasks:
1. Profile allocation hotspots and remove obvious avoidable allocations.
2. Reuse buffers and precompute:
   - windows
   - note frequency maps
   - harmonic band maps
   - CQT kernels
3. Ensure comparison mode shares transforms when possible.
4. Add performance counters or debug timing in:
   - capture
   - transform
   - detector
   - tracker
   - theory bridge
5. Add optional build/runtime notes for:
   - SIMD
   - AOT benchmark builds
6. Add or update:
   - `docs/audio/performance.md`
7. Add at least one performance-oriented regression test or smoke benchmark.

Acceptance:
- obvious per-frame allocations are reduced
- performance counters are visible or logged
- docs explain how to run a higher-performance build

Self-check:
- `dotnet test tests/MusicAudioAnalysis.Tests`
- `dotnet build Zyphonote.slnx`
