# 04 — Onset detection and note state tracker

Goal:
Add the timing intelligence that converts frame evidence into note events.

Tasks:
1. Implement a dedicated onset detector:
   - spectral flux
   - smoothing
   - adaptive threshold
   - local maxima extraction
2. Add per-note state tracking with states:
   - Off
   - AttackCandidate
   - Active
   - Sustained
   - Release
3. Keep tracker thresholds configurable.
4. Emit note events:
   - note on
   - note off
   - confidence
   - velocity-like estimate
5. Add a short retrospective correction buffer.
6. Add tests for:
   - single note onset
   - two separated onsets of the same note
   - simple sustain tail
7. Add UI sections:
   - onset curve
   - recent note events
   - active-note snapshot

Acceptance:
- tracker can emit note events from synthetic fixtures
- repeated-note behavior is explicitly tested
- onset evidence is visible in the UI

Self-check:
- `dotnet test tests/MusicAudioAnalysis.Tests`
- `dotnet build Zyphonote.slnx`
