# 03 — STFT / spectrogram core brought into Zyphonote

Goal:
Create the shared transform and spectrogram foundation.

Tasks:
1. Port or reimplement the useful STFT pieces from the reviewed spectral demo into `MusicAudioAnalysis.Core`.
2. Keep the new code modular:
   - transform settings
   - reusable window generation
   - FFT wrapper or implementation
   - spectrogram frame model
3. Add preprocessing utilities:
   - mono normalization
   - DC removal
   - optional high-pass
   - optional normalization
   - optional trim / noise gate only if cleanly isolated
4. Add a small fixture generator or import the deterministic synthetic idea for:
   - single note
   - simple dyad
   - triad
5. Add transform tests:
   - frame count expectations
   - frequency-bin sanity checks
   - simple synthetic note peak sanity test
6. Add a first spectrogram visualization section to the lab page.

Acceptance:
- STFT frames can be generated deterministically from fixture input
- spectrogram visualization appears on the page
- transform tests pass

Self-check:
- `dotnet test tests/MusicAudioAnalysis.Tests`
- `dotnet build Zyphonote.slnx`
