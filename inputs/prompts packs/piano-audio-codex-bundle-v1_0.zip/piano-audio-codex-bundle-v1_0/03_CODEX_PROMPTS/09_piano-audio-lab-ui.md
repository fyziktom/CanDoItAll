# 09 — Piano audio lab UI

Goal:
Turn the feature into a usable comparison workbench.

Tasks:
1. Upgrade the placeholder page into a practical lab page.
2. Add clear sections for:
   - source selection
   - detector selection
   - compare mode
   - spectrogram
   - note roll / note event list
   - harmony interpretation
   - performance metrics
3. Add a comparison table summarizing, per method:
   - detected note count
   - active notes
   - average confidence
   - runtime
4. Add a visual note-event or piano-roll display.
5. Keep the page understandable in both:
   - live mode
   - replay/offline mode
6. Add warnings or badges for:
   - live low-confidence
   - too many notes
   - likely sustain-heavy passage
   - experimental method enabled

Acceptance:
- lab page is usable without reading code
- multiple methods can be compared on the same clip
- raw detector evidence and harmony output are visible

Self-check:
- `dotnet build Zyphonote.slnx`
- manual browser verification
