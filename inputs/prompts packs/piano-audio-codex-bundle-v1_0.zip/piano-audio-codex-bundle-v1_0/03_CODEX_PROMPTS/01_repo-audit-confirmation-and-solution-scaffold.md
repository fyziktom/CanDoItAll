# 01 — Repo audit confirmation and solution scaffold

Goal:
Create the project scaffold for the new audio subsystem inside Zyphonote without yet implementing heavy detector logic.

Tasks:
1. Confirm current solution layout and choose final project names:
   - `src/MusicAudioAnalysis.Core`
   - `src/MusicAudioAnalysis.Browser`
   - `tests/MusicAudioAnalysis.Tests`
2. Add the new projects to `Zyphonote.slnx`.
3. Wire project references:
   - `App.Blazor` should reference the new audio projects.
4. Create initial folder structure in `MusicAudioAnalysis.Core`:
   - `Configuration`
   - `Models`
   - `Transforms`
   - `Features`
   - `Detectors`
   - `Tracking`
   - `Fusion`
   - `Evaluation`
   - `Fixtures`
5. Create initial folder structure in `MusicAudioAnalysis.Browser`:
   - `Services`
   - `Interop`
   - `wwwroot`
6. Add a short architecture note:
   - `docs/audio/piano-audio-lab-architecture.md`
7. Add placeholder interfaces based on `/02_DESIGN/06_module-contracts.md`.
8. Add a placeholder route/page:
   - `PianoAudioLab.razor`
   - simple "work in progress" sections for source/method/results

Acceptance:
- solution builds
- new projects are referenced correctly
- placeholder page route exists
- architecture note exists

Self-check:
- `dotnet build Zyphonote.slnx`
