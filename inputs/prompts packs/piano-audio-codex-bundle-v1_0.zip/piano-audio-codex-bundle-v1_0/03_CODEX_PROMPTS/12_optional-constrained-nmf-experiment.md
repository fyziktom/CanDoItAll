# 12 — Optional constrained NMF experiment

Goal:
Add an advanced classical experiment method without destabilizing the baseline product.

Tasks:
1. Add an experimental detector method for constrained NMF or a cleanly documented semi-online approximation.
2. Keep it behind:
   - an experiment flag
   - or an advanced preset
3. Reuse existing transform data rather than building an unrelated pipeline.
4. Support attack/sustain templates if practical.
5. Add clear UI labeling that this method is experimental.
6. Add focused tests for:
   - basic convergence sanity
   - simple note/chord activation on a short fixture
7. Add docs:
   - `docs/audio/nmf-experiment.md`

Acceptance:
- NMF method can run in replay/offline mode
- it does not block or complicate baseline usage
- tests and docs exist

Self-check:
- `dotnet test tests/MusicAudioAnalysis.Tests`
- `dotnet build Zyphonote.slnx`
