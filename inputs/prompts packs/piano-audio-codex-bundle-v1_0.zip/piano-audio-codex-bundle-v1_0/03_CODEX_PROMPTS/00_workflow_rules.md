# 00 — Workflow rules for Codex

Read this file before Prompt 01.

Rules:
1. Work inside the Zyphonote repository.
2. Keep all code comments in English.
3. Execute prompts in numeric order.
4. After each prompt:
   - run targeted build/tests
   - update `/00_README.md` progress checklist
   - add or update minimal docs if the prompt requires it
5. Prefer additive, modular changes over broad rewrites.
6. Keep the standalone Blazor WebAssembly PWA working.
7. Keep the detector methods pluggable.
8. Keep the raw detector output visible in the UI even when theory interpretation is enabled.
9. Keep audio capture/file decode/browser code isolated from DSP core.
10. If a prompt introduces optional experimental work, guard it behind a feature flag or preset.

Core build commands to use repeatedly:
- `dotnet build Zyphonote.slnx`
- `dotnet test Zyphonote.slnx`

If the full solution is too slow at every step, run focused project tests plus a full build at milestone steps.

Start with Prompt 01.
