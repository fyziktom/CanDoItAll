# 06 — CQT activation detector

Goal:
Add a pitch-aligned comparison detector.

Tasks:
1. Implement a CQT transform path or a clean approximation that is explicit in the code/docs.
2. Keep kernels or mappings precomputed and reusable.
3. Implement a CQT-based note activation detector behind `INoteDetectorMethod`.
4. Share the same tracker contract used by the harmonic method.
5. Expose CQT-specific settings separately from STFT settings.
6. Add tests comparing CQT activation sanity on:
   - single note
   - simple chord
   - close neighboring notes
7. Add side-by-side comparison support in the UI for:
   - Harmonic summation
   - CQT activation

Acceptance:
- CQT method runs through the same comparison pipeline
- UI can compare at least two methods on the same clip
- tests pass

Self-check:
- `dotnet test tests/MusicAudioAnalysis.Tests`
- `dotnet build Zyphonote.slnx`
