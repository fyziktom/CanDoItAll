# 02 — Browser audio capture and offline fixture storage

Goal:
Bring browser-side audio input into the Zyphonote host in a reusable way.

Tasks:
1. Implement browser microphone capture in `MusicAudioAnalysis.Browser` using:
   - `getUserMedia`
   - `AudioContext`
   - `AudioWorklet`
2. Port and adapt the minimal concepts from the reviewed spectral demo:
   - raw PCM capture
   - browser audio-file decode
3. Keep capture options explicit:
   - mono capture
   - request disabled AGC/noise suppression/echo cancellation
   - expose actual sample rate returned by the browser
4. Add a browser service:
   - `PianoAudioCaptureService`
5. Add simple models:
   - recorded block
   - capture capabilities
   - decoded file clip
6. Add local storage support for:
   - recent recordings
   - saved imported clips metadata
   - detector presets or placeholder preset persistence
7. Add a simple UI section on the lab page:
   - mic start/stop
   - file upload/decode
   - list of recent local recordings
8. Ensure worklet JS assets are included in static web assets.

Acceptance:
- microphone capture works through the service abstraction
- local file decode works
- recent recordings can be stored locally
- the page can show capture status and basic clip metadata

Self-check:
- `dotnet build Zyphonote.slnx`
- run the app and manually verify mic start/stop and file decode
