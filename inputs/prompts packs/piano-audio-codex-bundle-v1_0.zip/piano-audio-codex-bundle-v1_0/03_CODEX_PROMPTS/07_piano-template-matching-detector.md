# 07 — Piano template matching detector

Goal:
Add the strongest practical classical piano-specific method.

Tasks:
1. Implement a template manager for piano note templates.
2. Support at least:
   - theoretical harmonic templates
   - simple empirical template pack format for future extension
3. Implement attack vs sustain template handling if practical at this stage.
4. Implement a template-matching detector using normalized similarity.
5. Reuse the shared tracker and onset evidence.
6. Add a small built-in lightweight template pack or generation path for tests.
7. Add tests for:
   - note-template similarity ranking
   - simple chord detection
   - noisy single-note scenario
8. Add UI controls for:
   - template source
   - similarity threshold
   - attack/sustain split if supported

Acceptance:
- template detector is selectable in the lab
- template detector outputs note events through the shared tracker
- tests pass

Self-check:
- `dotnet test tests/MusicAudioAnalysis.Tests`
- `dotnet build Zyphonote.slnx`
