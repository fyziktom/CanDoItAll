# 10 — Fixtures, metrics, and benchmark harness

Goal:
Make the system measurable.

Tasks:
1. Add a benchmark harness that can run one or more clips through one or more methods.
2. Define metrics for:
   - note-event precision / recall / F1
   - onset precision / recall / F1
   - octave errors
   - false sustain rate or tail confusion proxy
   - runtime per frame or per second of audio
3. Add deterministic fixture scenarios:
   - isolated notes across octaves
   - simple intervals
   - triads
   - repeated notes
   - staccato phrase
   - simple sustain-tail cases
4. Add fixture metadata/annotations format.
5. Add benchmark result serialization for local storage/export.
6. Add a UI action:
   - `Run benchmark pack`
7. Write or update docs under:
   - `docs/audio/benchmarking.md`

Acceptance:
- benchmark harness can compare at least 3 methods on the same fixture pack
- metrics are visible in the UI or exportable
- deterministic tests exist

Self-check:
- `dotnet test tests/MusicAudioAnalysis.Tests`
- `dotnet build Zyphonote.slnx`
