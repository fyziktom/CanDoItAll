# 13 — Final validation and cleanup

Goal:
Finish with a coherent, documented, testable feature.

Tasks:
1. Run a final pass on naming and folder organization.
2. Remove dead scaffolding that never became useful.
3. Ensure presets exist for:
   - baseline balanced
   - low-latency
   - compare mode
   - template-focused
   - experimental NMF if present
4. Ensure docs exist and are discoverable under `docs/audio/`.
5. Ensure the lab page has enough inline hints to be usable.
6. Produce a final summary doc:
   - `docs/audio/final-validation-report.md`
7. Update `/00_README.md` progress checklist fully.
8. Confirm:
   - build passes
   - tests pass
   - app route works
   - offline/PWA basics were checked manually

Acceptance:
- the feature feels intentionally productized, not just scattered experiments
- docs and validation report exist
- final build/tests pass

Self-check:
- `dotnet build Zyphonote.slnx`
- `dotnet test Zyphonote.slnx`
