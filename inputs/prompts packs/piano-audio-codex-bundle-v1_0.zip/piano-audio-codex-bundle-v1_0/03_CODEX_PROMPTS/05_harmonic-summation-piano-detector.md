# 05 — Harmonic summation piano detector

Goal:
Implement the main classical baseline for piano note activation.

Tasks:
1. Implement an `INoteDetectorMethod` for harmonic summation.
2. Score all 88 piano notes each frame.
3. Use:
   - note-frequency table
   - harmonic partial weighting
   - missing-fundamental tolerance
   - register-aware or octave-aware thresholds
4. Add onset-aware entry logic so note attacks are not purely activation-threshold based.
5. Feed the detector output into the shared note-state tracker.
6. Add debug evidence:
   - per-note activation
   - supporting harmonics
   - activation heatmap or table for selected frame
7. Add tests for:
   - isolated notes across several octaves
   - major/minor triads
   - octave interval
   - repeated-note separation
8. Add a preset named similar to:
   - `PianoBaselineBalanced`

Acceptance:
- the lab page can run the harmonic detector on fixture data
- note events appear for synthetic chords and phrases
- per-note activation is inspectable

Self-check:
- `dotnet test tests/MusicAudioAnalysis.Tests`
- `dotnet build Zyphonote.slnx`
