# 08 — Detector fusion and theory bridge

Goal:
Combine method evidence and connect audio note events to Zyphonote harmony recognition.

Tasks:
1. Implement a fusion strategy that can combine:
   - harmonic summation
   - CQT activation
   - template matching
2. Normalize method confidence before fusion.
3. Preserve attribution so the UI can show which method supported a note.
4. Implement an audio-to-theory adapter that converts note events into:
   - `RealtimeMidiEvent`-like flow
   - `RealtimeNoteScoreTracker`
   - `RealtimeChordWindowDetector`
   - `RealtimeChordDetectionService`
5. Add a session service similar in spirit to `RealtimeChordDetectionSessionService`, but for audio.
6. Add UI sections for:
   - pitch-class score summary
   - chord candidates
   - bass/inversion if available
   - toggle for theory bridge on/off
7. Add tests ensuring:
   - audio note events can drive harmonic interpretation
   - theory bridge does not hide raw detector output

Acceptance:
- fusion detector exists
- harmonic interpretation updates from audio note events
- raw and interpreted outputs are both visible

Self-check:
- `dotnet test tests/MusicAudioAnalysis.Tests`
- `dotnet test tests/MusicTheory.Tests`
- `dotnet build Zyphonote.slnx`
