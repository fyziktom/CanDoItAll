# Current state remediation checklist

- [ ] Replace score disk storage dependence on `versionId` with repository blob/snapshot storage for new writes.
- [ ] Replace playlist manifest storage dependence on `playlistVersionId` with repository blob/snapshot storage for new writes.
- [ ] Keep learning package content-addressed manifest behavior as the pattern to emulate.
- [ ] Add immutable event snapshot commits.
- [ ] Add repository ids and current commit hashes to all four root entities.
- [ ] Add commit hash bridge columns to existing legacy version tables.
- [ ] Add read-model refresh logic when `main` moves.
