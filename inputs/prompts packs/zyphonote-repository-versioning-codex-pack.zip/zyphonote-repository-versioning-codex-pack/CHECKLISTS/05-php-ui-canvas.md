# PHP UI / canvas checklist

- [ ] Graph component reuses existing workbench/canvas design language.
- [ ] Score detail page shows repository graph and commit inspector.
- [ ] Playlist page shows repository graph in builder context.
- [ ] Event page shows repository graph in planning context.
- [ ] Learning builder page shows repository graph in authoring context.
- [ ] Branch/merge/fork/MR actions are discoverable but permission-aware.
- [ ] Textual inspector fallback exists for accessibility/readability.
