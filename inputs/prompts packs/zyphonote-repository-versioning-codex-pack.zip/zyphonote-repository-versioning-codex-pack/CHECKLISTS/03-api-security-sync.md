# API / security / sync checklist

- [ ] Repository APIs require auth where appropriate.
- [ ] Read access respects repo visibility and ownership.
- [ ] Write access respects ownership/fork policy.
- [ ] Protected default branch cannot be deleted or force-updated.
- [ ] Ref updates use compare-and-swap semantics.
- [ ] Origin status batch endpoint supports WASM sync.
- [ ] Pull batch endpoint can fetch enough data for offline graph/history.
- [ ] Commit/push endpoints return useful conflict detail.
- [ ] Audit log entries are written for repository mutations.
