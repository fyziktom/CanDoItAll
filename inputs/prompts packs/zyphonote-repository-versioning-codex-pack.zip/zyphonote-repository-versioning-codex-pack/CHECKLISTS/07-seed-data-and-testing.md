# Seed data and testing checklist

- [ ] Seed at least one clean merge scenario.
- [ ] Seed at least one conflict scenario.
- [ ] Seed at least one fork + open MR.
- [ ] Seed at least one merged MR.
- [ ] Add unit tests for hashing and branch CAS.
- [ ] Add unit tests for score merge preview contract.
- [ ] Extend API smoke tests for commit/branch/fork/MR flow.
