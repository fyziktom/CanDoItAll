# WASM offline checklist

- [ ] IndexedDB is the primary repo storage model in the contract.
- [ ] localStorage is limited to tiny UI state.
- [ ] Refs, commits, snapshots, blobs, and working copies have DTOs.
- [ ] Ahead/behind/diverged states are explicit.
- [ ] Local branch checkout behavior is defined.
- [ ] Offline commit creation can be verified by server canonicalization rules.
