# Master checklist

## Architecture
- [ ] Add a shared repository domain instead of extending each version table separately.
- [ ] Keep existing entity tables as read models / compatibility bridges.
- [ ] Use content-addressed blobs and snapshots.
- [ ] Preserve exact commit pinning for purchases/shares/publication.

## Database and storage
- [ ] Add repository schema migration.
- [ ] Add repository storage config roots.
- [ ] Add canonical hashing helpers.
- [ ] Add blob/snapshot/commit persistence helpers.
- [ ] Add repository verification tooling.

## Backfill and compatibility
- [ ] Backfill score histories.
- [ ] Backfill learning package histories.
- [ ] Backfill playlist histories.
- [ ] Create event repositories.
- [ ] Add legacy-version-to-commit mapping.

## Branches and merge
- [ ] Add branch refs.
- [ ] Protect default branch.
- [ ] Add fast-forward and merge-commit support.
- [ ] Add compare endpoint.
- [ ] Add merge-preview endpoint.
- [ ] Add score merge contracts and structured hunk payloads.

## Forks and merge requests
- [ ] Add fork policy enforcement.
- [ ] Add fork creation.
- [ ] Add merge request create/list/detail.
- [ ] Add MR merge and close actions.
- [ ] Add legal/listing restrictions for non-owner forks.

## PHP UI
- [ ] Add repository graph canvas module.
- [ ] Show graph on score detail/manage screens.
- [ ] Show graph on playlist pages.
- [ ] Show graph on event pages.
- [ ] Show graph on learning package builder pages.

## WASM/offline
- [ ] Add origin status batch endpoint.
- [ ] Add pull batch endpoint.
- [ ] Make DTOs suitable for IndexedDB storage.
- [ ] Keep localStorage use minimal.

## Tests and seeds
- [ ] Add unit tests for hashing/refs/merge logic.
- [ ] Add API smoke test for repository flows.
- [ ] Extend seed data with branches/forks/MRs.
- [ ] Document migration/backfill limitations honestly.

## Final audit
- [ ] Verify identical content reuses blobs.
- [ ] Verify non-default branch does not overwrite read model.
- [ ] Verify purchases/shares pin commit hashes.
- [ ] Verify graph renders usable history.
