# Merge / fork / MR checklist

- [ ] Score compare returns semantic hunks, not only raw text diffs.
- [ ] Playlist/package/event merges use stable keys.
- [ ] Merge preview exposes conflict hunks.
- [ ] Fork policy defaults are safe for private planning content.
- [ ] Non-owner forks are blocked from instant marketplace listing/publication.
- [ ] Merge request mergeability is rechecked at merge time.
- [ ] Merge requests store source/target head hashes and merge base.
