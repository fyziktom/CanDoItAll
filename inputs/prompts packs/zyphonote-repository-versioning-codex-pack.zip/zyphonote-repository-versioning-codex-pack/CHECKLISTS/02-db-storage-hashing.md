# DB / storage / hashing checklist

- [ ] Canonical JSON is identical between PHP and C# for the same logical input.
- [ ] Blob files are deduped by SHA-256.
- [ ] Snapshot files are deduped by snapshot hash.
- [ ] Commit payload files are stored and verify against commit hash.
- [ ] CID v1 raw is computed where configured.
- [ ] Repository storage paths are safe against traversal.
- [ ] Verification tool detects missing/mismatched blob/snapshot/commit files.
