# Scenario Master List

## Scenario inventory
| Scenario ID | Title | Process IDs | Estimated duration | Difficulty | Roles | Pages involved | Step count | Mermaid references |
|---|---|---|---|---|---|---|---|---|
| SCN-AUTH-LOGIN | Log in and enter the invoicing workspace | PROC-AUTH-ACCESS | 3-5 min | Introductory | administrator, manager, accountant, technician, user | /Account/Login, /Account/LoginWith2fa | 6 | 01_mermaid/proc-auth-access_authentication-and-account-self-service.mmd |
| SCN-AUTH-2FA-SETUP | Set up the authenticator app for two-factor authentication | PROC-AUTH-ACCESS | 4-7 min | Intermediate | administrator, manager, accountant, technician, user | /Account/Manage/EnableAuthenticator | 5 | 01_mermaid/proc-auth-access_authentication-and-account-self-service.mmd |
| SCN-ACCOUNT-PROFILE-2FA-MANAGE | Review account profile and two-factor settings | PROC-AUTH-ACCESS | 3-5 min | Introductory | administrator, manager, accountant, technician, user | /Account/Manage, /Account/Manage/TwoFactorAuthentication | 4 | 01_mermaid/proc-auth-access_authentication-and-account-self-service.mmd |
| SCN-DASHBOARD-TRIAGE | Triage operational alerts from the dashboard | PROC-DASHBOARD-TRIAGE | 4-6 min | Introductory | administrator, manager, accountant, technician, user | / | 5 | 01_mermaid/proc-dashboard-triage_dashboard-monitoring-and-operational-triage.mmd |
| SCN-CUSTOMER-WORKSPACE | Navigate the customer workspace and inspect customer context | PROC-CUSTOMER-WORKSPACE | 4-6 min | Introductory | administrator, manager, accountant, technician, user | /data | 6 | 01_mermaid/proc-customer-workspace_customer-workspace-navigation-and-context-drill-down.mmd |
| SCN-CUSTOMER-CREATE | Create a new customer record | PROC-CUSTOMER-MAINTENANCE | 4-6 min | Intermediate | administrator, manager, accountant | /data | 5 | 01_mermaid/proc-customer-maintenance_customer-create-edit-deactivate-and-delete.mmd |
| SCN-CUSTOMER-EDIT-STATUS | Edit a customer and review status changes safely | PROC-CUSTOMER-MAINTENANCE | 4-6 min | Intermediate | administrator, manager, accountant | /data | 5 | 01_mermaid/proc-customer-maintenance_customer-create-edit-deactivate-and-delete.mmd |
| SCN-CUSTOMER-IMPORT | Import customers with staged validation | PROC-CUSTOMER-IMPORT | 5-8 min | Intermediate | administrator, manager, accountant | /data | 7 | 01_mermaid/proc-customer-import_customer-import-with-staged-validation.mmd |
| SCN-PRODUCTION-MANUAL | Add monthly production manually for one customer | PROC-PRODUCTION-MANUAL | 4-7 min | Intermediate | administrator, manager, technician, accountant | /data, /import | 6 | 01_mermaid/proc-production-manual_manual-production-entry.mmd |
| SCN-PRODUCTION-BLOCKING-INVOICE | Resolve a production update blocked by an invoiced period | PROC-PRODUCTION-CONFLICT | 5-7 min | Advanced | administrator, manager, accountant, technician | /data | 5 | 01_mermaid/proc-production-conflict_production-change-with-blocking-invoice-conflict-handling.mmd |
| SCN-PRODUCTION-IMPORT | Import production data with preview, warnings, and skip logic | PROC-PRODUCTION-IMPORT | 5-8 min | Intermediate | administrator, manager, technician, accountant | /import | 7 | 01_mermaid/proc-production-import_production-import-with-staged-validation.mmd |
| SCN-INVOICE-MANUAL-CREATE | Create a manual invoice for one customer | PROC-INVOICE-MANUAL-CREATE | 4-6 min | Intermediate | administrator, manager, accountant | /data, /invoices | 5 | 01_mermaid/proc-invoice-manual-create_manual-single-invoice-creation.mmd |
| SCN-INVOICE-MONTHLY-RUN | Run the monthly invoice generation wizard | PROC-INVOICE-MONTHLY-RUN | 6-10 min | Advanced | administrator, manager, accountant | /create | 9 | 01_mermaid/proc-invoice-monthly-run_monthly-invoice-run-wizard.mmd |
| SCN-INVOICE-INSPECT-PROCESS | Inspect an invoice and use state-based actions | PROC-INVOICE-INSPECT | 4-6 min | Intermediate | administrator, manager, accountant, user | /invoices | 6 | 01_mermaid/proc-invoice-inspect_invoice-inspection-and-state-based-actions.mmd |
| SCN-INVOICE-EDIT-CORRECTION | Edit an invoice and understand correction safeguards | PROC-INVOICE-EDIT-CORRECTION | 5-7 min | Advanced | administrator, manager, accountant | /invoices, /data | 6 | 01_mermaid/proc-invoice-edit-correction_invoice-edit-with-correction-safeguards.mmd |
| SCN-INVOICE-PAYMENT | Mark an invoice as paid and verify payment metadata | PROC-INVOICE-PAYMENT | 3-5 min | Intermediate | administrator, manager, accountant | /invoices | 5 | 01_mermaid/proc-invoice-payment_invoice-payment-state-management.mmd |
| SCN-INVOICE-REVOKE-RESOLVE | Revoke an invoice or payment and resolve the follow-up correction task | PROC-INVOICE-REVOKE-CORRECTION | 5-8 min | Advanced | administrator, manager, accountant | /invoices | 5 | 01_mermaid/proc-invoice-revoke-correction_invoice-revoke-and-correction-task-resolution.mmd |
| SCN-EXPORT-INVOICES | Export invoices to spreadsheet or CSV | PROC-EXPORT-INVOICES | 3-5 min | Introductory | administrator, manager, accountant, user | /export | 5 | 01_mermaid/proc-export-invoices_invoice-export-workflow.mmd |
| SCN-EXPORT-PRODUCTION | Export production history for analysis | PROC-EXPORT-PRODUCTION | 3-5 min | Introductory | administrator, manager, technician, accountant, user | /export | 4 | 01_mermaid/proc-export-production_production-export-workflow.mmd |
| SCN-EXPORT-CUSTOMERS | Export customer records for offline review | PROC-EXPORT-CUSTOMERS | 3-5 min | Introductory | administrator, manager, accountant, user | /export, /data | 4 | 01_mermaid/proc-export-customers_customer-export-workflow.mmd |
| SCN-EXPORT-INVOICE-PACKAGE | Export an invoice PDF package as ZIP | PROC-EXPORT-INVOICE-PACKAGE | 3-5 min | Intermediate | administrator, manager, accountant | /export | 4 | 01_mermaid/proc-export-invoice-package_invoice-pdf-package-export-workflow.mmd |
| SCN-USERS-ACCESS | Create a user and manage role-based access | PROC-USERS-ACCESS | 5-8 min | Advanced | administrator | /users | 7 | 01_mermaid/proc-users-access_user-and-access-administration.mmd |
| SCN-AUDITS-INVESTIGATION | Investigate an audit trail event | PROC-AUDITS | 4-6 min | Intermediate | administrator, manager | /audits | 4 | 01_mermaid/proc-audits_audit-trail-investigation.mmd |
| SCN-LOGS-INVESTIGATION | Investigate system logs for operational troubleshooting | PROC-LOGS | 4-6 min | Intermediate | administrator, manager | /logs | 4 | 01_mermaid/proc-logs_system-log-investigation.mmd |
| SCN-ADMIN-CONFIG | Manage application configuration safely | PROC-ADMIN-CONFIG | 5-8 min | Advanced | administrator | /admin | 5 | 01_mermaid/proc-admin-config_application-configuration-management.mmd |
| SCN-ADMIN-MODEL-VISIBILITY | Adjust model visibility and billing feature flags | PROC-ADMIN-MODEL-VISIBILITY | 5-7 min | Advanced | administrator | /admin | 5 | 01_mermaid/proc-admin-model-visibility_model-visibility-administration.mmd |

## Detailed scenario checklist
### SCN-AUTH-LOGIN - Log in and enter the invoicing workspace
- Short description: Learn the standard sign-in flow, including how the system reacts to invalid credentials and required second-factor steps.
- Learning goals: Identify the login page structure.; Enter credentials correctly.; Recognize invalid login feedback and next steps.; Understand when the flow redirects to two-factor authentication.
- Prerequisites: A confirmed user account exists.; The learner knows the training account email and password.; The app is opened on /Account/Login.
- Roles: administrator, manager, accountant, technician, user
- Pages involved: /Account/Login, /Account/LoginWith2fa
- Step count: 6
- Mermaid references: 01_mermaid/proc-auth-access_authentication-and-account-self-service.mmd

### SCN-AUTH-2FA-SETUP - Set up the authenticator app for two-factor authentication
- Short description: Guide the learner through enabling an authenticator app when the application requires second-factor protection.
- Learning goals: Understand why 2FA setup is required.; Locate the shared key and QR code area.; Confirm the code entry and enable 2FA successfully.
- Prerequisites: The application is configured to require two-factor authentication.; The learner is signed in and is on /Account/Manage/EnableAuthenticator.; An authenticator app is available on a mobile device.
- Roles: administrator, manager, accountant, technician, user
- Pages involved: /Account/Manage/EnableAuthenticator
- Step count: 5
- Mermaid references: 01_mermaid/proc-auth-access_authentication-and-account-self-service.mmd

### SCN-ACCOUNT-PROFILE-2FA-MANAGE - Review account profile and two-factor settings
- Short description: Teach the learner how to revisit account settings, verify security posture, and maintain personal sign-in options.
- Learning goals: Navigate the account management area.; Recognize profile and security sections.; Understand how to verify whether 2FA is enabled.
- Prerequisites: The learner is authenticated.; The learner can open /Account/Manage and /Account/Manage/TwoFactorAuthentication.
- Roles: administrator, manager, accountant, technician, user
- Pages involved: /Account/Manage, /Account/Manage/TwoFactorAuthentication
- Step count: 4
- Mermaid references: 01_mermaid/proc-auth-access_authentication-and-account-self-service.mmd

### SCN-DASHBOARD-TRIAGE - Triage operational alerts from the dashboard
- Short description: Use the dashboard to review suspicious invoices, overdue unpaid invoices, and quick actions that jump into detailed work areas.
- Learning goals: Recognize the dashboard structure.; Open the most important operational tabs.; Use action tiles to jump into focused workflows.
- Prerequisites: The learner is authenticated and can access the dashboard.; Seed data contains at least one alert or billing item.
- Roles: administrator, manager, accountant, technician, user
- Pages involved: /
- Step count: 5
- Mermaid references: 01_mermaid/proc-dashboard-triage_dashboard-monitoring-and-operational-triage.mmd

### SCN-CUSTOMER-WORKSPACE - Navigate the customer workspace and inspect customer context
- Short description: Teach the split-view customer workspace, list filtering, view switching, and dashboard drill-down.
- Learning goals: Open the customer workspace.; Switch between card and table views.; Use filters and select a customer record.; Interpret dashboard tabs for the selected customer.
- Prerequisites: At least one customer exists.; The learner can access /data.
- Roles: administrator, manager, accountant, technician, user
- Pages involved: /data
- Step count: 6
- Mermaid references: 01_mermaid/proc-customer-workspace_customer-workspace-navigation-and-context-drill-down.mmd

### SCN-CUSTOMER-CREATE - Create a new customer record
- Short description: Walk through the customer creation dialog and explain the minimum data quality expected before saving.
- Learning goals: Open the add-customer dialog.; Identify the required inputs.; Save a valid customer record.
- Prerequisites: The learner has permission to manage customers.; The learner is on /data.
- Roles: administrator, manager, accountant
- Pages involved: /data
- Step count: 5
- Mermaid references: 01_mermaid/proc-customer-maintenance_customer-create-edit-deactivate-and-delete.mmd

### SCN-CUSTOMER-EDIT-STATUS - Edit a customer and review status changes safely
- Short description: Teach how to open an existing customer, update key fields, and think through status changes that can affect future invoice runs.
- Learning goals: Open the edit-customer dialog from customer context.; Review editable fields and current status.; Save a controlled update.
- Prerequisites: At least one customer exists.; The learner has permission to manage customers.
- Roles: administrator, manager, accountant
- Pages involved: /data
- Step count: 5
- Mermaid references: 01_mermaid/proc-customer-maintenance_customer-create-edit-deactivate-and-delete.mmd

### SCN-CUSTOMER-IMPORT - Import customers with staged validation
- Short description: Practice the customer import wizard from file selection through preview, revalidation, skip logic, and final import.
- Learning goals: Open the customer import dialog.; Load a file and inspect the preview.; Understand revalidation and skip-error behavior.; Run the import only after resolving or intentionally skipping issues.
- Prerequisites: The learner has a valid training import file.; The learner can access the Customers page and import permission is granted.
- Roles: administrator, manager, accountant
- Pages involved: /data
- Step count: 7
- Mermaid references: 01_mermaid/proc-customer-import_customer-import-with-staged-validation.mmd

### SCN-PRODUCTION-MANUAL - Add monthly production manually for one customer
- Short description: Teach the manual production entry wizard, including customer selection, period values, and zero-value policy awareness.
- Learning goals: Open the manual production flow.; Select the right customer and month range.; Enter production values correctly.; Understand zero-value handling before saving.
- Prerequisites: At least one active customer exists.; The learner can access /data or /import and has production write permission.
- Roles: administrator, manager, technician, accountant
- Pages involved: /data, /import
- Step count: 6
- Mermaid references: 01_mermaid/proc-production-manual_manual-production-entry.mmd

### SCN-PRODUCTION-BLOCKING-INVOICE - Resolve a production update blocked by an invoiced period
- Short description: Explain what happens when production data is linked to an existing invoice and how to proceed safely with or without override rights.
- Learning goals: Recognize why a production edit is blocked.; Understand the difference between blocked update and override workflow.; Know when a correction task is created.
- Prerequisites: A production record exists for a period already linked to an invoice.; The learner can open the production edit dialog.
- Roles: administrator, manager, accountant, technician
- Pages involved: /data
- Step count: 5
- Mermaid references: 01_mermaid/proc-production-conflict_production-change-with-blocking-invoice-conflict-handling.mmd

### SCN-PRODUCTION-IMPORT - Import production data with preview, warnings, and skip logic
- Short description: Practice the production import wizard, including zero-value checks, unresolved customer warnings, and safe completion.
- Learning goals: Open the production import center.; Attach and preview a production file.; Interpret errors, warnings, and updates.; Run the import safely.
- Prerequisites: A training production import file is available.; The learner has production import permission.
- Roles: administrator, manager, technician, accountant
- Pages involved: /import
- Step count: 7
- Mermaid references: 01_mermaid/proc-production-import_production-import-with-staged-validation.mmd

### SCN-INVOICE-MANUAL-CREATE - Create a manual invoice for one customer
- Short description: Guide the learner through one-off invoice creation from customer context and explain key billing safeguards.
- Learning goals: Start manual invoice creation from the correct customer context.; Review invoice period and production assumptions.; Save a draft invoice safely.
- Prerequisites: At least one customer exists.; The learner has invoice create permission.
- Roles: administrator, manager, accountant
- Pages involved: /data, /invoices
- Step count: 5
- Mermaid references: 01_mermaid/proc-invoice-manual-create_manual-single-invoice-creation.mmd

### SCN-INVOICE-MONTHLY-RUN - Run the monthly invoice generation wizard
- Short description: Teach the end-to-end monthly billing workflow from period selection through generation, manual review, processing, and reporting.
- Learning goals: Choose the billing month intentionally.; Generate waiting invoices and review summaries.; Use manual review for exceptions.; Process the run and inspect the report.
- Prerequisites: The learner has invoice generation permission.; Training data exists for at least one billable month.
- Roles: administrator, manager, accountant
- Pages involved: /create
- Step count: 9
- Mermaid references: 01_mermaid/proc-invoice-monthly-run_monthly-invoice-run-wizard.mmd

### SCN-INVOICE-INSPECT-PROCESS - Inspect an invoice and use state-based actions
- Short description: Teach the invoice center layout, filtering, preview/download actions, and state-dependent processing options.
- Learning goals: Filter and select an invoice.; Use the invoice inspector confidently.; Understand how available actions depend on invoice state.
- Prerequisites: At least one invoice exists.; The learner can access /invoices.
- Roles: administrator, manager, accountant, user
- Pages involved: /invoices
- Step count: 6
- Mermaid references: 01_mermaid/proc-invoice-inspect_invoice-inspection-and-state-based-actions.mmd

### SCN-INVOICE-EDIT-CORRECTION - Edit an invoice and understand correction safeguards
- Short description: Show the difference between editing a draft invoice and editing a sent invoice that requires cancellation and a correction task.
- Learning goals: Open the invoice edit path from the inspector.; Understand why sent invoices are not edited in place.; Recognize correction task creation after protected edits.
- Prerequisites: At least one editable invoice exists.; For the correction branch, a sent invoice exists in training data.
- Roles: administrator, manager, accountant
- Pages involved: /invoices, /data
- Step count: 6
- Mermaid references: 01_mermaid/proc-invoice-edit-correction_invoice-edit-with-correction-safeguards.mmd

### SCN-INVOICE-PAYMENT - Mark an invoice as paid and verify payment metadata
- Short description: Teach the payment workflow from the invoice inspector through confirmation and post-save verification.
- Learning goals: Open the mark-paid dialog from the inspector.; Enter the paid date and note correctly.; Confirm the paid state after save.
- Prerequisites: At least one eligible unpaid invoice exists.; The learner has permission to manage invoice payment state.
- Roles: administrator, manager, accountant
- Pages involved: /invoices
- Step count: 5
- Mermaid references: 01_mermaid/proc-invoice-payment_invoice-payment-state-management.mmd

### SCN-INVOICE-REVOKE-RESOLVE - Revoke an invoice or payment and resolve the follow-up correction task
- Short description: Teach the difference between revoking payment, revoking an invoice, and resolving a correction task after protected changes.
- Learning goals: Recognize the revoke and correction actions in the inspector.; Understand the confirmation requirements.; Complete correction resolution with an explicit note or replacement.
- Prerequisites: Training data includes an invoice eligible for revoke or correction resolution.; The learner has the required finance permission.
- Roles: administrator, manager, accountant
- Pages involved: /invoices
- Step count: 5
- Mermaid references: 01_mermaid/proc-invoice-revoke-correction_invoice-revoke-and-correction-task-resolution.mmd

### SCN-EXPORT-INVOICES - Export invoices to spreadsheet or CSV
- Short description: Teach the invoice export wizard from option selection to preview and download.
- Learning goals: Open the Export Center.; Use the invoice export wizard steps.; Review preview data before download.; Download the correct format.
- Prerequisites: The learner has export permission.; Invoice data exists for the selected filters.
- Roles: administrator, manager, accountant, user
- Pages involved: /export
- Step count: 5
- Mermaid references: 01_mermaid/proc-export-invoices_invoice-export-workflow.mmd

### SCN-EXPORT-PRODUCTION - Export production history for analysis
- Short description: Guide the learner through the production export wizard and explain why preview matters for operational analysis.
- Learning goals: Open the production export wizard.; Move through the wizard steps intentionally.; Validate preview data before export.
- Prerequisites: Production data exists.; The learner has export permission.
- Roles: administrator, manager, technician, accountant, user
- Pages involved: /export
- Step count: 4
- Mermaid references: 01_mermaid/proc-export-production_production-export-workflow.mmd

### SCN-EXPORT-CUSTOMERS - Export customer records for offline review
- Short description: Teach the customer export flow from the export tab or customer workspace dialog to final download.
- Learning goals: Open the customer export path.; Understand wizard navigation and preview.; Download the correct customer extract.
- Prerequisites: Customer data exists.; The learner has export permission.
- Roles: administrator, manager, accountant, user
- Pages involved: /export, /data
- Step count: 4
- Mermaid references: 01_mermaid/proc-export-customers_customer-export-workflow.mmd

### SCN-EXPORT-INVOICE-PACKAGE - Export an invoice PDF package as ZIP
- Short description: Guide the learner through packaging invoice documents into one ZIP archive for sharing or archival purposes.
- Learning goals: Open the invoice package export wizard.; Understand the difference between data export and document package export.; Generate and download the ZIP package.
- Prerequisites: Invoices with generated documents exist.; The learner has export permission.
- Roles: administrator, manager, accountant
- Pages involved: /export
- Step count: 4
- Mermaid references: 01_mermaid/proc-export-invoice-package_invoice-pdf-package-export-workflow.mmd

### SCN-USERS-ACCESS - Create a user and manage role-based access
- Short description: Teach the administration workflow for adding a user and adjusting roles or fine-grained permissions safely.
- Learning goals: Open the Users administration page.; Create a new user account.; Review role and permission assignment.; Save access changes intentionally.
- Prerequisites: The learner has user administration permission.; The environment allows user creation in training.
- Roles: administrator
- Pages involved: /users
- Step count: 7
- Mermaid references: 01_mermaid/proc-users-access_user-and-access-administration.mmd

### SCN-AUDITS-INVESTIGATION - Investigate an audit trail event
- Short description: Teach how to filter audit events, inspect event details, and jump from the trail back to related business records.
- Learning goals: Open the audit trail page.; Apply meaningful filters.; Inspect event details and related record links.
- Prerequisites: Audit data exists in the environment.; The learner has audit-view permission.
- Roles: administrator, manager
- Pages involved: /audits
- Step count: 4
- Mermaid references: 01_mermaid/proc-audits_audit-trail-investigation.mmd

### SCN-LOGS-INVESTIGATION - Investigate system logs for operational troubleshooting
- Short description: Teach how to filter application logs, inspect details, and distinguish technical diagnostics from audit history.
- Learning goals: Open the logs page.; Apply filters intentionally.; Inspect a log entry detail view.
- Prerequisites: Application log data exists.; The learner has log-view permission.
- Roles: administrator, manager
- Pages involved: /logs
- Step count: 4
- Mermaid references: 01_mermaid/proc-logs_system-log-investigation.mmd

### SCN-ADMIN-CONFIG - Manage application configuration safely
- Short description: Guide the learner through configuration save, reload, import/export, and the meaning of restart-required changes.
- Learning goals: Open the Admin page and recognize configuration zones.; Understand save, cancel, reload, and import/export controls.; Handle restart-required messaging correctly.
- Prerequisites: The learner has administrator permission.; The Admin page is available in the environment.
- Roles: administrator
- Pages involved: /admin
- Step count: 5
- Mermaid references: 01_mermaid/proc-admin-config_application-configuration-management.mmd

### SCN-ADMIN-MODEL-VISIBILITY - Adjust model visibility and billing feature flags
- Short description: Teach how field visibility and billing feature switches affect the UI and training scenarios, including zero-value processing.
- Learning goals: Open the model visibility tab.; Understand field visibility toggles.; Review billing feature flags such as zero-value processing.; Save changes with awareness of user impact.
- Prerequisites: The learner has administrator permission.; The Admin page is available.
- Roles: administrator
- Pages involved: /admin
- Step count: 5
- Mermaid references: 01_mermaid/proc-admin-model-visibility_model-visibility-administration.mmd


## Coverage notes
- Account access is split into login, authenticator setup, and account security review so Training Mode can start from the page the learner is actually on.
- Customer maintenance is split into create and edit/status flows because they have different validation and risk profiles.
- Invoice workflows are decomposed into manual creation, monthly run, inspection, edit/correction, payment, and revoke/correction resolution to keep steps teachable and reusable.
- Each export workflow has its own scenario because the wizard path, output type, and user intention differ.
- Admin configuration is split into general configuration management and model visibility/feature flags because their downstream impact is different.

## Validation
- [x] Every scenario references at least one process.
- [x] Every scenario references at least one Mermaid diagram.
- [x] Every scenario contains ordered steps with English instructional copy.
