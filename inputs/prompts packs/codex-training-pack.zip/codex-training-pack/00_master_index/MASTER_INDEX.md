# Codex Training Pack Master Index

## Purpose
This bundle is a complete implementation brief for adding **Training Mode** (interactive product tours) to the PVE Invoicing Blazor + Radzen application.

## Coverage summary
- Processes mapped: **23**
- Mermaid diagrams: **23**
- Scenarios: **26**
- Scenario schema files: **1**
- UI copy packs: **27**
- Architecture documents: **4**
- Codex task documents: **7**
- Acceptance documents: **2**

## Source-of-truth assumptions used while preparing this pack
- Navigation modules confirmed in the application shell: Dashboard, Customers, Import, Create Invoices, Invoices, Export, Users, Audits, Logs, Admin, Account.
- RBAC confirmed through the authorization constants and default role maps.
- Workflow safeguards confirmed through UI components, validation helpers, and workflow tests.
- Existing `data-testid` hooks were reused wherever available.
- Missing stable hooks were specified as proposed `data-tour-id` targets inside the scenario files and architecture notes.

## How Codex should consume this pack
1. Read `04_architecture/TRAINING_MODE_TECH_ARCHITECTURE.md`.
2. Read `05_codex_tasks/00_STARTER_PROMPT.md`.
3. Implement the work in the phase order defined in `05_codex_tasks/`.
4. Use `02_scenarios/scenarios.schema.json` as the data contract.
5. Load the scenario JSON files from `02_scenarios/`.
6. Validate the build against `05_codex_tasks/99_VALIDATION_CHECKLIST.md` and `06_acceptance/`.

## Folder tree
```text
/codex-training-pack/
  /00_master_index/
    MASTER_INDEX.md
    PROCESS_MASTER_LIST.md
    SCENARIO_MASTER_LIST.md
    PROCESS_SCENARIO_MAPPING.csv
  /01_mermaid/
    proc-auth-access_authentication-and-account-self-service.mmd
    proc-dashboard-triage_dashboard-monitoring-and-operational-triage.mmd
    proc-customer-workspace_customer-workspace-navigation-and-context-drill-down.mmd
    proc-customer-maintenance_customer-create-edit-deactivate-and-delete.mmd
    proc-customer-import_customer-import-with-staged-validation.mmd
    proc-production-manual_manual-production-entry.mmd
    proc-production-conflict_production-change-with-blocking-invoice-conflict-handling.mmd
    proc-production-import_production-import-with-staged-validation.mmd
    proc-invoice-manual-create_manual-single-invoice-creation.mmd
    proc-invoice-monthly-run_monthly-invoice-run-wizard.mmd
    proc-invoice-inspect_invoice-inspection-and-state-based-actions.mmd
    proc-invoice-edit-correction_invoice-edit-with-correction-safeguards.mmd
    proc-invoice-payment_invoice-payment-state-management.mmd
    proc-invoice-revoke-correction_invoice-revoke-and-correction-task-resolution.mmd
    proc-export-invoices_invoice-export-workflow.mmd
    proc-export-production_production-export-workflow.mmd
    proc-export-customers_customer-export-workflow.mmd
    proc-export-invoice-package_invoice-pdf-package-export-workflow.mmd
    proc-users-access_user-and-access-administration.mmd
    proc-audits_audit-trail-investigation.mmd
    proc-logs_system-log-investigation.mmd
    proc-admin-config_application-configuration-management.mmd
    proc-admin-model-visibility_model-visibility-administration.mmd
  /02_scenarios/
    scenarios.schema.json
    SCN-AUTH-LOGIN.json
    SCN-AUTH-2FA-SETUP.json
    SCN-ACCOUNT-PROFILE-2FA-MANAGE.json
    SCN-DASHBOARD-TRIAGE.json
    SCN-CUSTOMER-WORKSPACE.json
    SCN-CUSTOMER-CREATE.json
    SCN-CUSTOMER-EDIT-STATUS.json
    SCN-CUSTOMER-IMPORT.json
    SCN-PRODUCTION-MANUAL.json
    SCN-PRODUCTION-BLOCKING-INVOICE.json
    SCN-PRODUCTION-IMPORT.json
    SCN-INVOICE-MANUAL-CREATE.json
    SCN-INVOICE-MONTHLY-RUN.json
    SCN-INVOICE-INSPECT-PROCESS.json
    SCN-INVOICE-EDIT-CORRECTION.json
    SCN-INVOICE-PAYMENT.json
    SCN-INVOICE-REVOKE-RESOLVE.json
    SCN-EXPORT-INVOICES.json
    SCN-EXPORT-PRODUCTION.json
    SCN-EXPORT-CUSTOMERS.json
    SCN-EXPORT-INVOICE-PACKAGE.json
    SCN-USERS-ACCESS.json
    SCN-AUDITS-INVESTIGATION.json
    SCN-LOGS-INVESTIGATION.json
    SCN-ADMIN-CONFIG.json
    SCN-ADMIN-MODEL-VISIBILITY.json
  /03_ui_copy/
    ui_copy_master.json
    /ui_copy_by_scenario/
      SCN-AUTH-LOGIN.json
      SCN-AUTH-2FA-SETUP.json
      SCN-ACCOUNT-PROFILE-2FA-MANAGE.json
      SCN-DASHBOARD-TRIAGE.json
      SCN-CUSTOMER-WORKSPACE.json
      SCN-CUSTOMER-CREATE.json
      SCN-CUSTOMER-EDIT-STATUS.json
      SCN-CUSTOMER-IMPORT.json
      SCN-PRODUCTION-MANUAL.json
      SCN-PRODUCTION-BLOCKING-INVOICE.json
      SCN-PRODUCTION-IMPORT.json
      SCN-INVOICE-MANUAL-CREATE.json
      SCN-INVOICE-MONTHLY-RUN.json
      SCN-INVOICE-INSPECT-PROCESS.json
      SCN-INVOICE-EDIT-CORRECTION.json
      SCN-INVOICE-PAYMENT.json
      SCN-INVOICE-REVOKE-RESOLVE.json
      SCN-EXPORT-INVOICES.json
      SCN-EXPORT-PRODUCTION.json
      SCN-EXPORT-CUSTOMERS.json
      SCN-EXPORT-INVOICE-PACKAGE.json
      SCN-USERS-ACCESS.json
      SCN-AUDITS-INVESTIGATION.json
      SCN-LOGS-INVESTIGATION.json
      SCN-ADMIN-CONFIG.json
      SCN-ADMIN-MODEL-VISIBILITY.json
  /04_architecture/
    TRAINING_MODE_UX.md
    TRAINING_MODE_TECH_ARCHITECTURE.md
    DATA_MODEL.md
    EDGE_CASES_AND_FALLBACKS.md
  /05_codex_tasks/
    00_STARTER_PROMPT.md
    01_PHASE_1_FOUNDATION.md
    02_PHASE_2_SCENARIO_SELECTION_UI.md
    03_PHASE_3_SCENARIO_ENGINE.md
    04_PHASE_4_IMPLEMENT_SCENARIOS.md
    05_PHASE_5_TESTS_A11Y_POLISH.md
    99_VALIDATION_CHECKLIST.md
  /06_acceptance/
    DEFINITION_OF_DONE.md
    ACCEPTANCE_TESTS.md
```

## Validation status
- [x] Every mapped process has a Mermaid diagram.
- [x] Every mapped process has at least one scenario.
- [x] Every scenario contains ordered steps.
- [x] Every step contains full English learning copy.
- [x] Process -> scenario -> page -> diagram mapping is consistent.
- [x] The pack is ZIP-ready without placeholder TODO content.
