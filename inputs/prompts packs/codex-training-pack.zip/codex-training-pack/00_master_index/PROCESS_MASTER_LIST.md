# Process Master List

## Process inventory
The list below is the master source of truth for process coverage. It is organized to support implementation, QA coverage, and scenario tracking.

| Process ID | Name | Module | Menu | Frequency | Roles | Pages involved | Scenario IDs | Mermaid file |
|---|---|---|---|---|---|---|---|---|
| PROC-AUTH-ACCESS | Authentication and account self-service | Account | Login / Account | daily | administrator, manager, accountant, technician, user | /Account/Login, /Account/LoginWith2fa, /Account/Manage, /Account/Manage/EnableAuthenticator, /Account/Manage/TwoFactorAuthentication | SCN-AUTH-LOGIN, SCN-AUTH-2FA-SETUP, SCN-ACCOUNT-PROFILE-2FA-MANAGE | 01_mermaid/proc-auth-access_authentication-and-account-self-service.mmd |
| PROC-DASHBOARD-TRIAGE | Dashboard monitoring and operational triage | Dashboard | Dashboard | daily | administrator, manager, accountant, technician, user | / | SCN-DASHBOARD-TRIAGE | 01_mermaid/proc-dashboard-triage_dashboard-monitoring-and-operational-triage.mmd |
| PROC-CUSTOMER-WORKSPACE | Customer workspace navigation and context drill-down | Customers | Customers | daily | administrator, manager, accountant, technician, user | /data | SCN-CUSTOMER-WORKSPACE | 01_mermaid/proc-customer-workspace_customer-workspace-navigation-and-context-drill-down.mmd |
| PROC-CUSTOMER-MAINTENANCE | Customer create, edit, deactivate, and delete | Customers | Customers | weekly | administrator, manager, accountant, technician | /data | SCN-CUSTOMER-CREATE, SCN-CUSTOMER-EDIT-STATUS | 01_mermaid/proc-customer-maintenance_customer-create-edit-deactivate-and-delete.mmd |
| PROC-CUSTOMER-IMPORT | Customer import with staged validation | Customers | Customers / Import dialog | rare | administrator, manager | /data | SCN-CUSTOMER-IMPORT | 01_mermaid/proc-customer-import_customer-import-with-staged-validation.mmd |
| PROC-PRODUCTION-MANUAL | Manual production entry | Production | Customers / Import | weekly | administrator, manager, technician | /data, /import | SCN-PRODUCTION-MANUAL | 01_mermaid/proc-production-manual_manual-production-entry.mmd |
| PROC-PRODUCTION-CONFLICT | Production change with blocking invoice conflict handling | Production | Customers | rare | administrator, manager, technician | /data | SCN-PRODUCTION-BLOCKING-INVOICE | 01_mermaid/proc-production-conflict_production-change-with-blocking-invoice-conflict-handling.mmd |
| PROC-PRODUCTION-IMPORT | Production import with staged validation | Production | Import Production | monthly | administrator, manager, technician | /import | SCN-PRODUCTION-IMPORT | 01_mermaid/proc-production-import_production-import-with-staged-validation.mmd |
| PROC-INVOICE-MANUAL-CREATE | Manual single invoice creation | Invoices | Customers / Invoices | weekly | administrator, manager, accountant | /data, /invoices | SCN-INVOICE-MANUAL-CREATE | 01_mermaid/proc-invoice-manual-create_manual-single-invoice-creation.mmd |
| PROC-INVOICE-MONTHLY-RUN | Monthly invoice run wizard | Invoices | Add Invoices | monthly | administrator, manager, accountant | /create | SCN-INVOICE-MONTHLY-RUN | 01_mermaid/proc-invoice-monthly-run_monthly-invoice-run-wizard.mmd |
| PROC-INVOICE-INSPECT | Invoice inspection and state-based actions | Invoices | Invoices | daily | administrator, manager, accountant, technician, user | /invoices | SCN-INVOICE-INSPECT-PROCESS | 01_mermaid/proc-invoice-inspect_invoice-inspection-and-state-based-actions.mmd |
| PROC-INVOICE-EDIT-CORRECTION | Invoice edit with correction safeguards | Invoices | Invoices / Customer dashboard | weekly | administrator, manager, accountant | /invoices, /data | SCN-INVOICE-EDIT-CORRECTION | 01_mermaid/proc-invoice-edit-correction_invoice-edit-with-correction-safeguards.mmd |
| PROC-INVOICE-PAYMENT | Invoice payment state management | Invoices | Invoices | daily | administrator, manager, accountant | /invoices | SCN-INVOICE-PAYMENT | 01_mermaid/proc-invoice-payment_invoice-payment-state-management.mmd |
| PROC-INVOICE-REVOKE-CORRECTION | Invoice revoke and correction task resolution | Invoices | Invoices | rare | administrator, manager, accountant | /invoices | SCN-INVOICE-REVOKE-RESOLVE | 01_mermaid/proc-invoice-revoke-correction_invoice-revoke-and-correction-task-resolution.mmd |
| PROC-EXPORT-INVOICES | Invoice export workflow | Export | Export | monthly | administrator, manager, accountant | /export | SCN-EXPORT-INVOICES | 01_mermaid/proc-export-invoices_invoice-export-workflow.mmd |
| PROC-EXPORT-PRODUCTION | Production export workflow | Export | Export | monthly | administrator, manager, accountant | /export | SCN-EXPORT-PRODUCTION | 01_mermaid/proc-export-production_production-export-workflow.mmd |
| PROC-EXPORT-CUSTOMERS | Customer export workflow | Export | Export / Customers data dialog | weekly | administrator, manager, accountant | /export, /data | SCN-EXPORT-CUSTOMERS | 01_mermaid/proc-export-customers_customer-export-workflow.mmd |
| PROC-EXPORT-INVOICE-PACKAGE | Invoice PDF package export workflow | Export | Export | monthly | administrator, manager, accountant | /export | SCN-EXPORT-INVOICE-PACKAGE | 01_mermaid/proc-export-invoice-package_invoice-pdf-package-export-workflow.mmd |
| PROC-USERS-ACCESS | User and access administration | Administration | Users | rare | administrator | /users | SCN-USERS-ACCESS | 01_mermaid/proc-users-access_user-and-access-administration.mmd |
| PROC-AUDITS | Audit trail investigation | Administration | Audit Trail | weekly | administrator, manager | /audits | SCN-AUDITS-INVESTIGATION | 01_mermaid/proc-audits_audit-trail-investigation.mmd |
| PROC-LOGS | System log investigation | Administration | System Logs | weekly | administrator | /logs | SCN-LOGS-INVESTIGATION | 01_mermaid/proc-logs_system-log-investigation.mmd |
| PROC-ADMIN-CONFIG | Application configuration management | Administration | Admin Config | rare | administrator | /admin | SCN-ADMIN-CONFIG | 01_mermaid/proc-admin-config_application-configuration-management.mmd |
| PROC-ADMIN-MODEL-VISIBILITY | Model visibility administration | Administration | Admin Config > Model Visibility | rare | administrator | /admin | SCN-ADMIN-MODEL-VISIBILITY | 01_mermaid/proc-admin-model-visibility_model-visibility-administration.mmd |

## Checklist by module and menu
### Account
- [x] **PROC-AUTH-ACCESS** - Authentication and account self-service  
  - Menu: Login / Account  
  - Pages: /Account/Login, /Account/LoginWith2fa, /Account/Manage, /Account/Manage/EnableAuthenticator, /Account/Manage/TwoFactorAuthentication  
  - Roles: administrator, manager, accountant, technician, user  
  - Frequency: daily  
  - Scenarios: SCN-AUTH-LOGIN, SCN-AUTH-2FA-SETUP, SCN-ACCOUNT-PROFILE-2FA-MANAGE  
  - Diagram: `01_mermaid/proc-auth-access_authentication-and-account-self-service.mmd`

### Administration
- [x] **PROC-USERS-ACCESS** - User and access administration  
  - Menu: Users  
  - Pages: /users  
  - Roles: administrator  
  - Frequency: rare  
  - Scenarios: SCN-USERS-ACCESS  
  - Diagram: `01_mermaid/proc-users-access_user-and-access-administration.mmd`
- [x] **PROC-AUDITS** - Audit trail investigation  
  - Menu: Audit Trail  
  - Pages: /audits  
  - Roles: administrator, manager  
  - Frequency: weekly  
  - Scenarios: SCN-AUDITS-INVESTIGATION  
  - Diagram: `01_mermaid/proc-audits_audit-trail-investigation.mmd`
- [x] **PROC-LOGS** - System log investigation  
  - Menu: System Logs  
  - Pages: /logs  
  - Roles: administrator  
  - Frequency: weekly  
  - Scenarios: SCN-LOGS-INVESTIGATION  
  - Diagram: `01_mermaid/proc-logs_system-log-investigation.mmd`
- [x] **PROC-ADMIN-CONFIG** - Application configuration management  
  - Menu: Admin Config  
  - Pages: /admin  
  - Roles: administrator  
  - Frequency: rare  
  - Scenarios: SCN-ADMIN-CONFIG  
  - Diagram: `01_mermaid/proc-admin-config_application-configuration-management.mmd`
- [x] **PROC-ADMIN-MODEL-VISIBILITY** - Model visibility administration  
  - Menu: Admin Config > Model Visibility  
  - Pages: /admin  
  - Roles: administrator  
  - Frequency: rare  
  - Scenarios: SCN-ADMIN-MODEL-VISIBILITY  
  - Diagram: `01_mermaid/proc-admin-model-visibility_model-visibility-administration.mmd`

### Customers
- [x] **PROC-CUSTOMER-WORKSPACE** - Customer workspace navigation and context drill-down  
  - Menu: Customers  
  - Pages: /data  
  - Roles: administrator, manager, accountant, technician, user  
  - Frequency: daily  
  - Scenarios: SCN-CUSTOMER-WORKSPACE  
  - Diagram: `01_mermaid/proc-customer-workspace_customer-workspace-navigation-and-context-drill-down.mmd`
- [x] **PROC-CUSTOMER-MAINTENANCE** - Customer create, edit, deactivate, and delete  
  - Menu: Customers  
  - Pages: /data  
  - Roles: administrator, manager, accountant, technician  
  - Frequency: weekly  
  - Scenarios: SCN-CUSTOMER-CREATE, SCN-CUSTOMER-EDIT-STATUS  
  - Diagram: `01_mermaid/proc-customer-maintenance_customer-create-edit-deactivate-and-delete.mmd`
- [x] **PROC-CUSTOMER-IMPORT** - Customer import with staged validation  
  - Menu: Customers / Import dialog  
  - Pages: /data  
  - Roles: administrator, manager  
  - Frequency: rare  
  - Scenarios: SCN-CUSTOMER-IMPORT  
  - Diagram: `01_mermaid/proc-customer-import_customer-import-with-staged-validation.mmd`

### Dashboard
- [x] **PROC-DASHBOARD-TRIAGE** - Dashboard monitoring and operational triage  
  - Menu: Dashboard  
  - Pages: /  
  - Roles: administrator, manager, accountant, technician, user  
  - Frequency: daily  
  - Scenarios: SCN-DASHBOARD-TRIAGE  
  - Diagram: `01_mermaid/proc-dashboard-triage_dashboard-monitoring-and-operational-triage.mmd`

### Export
- [x] **PROC-EXPORT-INVOICES** - Invoice export workflow  
  - Menu: Export  
  - Pages: /export  
  - Roles: administrator, manager, accountant  
  - Frequency: monthly  
  - Scenarios: SCN-EXPORT-INVOICES  
  - Diagram: `01_mermaid/proc-export-invoices_invoice-export-workflow.mmd`
- [x] **PROC-EXPORT-PRODUCTION** - Production export workflow  
  - Menu: Export  
  - Pages: /export  
  - Roles: administrator, manager, accountant  
  - Frequency: monthly  
  - Scenarios: SCN-EXPORT-PRODUCTION  
  - Diagram: `01_mermaid/proc-export-production_production-export-workflow.mmd`
- [x] **PROC-EXPORT-CUSTOMERS** - Customer export workflow  
  - Menu: Export / Customers data dialog  
  - Pages: /export, /data  
  - Roles: administrator, manager, accountant  
  - Frequency: weekly  
  - Scenarios: SCN-EXPORT-CUSTOMERS  
  - Diagram: `01_mermaid/proc-export-customers_customer-export-workflow.mmd`
- [x] **PROC-EXPORT-INVOICE-PACKAGE** - Invoice PDF package export workflow  
  - Menu: Export  
  - Pages: /export  
  - Roles: administrator, manager, accountant  
  - Frequency: monthly  
  - Scenarios: SCN-EXPORT-INVOICE-PACKAGE  
  - Diagram: `01_mermaid/proc-export-invoice-package_invoice-pdf-package-export-workflow.mmd`

### Invoices
- [x] **PROC-INVOICE-MANUAL-CREATE** - Manual single invoice creation  
  - Menu: Customers / Invoices  
  - Pages: /data, /invoices  
  - Roles: administrator, manager, accountant  
  - Frequency: weekly  
  - Scenarios: SCN-INVOICE-MANUAL-CREATE  
  - Diagram: `01_mermaid/proc-invoice-manual-create_manual-single-invoice-creation.mmd`
- [x] **PROC-INVOICE-MONTHLY-RUN** - Monthly invoice run wizard  
  - Menu: Add Invoices  
  - Pages: /create  
  - Roles: administrator, manager, accountant  
  - Frequency: monthly  
  - Scenarios: SCN-INVOICE-MONTHLY-RUN  
  - Diagram: `01_mermaid/proc-invoice-monthly-run_monthly-invoice-run-wizard.mmd`
- [x] **PROC-INVOICE-INSPECT** - Invoice inspection and state-based actions  
  - Menu: Invoices  
  - Pages: /invoices  
  - Roles: administrator, manager, accountant, technician, user  
  - Frequency: daily  
  - Scenarios: SCN-INVOICE-INSPECT-PROCESS  
  - Diagram: `01_mermaid/proc-invoice-inspect_invoice-inspection-and-state-based-actions.mmd`
- [x] **PROC-INVOICE-EDIT-CORRECTION** - Invoice edit with correction safeguards  
  - Menu: Invoices / Customer dashboard  
  - Pages: /invoices, /data  
  - Roles: administrator, manager, accountant  
  - Frequency: weekly  
  - Scenarios: SCN-INVOICE-EDIT-CORRECTION  
  - Diagram: `01_mermaid/proc-invoice-edit-correction_invoice-edit-with-correction-safeguards.mmd`
- [x] **PROC-INVOICE-PAYMENT** - Invoice payment state management  
  - Menu: Invoices  
  - Pages: /invoices  
  - Roles: administrator, manager, accountant  
  - Frequency: daily  
  - Scenarios: SCN-INVOICE-PAYMENT  
  - Diagram: `01_mermaid/proc-invoice-payment_invoice-payment-state-management.mmd`
- [x] **PROC-INVOICE-REVOKE-CORRECTION** - Invoice revoke and correction task resolution  
  - Menu: Invoices  
  - Pages: /invoices  
  - Roles: administrator, manager, accountant  
  - Frequency: rare  
  - Scenarios: SCN-INVOICE-REVOKE-RESOLVE  
  - Diagram: `01_mermaid/proc-invoice-revoke-correction_invoice-revoke-and-correction-task-resolution.mmd`

### Production
- [x] **PROC-PRODUCTION-MANUAL** - Manual production entry  
  - Menu: Customers / Import  
  - Pages: /data, /import  
  - Roles: administrator, manager, technician  
  - Frequency: weekly  
  - Scenarios: SCN-PRODUCTION-MANUAL  
  - Diagram: `01_mermaid/proc-production-manual_manual-production-entry.mmd`
- [x] **PROC-PRODUCTION-CONFLICT** - Production change with blocking invoice conflict handling  
  - Menu: Customers  
  - Pages: /data  
  - Roles: administrator, manager, technician  
  - Frequency: rare  
  - Scenarios: SCN-PRODUCTION-BLOCKING-INVOICE  
  - Diagram: `01_mermaid/proc-production-conflict_production-change-with-blocking-invoice-conflict-handling.mmd`
- [x] **PROC-PRODUCTION-IMPORT** - Production import with staged validation  
  - Menu: Import Production  
  - Pages: /import  
  - Roles: administrator, manager, technician  
  - Frequency: monthly  
  - Scenarios: SCN-PRODUCTION-IMPORT  
  - Diagram: `01_mermaid/proc-production-import_production-import-with-staged-validation.mmd`


## Checklist by role
### administrator
- [x] PROC-AUTH-ACCESS - Authentication and account self-service (Account)
- [x] PROC-DASHBOARD-TRIAGE - Dashboard monitoring and operational triage (Dashboard)
- [x] PROC-CUSTOMER-WORKSPACE - Customer workspace navigation and context drill-down (Customers)
- [x] PROC-CUSTOMER-MAINTENANCE - Customer create, edit, deactivate, and delete (Customers)
- [x] PROC-CUSTOMER-IMPORT - Customer import with staged validation (Customers)
- [x] PROC-PRODUCTION-MANUAL - Manual production entry (Production)
- [x] PROC-PRODUCTION-CONFLICT - Production change with blocking invoice conflict handling (Production)
- [x] PROC-PRODUCTION-IMPORT - Production import with staged validation (Production)
- [x] PROC-INVOICE-MANUAL-CREATE - Manual single invoice creation (Invoices)
- [x] PROC-INVOICE-MONTHLY-RUN - Monthly invoice run wizard (Invoices)
- [x] PROC-INVOICE-INSPECT - Invoice inspection and state-based actions (Invoices)
- [x] PROC-INVOICE-EDIT-CORRECTION - Invoice edit with correction safeguards (Invoices)
- [x] PROC-INVOICE-PAYMENT - Invoice payment state management (Invoices)
- [x] PROC-INVOICE-REVOKE-CORRECTION - Invoice revoke and correction task resolution (Invoices)
- [x] PROC-EXPORT-INVOICES - Invoice export workflow (Export)
- [x] PROC-EXPORT-PRODUCTION - Production export workflow (Export)
- [x] PROC-EXPORT-CUSTOMERS - Customer export workflow (Export)
- [x] PROC-EXPORT-INVOICE-PACKAGE - Invoice PDF package export workflow (Export)
- [x] PROC-USERS-ACCESS - User and access administration (Administration)
- [x] PROC-AUDITS - Audit trail investigation (Administration)
- [x] PROC-LOGS - System log investigation (Administration)
- [x] PROC-ADMIN-CONFIG - Application configuration management (Administration)
- [x] PROC-ADMIN-MODEL-VISIBILITY - Model visibility administration (Administration)

### manager
- [x] PROC-AUTH-ACCESS - Authentication and account self-service (Account)
- [x] PROC-DASHBOARD-TRIAGE - Dashboard monitoring and operational triage (Dashboard)
- [x] PROC-CUSTOMER-WORKSPACE - Customer workspace navigation and context drill-down (Customers)
- [x] PROC-CUSTOMER-MAINTENANCE - Customer create, edit, deactivate, and delete (Customers)
- [x] PROC-CUSTOMER-IMPORT - Customer import with staged validation (Customers)
- [x] PROC-PRODUCTION-MANUAL - Manual production entry (Production)
- [x] PROC-PRODUCTION-CONFLICT - Production change with blocking invoice conflict handling (Production)
- [x] PROC-PRODUCTION-IMPORT - Production import with staged validation (Production)
- [x] PROC-INVOICE-MANUAL-CREATE - Manual single invoice creation (Invoices)
- [x] PROC-INVOICE-MONTHLY-RUN - Monthly invoice run wizard (Invoices)
- [x] PROC-INVOICE-INSPECT - Invoice inspection and state-based actions (Invoices)
- [x] PROC-INVOICE-EDIT-CORRECTION - Invoice edit with correction safeguards (Invoices)
- [x] PROC-INVOICE-PAYMENT - Invoice payment state management (Invoices)
- [x] PROC-INVOICE-REVOKE-CORRECTION - Invoice revoke and correction task resolution (Invoices)
- [x] PROC-EXPORT-INVOICES - Invoice export workflow (Export)
- [x] PROC-EXPORT-PRODUCTION - Production export workflow (Export)
- [x] PROC-EXPORT-CUSTOMERS - Customer export workflow (Export)
- [x] PROC-EXPORT-INVOICE-PACKAGE - Invoice PDF package export workflow (Export)
- [x] PROC-AUDITS - Audit trail investigation (Administration)

### accountant
- [x] PROC-AUTH-ACCESS - Authentication and account self-service (Account)
- [x] PROC-DASHBOARD-TRIAGE - Dashboard monitoring and operational triage (Dashboard)
- [x] PROC-CUSTOMER-WORKSPACE - Customer workspace navigation and context drill-down (Customers)
- [x] PROC-CUSTOMER-MAINTENANCE - Customer create, edit, deactivate, and delete (Customers)
- [x] PROC-INVOICE-MANUAL-CREATE - Manual single invoice creation (Invoices)
- [x] PROC-INVOICE-MONTHLY-RUN - Monthly invoice run wizard (Invoices)
- [x] PROC-INVOICE-INSPECT - Invoice inspection and state-based actions (Invoices)
- [x] PROC-INVOICE-EDIT-CORRECTION - Invoice edit with correction safeguards (Invoices)
- [x] PROC-INVOICE-PAYMENT - Invoice payment state management (Invoices)
- [x] PROC-INVOICE-REVOKE-CORRECTION - Invoice revoke and correction task resolution (Invoices)
- [x] PROC-EXPORT-INVOICES - Invoice export workflow (Export)
- [x] PROC-EXPORT-PRODUCTION - Production export workflow (Export)
- [x] PROC-EXPORT-CUSTOMERS - Customer export workflow (Export)
- [x] PROC-EXPORT-INVOICE-PACKAGE - Invoice PDF package export workflow (Export)

### technician
- [x] PROC-AUTH-ACCESS - Authentication and account self-service (Account)
- [x] PROC-DASHBOARD-TRIAGE - Dashboard monitoring and operational triage (Dashboard)
- [x] PROC-CUSTOMER-WORKSPACE - Customer workspace navigation and context drill-down (Customers)
- [x] PROC-CUSTOMER-MAINTENANCE - Customer create, edit, deactivate, and delete (Customers)
- [x] PROC-PRODUCTION-MANUAL - Manual production entry (Production)
- [x] PROC-PRODUCTION-CONFLICT - Production change with blocking invoice conflict handling (Production)
- [x] PROC-PRODUCTION-IMPORT - Production import with staged validation (Production)
- [x] PROC-INVOICE-INSPECT - Invoice inspection and state-based actions (Invoices)

### user
- [x] PROC-AUTH-ACCESS - Authentication and account self-service (Account)
- [x] PROC-DASHBOARD-TRIAGE - Dashboard monitoring and operational triage (Dashboard)
- [x] PROC-CUSTOMER-WORKSPACE - Customer workspace navigation and context drill-down (Customers)
- [x] PROC-INVOICE-INSPECT - Invoice inspection and state-based actions (Invoices)


## Checklist by frequency
### daily
- [x] PROC-AUTH-ACCESS - Authentication and account self-service [Account]
- [x] PROC-DASHBOARD-TRIAGE - Dashboard monitoring and operational triage [Dashboard]
- [x] PROC-CUSTOMER-WORKSPACE - Customer workspace navigation and context drill-down [Customers]
- [x] PROC-INVOICE-INSPECT - Invoice inspection and state-based actions [Invoices]
- [x] PROC-INVOICE-PAYMENT - Invoice payment state management [Invoices]

### weekly
- [x] PROC-CUSTOMER-MAINTENANCE - Customer create, edit, deactivate, and delete [Customers]
- [x] PROC-PRODUCTION-MANUAL - Manual production entry [Production]
- [x] PROC-INVOICE-MANUAL-CREATE - Manual single invoice creation [Invoices]
- [x] PROC-INVOICE-EDIT-CORRECTION - Invoice edit with correction safeguards [Invoices]
- [x] PROC-EXPORT-CUSTOMERS - Customer export workflow [Export]
- [x] PROC-AUDITS - Audit trail investigation [Administration]
- [x] PROC-LOGS - System log investigation [Administration]

### rare
- [x] PROC-CUSTOMER-IMPORT - Customer import with staged validation [Customers]
- [x] PROC-PRODUCTION-CONFLICT - Production change with blocking invoice conflict handling [Production]
- [x] PROC-INVOICE-REVOKE-CORRECTION - Invoice revoke and correction task resolution [Invoices]
- [x] PROC-USERS-ACCESS - User and access administration [Administration]
- [x] PROC-ADMIN-CONFIG - Application configuration management [Administration]
- [x] PROC-ADMIN-MODEL-VISIBILITY - Model visibility administration [Administration]


## Notes on workflow reality captured in this pack
- Zero-value processing is controlled by the Admin feature flag and affects production entry, production import, manual invoice creation, and monthly invoice generation.
- Editing or deleting a sent invoice creates correction work instead of silently rewriting history.
- Updating production linked to invoiced periods is protected and may require override permission plus correction handling.
- Export workflows are wizard-based and must support preview-before-download.
- Audit and log investigations are intentionally separate: business traceability vs technical diagnostics.

## Validation
- [x] All known menu modules are represented.
- [x] All mapped processes have at least one scenario.
- [x] All mapped processes have a Mermaid diagram.
- [x] Role coverage and frequency coverage are listed.
