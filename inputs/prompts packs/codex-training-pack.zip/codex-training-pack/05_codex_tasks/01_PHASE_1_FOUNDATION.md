# Phase 1 - Foundation

## Goal
Build the reusable Training Mode foundation without yet wiring every scenario target.

## Files to add
### Components
- `Components/Training/TrainingHost.razor`
- `Components/Training/TrainingModeToggle.razor`
- `Components/Training/TrainingOverlay.razor`
- `Components/Training/TrainingTooltipCard.razor`
- `Components/Training/TrainingProgressBar.razor`

### Services
- `Services/Training/TrainingModeService.cs`
- `Services/Training/JsonTrainingScenarioRepository.cs`
- `Services/Training/ProtectedLocalTrainingStateStore.cs`
- `Services/Training/TrainingTargetResolver.cs`
- `Services/Training/TrainingNavigationCoordinator.cs`
- `Services/Training/TrainingPermissionEvaluator.cs`

### Models
- `Models/Training/TrainingScenario.cs`
- `Models/Training/TrainingStep.cs`
- `Models/Training/TrainingSessionState.cs`
- `Models/Training/TrainingTargetRect.cs`
- `Models/Training/TrainingCompletionCondition.cs`

### Assets
- `wwwroot/js/trainingMode.js`
- `wwwroot/training/scenarios/` (copy scenario JSON files)
- `wwwroot/training/ui/` (copy UI copy JSON files)

## Files to update
- `Components/App.razor` - load `trainingMode.js`
- `Components/Layout/MainLayout.razor` - mount `TrainingHost`
- service registration file(s) - register Training Mode services

## Tasks
1. Create strongly typed models matching `02_scenarios/scenarios.schema.json`.
2. Create a JSON repository that loads scenario files from static assets.
3. Create a local state store using `ProtectedLocalStorage`.
4. Create a central `TrainingModeService` with explicit state machine states.
5. Create minimal JS functions for:
   - query selector lookup
   - bounding rectangle read
   - viewport visibility
   - scroll into view
   - mutation observation
6. Render a simple overlay and tooltip driven by the service.
7. Implement basic start, pause, resume, restart, exit lifecycle methods.

## Acceptance criteria
- Scenario files deserialize successfully.
- The host renders without affecting normal page behavior when inactive.
- The overlay can highlight a known static target.
- Progress survives page refresh in the same browser.
- The service exposes enough state for later scenario hub and engine work.
