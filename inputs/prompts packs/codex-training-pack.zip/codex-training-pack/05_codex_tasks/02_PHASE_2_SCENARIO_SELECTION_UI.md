# Phase 2 - Scenario Selection UI

## Goal
Implement the user-facing Training Mode entry points and the scenario card hub.

## Files to add
- `Components/Training/TrainingScenarioHub.razor`
- `Components/Training/TrainingScenarioCard.razor`
- `Components/Training/TrainingDiagramPanel.razor`
- optional view models under `Models/Training/`

## Files to update
- `Components/Layout/MainLayout.razor`
- relevant shell/header components for the global Training Mode toggle
- optional dashboard page if adding a secondary Training entry point

## Tasks
1. Add a global **Training Mode** toggle to the shell.
2. Open the scenario hub as a modal or drawer when Training Mode starts.
3. Filter scenarios by:
   - current route,
   - current user role,
   - optional feature context.
4. Render the required card metadata:
   - title
   - short description
   - learning goals
   - prerequisites
   - estimated duration
   - difficulty
   - roles
   - Mermaid diagram action
5. Add:
   - search
   - module filter
   - difficulty filter
   - current page vs all scenarios toggle
6. Add resume support when paused progress exists.
7. Add diagram viewing panel or modal for `.mmd` source display.

## Acceptance criteria
- The hub opens from the shell on every authenticated page.
- Scenario cards show the required metadata and actions.
- The current-page filter reduces the list meaningfully.
- Resume and restart actions appear when expected.
- Diagram viewing works for every scenario card.
