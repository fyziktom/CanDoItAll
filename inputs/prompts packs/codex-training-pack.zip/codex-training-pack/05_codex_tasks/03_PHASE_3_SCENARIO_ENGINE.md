# Phase 3 - Scenario Engine

## Goal
Turn the foundation into a robust step engine that can drive real workflows.

## Tasks
1. Implement step activation and completion evaluation.
2. Support these completion conditions:
   - `elementVisible`
   - `routeIs`
   - `dialogVisible`
   - `inputHasValue`
   - `fieldChanged`
   - `filterApplied`
   - `previewLoaded`
   - `downloadTriggered`
   - `manualConfirm`
3. Implement automatic target resolution from:
   - `data-tour-id`
   - `data-testid`
   - explicit selector
4. Reposition overlay and tooltip on:
   - route changes
   - window resize
   - scroll
   - target mutation
5. Support `Back`, `Next`, `Skip`, `Exit`, `Resume`, and `Restart`.
6. Support hint-only and conflict-warning step rendering.
7. Add safe recovery when the target is missing:
   - retry
   - scroll into view
   - show fallback
   - skip
8. Support route navigation during a scenario and resume after the next render.
9. Support dialogs and dropdown overlays in Radzen.

## Files likely to update
- `TrainingModeService`
- `TrainingTargetResolver`
- `TrainingOverlay`
- `TrainingTooltipCard`
- `trainingMode.js`

## Acceptance criteria
- A scenario can move across at least two different routes.
- A scenario can target content inside a Radzen dialog.
- Missing targets fail gracefully with fallback guidance.
- Overlay and tooltip remain aligned during resize and scroll.
- Progress tracking stays consistent after route changes.
