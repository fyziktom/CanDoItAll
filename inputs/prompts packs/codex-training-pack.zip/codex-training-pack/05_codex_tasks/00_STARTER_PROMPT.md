# Starter Prompt for Codex

You are implementing **Training Mode** for the PVE Invoicing Blazor + Radzen application.

## Objective
Add a reusable guided-tour system that:
- can be turned on at runtime,
- opens a scenario hub with scenario cards,
- runs step-by-step guided overlays on top of real pages,
- supports navigation across pages and dialogs,
- supports conflict and warning steps,
- supports resume, restart, and exit,
- loads scenario content from JSON.

## Read these files first
1. `04_architecture/TRAINING_MODE_TECH_ARCHITECTURE.md`
2. `04_architecture/TRAINING_MODE_UX.md`
3. `04_architecture/DATA_MODEL.md`
4. `04_architecture/EDGE_CASES_AND_FALLBACKS.md`
5. `00_master_index/PROCESS_MASTER_LIST.md`
6. `00_master_index/SCENARIO_MASTER_LIST.md`
7. `00_master_index/PROCESS_SCENARIO_MAPPING.csv`

## Mandatory implementation rules
- Reuse existing `data-testid` selectors when stable.
- Add dedicated `data-tour-id` selectors for missing or fragile training targets.
- Keep user-facing Training Mode copy in English.
- Do not rewrite business workflows; layer Training Mode on top of existing behavior.
- Keep the solution modular and future-localizable.
- Prefer Blazor plus minimal JS interop over JS-heavy logic.
- Build the implementation in the phase order defined in this folder.

## Implementation success criteria
- Scenario hub is visible from the authenticated shell.
- Scenario cards are filtered by route and role.
- Scenario JSON files load and validate.
- Overlay and highlight work on normal pages and Radzen dialogs.
- Navigation across routes works during a scenario.
- Resume and restart work after exit or page reload.
- At least the scenarios in `02_scenarios/` are wired and runnable.
- Validation passes using `99_VALIDATION_CHECKLIST.md`.
