# Validation Checklist

Use this file as the final implementation gate.

## Scenario data
- [ ] All scenario JSON files are copied into the project.
- [ ] Scenario JSON files deserialize without error.
- [ ] Scenario IDs match the packaged IDs exactly.
- [ ] Step counts match the packaged definitions.
- [ ] All English copy is preserved.

## UI entry
- [ ] Training Mode toggle is visible in the authenticated shell.
- [ ] Scenario hub opens from the toggle.
- [ ] Current-page filtering works.
- [ ] Resume and restart actions work.

## Engine
- [ ] Overlay renders only when Training Mode is active.
- [ ] Highlight aligns to the target element.
- [ ] Tooltip placement falls back safely when space is limited.
- [ ] Route navigation during a scenario works.
- [ ] Missing targets show fallback guidance instead of crashing.
- [ ] Back, Next, Skip, Exit, Resume, and Restart all work.

## Selectors
- [ ] Existing `data-testid` selectors used by scenarios still resolve.
- [ ] Required new `data-tour-id` selectors were added.
- [ ] No target relies on brittle generated class names only.
- [ ] Dialog root selectors resolve reliably after open.

## Workflow coverage
- [ ] Account scenarios work.
- [ ] Dashboard scenario works.
- [ ] Customer scenarios work.
- [ ] Production scenarios work.
- [ ] Invoice scenarios work.
- [ ] Export scenarios work.
- [ ] Administration scenarios work.

## Role and feature rules
- [ ] Scenario visibility respects role restrictions.
- [ ] Feature-dependent steps behave correctly when flags change.
- [ ] Hidden targets from model visibility settings are handled safely.

## Radzen-specific validation
- [ ] Dialog steps resolve correctly.
- [ ] Notification-related steps do not depend solely on toast timing.
- [ ] Dropdown and popup steps remain usable.

## Persistence
- [ ] Exit stores paused progress.
- [ ] Resume restores the current step.
- [ ] Restart clears previous progress.
- [ ] Refreshing the browser allows resume.

## Accessibility
- [ ] Keyboard-only walkthrough is possible.
- [ ] Screen-reader announcements exist for step changes.
- [ ] Focus is visible and not lost.
- [ ] Escape exits Training Mode.
- [ ] Contrast remains acceptable for overlay and tooltip states.

## Final acceptance
- [ ] `06_acceptance/DEFINITION_OF_DONE.md` is satisfied.
- [ ] `06_acceptance/ACCEPTANCE_TESTS.md` pass.
