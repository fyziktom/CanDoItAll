# Phase 4 - Implement Scenarios

## Goal
Wire the packaged scenarios to the real application UI.

## Tasks
1. Copy the scenario JSON and UI copy assets into the project.
2. Add missing `data-tour-id` attributes to the existing components referenced by the scenarios.
3. Validate that every scenario target resolves in the intended page state.
4. For each scenario group, wire and smoke-test in this order:

### Account
- `SCN-AUTH-LOGIN`
- `SCN-AUTH-2FA-SETUP`
- `SCN-ACCOUNT-PROFILE-2FA-MANAGE`

### Dashboard
- `SCN-DASHBOARD-TRIAGE`

### Customers
- `SCN-CUSTOMER-WORKSPACE`
- `SCN-CUSTOMER-CREATE`
- `SCN-CUSTOMER-EDIT-STATUS`
- `SCN-CUSTOMER-IMPORT`

### Production
- `SCN-PRODUCTION-MANUAL`
- `SCN-PRODUCTION-BLOCKING-INVOICE`
- `SCN-PRODUCTION-IMPORT`

### Invoices
- `SCN-INVOICE-MANUAL-CREATE`
- `SCN-INVOICE-MONTHLY-RUN`
- `SCN-INVOICE-INSPECT-PROCESS`
- `SCN-INVOICE-EDIT-CORRECTION`
- `SCN-INVOICE-PAYMENT`
- `SCN-INVOICE-REVOKE-RESOLVE`

### Export
- `SCN-EXPORT-INVOICES`
- `SCN-EXPORT-PRODUCTION`
- `SCN-EXPORT-CUSTOMERS`
- `SCN-EXPORT-INVOICE-PACKAGE`

### Administration
- `SCN-USERS-ACCESS`
- `SCN-AUDITS-INVESTIGATION`
- `SCN-LOGS-INVESTIGATION`
- `SCN-ADMIN-CONFIG`
- `SCN-ADMIN-MODEL-VISIBILITY`

## Required target audit
Create a selector audit table during implementation with columns:
- scenario ID
- step ID
- selector
- page
- existing or newly added hook
- resolution result

## Acceptance criteria
- Every packaged scenario loads.
- Every scenario has a resolvable target for each non-branching step.
- Newly added `data-tour-id` hooks are semantic and stable.
- Scenario execution matches the intended workflow text.
