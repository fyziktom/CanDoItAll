# Phase 5 - Tests, Accessibility, and Polish

## Goal
Finish the feature to production-ready quality.

## Automated tests
### Unit tests
Add tests for:
- scenario deserialization
- schema compatibility
- state transitions
- completion condition evaluation
- permission filtering
- resume state restoration

### Component tests
Add tests for:
- overlay rendering
- tooltip progression
- conflict step rendering
- missing-target fallback rendering

### End-to-end tests
Add or extend Playwright coverage for:
- shell toggle -> scenario hub open
- route navigation during a scenario
- dialog targeting
- resume after reload
- role-filtered scenario visibility
- zero-value warning branch
- correction-warning branch

## Accessibility tasks
1. Verify keyboard navigation through the tooltip controls.
2. Verify Escape exits Training Mode.
3. Verify screen-reader announcement of each step.
4. Verify contrast and focus visibility.
5. Verify reduced-motion compatibility.

## UX polish tasks
1. Prevent tooltip overlap with important action buttons.
2. Smooth repositioning without visible jitter.
3. Distinguish hints, warnings, and conflicts visually.
4. Keep copy spacing and typography consistent with the app shell.

## Acceptance criteria
- Automated tests cover the engine and at least one scenario in every major module.
- Keyboard and screen-reader checks pass.
- No obvious overlay jitter or clipping remains.
- Training Mode feels integrated with the existing Radzen UI.
