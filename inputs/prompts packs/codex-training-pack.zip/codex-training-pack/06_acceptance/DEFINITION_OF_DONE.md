# Definition of Done

Training Mode is done only when **all** items below are true.

## 1. Functional completeness
- A global Training Mode entry point exists in the authenticated shell.
- A scenario hub with scenario cards exists.
- Scenario cards show:
  - title
  - short description
  - learning goals
  - prerequisites
  - estimated duration
  - difficulty
  - roles
  - Mermaid diagram action
- Scenario content is loaded from JSON, not hard-coded in components.
- The engine can start, pause, resume, restart, and exit a scenario.
- The engine supports cross-page navigation.
- The engine supports Radzen dialog targets.
- The engine supports conflict and warning steps.

## 2. Process coverage
- Every process in `00_master_index/PROCESS_MASTER_LIST.md` has a Mermaid diagram.
- Every process has at least one runnable scenario.
- Every scenario from `00_master_index/SCENARIO_MASTER_LIST.md` is present in the implementation.
- Every packaged scenario step is wired to a real or intentionally branched UI target.

## 3. UX quality
- Overlay, highlight, and tooltip are visually stable.
- Tooltip placement avoids hiding the target whenever possible.
- Progress is visible.
- Warning and conflict steps are clearly differentiated.
- Missing-target states fail gracefully with useful fallback guidance.

## 4. Technical quality
- Scenario files validate against the schema contract.
- Service registration is clean and testable.
- The implementation does not require large changes to existing business logic.
- `data-tour-id` additions are semantic and stable.
- The implementation is resilient to route changes, dialog timing, and resize events.

## 5. Role and configuration correctness
- Scenario visibility respects user roles.
- Step behavior tolerates hidden fields from model visibility settings.
- Feature-sensitive workflows correctly handle:
  - zero-value processing policy
  - two-factor requirement
  - manual review thresholds
  - restart-required configuration changes

## 6. Persistence
- Progress is stored locally and restored after refresh.
- Resume starts from the correct step.
- Restart clears old progress.
- Exit returns the app to normal mode immediately.

## 7. Testing
- Unit tests exist for core scenario loading and engine logic.
- UI/component tests exist for overlay and tooltip behavior.
- End-to-end coverage includes at least one scenario from every major module.
- Manual QA covers all packaged scenarios.

## 8. Accessibility
- Keyboard-only operation works.
- Step changes are announced to assistive technology.
- Focus handling is reliable.
- Escape exits Training Mode.
- Visual contrast is acceptable.

## 9. Documentation
- Architecture docs remain aligned with the implemented solution.
- Scenario mapping remains aligned with the final selectors.
- Validation checklist is complete.

## 10. Final release gate
Training Mode is not done if any of the following remains true:
- a process has no scenario,
- a scenario has broken selectors,
- a critical route transition breaks the flow,
- conflict steps are not distinguishable,
- resume and restart are unreliable,
- tests do not cover the reusable engine.
