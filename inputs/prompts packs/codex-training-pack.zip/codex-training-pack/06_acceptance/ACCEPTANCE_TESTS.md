# Acceptance Tests

## Test set A - Scenario hub and activation
### A1 - Shell entry
1. Sign in as an eligible user.
2. Confirm the Training Mode toggle is visible.
3. Activate Training Mode.
4. Verify the scenario hub opens.

Expected result:
- The hub opens without navigating away from the current page.
- The current page remains visible behind the hub.

### A2 - Card content
1. Inspect any scenario card.
2. Verify title, short description, learning goals, prerequisites, duration, difficulty, roles, and diagram action are present.

Expected result:
- All required card fields are rendered.

### A3 - Current page filtering
1. Open Training Mode on `/data`.
2. Compare **Current page** vs **All scenarios**.

Expected result:
- Current-page mode prioritizes customer, export-from-customers, and related scenarios.
- All-scenarios mode shows the full catalog allowed by role.

## Test set B - Engine basics
### B1 - Start and exit
1. Start any scenario.
2. Verify overlay and tooltip appear.
3. Exit Training Mode.

Expected result:
- Overlay disappears immediately.
- Normal interaction returns.
- Resume is offered next time.

### B2 - Back and next
1. Start a scenario with at least four steps.
2. Move forward two steps.
3. Move back one step.

Expected result:
- Step content and progress update correctly in both directions.

### B3 - Missing target fallback
1. Start a scenario.
2. Intentionally hide the expected target by changing tab or route.
3. Wait for resolution.

Expected result:
- The engine shows a useful fallback message instead of crashing.

## Test set C - Cross-route workflows
### C1 - Dashboard to Create Invoices
1. Start `SCN-DASHBOARD-TRIAGE`.
2. Follow the step that opens `/create`.

Expected result:
- The engine survives the route change and continues on the target page.

### C2 - Customers to Invoice or Production dialog
1. Start a customer or production scenario that opens a dialog.

Expected result:
- The target resolves after the Radzen dialog opens.
- Highlight alignment remains correct.

## Test set D - Role filtering
### D1 - Administrator catalog
1. Sign in as an administrator.
2. Open the scenario hub.

Expected result:
- Administrator scenarios such as Users, Audits, Logs, and Admin are visible.

### D2 - Read-only user catalog
1. Sign in as a limited user.
2. Open the scenario hub.

Expected result:
- Restricted admin scenarios are hidden or unavailable.
- Read-only or safe scenarios remain available.

## Test set E - Workflow-specific checks
### E1 - Zero-value warning path
1. Use a scenario that explains zero-value handling.
2. Run it in an environment where zero-value processing is disabled.

Expected result:
- The scenario explains that zero is blocked.
- The UI and training copy remain consistent.

### E2 - Correction safeguard path
1. Start `SCN-INVOICE-EDIT-CORRECTION` with a sent invoice.
2. Save the edited invoice.

Expected result:
- Training explains the cancellation/correction path.
- The scenario remains aligned with the resulting UI state.

### E3 - Payment workflow
1. Start `SCN-INVOICE-PAYMENT`.
2. Mark an invoice as paid.

Expected result:
- The paid dialog appears.
- Saving returns to an updated inspector state.

### E4 - Revoke or correction resolution
1. Start `SCN-INVOICE-REVOKE-RESOLVE`.
2. Complete the prepared recovery path.

Expected result:
- The dialog requires deliberate confirmation.
- The final invoice state refreshes correctly.

## Test set F - Export workflows
### F1 - Invoice export
1. Start `SCN-EXPORT-INVOICES`.
2. Reach preview and download.

Expected result:
- Preview loads.
- Download starts in the selected format.

### F2 - Invoice package export
1. Start `SCN-EXPORT-INVOICE-PACKAGE`.
2. Reach the ZIP step.

Expected result:
- Package preview loads.
- ZIP download can be triggered.

## Test set G - Persistence
### G1 - Resume after refresh
1. Start a scenario.
2. Advance to a mid-scenario step.
3. Refresh the browser.
4. Reopen Training Mode.

Expected result:
- Resume is offered.
- The scenario returns to the correct step or a safe recovery prompt.

### G2 - Restart
1. Resume a paused scenario.
2. Choose Restart.

Expected result:
- Step index resets to the beginning.
- Previous progress is cleared.

## Test set H - Accessibility
### H1 - Keyboard-only run
1. Use only keyboard input.
2. Open the hub, start a scenario, move between steps, and exit.

Expected result:
- All core actions are reachable by keyboard.

### H2 - Screen-reader announcements
1. Run a scenario with a screen reader active.

Expected result:
- Step title and body are announced when steps change.

### H3 - Escape exit
1. Start a scenario.
2. Press Escape.

Expected result:
- Training Mode exits cleanly or shows a clear exit confirmation when appropriate.

## Acceptance result
Training Mode is accepted only when:
- all relevant tests above pass,
- no critical selector failures remain,
- process coverage stays aligned with the packaged process and scenario lists.
