# Training Mode Technical Architecture

## 1. Architectural recommendation
Implement Training Mode as a reusable client-side guidance engine layered on top of the existing Blazor + Radzen UI.

### Recommended approach
Use **Blazor components plus a minimal JavaScript DOM bridge**.

This is the recommended option because:
- Blazor alone does not provide reliable general-purpose DOM measurement.
- Highlight overlays require accurate element rectangles.
- Radzen dialogs, popups, and notifications are DOM-driven and can move outside the normal component tree.
- Resize, scroll, and route changes must be tracked in real time.

## 2. Element position strategy
### Option A - Pure Blazor without JavaScript
Possible only in a narrow sense:
- you can show instructional cards attached to known wrapper components,
- you can guide static layouts,
- you can use CSS-only overlays for fixed regions.

Limitations:
- no reliable `getBoundingClientRect`,
- poor support for dynamic Radzen dialogs and notifications,
- weak responsiveness handling,
- poor resilience when layout changes.

**Conclusion: not recommended for this application.**

### Option B - Minimal JavaScript DOM bridge
Use a tiny JS module to:
- locate target elements by selector,
- read `getBoundingClientRect`,
- observe resize, scroll, and DOM mutation,
- return a normalized rectangle to Blazor,
- report element visibility and viewport clipping.

**Conclusion: recommended.**

## 3. Proposed component and service map
### Blazor components
Recommended new files:
- `Components/Training/TrainingModeToggle.razor`
- `Components/Training/TrainingScenarioHub.razor`
- `Components/Training/TrainingOverlay.razor`
- `Components/Training/TrainingTooltipCard.razor`
- `Components/Training/TrainingProgressBar.razor`
- `Components/Training/TrainingConflictBanner.razor`
- `Components/Training/TourTarget.razor` (optional wrapper for new or fragile targets)
- `Components/Training/TrainingHost.razor`

### Services
Recommended new files:
- `Services/Training/ITrainingScenarioRepository.cs`
- `Services/Training/JsonTrainingScenarioRepository.cs`
- `Services/Training/ITrainingStateStore.cs`
- `Services/Training/ProtectedLocalTrainingStateStore.cs`
- `Services/Training/TrainingModeService.cs`
- `Services/Training/TrainingTargetResolver.cs`
- `Services/Training/TrainingNavigationCoordinator.cs`
- `Services/Training/TrainingPermissionEvaluator.cs`
- `Services/Training/TrainingTelemetryService.cs`

### Models
Recommended new files:
- `Models/Training/TrainingScenario.cs`
- `Models/Training/TrainingStep.cs`
- `Models/Training/TrainingCompletionCondition.cs`
- `Models/Training/TrainingBranchRule.cs`
- `Models/Training/TrainingSessionState.cs`
- `Models/Training/TrainingTargetRect.cs`
- `Models/Training/TrainingScenarioCardViewModel.cs`

### JavaScript
Recommended new file:
- `wwwroot/js/trainingMode.js`

Load it beside the existing site scripts in `Components/App.razor`.

## 4. Host placement
Add one top-level host component to the authenticated shell, ideally in `MainLayout.razor` or directly under the layout body.

Responsibilities:
- render the scenario hub,
- render the overlay and tooltip,
- listen for current scenario state changes,
- stay alive across page navigation.

This avoids re-instantiating the engine on every page route.

## 5. Stable target identification strategy
### Primary recommendation
Use dedicated `data-tour-id` attributes for Training Mode targets.

Why not rely only on `data-testid`:
- `data-testid` already serves automated tests,
- tests may change for different reasons,
- training selectors should be owned by the UX guidance system.

### Selector priority order
1. `data-tour-id`
2. existing `data-testid`
3. explicit CSS selector from scenario JSON
4. wrapper component registration
5. safe manual-confirm fallback

### Naming convention
Use semantic, stable names:
- `customer-add-name`
- `invoice-edit-save`
- `training-hub-search`
- `dashboard-alert-suspicious`

Do not encode visual layout or index position into IDs unless absolutely unavoidable.

### Where to add `data-tour-id`
Add them to:
- buttons that launch dialogs,
- dialog root cards,
- main form sections,
- primary inputs,
- primary save buttons,
- tabs and wizard containers,
- high-risk warnings.

## 6. Wrapper and registry strategy
### Use wrappers selectively
For fragile Radzen content or repeated dynamic components, use a thin wrapper:
```razor
<TourTarget Id="invoice-edit-save">
    <RadzenButton ... />
</TourTarget>
```

The wrapper should:
- emit `data-tour-id`,
- optionally register metadata with `TrainingTargetResolver`,
- remain visually neutral.

### Registry use cases
Maintain a lightweight registry for:
- dynamically created rows,
- repeated components,
- dialog content that appears later,
- virtualized or paged lists.

The registry should never replace selectors entirely. It should enrich them.

## 7. Scenario engine flow
### Session lifecycle
1. Training Mode turns on.
2. Scenario hub loads card metadata.
3. User starts or resumes a scenario.
4. Engine loads the scenario JSON.
5. Engine evaluates route, role, and feature-flag prerequisites.
6. Engine navigates if required.
7. Engine resolves the active target.
8. Engine renders overlay and tooltip.
9. Engine waits for completion condition.
10. Engine advances, branches, pauses, or exits.

### Recommended state machine
Use explicit states:
- `Idle`
- `HubOpen`
- `LoadingScenario`
- `Navigating`
- `ResolvingTarget`
- `ShowingStep`
- `WaitingForCompletion`
- `Paused`
- `Completed`
- `Exited`
- `Blocked`

Avoid implicit state derived only from UI rendering.

## 8. Completion condition handling
Support the following completion types in the engine:
- `elementVisible`
- `routeIs`
- `dialogVisible`
- `inputHasValue`
- `fieldChanged`
- `filterApplied`
- `previewLoaded`
- `downloadTriggered`
- `manualConfirm`
- `workflowCompleted`
- `notificationShown`
- `gridSelectionChanged`

### Event sources
Use:
- `NavigationManager.LocationChanged`
- JS `MutationObserver`
- JS `ResizeObserver`
- JS scroll and viewport listeners
- optional Blazor callback hooks for known events

## 9. Handling action-bound steps
### Click steps
For click steps:
- highlight the button,
- let the user perform the action,
- observe resulting dialog, route, or state change.

### Type steps
For type steps:
- do not inspect sensitive text semantically,
- validate only that a value exists or changed when possible,
- allow manual confirm for sensitive fields like passwords.

### Select steps
For selectors and dropdowns:
- watch for value change or selected label change,
- re-measure after dropdown close.

### Navigate steps
When a step requires another page:
- save the pending step state,
- navigate with `NavigationManager.NavigateTo`,
- resume target resolution after the next render cycle.

## 10. Navigation between pages
Training scenarios in this app cross routes, so navigation must be first-class.

Recommended approach:
- each scenario declares `pagesInvolved`,
- each step may optionally declare an expected route,
- the engine performs route pre-check before showing the step,
- if the learner navigates away unexpectedly, the engine pauses and offers recovery.

Recovery options:
- **Return to expected page**
- **Resume on current page if target exists**
- **Restart scenario**

## 11. Radzen Dialog, Popup, and Notification handling
Radzen can render content outside the local component subtree.

### Dialogs
Best practice:
- add `data-tour-id` to the root element inside each dialog component,
- resolve the dialog content after it opens,
- keep a short retry loop for dialog rendering.

### Notifications
For toasts or notifications:
- watch the global notification container with a mutation observer,
- match text only when necessary,
- prefer completion by business state change over toast text.

### Popups and dropdowns
For dropdown popups:
- treat them as transient targets,
- resolve target after the popup opens,
- allow auto placement to prevent tooltip overlap.

## 12. Role and permission filtering
Training Mode must not show unusable scenarios to the current user.

Required filtering:
- scenario card hidden when required roles do not match,
- scenario card disabled when route exists but critical permission is missing,
- steps skipped or replaced when a minor permission difference hides a non-critical target.

Recommended rule split:
- **Scenario-level gating** for hard role restrictions,
- **Step-level branching** for feature or visibility differences.

## 13. Feature-flag awareness
Several workflows depend on configuration:
- zero-value processing,
- model visibility switches,
- manual review thresholds,
- two-factor requirement,
- dashboard permissions.

The engine should support a feature context object so scenario availability and branching can react to current config values.

## 14. Resume, restart, and progress tracking
### Storage recommendation
Use `ProtectedLocalStorage` for the first implementation.

Why:
- fast to build,
- scoped to current browser session or user,
- no schema migration in the main database for phase 1.

Store:
- scenario ID,
- current step index,
- visited steps,
- started timestamp,
- paused timestamp,
- last known route,
- optional training mode preferences.

Design the service behind `ITrainingStateStore` so a later DB-backed implementation can replace it without changing the engine.

## 15. File format recommendation
Use **JSON** for scenario files.

Why JSON is recommended over YAML here:
- native, strict parsing in .NET,
- easier schema validation,
- safer for machine-generated or machine-edited content,
- fewer whitespace errors,
- better fit for future API delivery and localization tooling.

## 16. Recommended project placement
Suggested physical locations in the existing project:

- `PVEInvoicing/Components/Training/*`
- `PVEInvoicing/Services/Training/*`
- `PVEInvoicing/Models/Training/*`
- `PVEInvoicing/wwwroot/training/scenarios/*.json`
- `PVEInvoicing/wwwroot/training/ui/*.json`
- `PVEInvoicing/wwwroot/js/trainingMode.js`

If the team prefers embedded resources instead of static files, keep the same folder structure in the repository and map it at startup.

## 17. Naming conventions
### Classes
- `TrainingModeService`
- `TrainingScenarioRepository`
- `TrainingOverlayComponent`

### Components
- `TrainingOverlay.razor`
- `TrainingTooltipCard.razor`

### JSON assets
- scenario files named by stable scenario ID, for example `SCN-INVOICE-MONTHLY-RUN.json`

### Target IDs
- lowercase kebab-case
- semantic
- stable across layout tweaks

## 18. Testability strategy
### Unit tests
Add tests for:
- scenario parsing,
- schema validation,
- completion condition evaluation,
- branch rule evaluation,
- permission filtering,
- resume state restoration.

### Component tests
Add tests for:
- overlay rendering,
- tooltip navigation,
- current step changes,
- missing target fallback UI.

### End-to-end tests
Use Playwright or the existing UI test stack for:
- scenario hub launch,
- route navigation during scenarios,
- dialog-based steps,
- resume after page reload,
- zero-value and correction warnings.

## 19. Performance expectations
Training Mode should:
- not block page rendering,
- throttle repeated DOM measurements,
- re-measure only on relevant events,
- avoid scanning the whole DOM on every frame.

Recommended safeguards:
- cache successful selectors for the current step,
- debounce scroll and resize reactions,
- cap mutation observer processing to the active step only.

## 20. Security and privacy
Do not record sensitive typed values in telemetry.
Use presence and completion signals, not raw content, for:
- passwords,
- authenticator codes,
- payment notes,
- imported file content.

## 21. Implementation definition of done
The implementation is done when:
- a reusable engine exists,
- scenario cards are loaded from JSON,
- target highlighting works across normal pages and Radzen dialogs,
- page navigation during a scenario is supported,
- resume and restart work,
- scenario gating respects roles and feature flags,
- automated and manual validation pass.
