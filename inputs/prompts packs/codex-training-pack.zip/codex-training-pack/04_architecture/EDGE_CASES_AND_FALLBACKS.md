# Edge Cases and Fallbacks

## 1. Missing target element
### Problem
The step target does not exist in the current DOM.

Typical causes:
- the user is on the wrong page,
- the wrong tab is open,
- the role hides the target,
- a feature flag removed the field,
- the dialog is not open yet.

### Required behavior
1. Retry target resolution briefly.
2. Check whether the route matches the expected page.
3. If not, navigate or prompt recovery.
4. Show the scenario's `fallback` text.
5. Offer:
   - Retry
   - Skip step
   - Exit training

## 2. Target exists but is offscreen
### Problem
The element exists but is outside the viewport or inside a scrollable container.

### Mitigation
- Scroll the nearest scroll container first.
- Then scroll the page if needed.
- Re-measure after scroll.
- If still clipped, switch tooltip placement to `auto` or bottom sheet mode.

## 3. Hidden behind collapsed UI
### Examples
- customer dashboard tab not selected,
- accordion collapsed,
- filter drawer closed,
- left navigation collapsed.

### Mitigation
Prefer scenario steps that explicitly open the container before targeting inner elements.

## 4. Radzen dialog not yet mounted
### Problem
The click action was performed, but the dialog content root is not visible yet.

### Mitigation
- Watch for DOM mutation after the triggering action.
- Retry selector resolution for a short bounded interval.
- Target the dialog content root, not the outer overlay chrome, whenever possible.

## 5. Notifications and toasts are transient
### Problem
A toast appears too briefly to be a reliable visual target.

### Mitigation
- Prefer business-state completion instead of toast-text completion.
- Use notification matching only as a secondary signal.
- Never block progress solely because a toast animation was missed.

## 6. Role-based differences
### Problem
A scenario is valid for one role but not another.

### Mitigation
- Filter scenarios at the card level when access is fundamentally missing.
- Use step-level branching only for minor visual or action differences.
- Never guide a user to an action they cannot invoke.

## 7. Feature-flag differences
### Critical flags in this application
- two-factor required
- zero-value processing allowed
- model visibility toggles
- manual review thresholds
- dashboard permission switches

### Mitigation
- load a runtime feature context into the engine,
- branch only when the scenario explicitly models the feature difference,
- otherwise replace the step with a hint-only explanation.

## 8. Data drift between environments
### Problem
Training data differs from production-like data, so a scenario cannot find the exact intended record.

### Mitigation
- prefer semantic selectors over row indexes,
- use filtered lists and first-visible-row fallback where acceptable,
- provide seeded training fixtures when repeatability matters,
- document scenario prerequisites clearly.

## 9. Concurrent edits and stale state
### Problem
Another user or process changed data while the learner is mid-scenario.

### Mitigation
- surface reload or refresh actions clearly,
- allow the engine to pause and recover,
- use optimistic but bounded retries,
- explain concurrency-sensitive actions in the scenario copy.

## 10. Navigation away from the expected route
### Problem
The learner clicks elsewhere or the app redirects unexpectedly.

### Mitigation
- detect route change immediately,
- compare against the expected page set,
- pause the scenario when the new route is incompatible,
- offer return-to-route or restart.

## 11. Page reload during Training Mode
### Problem
The browser refreshes or the Blazor circuit reconnects.

### Mitigation
- restore state from `ITrainingStateStore`,
- validate the last route and scenario ID,
- reopen the scenario hub with **Resume** prominently available.

## 12. File-upload steps
### Problem
Browser file picker interactions cannot be fully automated by the training engine.

### Mitigation
- use completion conditions based on file input value presence,
- keep fallback text simple and explicit,
- allow manual confirm when browser security blocks introspection.

## 13. Sensitive input steps
### Examples
- passwords
- authenticator codes

### Mitigation
- never capture raw values,
- validate only that a value exists or a route transition happened,
- allow manual confirm where appropriate.

## 14. Virtualized or paged lists
### Problem
The target row is not in the DOM until paged or scrolled into view.

### Mitigation
- target list container first,
- use filter/search guidance,
- avoid hard-coded row indexes,
- use first-visible-item patterns only for training data with repeatable seed sets.

## 15. Layout shifts and responsive changes
### Problem
The target rectangle changes while the tooltip is open.

### Mitigation
- re-measure on resize and major mutation,
- debounce repositioning,
- fall back to bottom sheet tooltip when side placement becomes unstable.

## 16. Overlay blocking the intended interaction
### Problem
An overly aggressive overlay prevents clicking the target.

### Mitigation
- use a pointer-events strategy that blocks the background but leaves the highlight cutout interactive,
- keep tooltip card draggable or repositionable only if necessary,
- test all primary actions with overlay active.

## 17. A11y edge cases
### Problem
Screen-reader or keyboard users get trapped or lose context.

### Mitigation
- announce each new step,
- keep focus on the tooltip when required,
- move focus to the highlighted element when action is expected,
- support Escape to exit and a visible exit button.

## 18. Training content drift after UI changes
### Problem
The product UI changes but scenario JSON still points to older targets.

### Mitigation
- make `data-tour-id` part of the component contract,
- validate scenario targets in CI,
- keep a scenario smoke-test suite for every major page,
- update the process and scenario mapping whenever a workflow changes.

## 19. Recovery priority order
When something goes wrong, recover in this order:
1. retry selector resolution
2. reveal hidden container
3. scroll target into view
4. navigate to expected route
5. skip the step with explanation
6. exit and keep resumable progress

## 20. Edge-case definition of done
Edge-case handling is complete when:
- missing targets fail gracefully,
- dialogs and notifications are handled reliably,
- role and feature differences do not break the flow,
- resume and recovery options are always available,
- scenario JSON includes meaningful fallback text for every step.
