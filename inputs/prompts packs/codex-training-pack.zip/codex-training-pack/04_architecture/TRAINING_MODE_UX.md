# Training Mode UX Proposal

## 1. UX goals
Training Mode must teach the application without breaking the normal operator workflow. The UX should feel like a guided overlay on top of the real app, not a disconnected demo.

Primary goals:
- Teach real production workflows in the real UI.
- Keep guidance concise, instructional, and action-oriented.
- Make errors, conflicts, and warnings explicit at the moment they matter.
- Support safe exit, resume, and restart at any time.
- Remain usable on large desktop layouts first, while degrading safely on smaller screens.

## 2. Entry points and activation
### Recommended primary entry point
Add a **Training Mode** toggle to the global application shell, ideally in the top app bar near the help or account area.

Why this placement:
- It is globally discoverable.
- It does not depend on the learner already knowing a module.
- It is visible after login and on every protected page.

### Secondary entry points
Also expose:
- a **Start training** action in the dashboard quick actions area,
- a **Training Mode** item inside the Account page,
- optional contextual **Train me on this page** action in page headers.

### Activation behavior
When the user turns Training Mode on:
1. The app stays on the current page.
2. A scenario hub opens as a modal sheet or wide drawer.
3. Scenarios are pre-filtered to:
   - the current route,
   - the current user's roles,
   - visible feature flags where possible.
4. The learner can switch to **All scenarios** if they want broader exploration.

## 3. Scenario selection screen
The scenario selection UI should be card-based as requested.

Each scenario card must display:
- **Title**
- **Short description**
- **Learning goals**
- **Prerequisites**
- **Estimated duration**
- **Difficulty**
- **Roles**
- **Mermaid diagram action**

### Recommended card layout
Top area:
- title
- difficulty pill
- duration pill

Middle area:
- short description
- 3-4 learning goals as bullets
- prerequisites summary

Bottom area:
- role chips
- pages involved
- buttons:
  - **Start scenario**
  - **View diagram**
  - **Resume scenario** (only when saved progress exists)

### Scenario hub controls
The hub should include:
- search box
- filters for module, role, difficulty, current page, and status
- toggle between **Recommended for this page** and **All scenarios**
- sort by **Most relevant**, **Shortest first**, and **Most advanced**

## 4. Guided overlay design
### Core overlay layers
Training Mode should render three visual layers:
1. **Dim layer** - a semi-transparent fullscreen overlay.
2. **Highlight cutout** - a clearly visible focus ring around the active target.
3. **Tooltip card** - the instruction card anchored to the target or placed automatically.

### Tooltip card content
Each step card should show:
- step title
- short instructional body
- progress indicator
- optional hint, warning, or conflict label
- controls:
  - **Back**
  - **Next**
  - **Skip**
  - **Exit**

### Progress presentation
Use both:
- textual progress, for example **Step 4 of 9**
- a slim progress bar inside the card

### Navigation rules
- **Back** returns to the previous step whenever safe.
- **Next** is enabled after the completion condition is satisfied or the learner explicitly confirms.
- **Skip** is always available but should ask for confirmation on conflict-critical steps.
- **Exit** returns the UI to normal mode and stores resumable progress.

## 5. Copy tone and microcopy rules
All user-facing training copy should be:
- concise,
- instructional,
- calm,
- professional,
- focused on what and why.

Good pattern:
- First sentence: what the learner should do.
- Second sentence: why it matters in the workflow.

Avoid:
- long paragraphs,
- implementation jargon,
- blame language,
- ambiguous wording like "maybe" or "probably".

## 6. Conflict and warning presentation
Training Mode must distinguish guidance types visually and semantically.

### Hint step
Use a light informational style for:
- optional tips,
- efficiency notes,
- navigation reminders.

### Warning step
Use a warning style for:
- suspicious values,
- zero-value policy,
- manual review requirements,
- hidden state restrictions.

### Conflict step
Use a stronger alert style for:
- editing sent invoices,
- production blocked by invoiced periods,
- revoke or correction actions,
- permission mismatches,
- restart-required configuration changes.

Conflict steps should:
- not be easy to dismiss accidentally,
- include one clear explanation,
- include explicit fallback instructions,
- optionally require manual confirmation before proceeding.

## 7. Returning to normal mode
The user must be able to leave Training Mode cleanly.

Required behaviors:
- Exit removes overlay, highlight, and tooltip immediately.
- Any page state already changed by the learner stays changed.
- Scenario progress is saved as **paused**.
- The next Training Mode entry offers:
  - **Resume**
  - **Restart**
  - **Dismiss**

## 8. Resume and restart UX
### Resume
Resume should continue from:
- the last completed step,
- the saved route,
- the saved scenario ID,
- the last known target state if still available.

If the exact target is no longer visible, the engine should:
- show the fallback instructions,
- offer **Restart from current page**,
- or restart from the nearest safe checkpoint.

### Restart
Restart should:
- clear current scenario progress,
- return to the scenario's start route,
- begin from step 1.

## 9. Responsive behavior
Training Mode is desktop-first because this application is dense and accounting-heavy.

Recommended responsive rules:
- On wide screens, place the tooltip beside the highlight target.
- On medium screens, allow the tooltip to float at the bottom if side placement would overlap important UI.
- On narrow screens, pin the tooltip to the bottom sheet and use scroll-to-target behavior.

Never allow:
- the tooltip to cover the highlighted target completely,
- action buttons to move offscreen,
- the page to become impossible to scroll.

## 10. Accessibility requirements
Training Mode must support:
- keyboard-only operation,
- visible focus state,
- Escape to exit,
- arrow navigation if desired,
- screen-reader announcement of step title and body,
- reduced-motion mode,
- contrast-safe highlight and tooltip colors.

Accessibility specifics:
- Tooltip card uses `role="dialog"` with proper labelling.
- Non-active page content becomes inert while a step requires focused interaction.
- Step changes announce themselves through an aria-live region.
- Keyboard trap exists only inside the active tooltip when required.

## 11. Recommended empty and edge states
### No matching scenarios
Show:
- **No scenarios match the current page and role.**
- Secondary action: **Show all scenarios**

### Missing target
Show:
- **Target not visible**
- fallback instruction from scenario data
- actions:
  - **Retry**
  - **Skip step**
  - **Exit training**

### Permission mismatch
Show:
- **This scenario requires permissions that are not available in the current session.**
- actions:
  - **Choose another scenario**
  - **View prerequisites**

## 12. UX definition of done
Training Mode UX is complete when:
- users can turn it on from the shell,
- scenario cards are searchable and filterable,
- each card shows the required metadata,
- the overlay, highlight, and tooltip behave consistently,
- warnings and conflicts are visually distinct,
- users can exit, resume, and restart safely,
- keyboard and screen-reader behavior are verified.
