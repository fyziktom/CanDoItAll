# Training Mode Data Model

## 1. Recommended format
Use **JSON** as the source format for scenario files.

### Why JSON is the right fit here
- Native deserialization in .NET.
- Strong schema validation.
- Easier deterministic diffs for machine-generated updates.
- Lower risk of indentation or whitespace mistakes than YAML.
- Better compatibility with future API-delivered scenarios or localization tooling.

## 2. Top-level scenario contract
Each scenario file should follow this shape:

- `scenarioId`
- `title`
- `shortDescription`
- `learningGoals`
- `prerequisites`
- `estimatedDuration`
- `difficulty`
- `roles`
- `pagesInvolved`
- `processIds`
- `mermaidDiagramReferences`
- `scenarioType`
- `category`
- `tags`
- `steps`

## 3. Step contract
Each step should contain at least:
- `stepId`
- `title`
- `body`
- `targetSelector` or `targetId`
- `placement`
- `trigger`
- `actionExpected`
- `completionCondition`
- `validations`
- `validationMessage`
- `commonMistakes`
- `conflictsOrEdgeCases`
- `fallback`
- `hintOnly`
- `conflictWarning`
- `branching`

## 4. Field semantics
### `targetSelector`
Preferred when the target already exists in the live UI through:
- `data-tour-id`
- `data-testid`
- another stable CSS selector

### `targetId`
Useful when a wrapper component or target registry resolves a semantic ID to a live element.

### `placement`
Supported values:
- `top`
- `right`
- `bottom`
- `left`
- `auto`

### `trigger`
Describes when the step becomes active.
Examples:
- immediate after previous step
- after route change
- after dialog open
- after a feature-dependent branch

### `actionExpected`
Supported values in this pack:
- `observe`
- `click`
- `type`
- `select`
- `navigate`
- `confirm`

### `completionCondition`
Human-readable plus machine-usable description of what the engine waits for.

Examples:
- route equals `/create`
- dialog root becomes visible
- input has a non-empty value
- preview grid is visible
- learner manually confirms a warning step

### `validations`
Optional machine-side checks that should run before allowing the learner to continue.

Typical examples:
- target exists
- route matches
- required field has value
- dialog did not close unexpectedly

### `branching`
Optional branch rules used when:
- a role does not expose a target,
- a feature flag changes the workflow,
- a conflict or warning requires an alternate next step.

## 5. Branching design
Branch rules should be explicit and minimal.

Recommended shape:
- `when` - a simple condition string or resolvable predicate key
- `nextStepId` - the step to jump to
- `reason` - human-readable explanation for maintainers

Example uses:
- zero-value processing enabled vs disabled
- sent invoice vs draft invoice
- current user can override production conflict vs cannot override

## 6. Hint-only steps
Set `hintOnly: true` when the step is educational but not required for progression.

Use this for:
- optional efficiency tips,
- environment-dependent banners,
- notes about downstream effects.

## 7. Conflict-warning steps
Set `conflictWarning: true` when the step explains a high-impact workflow branch such as:
- correction creation,
- invoice revoke,
- production override,
- restart-required configuration change.

The engine should render these in a stronger warning style.

## 8. Localization readiness
Even though all copy in this pack is English, the model should support localization later.

Recommended forward-compatible approach:
- keep stable scenario and step IDs,
- allow a future `uiKey` or translation key map,
- separate runtime UI shell copy from scenario content copy,
- preserve English source JSON as the default authoring language.

## 9. Example scenario fragment
```json
{
  "scenarioId": "SCN-INVOICE-PAYMENT",
  "title": "Mark an invoice as paid and verify payment metadata",
  "shortDescription": "Teach the payment workflow from the invoice inspector through confirmation and post-save verification.",
  "learningGoals": [
    "Open the mark-paid dialog from the inspector.",
    "Enter the paid date and note correctly.",
    "Confirm the paid state after save."
  ],
  "estimatedDuration": "3-5 min",
  "difficulty": "Intermediate",
  "roles": ["administrator", "manager", "accountant"],
  "pagesInvolved": ["/invoices"],
  "processIds": ["PROC-INVOICE-PAYMENT"],
  "mermaidDiagramReferences": [
    "01_mermaid/proc-invoice-payment_invoice-payment-state-management.mmd"
  ],
  "scenarioType": "guided",
  "category": "Invoices",
  "steps": [
    {
      "stepId": "pay-02",
      "title": "Open the Mark Paid dialog",
      "body": "Use the inspector action so the payment event stays linked to the visible invoice context and audit trail.",
      "targetSelector": "[data-testid='btn-inspector-mark-paid']",
      "placement": "top",
      "trigger": {
        "type": "immediate",
        "description": "Show this step as soon as the previous step is complete."
      },
      "actionExpected": "click",
      "completionCondition": {
        "type": "elementVisible",
        "description": "The mark paid dialog is visible.",
        "selector": "[data-testid='dlg-mark-invoice-paid']"
      },
      "validations": [],
      "validationMessage": "Open the Mark Paid dialog before continuing.",
      "commonMistakes": [
        "Trying to infer payment state from the document instead of using the workflow action."
      ],
      "conflictsOrEdgeCases": [
        "If the button is disabled, select another eligible invoice."
      ],
      "fallback": "Use the Mark Paid action in the inspector.",
      "hintOnly": false,
      "conflictWarning": false,
      "branching": []
    }
  ]
}
```

## 10. Schema file
The machine-readable schema is stored at:
- `02_scenarios/scenarios.schema.json`

## 11. Authoring rules for future scenarios
When adding new scenarios:
1. Reuse existing process IDs where possible.
2. Reuse or add stable `data-tour-id` selectors.
3. Keep titles imperative and clear.
4. Keep bodies short and instructional.
5. Always include fallback guidance.
6. Add a Mermaid reference.
7. Update process-scenario mapping.
8. Validate the JSON against the schema before merge.
