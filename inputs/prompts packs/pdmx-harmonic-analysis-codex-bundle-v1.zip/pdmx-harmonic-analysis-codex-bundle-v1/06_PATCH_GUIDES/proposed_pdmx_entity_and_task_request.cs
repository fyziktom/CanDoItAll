namespace Zyphonote.App.PdmxTool.Data;

public sealed class ScoreHarmonicAnalysis
{
    public int Id { get; set; }

    public int IndexedScoreId { get; set; }

    public IndexedScore IndexedScore { get; set; } = null!;

    public string AnalyzerName { get; set; } = string.Empty;

    public string AnalysisVersion { get; set; } = string.Empty;

    public DateTime CreatedUtc { get; set; }

    public DateTime UpdatedUtc { get; set; }

    public double Confidence { get; set; }

    public string? Summary { get; set; }

    public string? PrimaryKey { get; set; }

    public string? PrimaryMode { get; set; }

    public bool HasModulation { get; set; }

    public int TagCount { get; set; }

    public int SegmentCount { get; set; }

    public int WarningCount { get; set; }

    public string SearchTagsCsv { get; set; } = string.Empty;

    public string SearchModesCsv { get; set; } = string.Empty;

    public string SearchChordSetCsv { get; set; } = string.Empty;

    public string SearchProgressionsCsv { get; set; } = string.Empty;

    public string SearchDevicesCsv { get; set; } = string.Empty;

    public string SearchCadencesCsv { get; set; } = string.Empty;

    public string SearchStylesCsv { get; set; } = string.Empty;

    public string? HarmonicFingerprint { get; set; }

    public string TagsJson { get; set; } = "[]";

    public string SegmentsJson { get; set; } = "[]";

    public string WarningsJson { get; set; } = "[]";

    public string? RawAnalysisJson { get; set; }

    public string? LastStatus { get; set; }

    public string? LastError { get; set; }
}

public sealed record GenerateHarmonicAnalysisTaskRequest(
    IReadOnlyList<int> IndexedScoreIds,
    bool ForceRebuild);
