# Proposed Fixture Builder Example

The exact names are optional, but this is the intended test-only flow.

```csharp
var context = new ProgressionContext(
    Key: new KeyContext(0, ModeType.Major, EnharmonicPreference.Sharps),
    Difficulty: DifficultyPreset.Advanced,
    Length: 8,
    AllowSevenths: true,
    AllowSecondaryDominants: true,
    AllowBorrowedChords: false,
    AllowRomanticColor: false,
    Loopable: false,
    MoodPreset: ProgressionMoodPreset.JazzStandard,
    ForcedCatalogEntryId: null,
    VoiceLeadingMode: VoiceLeadingMode.Optimal,
    StylePack: StylePackPreset.BebopStandardJazz,
    MotifSeed: 1200,
    DeviceSeed: 2200);

var progression = generator.Generate(context, ClefType.Treble, EnharmonicPreference.Sharps);
var document = HarmonicFixtureBuilder.ToScoreDocument(progression, includeExplicitChordSymbols: true);
var musicXml = new MusicXmlSubsetService().Export(document);
```

Suggested helper responsibilities:
- map progression measure data to `ScoreMeasure.ChordSymbol`,
- add note events from generated voicing notes,
- preserve deterministic timing/duration,
- optionally write fixture files for reuse in integration tests.
