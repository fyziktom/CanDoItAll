using System.Text.Json.Serialization;

namespace MusicTheory.Core.Analysis;

public enum HarmonicTagCategory
{
    Unknown = 0,
    Key = 1,
    Mode = 2,
    Chord = 3,
    Progression = 4,
    Cadence = 5,
    Device = 6,
    Style = 7,
    Modulation = 8
}

public sealed record HarmonicTag(
    HarmonicTagCategory Category,
    string Value,
    string DisplayText,
    double? Confidence = null,
    string? Source = null);

public sealed record HarmonicSegment(
    int Index,
    int StartMeasure,
    int EndMeasure,
    string? LocalKey,
    string? LocalMode,
    string? ChordSymbol,
    string? RomanNumeral,
    string? HarmonicFunction,
    double? Confidence,
    string? Notes,
    string? AppliedDevice = null,
    string? SectionLabel = null);

public sealed record HarmonicSearchProjection(
    string? SearchKey,
    IReadOnlyList<string> SearchModes,
    IReadOnlyList<string> SearchTags,
    IReadOnlyList<string> SearchChordSet,
    IReadOnlyList<string> SearchProgressions,
    IReadOnlyList<string> SearchDevices,
    IReadOnlyList<string> SearchCadences,
    IReadOnlyList<string> SearchStyles,
    bool HasModulation,
    string? HarmonicFingerprint);

public sealed record HarmonicAnalysisResult(
    string AnalyzerName,
    string AnalysisVersion,
    DateTime CreatedAtUtc,
    double Confidence,
    string? Summary,
    string? PrimaryKey,
    string? PrimaryMode,
    bool HasModulation,
    IReadOnlyList<HarmonicTag> Tags,
    IReadOnlyList<HarmonicSegment> Segments,
    IReadOnlyList<string> NormalizedProgressions,
    IReadOnlyList<string> NormalizedChordSet,
    IReadOnlyList<string> Warnings,
    HarmonicSearchProjection SearchProjection,
    string? RawAnalysisJson = null);

public interface IHarmonicAnalysisService
{
    Task<HarmonicAnalysisResult> AnalyzeMusicXmlAsync(
        string musicXml,
        CancellationToken cancellationToken = default);
}
