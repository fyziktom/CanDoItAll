# Runtime Smoke Checks

These checks were **not executable in the audit environment** and must be performed locally.

## Local startup
1. run the workstation app,
2. queue index sample,
3. confirm harmonic analysis task is also queued for applicable scores,
4. wait for completion,
5. open a harmony-enabled score detail page.

## Manual UI checks
Verify:
- summary card values are sensible,
- tags are grouped and readable,
- segment rows match the notation,
- warnings appear for ambiguous material,
- rerun action updates timestamp/version,
- no visual regressions in notation preview width/layout.

## Manual data checks
Inspect SQLite data or app logs to confirm:
- persisted harmonic projection fields are filled,
- JSON detail payloads are valid,
- failure cases capture last error cleanly,
- re-run overwrites or versions data consistently.

## Local Playwright / MCP debugging
If visual issues or timing flakiness appear:
- inspect with Playwright MCP or headed Playwright runs,
- add `data-testid` hooks rather than relying on fragile text selectors,
- keep assertions focused on stable reviewer-visible outcomes.
