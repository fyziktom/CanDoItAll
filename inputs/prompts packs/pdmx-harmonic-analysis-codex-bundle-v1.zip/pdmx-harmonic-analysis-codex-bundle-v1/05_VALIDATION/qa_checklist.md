# QA Checklist

## Task pipeline
- [ ] indexing still works on the baseline sample dataset
- [ ] indexing auto-queues harmonic analysis for applicable scores
- [ ] task dashboard shows harmonic tasks
- [ ] pause/resume/retry/cancel still behave correctly
- [ ] one failed score does not break the whole batch

## Score detail page
- [ ] harmony section is visible and readable
- [ ] summary fields render correctly
- [ ] grouped tag chips render
- [ ] segment rows render
- [ ] warnings render for ambiguous/bad inputs
- [ ] run/re-run harmony action works
- [ ] notation preview still renders
- [ ] review save still works
- [ ] Ollama suggestion panel still works

## Data quality
- [ ] clear ii-V-I fixture gets the expected progression/cadence tags
- [ ] Neapolitan fixture gets the expected device tag
- [ ] Dorian fixture keeps modal identity
- [ ] modulation fixture sets `HasModulation`
- [ ] ambiguous fixture lowers confidence and emits warnings
- [ ] raw JSON/debug fields are optional helpers, not the only stored representation

## Future portability
- [ ] theory logic lives in `MusicTheory.Core`
- [ ] workstation persistence/UI logic lives in `App.PdmxTool`
- [ ] contracts are reusable by the main user-facing app later
