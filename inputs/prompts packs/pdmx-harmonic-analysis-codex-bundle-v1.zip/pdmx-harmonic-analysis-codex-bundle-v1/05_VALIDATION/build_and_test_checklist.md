# Build and Test Checklist

Run these locally after implementation.

## Build
```bash
dotnet build Zyphonote.slnx
```

## MusicTheory focused
```bash
dotnet test tests/MusicTheory.Tests/Zyphonote.MusicTheory.Tests.csproj
```

## App.PdmxTool integration
```bash
dotnet test tests/App.PdmxTool.Tests/Zyphonote.App.PdmxTool.Tests.csproj
```

## Playwright workstation UI
```bash
RUN_PLAYWRIGHT=1 dotnet test tests/App.PdmxTool.PlaywrightTests/Zyphonote.App.PdmxTool.PlaywrightTests.csproj
```

## Optional full suite
```bash
dotnet test Zyphonote.slnx
```

## Must-pass checks
- builds from clean restore,
- migration is included,
- MusicTheory tests pass,
- App.PdmxTool tests pass,
- Playwright harmony tests pass,
- existing workstation preview/review tests still pass.
