# Generated Fixture Builder Outline

This is a design note for a test-only helper, not a requirement to use these exact names.

## Suggested helper responsibilities

1. Accept a `ProgressionContext` or an already generated `ChordProgression`.
2. Build a small `ScoreDocument` with:
   - metadata,
   - time signature,
   - measures,
   - chord symbols,
   - deterministic note content.
3. Export to MusicXML using `MusicXmlSubsetService`.
4. Optionally persist the result under `tests/MusicTheory.Tests/Fixtures/Harmony`.
5. Return both:
   - the MusicXML string,
   - the expected high-level harmonic intent metadata for assertions.

## Recommended helper API shape

Example:
```csharp
var fixture = HarmonicFixtureBuilder.BuildFromProgression(
    context,
    seed: 2026,
    includeExplicitChordSymbols: true);
```

Return shape could include:
- `MusicXml`
- `Progression`
- `ExpectedPrimaryKey`
- `ExpectedMode`
- `ExpectedLikelyTags`
- `ExpectedLikelyCadence`
- `ExpectedHasModulation`

## Why this is useful

- reuses the repo's own theory engine to synthesize musically coherent test material,
- broadens coverage beyond hand-authored fixtures,
- helps detect analyzer regressions as theory modules evolve.

## Why it still should not replace manual exact fixtures

Generated material is ideal for coverage breadth, but exact theory semantics still deserve tiny explicit golden cases.
