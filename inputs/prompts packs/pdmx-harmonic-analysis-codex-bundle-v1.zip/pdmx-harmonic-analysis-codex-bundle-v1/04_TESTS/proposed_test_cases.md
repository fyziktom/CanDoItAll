# Proposed Test Cases

## `tests/MusicTheory.Tests`

### `HarmonicAnalysisServiceTests`
- `AnalyzeFromMusicXml_IiVIFixture_ProducesKeyModeAndProgressionTag`
- `AnalyzeFromMusicXml_NeapolitanFixture_ProducesDeviceTag`
- `AnalyzeFromMusicXml_DorianFixture_ProducesModeTag`
- `AnalyzeFromMusicXml_AmbiguousFixture_LowersConfidenceAndAddsWarnings`
- `AnalyzeFromMusicXml_ModulationFixture_SetsHasModulationAndLocalSegments`

### `HarmonicTagNormalizationTests`
- `NormalizeTag_UsesLowercaseDashSeparatedValue`
- `NormalizeProgression_IiVIMapsToIiVI`
- `Fingerprint_IsStableForEquivalentNormalizedProjection`

### `HarmonicSearchProjectionTests`
- `Projection_CollectsDistinctSearchFields`
- `Projection_OmitsUnsupportedSpeculativeTags`
- `Projection_SerializesDeterministically`

## `tests/App.PdmxTool.Tests`

### `HarmonicAnalysisWorkflowTests`
- `Pipeline_IndexesAndQueuesHarmonicAnalysis_ForScoresWithMxl`
- `HarmonicTask_PersistsSummaryTagsSegmentsAndProjection`
- `CatalogDetail_ReturnsPersistedHarmonyData`
- `SingleScoreRerun_UpdatesAnalysisTimestamp`
- `MissingOrInvalidScore_StoresFailureWithoutBreakingBatch`

## `tests/App.PdmxTool.PlaywrightTests`

### `WorkstationHarmonyUiTests`
- `E2E_Workstation_HarmonyPanel_ShowsPersistedAnalysis`
- `E2E_Workstation_HarmonyPanel_CanTriggerRerun`
- `E2E_Workstation_HarmonyPanel_ShowsWarningsForAmbiguousItem`
- `E2E_Workstation_HarmonyPanel_DoesNotBreakNotationPreview`

## Additional regression tests worth adding

- indexing without MXL should not enqueue harmonic analysis,
- harmonic analysis should not require Ollama availability,
- failed harmonic analysis should not block later review save,
- manual review data should survive harmony reruns.
