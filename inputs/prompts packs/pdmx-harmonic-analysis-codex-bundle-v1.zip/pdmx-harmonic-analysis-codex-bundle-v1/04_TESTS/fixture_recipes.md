# Fixture Recipes

Use these recipes to create deterministic fixtures for both theory tests and workstation workflow tests.

## Recipe A — exact ii-V-I fixture

Purpose:
- verify `progression:ii-v-i`
- verify dominant-to-tonic cadence
- verify basic jazz-style harmonic tags

Preferred construction:
- explicit chord symbols in MusicXML or `ScoreDocument`
- measure plan:
  - m1: Dm7
  - m2: G7
  - m3: Cmaj7
  - m4: Cmaj7
- key target: C major

Expected tags:
- `key:c-major`
- `progression:ii-v-i`
- `cadence:authentic`

## Recipe B — exact Neapolitan minor fixture

Purpose:
- verify `device:neapolitan`
- verify minor-key context
- verify confidence and warnings stay sensible

Preferred construction:
- explicit compact fixture, not generator-only
- example in A minor:
  - m1: Bb major first inversion (`bII6`)
  - m2: E7
  - m3: Am

Expected tags:
- `key:a-minor` or equivalent primary minor label
- `device:neapolitan`
- `cadence:authentic`

## Recipe C — modal Dorian fixture

Purpose:
- verify mode detection does not collapse everything into major/minor

Suggested construction:
- short modal vamp around D Dorian:
  - Dm7
  - G
  - Dm7
  - G
- note content should emphasize B natural to separate from natural minor

Expected tags:
- `mode:dorian`
- no forced authentic cadence tag unless actually justified

## Recipe D — modulation fixture

Purpose:
- verify `HasModulation`
- verify local key changes in segments

Construction options:
- manual compact fixture, or
- generator-backed long-form fixture using an explicit modulation-capable context

Expected:
- `HasModulation == true`
- segment list shows local-key change
- warnings remain empty or low if the material is explicit

## Recipe E — ambiguous/noisy fixture

Purpose:
- verify warnings and confidence degradation

Construction:
- sparse or conflicting note content,
- few/no explicit chord symbols,
- measures that force carry-forward behavior.

Expected:
- warnings present,
- confidence lower than clean fixtures,
- no overconfident advanced device tags.

## Generator-backed recipe suggestions

Use `ChordProgressionGenerator` for broader coverage with explicit seeds.

Good candidate contexts:
- Jazz / ii-V-heavy:
  - `StylePackPreset.BebopStandardJazz`
  - `AllowSecondaryDominants = true`
  - `VoiceLeadingMode = Optimal`
- Romantic chromatic:
  - `StylePackPreset.RomanticClassicalColor`
  - `AllowRomanticColor = true`
- Long-form modulation:
  - `ModulationPlanType.CircleOfFifthsTravel`
  - explicit `MotifSeed` and `DeviceSeed`

## Important warning

Do not use generator-backed fixtures as the only proof for exact semantic tags like:
- Neapolitan
- exact cadence family
- exact modulation boundary

Those should also have manual compact fixtures.
