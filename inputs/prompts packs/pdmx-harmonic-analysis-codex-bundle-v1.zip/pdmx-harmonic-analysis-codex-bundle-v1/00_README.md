# PDMX Viewer Harmonic Analysis – Codex Implementation Bundle (v1)

This bundle is a repository-grounded handoff for implementing **harmonic analysis, harmonic tagging, and future search preparation** inside **PDMX Viewer** without breaking the current preprocessing workflow.

It was prepared from a **static audit of the current repository state** on **2026-03-14**.  
The audit covered:
- `src/App.PdmxTool`
- `src/MusicTheory.Core`
- `tests/App.PdmxTool.Tests`
- `tests/App.PdmxTool.PlaywrightTests`
- `tests/MusicTheory.Tests`
- relevant docs under `docs/`

## What is already true in the repo

- PDMX Viewer already has:
  - catalog indexing from `PDMX.csv`,
  - durable processing tasks,
  - grouping,
  - detail page with notation preview,
  - Ollama metadata enrichment,
  - integration and Playwright test infrastructure.
- `MusicTheory.Core` already has substantial reusable theory logic:
  - progression generation,
  - harmonic device engine,
  - style packs,
  - MusicXML import/export,
  - chord recognition,
  - scale inference,
  - etude analysis from MusicXML.
- There is **not yet** a real persisted harmonic-analysis layer in PDMX Viewer.
- There is **not yet** a task kind or storage model for per-item harmonic metadata.
- There is **not yet** a detail-page harmony inspection panel.

## Hard rules for Codex

1. Use **code as the source of truth** when docs and code disagree.
2. Keep **all source-code comments in English only**.
3. Follow the prompt files in `/03_CODEX_PROMPTS` **in numeric order**.
4. Prefer **small, compilable checkpoints**.
5. After each prompt, run the narrowest relevant tests first, then the broader suite.
6. Reuse `MusicTheory.Core` building blocks instead of duplicating theory logic inside `App.PdmxTool`.
7. Keep harmonic analysis **independent from Ollama**.
8. Keep current indexing fast and deterministic. If harmonic analysis is added to the automatic pipeline, prefer an **additional queued stage** rather than inflating CSV indexing with heavy parsing work.
9. Add runtime/UI verification with Playwright. This repo already has Playwright tests and the user also has Playwright MCP available locally.
10. Do not invent integrations that are not present in the repository.

## Recommended execution flow

1. Read `/01_CONTEXT/*`.
2. Read `/02_DESIGN/*`.
3. Read `/03_CODEX_PROMPTS/00_START_PROMPT.md`.
4. Execute prompts `01..09` in order.
5. Verify with `/05_VALIDATION/*`.
6. Update this checklist as you finish each prompt.

## Progress checklist

- [ ] 01 Repo audit alignment and implementation note
- [ ] 02 Shared harmonic domain contracts and analyzer service
- [ ] 03 PDMX persistence model and task plumbing
- [ ] 04 Automatic pipeline integration and rerun flow
- [ ] 05 Score detail UI and review ergonomics
- [ ] 06 Unit, integration, and generated-fixture tests
- [ ] 07 Playwright UI verification
- [ ] 08 Documentation correction and cleanup
- [ ] 09 Final validation and polish

## Important limitations of this audit

This bundle was prepared **without runtime build execution** in this environment because `dotnet` is not installed here.  
That means:
- repository structure and code paths were verified statically,
- test coverage and Playwright flows were reviewed from source,
- implementation guidance is grounded in real files,
- but build/test/runtime success still must be verified locally by Codex.

Treat `/05_VALIDATION/runtime-smoke-checks.md` as required follow-up, not optional.

## Most important architectural recommendation

Implement this as a **real enrichment stage** with persisted results and an inspection UI.  
Do **not** implement it as a one-off UI-only widget and do **not** bury the logic inside the existing Ollama metadata flow.
