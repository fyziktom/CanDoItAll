# 08 — Documentation correction and cleanup

Goal: bring the docs back in line with the code after the implementation is real.

Tasks:
1. Add a workstation harmonic-analysis doc, for example:
   - `docs/pdmx-workstation/06-harmonic-analysis.md`
2. Update `docs/testing-theory.md`:
   - correct the project path,
   - add the new harmonic-analysis tests,
   - document the hybrid fixture strategy.
3. Update or clean up theory docs where code and docs were misaligned:
   - `docs/progression-generator.md`
   - `docs/style-packs.md`
4. Keep the docs concise, code-grounded, and reproducible.

Acceptance:
- docs match the actual implementation,
- test commands are correct,
- the new harmonic workflow is documented.

Self-check:
- manually verify every doc command/path exists in the repo
