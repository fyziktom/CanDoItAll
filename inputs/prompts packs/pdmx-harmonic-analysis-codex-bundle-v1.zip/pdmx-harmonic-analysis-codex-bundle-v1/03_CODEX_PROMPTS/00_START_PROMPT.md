# START PROMPT (Codex)

You are Codex. Implement harmonic analysis, harmonic tagging, and future search preparation inside **PDMX Viewer** using this bundle.

Hard rules:
- Read `/00_README.md`, `/01_CONTEXT/*`, and `/02_DESIGN/*` before coding.
- Execute prompt files in `/03_CODEX_PROMPTS` in numeric order.
- Use repository code as the source of truth over docs when they disagree.
- Keep all source-code comments in English only.
- Prefer small, compilable checkpoints.
- After each prompt, run the narrowest relevant tests first.
- Do not couple harmonic analysis to Ollama.
- Reuse `MusicTheory.Core` theory/MusicXML infrastructure instead of reimplementing it in `App.PdmxTool`.
- Keep indexing lightweight; if adding automatic harmonic work, prefer queueing a follow-up task.
- Add or update Playwright coverage. The repo already has Playwright tests, and local Playwright MCP is available.

Start now:
1. Read `/01_CONTEXT/01_repository_audit.md`.
2. Read `/01_CONTEXT/02_gap_analysis.md`.
3. Read `/01_CONTEXT/04_file_target_map.md`.
4. Execute `/03_CODEX_PROMPTS/01_repo_audit_alignment.md`.
