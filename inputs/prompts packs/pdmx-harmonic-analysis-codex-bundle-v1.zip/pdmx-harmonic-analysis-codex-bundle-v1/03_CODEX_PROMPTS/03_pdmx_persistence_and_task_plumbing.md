# 03 — PDMX persistence model and task plumbing

Goal: persist harmonic analysis results in the workstation and wire them into the existing task system.

Tasks:
1. Extend workstation data models to store harmonic analysis projections.
2. Add the necessary EF Core configuration and migration(s).
3. Decide on the pragmatic v1 persistence shape:
   - searchable scalar fields,
   - JSON detail payloads for collections,
   - provenance/versioning fields.
4. Add a new task kind:
   - `GenerateHarmonicAnalysis` (or equivalent)
5. Add a new task request model:
   - list of indexed score IDs,
   - optional force rebuild flag.
6. Add enqueue helper(s) to `ProcessingTaskService`.
7. Add worker dispatch in `ProcessingTaskWorker`.
8. Add an application service to execute the task, store results, and report progress/cursor/status.
9. Extend `PdmxCatalogService.GetScoreDetailAsync(...)` and related view models so the detail page can load harmonic data.

Guidance:
- Keep the persistence model query-friendly for future filtering.
- Do not store only a raw JSON blob.
- Follow existing patterns used for `OllamaSuggestion` and processing tasks.

Acceptance:
- Migration exists.
- Harmonic results can be stored and reloaded for an indexed score.
- Task worker can dispatch the new task kind.
- Detail query can return harmonic data.

Self-check:
- `dotnet test tests/App.PdmxTool.Tests/Zyphonote.App.PdmxTool.Tests.csproj --filter "FullyQualifiedName~Workflow|FullyQualifiedName~Harmonic"`
