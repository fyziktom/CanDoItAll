# 04 — Automatic pipeline integration and rerun flow

Goal: make harmonic analysis part of the real workstation enrichment flow, not just a manual one-off.

Tasks:
1. Integrate harmonic analysis into the automatic pipeline in a way that preserves indexing ergonomics.
2. Preferred design:
   - indexing collects newly indexed/updated score IDs with available score files,
   - on successful completion it enqueues a harmonic-analysis task.
3. Handle re-run scenarios:
   - detail page should be able to trigger analysis for a single item,
   - task service should support forced rebuild when requested.
4. Ensure failures are non-fatal:
   - one bad score file should not crash the whole batch,
   - warnings/errors should be persisted and surfaced.
5. Keep harmonic analysis completely independent from Ollama generation.

Guidance:
- Keep the pipeline visible in the task dashboard.
- Avoid blocking the page on synchronous heavy analysis.
- Prefer explicit queued work over hidden side effects.

Acceptance:
- Harmonic analysis is automatically queued for newly indexed applicable scores.
- Single-item re-run flow exists.
- Progress/status/error handling follows existing task conventions.

Self-check:
- `dotnet test tests/App.PdmxTool.Tests/Zyphonote.App.PdmxTool.Tests.csproj --filter "FullyQualifiedName~HarmonicAnalysisWorkflow|FullyQualifiedName~IndexingWorkflow"`
