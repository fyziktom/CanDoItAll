# 07 — Playwright UI verification

Goal: verify the reviewer UI flow and prevent regressions in the workstation detail experience.

Tasks:
1. Add or extend Playwright tests to cover:
   - loading a harmony-ready dataset,
   - opening score detail,
   - seeing harmony panel content,
   - running or re-running harmony analysis,
   - rendering grouped tags,
   - rendering segment rows,
   - rendering warnings for an ambiguous score,
   - ensuring notation preview still renders.
2. Prefer a dedicated Playwright test file, for example:
   - `tests/App.PdmxTool.PlaywrightTests/WorkstationHarmonyUiTests.cs`
3. If needed, introduce a dedicated harmony sample dataset root for Playwright instead of overloading the current generic sample fixture.
4. Use stable selectors or `data-testid` attributes where current text-based selection would be brittle.

Guidance:
- Keep the existing Playwright tests green.
- If the repo already uses `RUN_PLAYWRIGHT`, preserve that convention.
- Use local Playwright MCP/manual browser inspection if available to debug visual issues before finalizing assertions.

Acceptance:
- New UI coverage exists and is reliable.
- Existing preview/review flows still pass.

Self-check:
- `RUN_PLAYWRIGHT=1 dotnet test tests/App.PdmxTool.PlaywrightTests/Zyphonote.App.PdmxTool.PlaywrightTests.csproj`
