# 02 — Shared harmonic domain contracts and analyzer service

Goal: create the reusable harmonic-analysis core in `MusicTheory.Core`.

Tasks:
1. Add shared contracts for:
   - `HarmonicAnalysisResult`
   - `HarmonicTag`
   - `HarmonicSegment`
   - `HarmonicSearchProjection`
   - any enums/helpers needed for normalized tag categories
2. Add an analyzer abstraction such as:
   - `IHarmonicAnalysisService`
3. Implement a practical v1 service such as:
   - `ScoreHarmonicAnalysisService`
4. Reuse existing core infrastructure where it helps:
   - `MusicXmlEtudeGenerator`
   - `MusicXmlSubsetService`
   - chord recognition
   - `TonalScaleLibrary`
   - diatonic harmony helpers
   - harmonic device vocabulary
5. Produce a first-pass result that includes at least:
   - key and mode when inferable,
   - confidence,
   - warnings,
   - per-measure or per-segment chord data,
   - normalized chord set,
   - normalized progression hints,
   - cadence tags when inferable,
   - device tags only when justified,
   - future-search projection fields.
6. Keep the service deterministic and LLM-free.

Guidance:
- Prefer honest heuristics over fake certainty.
- It is acceptable for v1 to tag only a subset of advanced devices.
- If analysis is ambiguous, lower confidence and add warnings.

Acceptance:
- New shared contracts exist in `MusicTheory.Core`.
- Analyzer returns structured results, not just prose.
- Narrow theory tests for the new core logic exist and pass.

Self-check:
- `dotnet test tests/MusicTheory.Tests/Zyphonote.MusicTheory.Tests.csproj --filter "FullyQualifiedName~HarmonicAnalysis|FullyQualifiedName~MusicXmlEtudeGenerator|FullyQualifiedName~ProgressionAndVoicing|FullyQualifiedName~HarmonicDeviceAndForm"`
