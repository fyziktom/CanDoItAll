# 01 — Repo audit alignment and implementation note

Goal: verify the bundle against the current repo and lock the implementation plan to real file paths before broad edits.

Tasks:
1. Inspect the current codebase and confirm or correct:
   - current PDMX task kinds,
   - score detail view composition,
   - existing model/persistence patterns,
   - reusable theory/MusicXML services,
   - current App.PdmxTool test and Playwright setup.
2. Produce a short implementation note in docs, for example:
   - `docs/pdmx-workstation/06-harmonic-analysis-implementation-note.md`
3. In that note, explicitly list:
   - files to create,
   - files to modify,
   - which bundle assumptions were confirmed,
   - which assumptions required adaptation.
4. Do not do broad refactors yet.

Acceptance:
- The implementation note exists and is grounded in the actual repo.
- Any deviations from the bundle are captured before coding proceeds.

Self-check:
- `dotnet build Zyphonote.slnx`
