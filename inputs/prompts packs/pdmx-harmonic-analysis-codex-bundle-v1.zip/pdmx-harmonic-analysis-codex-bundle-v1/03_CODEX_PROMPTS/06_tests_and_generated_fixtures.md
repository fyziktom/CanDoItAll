# 06 — Unit, integration, and generated-fixture tests

Goal: add real test coverage and synthesize strong harmony fixtures.

Tasks:
1. Add unit tests for:
   - tag generation,
   - progression normalization,
   - cadence/device detection heuristics,
   - search projection output,
   - confidence/warning behavior,
   - serialization if applicable.
2. Add workstation integration tests for:
   - harmonic task persistence,
   - auto-queue after indexing,
   - detail query returning harmonic data,
   - single-item re-run,
   - invalid MusicXML / missing file handling.
3. Add a **dedicated harmony sample dataset** instead of mutating the existing baseline sample set unless there is a compelling reason not to.
4. Add a deterministic fixture-generation helper using:
   - `ChordProgressionGenerator`,
   - style packs / device settings / seeds,
   - a helper that exports a small `ScoreDocument` to MusicXML.
5. Use a hybrid fixture approach:
   - manual exact fixtures for precise semantics,
   - generator-backed fixtures for breadth/regression.

Guidance:
- Do not make exact semantic tests depend on probabilistic or loosely constrained generation.
- Use explicit seeds everywhere generation is involved.
- Keep fixtures readable.

Acceptance:
- MusicTheory tests cover new analyzer logic.
- App.PdmxTool integration tests cover the new task flow.
- Generated fixture helper exists and is actually used.
- New tests are deterministic.

Self-check:
- `dotnet test tests/MusicTheory.Tests/Zyphonote.MusicTheory.Tests.csproj`
- `dotnet test tests/App.PdmxTool.Tests/Zyphonote.App.PdmxTool.Tests.csproj`
