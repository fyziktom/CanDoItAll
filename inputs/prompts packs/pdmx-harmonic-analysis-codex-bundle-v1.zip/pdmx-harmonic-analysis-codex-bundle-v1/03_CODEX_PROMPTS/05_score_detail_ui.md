# 05 — Score detail UI and review ergonomics

Goal: add a reviewer-facing harmony inspection surface to the score detail page.

Tasks:
1. Add a new Harmony / Harmonic Analysis section or component to `ScoreDetail.razor`.
2. Show:
   - key,
   - mode,
   - confidence,
   - modulation yes/no,
   - summary,
   - analyzer name/version,
   - timestamp.
3. Render harmonic tags as grouped chips/badges.
4. Render a segment table/list with:
   - measure range,
   - local key/mode,
   - chord symbol,
   - Roman numeral,
   - harmonic function,
   - confidence,
   - notes.
5. Render diagnostics:
   - warnings,
   - low-confidence markers,
   - last error if analysis failed.
6. Add actions:
   - run/re-run harmony analysis.
7. Keep room for future manual override without implementing the full editor yet.

Guidance:
- Reuse current app styling and component patterns.
- Do not redesign unrelated parts of the page.
- Ensure existing preview/review/Ollama sections still work.

Acceptance:
- Score detail page shows persisted harmonic data clearly.
- Reviewer can trigger analysis from the page.
- Existing page functionality remains intact.

Self-check:
- `dotnet test tests/App.PdmxTool.Tests/Zyphonote.App.PdmxTool.Tests.csproj`
- run local manual smoke check on `/scores/{id}`
