# Repository Audit

## Relevant projects

### 1) `src/App.PdmxTool`
Internal workstation / viewer for PDMX ingest, review, grouping, metadata curation, and controlled enrichment.

Verified relevant files:
- `src/App.PdmxTool/Program.cs`
- `src/App.PdmxTool/Data/WorkstationModels.cs`
- `src/App.PdmxTool/Data/PdmxWorkstationDbContext.cs`
- `src/App.PdmxTool/Services/PdmxIndexingService.cs`
- `src/App.PdmxTool/Services/PdmxCatalogService.cs`
- `src/App.PdmxTool/Services/PdmxGroupingService.cs`
- `src/App.PdmxTool/Services/ProcessingTaskService.cs`
- `src/App.PdmxTool/Services/ProcessingTaskWorker.cs`
- `src/App.PdmxTool/Services/ScorePreviewService.cs`
- `src/App.PdmxTool/Services/MxlReader.cs`
- `src/App.PdmxTool/Services/OllamaService.cs`
- `src/App.PdmxTool/Services/OllamaMetadataService.cs`
- `src/App.PdmxTool/Components/Pages/ScoreDetail.razor`

### 2) `src/MusicTheory.Core`
Reusable theory, generation, notation, and recognition logic.

Verified relevant files:
- `src/MusicTheory.Core/Generation/ChordProgressionGenerator.cs`
- `src/MusicTheory.Core/Generation/HarmonicStylePackLibrary.cs`
- `src/MusicTheory.Core/Generation/HarmonicDevices.cs`
- `src/MusicTheory.Core/Generation/Etudes/MusicXmlEtudeGenerator.cs`
- `src/MusicTheory.Core/Generation/Etudes/MusicXmlEtudeContracts.cs`
- `src/MusicTheory.Core/Theory/DiatonicHarmonyService.cs`
- `src/MusicTheory.Core/Theory/TonalScaleLibrary.cs`
- `src/MusicTheory.Core/Recognition/RealtimeChordDetectionService.cs`
- `src/MusicTheory.Core/NotationEditor/Formats/MusicXmlSubsetService.cs`
- `src/MusicTheory.Core/NotationEditor/Model/*`

### 3) Test projects
- `tests/App.PdmxTool.Tests`
- `tests/App.PdmxTool.PlaywrightTests`
- `tests/MusicTheory.Tests`

## What PDMX Viewer currently does

### Indexing
`PdmxIndexingService` reads `PDMX.csv`, normalizes source metadata, and persists `IndexedScore` rows.  
Important: indexing currently does **not** parse MusicXML content during catalog indexing.

### Grouping
`PdmxGroupingService` creates deterministic song groups from normalized work/title keys and optional manual override.

### Review/detail flow
`PdmxCatalogService.GetScoreDetailAsync(...)` loads:
- source metadata,
- review draft state,
- optional Ollama suggestion.

`ScoreDetail.razor` already provides:
- notation preview via `NotationEditor`,
- review metadata editing,
- Ollama suggestion panel,
- source field display.

### Preview loading
`ScorePreviewService` loads the MXL/MusicXML on demand for the selected score.  
That is a strong fit for harmony extraction logic, but it is currently only used for preview.

### Durable task system
`ProcessingTaskService` + `ProcessingTaskWorker` already provide queue/lease/progress/retry/pause/cancel behavior.

Current task kinds:
- `IndexSubsetSample`
- `GenerateSongGroups`
- `GenerateOllamaSuggestions`

There is **no harmonic-analysis task kind** yet.

## What `MusicTheory.Core` already provides that should be reused

### MusicXML analysis
`MusicXmlEtudeGenerator.AnalyzeFromMusicXml(...)` already does useful first-pass harmonic extraction:
- imports MusicXML,
- analyzes measure pitch classes,
- prefers explicit `<harmony>` symbols when present,
- falls back to chord recognition from notes,
- resolves scale candidates with `TonalScaleLibrary`,
- returns warnings.

This is the best current reuse anchor for a v1 harmonic-analysis service.

### Progression generator
`ChordProgressionGenerator` already exposes:
- deterministic seeded generation,
- style packs,
- harmonic devices,
- section/form modeling,
- `RomanDisplay`,
- `FunctionTag`,
- `AppliedDevice`,
- `KeyAtStep`,
- measure-level voicing output.

This is excellent for **test-fixture generation**, but not sufficient by itself as the PDMX analysis pipeline.

### Theory and device vocabulary
Existing code already models concepts you want to surface as tags:
- secondary dominants,
- tritone substitution,
- Neapolitan,
- augmented sixth,
- backdoor dominant,
- modal interchange,
- chromatic mediant,
- modulation bridges,
- cadence types,
- style packs.

## Existing test infrastructure worth reusing

### App integration tests
`tests/App.PdmxTool.Tests/IndexingWorkflowTests.cs` already creates temp SQLite DBs, runs indexing/grouping, loads preview, and validates end-to-end workstation behavior.

### Playwright tests
`tests/App.PdmxTool.PlaywrightTests/WorkstationUiTests.cs` already proves:
- app boot with temp DB and sample data,
- catalog navigation,
- score detail preview rendering,
- review-save flow,
- selection flow.

The fixture launches the app with:
- temp SQLite path,
- temp dataset root,
- `dotnet run --no-build`,
- `RUN_PLAYWRIGHT` gate.

### Theory tests
`tests/MusicTheory.Tests` already includes strong coverage for:
- progression generation,
- harmonic devices,
- cadence behavior,
- etude MusicXML analysis,
- deterministic seed-based generation,
- tonal theory.

## Sample data situation

Existing workstation sample dataset:
- `tests/TestData/PdmxSample/Data/PDMX.csv`
- 4 items
- useful for indexing/grouping/preview smoke tests

Recommendation for harmony work:
- keep the current sample dataset stable,
- create a **separate dedicated harmony sample dataset** for new workflow tests,
- avoid changing the old sample dataset in ways that could destabilize unrelated workstation tests.
