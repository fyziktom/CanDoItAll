# Documentation Audit

## Docs that are useful and broadly aligned

### PDMX workstation docs
Useful:
- `docs/pdmx-workstation/README.md`
- `docs/pdmx-workstation/03-architecture.md`
- `docs/pdmx-workstation/04-implementation-plan.md`
- `docs/pdmx-workstation/05-validation-checklist.md`

These correctly position the workstation as:
- deterministic preprocessing first,
- human review loop second,
- explicit background enrichment tasks,
- on-demand preview rather than eager heavy parsing.

That supports the recommended design for harmonic analysis as a **new queued enrichment stage**.

### Harmonic assistant docs
Useful mostly as examples of:
- how the repo documents deep subsystem audits,
- how Codex automation bundles are structured,
- how validation reports and prompt sequences are formatted.

Particularly useful references:
- `docs/harmonic-assistant/harmonic-assistant-source-map.md`
- `harmonic-assistant-codex-automation-bundle-v2_1/*`

## Docs that should be corrected while doing this work

### 1) `docs/testing-theory.md`
The current test command is incorrect.

Current text:
```bash
dotnet test tests/MusicTheory.Tests/MusicTheory.Tests.csproj
```

Real project path:
```bash
dotnet test tests/MusicTheory.Tests/Zyphonote.MusicTheory.Tests.csproj
```

This is a concrete documentation bug and should be fixed.

### 2) `docs/style-packs.md`
Problems found:
- section order is confusing,
- headings are duplicated (`Smooth Jazz Hotel`, `Romantic Classical Color` appear twice in different roles),
- runtime weight snapshots are not clearly separated from prose descriptions,
- at least some runtime weights present in code are omitted in the doc summary.

Code source of truth:
- `src/MusicTheory.Core/Generation/HarmonicStylePackLibrary.cs`

### 3) `docs/progression-generator.md`
The determinism wording is too absolute / too simplified.

Better wording:
- deterministic output depends on the full effective context,
- generator seed and any explicit `MotifSeed` / `DeviceSeed` matter,
- advanced pipeline behavior is not described well enough in the current doc.

## Documentation principle for this implementation

For this feature branch, update docs only after code is real.  
Do not let old prose dictate design when current code already shows a better reusable path.

## Docs to add or extend as part of the implementation

Recommended additions:
- `docs/pdmx-workstation/06-harmonic-analysis.md`
  - architecture
  - data model
  - task flow
  - reviewer UI
- extend `docs/testing-theory.md`
  - new harmonic-analysis tests
  - generator-backed fixture strategy
- optionally add a short note under `docs/progression-generator.md`
  - this generator is also used to synthesize deterministic harmony fixtures for workstation analysis tests
