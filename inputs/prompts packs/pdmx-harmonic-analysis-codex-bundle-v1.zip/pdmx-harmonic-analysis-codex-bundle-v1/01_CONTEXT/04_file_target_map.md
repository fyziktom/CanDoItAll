# File Target Map

This is the most likely file impact map for a clean v1 implementation.

## High-probability files to change in `src/App.PdmxTool`

### Data / EF / models
- `src/App.PdmxTool/Data/WorkstationModels.cs`
- `src/App.PdmxTool/Data/PdmxWorkstationDbContext.cs`
- `src/App.PdmxTool/Data/Migrations/*`
- `src/App.PdmxTool/Services/PdmxCatalogService.cs`

### Services
- `src/App.PdmxTool/Services/ProcessingTaskService.cs`
- `src/App.PdmxTool/Services/ProcessingTaskWorker.cs`
- `src/App.PdmxTool/Services/PdmxIndexingService.cs`
- `src/App.PdmxTool/Services/ScorePreviewService.cs` (possibly only for code reuse, not necessarily behavior change)
- `src/App.PdmxTool/Program.cs`

### New likely workstation files
- `src/App.PdmxTool/Services/HarmonicAnalysisProjectionService.cs`
- `src/App.PdmxTool/Services/HarmonicAnalysisTaskService.cs`
- `src/App.PdmxTool/Services/HarmonicAnalysisMapper.cs`
- `src/App.PdmxTool/Models/HarmonicAnalysisViewModels.cs` (or equivalent)

### UI
- `src/App.PdmxTool/Components/Pages/ScoreDetail.razor`
- possibly a new component such as:
  - `src/App.PdmxTool/Components/Score/HarmonicAnalysisPanel.razor`

## High-probability files to add/change in `src/MusicTheory.Core`

- add a new folder such as:
  - `src/MusicTheory.Core/Analysis/*`
- likely new files:
  - `HarmonicAnalysisResult.cs`
  - `HarmonicTag.cs`
  - `HarmonicSegment.cs`
  - `HarmonicSearchProjection.cs`
  - `IHarmonicAnalysisService.cs`
  - `ScoreHarmonicAnalysisService.cs`
  - normalization/tag helper files

Existing files likely to be reused, not heavily modified:
- `Generation/Etudes/MusicXmlEtudeGenerator.cs`
- `NotationEditor/Formats/MusicXmlSubsetService.cs`
- `Theory/DiatonicHarmonyService.cs`
- `Theory/TonalScaleLibrary.cs`
- `Generation/HarmonicDevices.cs`
- `Generation/HarmonicStylePackLibrary.cs`

## High-probability test files to add

### MusicTheory
- `tests/MusicTheory.Tests/HarmonicAnalysisServiceTests.cs`
- `tests/MusicTheory.Tests/HarmonicTagNormalizationTests.cs`
- `tests/MusicTheory.Tests/HarmonicSearchProjectionTests.cs`
- `tests/MusicTheory.Tests/Fixtures/Harmony/*` (or equivalent)

### App workstation
- `tests/App.PdmxTool.Tests/HarmonicAnalysisWorkflowTests.cs`
- `tests/App.PdmxTool.Tests/TestPaths.cs` (only if new sample root helper is needed)

### Playwright
- `tests/App.PdmxTool.PlaywrightTests/WorkstationHarmonyUiTests.cs`
- `tests/App.PdmxTool.PlaywrightTests/PdmxToolPlaywrightFixture.cs` (only if a dedicated harmony sample dataset root is introduced)

## New likely test data
- `tests/TestData/PdmxHarmonySample/Data/PDMX.csv`
- harmony-focused MXL/MusicXML files with explicit expected tags

## Recommended implementation split

1. shared core contracts and service,
2. workstation persistence and task integration,
3. detail UI,
4. tests and docs,
5. final cleanup.
