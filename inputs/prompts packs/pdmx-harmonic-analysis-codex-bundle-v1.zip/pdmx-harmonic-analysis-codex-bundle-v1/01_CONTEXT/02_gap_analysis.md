# Gap Analysis

## Missing in PDMX Viewer today

### 1) No persisted harmonic analysis model
There is no entity/table for:
- harmonic summary,
- harmonic tags,
- harmonic segments,
- confidence,
- warnings,
- search projection data,
- analysis provenance/versioning.

### 2) No harmonic-analysis service boundary in the app
There is no `IHarmonicAnalysisService`-style abstraction in PDMX Viewer or `MusicTheory.Core` for batch score analysis.

### 3) No automatic harmonic enrichment stage
The task worker only knows indexing, grouping, and Ollama suggestions.

### 4) No detail-page harmony review UI
`ScoreDetail.razor` has preview/review/Ollama/source sections only.

### 5) No future-search projection
There is nothing persisted that would let the main app later filter by:
- key,
- mode,
- chord family,
- progression,
- cadence,
- harmonic devices,
- modulation,
- style hints.

## Specific implementation pitfalls to avoid

### Pitfall A — doing heavy harmonic work inside CSV indexing
`PdmxIndexingService` currently keeps indexing lightweight.  
If harmonic analysis is shoved directly into CSV indexing, initial ingest latency will jump and current assumptions about deterministic indexing cost will degrade.

**Recommendation:** keep indexing as phase 1, then enqueue harmonic analysis as phase 2 for scores with MXL/MusicXML.

### Pitfall B — tying harmony analysis to Ollama
Ollama is currently used for text metadata enrichment only.  
Harmonic analysis must remain deterministic and runnable without LLM availability.

### Pitfall C — inventing a brand-new theory stack in `App.PdmxTool`
The core project already has real logic for:
- MusicXML import,
- chord recognition,
- scale inference,
- harmonic devices,
- progression semantics.

Duplicating that in the workstation app would increase drift and maintenance cost.

### Pitfall D — requiring perfect theory detection in v1
A practical v1 is enough:
- key/mode inference,
- per-measure chord analysis,
- Roman/function where reliable,
- normalized tags,
- cadence/progression heuristics,
- warnings for ambiguity.

### Pitfall E — using only a raw JSON blob
A raw JSON snapshot is useful for debugging, but not enough by itself.  
At minimum, persist:
- searchable scalar fields,
- normalized tag arrays / CSV projections,
- provenance,
- and then optionally the raw JSON.

### Pitfall F — relying only on generator-based fixtures for exact expected tags
Seeded generators are great for bulk/regression fixtures, but exact device expectations like `device:neapolitan` should still have **manual deterministic golden fixtures**.

Best practice:
- manual exact fixtures for unit-level semantic assertions,
- generator-built fixtures for breadth and regression.

## Current code features that reduce implementation risk

- durable task orchestration is already there,
- on-demand preview already gives access to parsed notation,
- MusicXML analysis helpers already exist,
- EF Core migrations are already in place,
- there is already a proven pattern for enrichment persistence (`OllamaSuggestion`),
- there is already Playwright coverage for the workstation detail flow.

## High-confidence implementation path

1. Add shared harmonic analysis contracts in `MusicTheory.Core`.
2. Build a v1 analyzer service that wraps/reuses `MusicXmlEtudeGenerator` and theory helpers.
3. Persist app-level harmonic analysis projection in `App.PdmxTool`.
4. Add a new processing task kind for harmonic analysis.
5. Auto-enqueue it after indexing for newly indexed scores with usable score files.
6. Add a harmony panel to `ScoreDetail.razor`.
7. Add deterministic theory tests + workstation workflow tests + Playwright coverage.
