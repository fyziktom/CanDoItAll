# Domain Model and Persistence Plan

## Shared core model (recommended)

Put these contracts in `MusicTheory.Core` so they can later be reused by the main user-facing app.

### `HarmonicAnalysisResult`
Suggested fields:
- `AnalyzerName`
- `AnalysisVersion`
- `CreatedAtUtc`
- `Confidence`
- `Summary`
- `PrimaryKey`
- `PrimaryMode`
- `HasModulation`
- `Tags`
- `Segments`
- `NormalizedProgressions`
- `NormalizedChordSet`
- `Warnings`
- `SearchProjection`
- optional `RawAnalysisJson`

### `HarmonicTag`
Suggested fields:
- `Category`
- `Value`
- `DisplayText`
- `Confidence`
- `Source`

### `HarmonicSegment`
Suggested fields:
- `Index`
- `StartMeasure`
- `EndMeasure`
- `LocalKey`
- `LocalMode`
- `ChordSymbol`
- `RomanNumeral`
- `HarmonicFunction`
- `Confidence`
- `Notes`
- `AppliedDevice`
- `SectionLabel`

### `HarmonicSearchProjection`
Suggested fields:
- `SearchKey`
- `SearchModes`
- `SearchTags`
- `SearchChordSet`
- `SearchProgressions`
- `SearchDevices`
- `SearchCadences`
- `SearchStyles`
- `HasModulation`
- `HarmonicFingerprint`

## Workstation persistence model (recommended pragmatic v1)

SQLite in this app does not need a fully normalized relational graph for every collection in v1.

Recommended compromise:
- one persisted parent entity with scalar searchable fields,
- JSON text snapshots for richer collections,
- keep the raw analysis JSON optional for debugging only.

### Suggested workstation entity
`ScoreHarmonicAnalysis`

Suggested fields:
- `Id`
- `IndexedScoreId` (unique, 1:1)
- `AnalyzerName`
- `AnalysisVersion`
- `CreatedUtc`
- `UpdatedUtc`
- `Confidence`
- `Summary`
- `PrimaryKey`
- `PrimaryMode`
- `HasModulation`
- `TagCount`
- `SegmentCount`
- `WarningCount`
- `SearchTagsCsv`
- `SearchModesCsv`
- `SearchChordSetCsv`
- `SearchProgressionsCsv`
- `SearchDevicesCsv`
- `SearchCadencesCsv`
- `SearchStylesCsv`
- `HarmonicFingerprint`
- `TagsJson`
- `SegmentsJson`
- `WarningsJson`
- `RawAnalysisJson`
- `LastError`
- `LastStatus`

This gives:
- structured scalars for list filters later,
- rich detail payload for the item page,
- easy migration path to a more normalized or indexed system later.

## Why not only child tables in v1

Child tables are possible, but they add migration complexity and are not required yet for the workstation’s immediate purpose:
- preprocessing,
- inspection,
- reviewer validation,
- later export.

JSON snapshots are acceptable **as long as** the top-level searchable fields are broken out separately.

## App-level task request model

Suggested request:
- `GenerateHarmonicAnalysisTaskRequest`
  - `int[] IndexedScoreIds`
  - `bool ForceRebuild`

This mirrors the existing Ollama task request pattern and keeps orchestration explicit.

## Versioning guidance

Persist both:
- `AnalyzerName`
- `AnalysisVersion`

That will matter once heuristics improve and old results need to be re-run or compared.

## Suggested confidence strategy

Keep v1 confidence simple and honest:
- scale candidate strength,
- fraction of measures with direct chord symbols,
- fraction resolved by recognition,
- penalty for carry-forward reuse,
- penalty for unsupported/ambiguous measures.

Avoid fake precision.
