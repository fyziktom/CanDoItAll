# Search Preparation Notes

The workstation does not need the final end-user search UI yet, but it should persist enough normalized information so the future main app can filter/search by harmony without re-analyzing every score from scratch.

## Recommended v1 normalized fields

- `SearchKey`
- `SearchModes`
- `SearchTags`
- `SearchChordSet`
- `SearchProgressions`
- `SearchDevices`
- `SearchCadences`
- `SearchStyles`
- `HasModulation`
- `HarmonicFingerprint`

## Fingerprint guidance

Keep v1 simple and inspectable.

Example fingerprint ingredients:
- primary key/mode,
- sorted normalized chord set,
- sorted device tags,
- sorted cadence tags,
- modulation flag.

Example shape:
```text
key:c-major|mode:major|chords:maj7,min7,7|devices:secondary-dominant|cadences:authentic|modulation:no
```

This is not a similarity embedding. It is just a compact deterministic descriptor.

## Tag normalization guidance

Prefer lowercase, dash-separated normalized values:
- `key:c-major`
- `mode:dorian`
- `progression:ii-v-i`
- `device:secondary-dominant`
- `cadence:authentic`
- `style:jazz-harmony`

Keep display text separate from normalized value.

## Do not over-promise detection
Only persist tags the analyzer can actually justify.  
When uncertain:
- lower confidence,
- add warning,
- omit the tag rather than inventing certainty.
