# Harmonic Analysis v1 Architecture

## Goal

Add harmonic intelligence to PDMX Viewer in a way that:
- fits the existing workstation enrichment model,
- persists inspectable results,
- supports review/validation in the detail UI,
- prepares future search/filtering,
- reuses `MusicTheory.Core`,
- stays portable to the future user-facing application.

## Recommended layering

### Layer A — `MusicTheory.Core`
Responsibility:
- pure analysis contracts,
- deterministic score/MusicXML harmonic analysis,
- normalization,
- tag generation,
- search projection generation,
- no dependence on workstation DB/UI.

### Layer B — `App.PdmxTool` application services
Responsibility:
- read indexed score paths,
- call core analyzer,
- project result into persisted workstation entity,
- queue and manage background tasks,
- expose detail page view models.

### Layer C — `App.PdmxTool` UI
Responsibility:
- display harmonic summary/tags/segments/diagnostics,
- let the reviewer re-run analysis,
- later host manual correction affordances.

## Why this split is the least risky

- It keeps theory logic portable to the main app later.
- It matches how the repo already separates core music logic from app orchestration.
- It avoids turning the workstation into the new “source of truth” for theory rules.
- It supports future reuse by any UI, API, or batch export pipeline.

## Recommended v1 flow

### Automatic flow
1. CSV indexing persists `IndexedScore`.
2. Indexing identifies new/updated scores with usable MXL/MusicXML.
3. Indexing enqueues a **harmonic analysis task** for those score IDs.
4. Harmonic task loads each file, runs analyzer, stores persisted result and projection fields.

### Detail-page flow
1. Reviewer opens `/scores/{id}`.
2. Page loads current persisted harmonic analysis if available.
3. Harmony panel shows:
   - summary,
   - tags,
   - segments,
   - warnings,
   - provenance.
4. Reviewer may re-run analysis for this item from the UI.

## Why auto-queue is better than inline analysis during indexing

- preserves lightweight deterministic indexing,
- keeps task visibility explicit in the dashboard,
- allows pause/retry/cancel,
- avoids making every indexing pass depend on MusicXML parsing cost,
- matches existing workstation architecture.

## Suggested analyzer strategy for v1

Use a **pragmatic hybrid**:
- base measure analysis from `MusicXmlEtudeGenerator`,
- score import via `MusicXmlSubsetService`,
- chord inference from explicit chord symbols when available,
- otherwise note-based recognition,
- key/mode inference via `TonalScaleLibrary`,
- normalized Roman/function heuristics where reliable,
- progression/cadence/device tags from deterministic heuristics,
- warnings for ambiguous or unsupported cases.

## Explicit non-goals for v1

- perfect Schenkerian or advanced formal analysis,
- user-facing harmonic search UI,
- full manual edit/correction editor,
- cross-score harmonic similarity ranking,
- LLM-generated harmonic explanations as part of the core pipeline.
