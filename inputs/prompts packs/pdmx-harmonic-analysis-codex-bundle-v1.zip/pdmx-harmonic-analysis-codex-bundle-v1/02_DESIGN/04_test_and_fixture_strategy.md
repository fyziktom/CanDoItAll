# Test and Fixture Strategy

## Core principle

Use a **three-tier test strategy**.

### Tier 1 — exact semantic fixtures
Goal:
- prove deterministic tagging and normalization for exact theory cases.

Use:
- hand-authored tiny MusicXML fixtures,
- or hand-built `ScoreDocument` fixtures exported through `MusicXmlSubsetService`.

Best for:
- Neapolitan,
- secondary dominant,
- cadence classification,
- explicit mode tags,
- exact progression normalization.

### Tier 2 — generator-backed synthetic fixtures
Goal:
- broader coverage and regression resilience.

Use:
- `ChordProgressionGenerator`,
- style packs,
- seeds,
- generated `ChordProgression` / measure plans,
- helper that turns generated measures into `ScoreDocument` / MusicXML.

Best for:
- bulk device coverage,
- long-form progression coverage,
- modulation scenarios,
- confidence/warning robustness,
- ensuring analyzer does not regress on internally generated musical material.

### Tier 3 — workstation workflow tests
Goal:
- prove PDMX Viewer task/persistence/UI integration.

Use:
- dedicated `tests/TestData/PdmxHarmonySample`,
- temp SQLite,
- background task execution,
- detail-page loading,
- Playwright navigation and assertions.

## Why a dedicated harmony sample dataset is recommended

Existing sample dataset is already used by unrelated workflow tests.  
Harmony work should not destabilize those baseline tests.

Recommended new dataset:
- `tests/TestData/PdmxHarmonySample/Data/PDMX.csv`
- a small set of harmony-focused examples

Example dataset contents:
1. simple ii-V-I jazz example
2. tonal minor + Neapolitan example
3. modal/Dorian example
4. modulation example
5. one intentionally ambiguous example for warning handling

## Proposed new tests

### `tests/MusicTheory.Tests`
- `HarmonicAnalysisServiceTests`
- `HarmonicTagNormalizationTests`
- `HarmonicSearchProjectionTests`

Example assertions:
- key/mode inference,
- normalized progression strings,
- device tags,
- cadence tags,
- confidence degradation when carry-forward is needed,
- warnings for unsupported chord symbols,
- serialization round-trip if applicable.

### `tests/App.PdmxTool.Tests`
- harmonic task writes persisted result,
- indexing enqueues harmonic stage for new scores,
- detail query returns harmonic view model,
- re-run updates timestamp/version,
- missing file or invalid XML stores error without crashing the worker.

### `tests/App.PdmxTool.PlaywrightTests`
- harmony panel appears on score detail,
- reviewer can run/re-run harmony analysis,
- grouped chips/tags render,
- segment rows render,
- warnings render for ambiguous item,
- existing preview/review flow still works.

## Recommended fixture generation helper

Add a test-only helper that can:
1. create or accept a `ChordProgression`,
2. map measures/chord symbols into a `ScoreDocument`,
3. add deterministic note content,
4. export MusicXML using `MusicXmlSubsetService`,
5. write fixture files for reuse.

Important:
- manual fixtures for exact semantics,
- generated fixtures for breadth.

## Determinism guidance

For generator-backed fixtures:
- always set explicit seeds,
- prefer `VoiceLeadingMode.Optimal` or another explicitly chosen mode,
- use fixed key/mode/style pack,
- do not depend on implicit defaults if the test’s musical meaning matters.
