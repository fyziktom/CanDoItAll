# Pipeline and UI Flow

## Automatic pipeline proposal

### During indexing
When `PdmxIndexingService` upserts or creates indexed scores:
- gather IDs that have accessible MXL/MusicXML,
- after indexing completes successfully, enqueue a harmonic analysis task for those IDs.

Do **not** parse every MXL inline inside the main CSV index loop unless there is a strong repo-specific reason discovered during implementation.

## Background worker proposal

Add a new task kind:
- `GenerateHarmonicAnalysis`

Add a new service:
- `HarmonicAnalysisTaskService`

Responsibilities:
- load each indexed score,
- read MusicXML through the same path-resolution logic already used by preview,
- call the shared analyzer,
- map result into persisted workstation projection,
- update progress / cursor / status,
- store warnings and last error details.

## UI proposal for `ScoreDetail.razor`

Add a new section or child component:
- `Harmony`
- or `Harmonic Analysis`

### Subsections

#### 1) Summary card
Show:
- detected key,
- detected mode,
- confidence,
- modulation yes/no,
- generated summary,
- timestamp,
- analyzer name/version.

#### 2) Tag groups
Render chips/badges grouped by category:
- key/mode,
- chords,
- progressions,
- cadences,
- devices,
- styles,
- modulation.

#### 3) Segment table/list
Show:
- measure range,
- local key/mode,
- chord symbol,
- Roman numeral,
- function,
- confidence,
- notes/warnings.

#### 4) Diagnostics block
Show:
- warnings,
- unsupported cases,
- last error,
- low-confidence note,
- source of analysis.

#### 5) Actions
Add at least:
- `Run harmony analysis`
- `Re-run harmony analysis`

Optional if architecture fits:
- `Copy search tags`
- `Copy fingerprint`

## Reviewer ergonomics

v1 can remain read-only, but the UI should make room for v2:
- a manual override placeholder,
- or a compact “future manual correction” box.

## Do not block page load unnecessarily

Recommended behavior:
- load persisted result with the rest of detail data,
- avoid heavy synchronous analysis every time the page opens,
- let auto-pipeline populate it,
- allow explicit rerun from the page.

## Future reuse

The detail-page component should depend on a view model shaped from the shared core contracts, not on raw DB JSON strings.
