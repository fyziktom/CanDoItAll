Phase 1 - Baseline audit and branching.

Tasks:
1. Audit the existing code paths in both firmware lines and confirm the current trigger ownership.
2. Confirm where battery telemetry is read and where IR analog ownership currently lives.
3. Confirm the current protocol DTO surface for config and stats.
4. Create a branch plan or commit plan that keeps:
   - common piezo foundation changes
   - IRDrums changes
   - InvisibleDrums changes
   - protocol/UI changes
   logically separated.

Mandatory outputs:
- a concise audit note referencing exact files and current responsibilities
- a dependency map of what must change before what
- confirmation that GPIO32 is reserved for piezo in the new design
- confirmation that current IR auto-probe or analog scanning behavior will not be left conflicting with GPIO32

Do not code the full feature yet. First establish the exact baseline and implementation plan.
Then return to `CHECKLIST.md` and mark what is only analyzed vs actually completed.
