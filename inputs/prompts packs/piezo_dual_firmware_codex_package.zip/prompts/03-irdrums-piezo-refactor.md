Phase 3 - IRDrums piezo refactor.

Goal:
Convert `firmware/IRDrums` to piezo-first triggering.

Tasks:
1. Add piezo configuration persistence and defaults.
2. Add piezo stats.
3. Replace the current IMU-first hit trigger path with piezo-first logic.
4. Freeze the active IR beacon at piezo scan start.
5. Use the frozen beacon mapping when the scan commits the hit.
6. Keep IMU only as optional debug/context.
7. Gate battery telemetry so it can be disabled after init if real tests require it.
8. Make the display and serial diagnostics reflect piezo-first behavior.

Important:
- do not perform a giant unrelated refactor of the sketch
- keep the Arduino IDE build straightforward
- preserve existing BLE MIDI and SysEx behavior unless explicitly changed by this package

Required deliverables:
- exact files changed
- summary of the new hit path
- summary of any old IMU fields retained only for debug
- return to `CHECKLIST.md`
