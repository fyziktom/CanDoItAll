Phase 4 - InvisibleDrums piezo refactor.

Goal:
Convert `firmware/InvisibleBleMidiDrums` to piezo-first triggering while preserving spatial targeting.

Tasks:
1. Extend config and persistence with piezo settings.
2. Replace or rewrite the existing `HitDetector` so piezo owns hit detection.
3. Keep IMU + IR logic for target/zone tracking only.
4. Freeze the current zone/target snapshot at piezo scan start.
5. Prevent `IrBeaconTracker` from probing or claiming GPIO32 when piezo is enabled.
6. Ensure ADC ownership is coherent and documented.
7. Keep the future path open for BNO055/BNO08x by avoiding hard coupling between piezo engine and a specific IMU implementation.

Required outcome:
- piezo is authoritative for "hit happened"
- spatial logic is authoritative for "which zone"
- one downstroke equals one hit

Required deliverables:
- exact files changed
- explanation of ADC ownership
- explanation of frozen target semantics
- return to `CHECKLIST.md`
