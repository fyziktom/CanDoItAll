Phase 7 - Playtest and regression.

Goal:
Prove the system is musically more usable and technically stable.

Tasks:
1. Run or describe bench validation for single-hit correctness.
2. Run or describe playtest validation for:
   - quarter notes
   - eighths
   - sixteenths
   - thirty-second bursts
   - mixed accents
   - soft ghost notes
3. Verify discovery, config, and stats still function.
4. Verify both Blazor pages still operate.
5. Verify no accidental regression in module naming, connection, and basic note playback.

If something remains unverified due to environment limits:
- state it explicitly,
- describe the manual test needed,
- do not hide uncertainty.

Required deliverables:
- pass/fail table
- remaining manual tests
- tuning recommendations after first field test
- return to `CHECKLIST.md`
