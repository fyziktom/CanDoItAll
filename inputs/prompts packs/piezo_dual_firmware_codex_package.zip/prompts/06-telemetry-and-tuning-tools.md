Phase 6 - Telemetry and tuning tools.

Goal:
Make tuning practical on real hardware.

Tasks:
1. Add low-rate serial diagnostics for piezo state.
2. Add or improve on-screen compact diagnostics.
3. Extend stats payloads for piezo signal health.
4. Add a tuning-friendly UI presentation for:
   - state
   - threshold
   - envelope
   - peak
   - last velocity
   - frozen target
5. Add at least one preset strategy or default profiles for piezo tuning.

Important:
- keep diagnostics understandable
- do not spam serial output by default
- keep the tiny M5 display readable

Required deliverables:
- telemetry field list
- preset list
- tuning workflow note
- return to `CHECKLIST.md`
