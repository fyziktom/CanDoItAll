Phase 5 - Protocol and Blazor updates.

Goal:
Expose the new piezo configuration and telemetry without breaking the existing workflow.

Tasks:
1. Extend the C# DTOs with optional piezo-related fields.
2. Update device-client config/stats handling as needed.
3. Update session service handling and module state projection.
4. Add piezo sections to:
   - `IrDrums.razor`
   - `InvisibleDrums.razor`
5. Surface whether battery telemetry is active or intentionally unavailable.
6. Surface hit source as piezo.
7. Preserve backward compatibility with older devices as much as possible.

Do not invent a second transport.
Stay with the existing SysEx and Blazor integration model.

Required deliverables:
- DTO diff summary
- UI surface summary
- backward-compatibility notes
- return to `CHECKLIST.md`
