Implement the piezo-first drum refinement package in this folder.

Read first:
1. `README_PACKAGE.md`
2. `CHECKLIST.md`
3. `docs/01-executive-summary.md`
4. `docs/02-repo-audit-and-current-state.md`
5. `docs/03-m5stickc-g32-and-power-management.md`
6. `docs/04-piezo-front-end-and-hardware.md`
7. `docs/05-common-piezo-hit-engine.md`
8. `docs/06-irdrums-piezo-integration.md`
9. `docs/07-invisible-drums-piezo-integration.md`
10. `docs/08-protocol-and-blazor-surface.md`
11. `docs/09-telemetry-tuning-and-debug.md`
12. `docs/10-validation-playtest-and-acceptance.md`
13. `docs/11-open-source-survey-and-licensing.md`
14. `docs/12-file-touch-plan-and-risks.md`

Then execute prompts strictly in order:
- `prompts/01-baseline-audit-and-branching.md`
- `prompts/02-common-piezo-foundation.md`
- `prompts/03-irdrums-piezo-refactor.md`
- `prompts/04-invisible-piezo-refactor.md`
- `prompts/05-protocol-and-blazor-updates.md`
- `prompts/06-telemetry-and-tuning-tools.md`
- `prompts/07-playtest-and-regression.md`
- `prompts/08-final-audit.md`

Non-negotiable rules:
- do not skip any phase
- do not keep IMU magnitude as the main trigger source
- do not keep selecting the target at the end of the hit
- freeze target at piezo scan start
- do not blindly disable PMU functionality before proving it is necessary
- if battery telemetry must be disabled, do it as a deliberate post-init fallback
- do not let IR auto-probe use GPIO32 when piezo is enabled
- comments in source code must remain in English only
- return to `CHECKLIST.md` after every phase and state exactly what is done and what remains

Your first response must contain:
- checklist-to-task mapping
- risk list
- exact file-touch plan
- implementation sequence
- the first files you will inspect and modify
