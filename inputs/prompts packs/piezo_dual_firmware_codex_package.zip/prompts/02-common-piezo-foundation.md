Phase 2 - Common piezo foundation.

Implement the shared conceptual foundation used by both firmware lines.

Tasks:
1. Introduce a `PiezoConfig` model in each firmware line.
2. Introduce a `PiezoStats` model in each firmware line.
3. Implement a piezo-first state machine:
   - Idle
   - Scan
   - Mask
   - WaitQuiet
4. Implement threshold-crossing candidate start.
5. Implement scan-window peak capture.
6. Implement velocity mapping from piezo peak.
7. Implement a clear separation between:
   - scan time
   - mask time
   - quiet re-arm
8. Add serial-friendly compact diagnostics.

Design constraints:
- use GPIO32
- assume ADC1
- keep the implementation debuggable
- do not overfit with opaque adaptive magic
- keep the first version deterministic and understandable

If you introduce helper files, keep them focused and documented.

At the end of the phase:
- summarize the common algorithm
- list the final config fields
- list the final stats fields
- return to `CHECKLIST.md`
