# 01 Executive Summary

## Decision

The next iteration must move **hit detection** to a **piezo sensor** on **GPIO32 / ADC1** and treat:
- **IR beacons** as target selectors,
- **IMU** as orientation/context,
- **piezo** as the only authoritative hit source.

This decision applies to both firmware families:
- `firmware/IRDrums`
- `firmware/InvisibleBleMidiDrums`

## Why this is the right pivot

The existing IMU-only or IMU-primary triggering is fundamentally weak for drumming because:
1. it confuses **downstroke** and **return/upstroke**,
2. it struggles with **mixed dynamics**,
3. it struggles with **fast note densities** and **accented subdivisions**,
4. its thresholds tend to drift between under-trigger and over-trigger behavior.

A piezo sensor is the standard answer in electronic drums because it detects the **mechanical impact event directly**. That lets the rest of the motion model focus on *where the player is aiming*, not on *whether a hit happened*.

## Core design rule

**Targeting and hit detection must be independent subsystems.**

- The targeting subsystem answers: **which drum / zone / beacon is currently selected?**
- The piezo subsystem answers: **did a real impact happen, and with what intensity?**

At the first moment the piezo crosses the candidate threshold:
- freeze the currently selected target,
- start a short scan window,
- capture the peak,
- convert it to velocity,
- emit exactly one MIDI hit,
- enter mask,
- then require quiet before re-arm.

## Shared architectural outcome

Both firmware lines should converge on the same abstract model:

- `PiezoConfig`
- `PiezoStats`
- `PiezoHitEngine`
- `PiezoSampler` or equivalent fixed-rate ADC path
- protocol fields for config and diagnostics
- UI sections for live tuning and telemetry

The two lines differ mainly in target selection:
- **IRDrums**: target comes from the active IR beacon map.
- **InvisibleDrums**: target comes from IMU orientation plus optional IR beacon assistance.

## Important practical note

Do **not** start by blindly disabling power-management access.  
The package documents a safer order:

1. initialize M5Unified normally,
2. bring up display / IMU / BLE / config storage,
3. enable piezo on GPIO32,
4. test whether PMU polling actually interferes,
5. only if needed, disable or gate PMU battery reads after boot.

This prevents unnecessary regressions and keeps the fallback narrow.

## Success criteria

The work is complete only when:
- one physical strike produces one trigger,
- fast mixed patterns are playable,
- ghost notes and accents both work,
- target transitions remain stable,
- both firmware variants expose piezo config and stats through the existing app surface.
