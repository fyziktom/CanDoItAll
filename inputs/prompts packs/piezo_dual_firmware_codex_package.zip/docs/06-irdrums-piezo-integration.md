# 06 IRDrums Piezo Integration

## Target behavior

IRDrums should become:

- **IR beacon** = instrument selector
- **piezo** = hit detector
- **IMU** = optional context only

## Existing pressure points in IRDrums

The current sketch still:
- derives trigger timing from approach/rebound motion logic,
- derives velocity from motion-related values,
- updates UI and stats around those concepts.

That must change.

## Integration steps

### 1. Add piezo configuration
Add a `PiezoConfig` block to the IRDrums config and config serialization.

Expected fields:
- `enabled`
- `pin`
- `sample_rate_hz`
- `scan_ms`
- `mask_ms`
- `quiet_ms`
- `threshold_floor`
- `threshold_offset`
- `noise_alpha`
- `noise_scale`
- `quiet_threshold`
- `vel_peak_min`
- `vel_peak_ref`
- `vel_gamma`
- `power_telemetry_enabled`

### 2. Add piezo stats
Expose:
- current state
- raw and envelope
- threshold
- last peak
- last velocity
- hit count
- reject counts

### 3. Trigger pipeline rewrite
Current flow is IMU-led. Replace it with:

1. IR scanner keeps producing the current live beacon candidate.
2. Piezo threshold crossing begins a hit candidate.
3. At that moment, freeze:
   - current beacon index
   - current beacon confidence
   - optional IMU snapshot for debug only
4. During scan window, capture piezo peak.
5. When scan ends:
   - if peak is valid, emit MIDI note for the frozen beacon mapping,
   - compute velocity from piezo peak,
   - enter mask.

### 4. Use IMU only as optional metadata
Do not delete IMU code if it helps debug, but stop using it as the primary trigger gate.

Acceptable uses:
- display diagnostics,
- future articulation experiments,
- profile labeling,
- optional extra rejection logic only if documented and disabled by default.

## Preferred implementation approach

Because IRDrums is monolithic, Codex should avoid a huge file explosion in the first pass.

Recommended:
- keep the sketch as the main Arduino entry point,
- add compact internal classes/sections:
  - `PiezoHitEngine`
  - `PiezoStats`
  - `PiezoConfig`
- if a helper `.h/.cpp` pair is introduced, keep the count low and document every move.

## Critical rule for beacon handling

The active beacon must be frozen at **piezo candidate start**.  
Do not wait until the end of the scan window to choose the beacon.  
Otherwise fast hand motion near beacon boundaries will mis-assign hits.

## IR-specific telemetry additions

Add fields such as:
- `piezo_state`
- `piezo_peak`
- `piezo_last_vel`
- `frozen_beacon_at_scan`
- `beacon_conf_at_scan`
- `beacon_switch_during_scan`

These are invaluable when tuning fast passages.

## UI requirements

`IrDrums.razor` should gain:
- piezo config controls,
- live piezo telemetry chips,
- a note explaining whether battery telemetry is active or intentionally disabled,
- a clear label that hit detection source is `piezo`.
