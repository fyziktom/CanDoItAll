# 02 Repo Audit and Current State

## Firmware repo overview

The current firmware repository contains two active lines:

### A. `firmware/IRDrums`
Characteristics:
- mostly monolithic `IRDrums.ino`
- own IR scanning path
- current hit engine is strongly tied to IMU-derived approach/rebound logic
- existing stats, protocol handlers, and display UI live inside the sketch

Observed pressure points:
- trigger logic still depends on accel/gyro thresholds
- velocity is still derived from motion metrics
- battery and PMU are queried directly from the sketch
- analog path currently belongs only to the IR receiver on `aoPin`, default `36`

### B. `firmware/InvisibleBleMidiDrums`
Characteristics:
- more modular C++ layout
- current hit detection is in `src/HitDetector.*`
- current IR processing is in `src/IrBeaconTracker.*`
- config and persistence are already structured
- protocol routing and BLE MIDI integration already exist

Observed pressure points:
- `HitDetector` is IMU-based
- `IrBeaconTracker` has an auto-probe candidate list that includes **GPIO32**
- battery level is surfaced in Hello/UI
- the current schema is still organized around IMU-first triggering

## App repo overview

The app repository already has a useful protocol and UI base:
- `src/InvisibleDrums.Protocol`
- `src/App.Blazor/Services/InvisibleDrumsSessionService.cs`
- `src/App.Blazor/Pages/IrDrums.razor`
- `src/App.Blazor/Pages/InvisibleDrums.razor`

Strengths:
- existing SysEx protocol and DTOs
- existing discovery and per-module session handling
- existing stats/config round-trips
- existing UI shells for both module families

Gaps for the piezo transition:
- no piezo config DTOs
- no piezo stats surface
- no capability flags for piezo-specific behavior
- UI still reflects IMU-first assumptions

## Most important code-level findings

### IRDrums
Current defaults and behavior show that:
- analog IR input is on `aoPin = 36`
- sample rate and frame sizes are tuned for beacon detection
- setup still enables `cfg.internal_imu = true` and `cfg.output_power = true`
- battery UI reads from `M5.Power.getBatteryLevel()`
- the trigger path is still driven by approach/rebound and projected motion scores

### InvisibleBleMidiDrums
Current files indicate that:
- `TriggerConfig` is still built around accel/gyro thresholds
- `IrBeaconConfig.aoPin` defaults to `36`
- `IrBeaconTracker` auto-probes `{36, 33, 32, 35, 34, 39}`
- `buildHelloPayload()` includes a battery field
- the page/service/protocol stack is ready for extension, not replacement

## Required conclusion

This is **not** a small parameter-tuning task.

It is a **piezo-first architectural refactor** with:
- shared concepts,
- separate per-firmware integrations,
- a modest but necessary protocol/UI extension.
