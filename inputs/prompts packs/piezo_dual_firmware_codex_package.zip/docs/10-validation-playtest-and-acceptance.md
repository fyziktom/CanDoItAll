# 10 Validation, Playtest, and Acceptance

## Minimum bench tests

### Static tests
- boot with piezo connected
- boot with piezo disconnected
- discovery still works
- config round-trip still works
- page loads still work for both module types

### Signal tests
- resting noise capture
- finger tap on piezo
- stick tap with soft, medium, hard intensity
- confirm exactly one hit per strike

## Musical tests

### Single-surface timing
- quarter notes at slow and medium tempo
- eighth notes
- sixteenth notes
- thirty-second note bursts

### Mixed-density tests
- quarters with inserted sixteenth pairs
- sixteenth stream with accented quarter notes
- alternating soft and strong hits
- buzz-like or rapid repeated taps within realistic physical limits

### Target transition tests
#### IRDrums
- move from one beacon to another and strike during transition
- verify frozen beacon at scan start, not at scan end

#### InvisibleDrums
- move between angular zones and strike near boundaries
- verify frozen zone at scan start

## Regression tests

- battery telemetry on and off
- BLE MIDI discovery and reconnect
- protocol Hello/GetCfg/SetCfg/Stats still work
- no compile regression in Arduino IDE target environment

## Acceptance criteria

The phase is accepted only if:
- double-trigger on upstroke is no longer the normal outcome,
- soft hits can be tuned without making hard hits unstable,
- fast repeated hits are possible without excessive missed notes,
- both UI pages expose the new piezo tuning surface,
- both firmware lines persist piezo config correctly.
