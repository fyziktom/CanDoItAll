# 09 Telemetry, Tuning, and Debug

## Why this matters

Piezo tuning fails when the firmware is opaque.  
Codex must make the hit engine observable.

## Required live telemetry

At minimum expose:
- state: `idle | scan | mask | wait_quiet`
- raw sample
- centered sample
- envelope
- noise estimate
- dynamic threshold
- scan age
- current scan peak
- last committed peak
- last committed velocity
- reject reason counters
- current frozen target identifier

## Optional but useful telemetry
- baseline / DC estimate
- quiet countdown remaining
- time since last hit
- whether PMU telemetry is active or disabled
- whether GPIO32 is reserved and locked

## Serial diagnostics

Add a low-rate serial summary mode that can be enabled without flooding:
- 10 Hz or less
- one compact line with piezo and target state
- no per-sample spam in normal mode

Example:
```text
[PZ] st=scan raw=188 env=91 thr=37 peak=124 last=0 vel=0 tgt=2 conf=0.81
```

## Display diagnostics

Because the M5StickC display is tiny, do not try to show everything.  
Show only:
- current target
- piezo state
- last velocity
- battery flag or `BAT --` if disabled
- one compact peak/threshold pair

## Tuning workflow

Use this exact order:

1. verify raw signal is present,
2. verify noise floor at rest,
3. verify threshold crossing on soft taps,
4. verify scan peak for medium hits,
5. verify no retrigger on rebound,
6. verify repeated hits at speed,
7. only then tune velocity curve.

## Preset strategy

Ship at least these presets:
- `piezo_default`
- `piezo_soft`
- `piezo_hard_mount`
- `piezo_fast_rolls`

Preset changes should only touch piezo-related values and maybe note-off defaults if needed.

## Metrics to compare across tests

- hit rate
- false double rate
- missed soft-hit rate
- maximum playable repetition rate
- perceived dynamic range
- target misassignment rate
