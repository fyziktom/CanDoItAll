# 11 Open-Source Survey and Licensing

## Purpose

The implementation should reuse proven ideas where licensing allows it.

## Useful references

### HelloDrum
- Arduino-oriented drum trigger library
- permissive MIT license
- relevant for:
  - trigger threshold handling
  - scan / mask style drum trigger logic
  - general electronic drum module behavior

Use selectively if specific code patterns fit the project style.

### EavesDrum
- strong design reference for piezo front-end and trigger concepts
- useful concepts:
  - biased ADC input
  - peak capture during scan time
  - mask time after scan
- license is GPL, so treat it as a design reference unless you intentionally adopt GPL obligations

### edrumulus
- useful terminology and trigger design concepts
- useful for:
  - scan time
  - mask time
  - retrigger behavior
- license is GPL-family, so use as conceptual reference, not copy source into a permissive codebase

## Project rule

Permitted:
- reading docs and behavior descriptions
- adopting terminology
- implementing original code that follows the same engineering principles
- selective reuse from MIT-compatible sources with attribution where appropriate

Not permitted unless the project intentionally changes licensing:
- copying GPL code into this codebase

## Design ideas worth adopting

- threshold crossing starts the scan
- peak is captured during a short scan window
- mask begins after the scan
- re-arm requires the signal to settle
- velocity is mapped from peak, not motion guesswork
