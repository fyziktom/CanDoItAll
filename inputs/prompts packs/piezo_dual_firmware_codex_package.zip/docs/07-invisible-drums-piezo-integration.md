# 07 Invisible Drums Piezo Integration

## Target behavior

InvisibleDrums should become:

- **IMU + optional IR beacons** = spatial targeting / zone selection
- **piezo** = hit detector

## Why this is especially important here

InvisibleDrums is where IMU-trigger logic causes the most ambiguity:
- approach and rebound are similar in magnitude,
- fast stick returns create false doubles,
- mixed dynamics are hard to classify reliably.

Piezo solves the "did I hit?" question.  
IMU and IR only need to solve "what was I aiming at?".

## Integration strategy

### 1. Keep the current spatial model, but decouple it
The current angular zone and IR orientation work should not be discarded.  
Instead:
- continue updating the current zone candidate continuously,
- when piezo starts a scan, freeze the current target snapshot,
- compute the final note from that frozen target.

### 2. Replace or heavily repurpose `HitDetector`
Current `HitDetector` is IMU-first.  
Either:
- replace it with `PiezoHitDetector`, or
- keep the file name but rewrite the semantics so hit detection is piezo-first.

The cleaner long-term path is:
- `TargetTracker` for orientation/zone tracking,
- `PiezoHitEngine` for impact detection,
- an orchestrator that joins them.

### 3. Fix analog resource ownership
Current `IrBeaconTracker` auto-probes GPIO32.  
That is incompatible with reserving GPIO32 for piezo and must be fixed.

Preferred behavior:
- if piezo is enabled, GPIO32 is removed from the auto-probe candidate list,
- IR analog input stays explicit on GPIO36 unless the user changes it knowingly,
- avoid two independent ADC worker loops fighting over ADC1.

## Preferred implementation shape

Introduce a shared or coordinated analog path:
- one worker task owns ADC1 reads for the module,
- piezo gets sampled at a steady cadence,
- IR AO sampling stays on its own cadence/frame logic,
- results are published to the rest of the app through snapshots.

If Codex chooses a temporary two-task solution, it must:
- document the risk,
- prove it works under BLE load,
- mark it as an interim implementation.

## Zone freezing rule

At piezo scan start, freeze:
- current selected zone
- current body-frame direction snapshot
- current yaw / orientation snapshot
- current IR-assisted target bias state if relevant

The note emitted at scan end must use this frozen snapshot.

## Future sensor upgrade compatibility

The design must stay compatible with a future BNO055 / BNO08x migration.  
That means:
- the piezo engine must not depend on a specific IMU class,
- the targeting interface should be abstract enough to swap the orientation source later.

## UI requirements

`InvisibleDrums.razor` should gain:
- piezo config section,
- hit source indicator,
- live piezo telemetry,
- visibility into frozen zone vs live zone during a scan.
