# 12 File Touch Plan and Risks

## Primary file-touch plan

### Firmware: IRDrums
Required files:
- `firmware/IRDrums/IRDrums.ino`

Preferred additions only if needed:
- `firmware/IRDrums/PiezoHitEngine.h`
- `firmware/IRDrums/PiezoHitEngine.cpp`

### Firmware: InvisibleBleMidiDrums
Required files:
- `firmware/InvisibleBleMidiDrums/InvisibleBleMidiDrums.ino`
- `firmware/InvisibleBleMidiDrums/src/AppConfig.h`
- `firmware/InvisibleBleMidiDrums/src/Persistence.cpp`
- `firmware/InvisibleBleMidiDrums/src/HitDetector.h`
- `firmware/InvisibleBleMidiDrums/src/HitDetector.cpp`
- `firmware/InvisibleBleMidiDrums/src/IrBeaconTracker.h`
- `firmware/InvisibleBleMidiDrums/src/IrBeaconTracker.cpp`

Likely new files:
- `firmware/InvisibleBleMidiDrums/src/PiezoHitEngine.h`
- `firmware/InvisibleBleMidiDrums/src/PiezoHitEngine.cpp`
- possibly `AnalogSampler.*` if Codex chooses a shared ADC worker abstraction

### App / protocol
Required files:
- `src/InvisibleDrums.Protocol/IdrmTypes.cs`
- `src/InvisibleDrums.Protocol/IdrmDeviceClient.cs`
- `src/App.Blazor/Services/InvisibleDrumsSessionService.cs`
- `src/App.Blazor/Pages/IrDrums.razor`
- `src/App.Blazor/Pages/InvisibleDrums.razor`

## Main risks

### 1. ADC ownership conflicts
If IR and piezo sampling are implemented as independent loops on ADC1, timing jitter or contention may appear.

Mitigation:
- prefer one owner task for ADC1 per firmware.

### 2. Over-large mask time
If mask is too long, fast repeated notes will feel dead.

Mitigation:
- treat scan, mask, and quiet separately
- validate fast rolls explicitly

### 3. Underestimated analog front-end issues
A poor piezo front-end can look like a firmware problem.

Mitigation:
- surface raw and envelope telemetry
- document preferred wiring

### 4. Protocol drift
Adding piezo fields carelessly can break UI or deserialization.

Mitigation:
- add optional fields only
- preserve existing message types where possible

### 5. Excessive refactor size in IRDrums
The sketch is large and monolithic.

Mitigation:
- do the trigger-path pivot first
- avoid unrelated cleanup in the same phase

## Phase order summary

1. baseline audit
2. common piezo foundation
3. IRDrums integration
4. InvisibleDrums integration
5. protocol/UI extension
6. telemetry and tuning tools
7. playtest/regression
8. final audit
