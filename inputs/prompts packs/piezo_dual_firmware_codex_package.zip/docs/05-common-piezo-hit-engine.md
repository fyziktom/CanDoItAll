# 05 Common Piezo Hit Engine

## Core principle

The piezo engine must be the same *conceptually* in both firmware lines even if the integration details differ.

## State machine

Implement the following states:

1. `Idle`
2. `Scan`
3. `Mask`
4. `WaitQuiet`

### Idle
Wait for threshold crossing:
- compute a filtered or rectified signal,
- compare against a dynamic threshold,
- when crossed, freeze the current target snapshot and enter `Scan`.

### Scan
For a short fixed window:
- collect samples,
- track the peak,
- optionally track peak time and sign,
- do **not** emit multiple hits,
- at the end of the window, convert the peak to velocity and emit one hit.

### Mask
After the scan:
- ignore new candidates for a short period,
- this suppresses ringing and immediate retriggers.

### WaitQuiet
After mask:
- require the envelope to fall below a quiet threshold for a minimum quiet time,
- only then re-arm.

This is what prevents the classic:
- downstroke hit,
- rebound ring,
- upstroke false trigger.

## Candidate start and target freeze

The most important integration rule:

**Freeze target at scan start, not at trigger send time.**

That means:
- IRDrums freezes the beacon winner at scan start.
- InvisibleDrums freezes the zone/orientation snapshot at scan start.

## Signal features

The first implementation only needs a small feature set:
- raw sample
- baseline
- centered sample
- rectified magnitude
- envelope
- dynamic threshold
- peak during scan
- quiet detector

Do not overcomplicate v1 with advanced spectral logic.

## Threshold model

Use a threshold model that is understandable and debuggable:
- `threshold = max(floor, noiseEstimate * noiseScale + offset)`

Where:
- `floor` prevents collapse to zero,
- `noiseEstimate` adapts slowly,
- `noiseScale` keeps it proportional to environment noise,
- `offset` prevents chatter around the floor.

Noise estimation should not adapt quickly during a scan or mask.

## Velocity model

Velocity should be computed from the scan peak, for example:

`norm = clamp((peak - peakMin) / (peakRef - peakMin), 0, 1)`

`velocity = velocityMin + pow(norm, gamma) * (velocityMax - velocityMin)`

Parameters:
- `peakMin`
- `peakRef`
- `gamma`
- `velocityMin`
- `velocityMax`

This is much easier to tune than motion-derived hybrid formulas.

## Suggested data structures

```cpp
struct PiezoConfig {
  bool enabled;
  int8_t pin;
  uint16_t sampleRateHz;
  uint16_t scanTimeMsX10;
  uint16_t maskTimeMsX10;
  uint16_t quietTimeMsX10;
  uint16_t thresholdFloor;
  float noiseAlpha;
  float noiseScale;
  uint16_t thresholdOffset;
  uint16_t quietThreshold;
  uint16_t velocityPeakMin;
  uint16_t velocityPeakRef;
  float velocityGamma;
  bool powerTelemetryEnabled;
};

struct PiezoStats {
  uint16_t raw;
  int16_t centered;
  uint16_t rectified;
  float envelope;
  float noise;
  float threshold;
  uint16_t scanPeak;
  uint16_t lastPeak;
  uint8_t lastVelocity;
  uint32_t hits;
  uint32_t retriggerRejects;
  uint32_t quietRejects;
  uint32_t maskRejects;
  const char* state;
};
```

## Timing model

Do not let scan, mask, and quiet collapse into one giant refractory value.  
They solve different problems:

- **scan** captures the hit peak,
- **mask** suppresses immediate ringing,
- **quiet** guarantees re-arm only after the signal actually settles.

## Shared acceptance requirement

A single physical downstroke must lead to:
- one candidate,
- one peak capture,
- one MIDI event,
- one mask phase,
- one quiet re-arm,
- zero upstroke retrigger.
