# 03 M5StickC, GPIO32, and Power-Management Handling

## Verified board facts

For M5StickC-class hardware used here, the important practical points are:

- the board exposes **GPIO32** and **GPIO33** on the external side,
- the board PMU / IMU system bus uses the normal system I2C pins,
- GPIO32 is an **ADC-capable pin on ADC1**, which is the correct ADC block to prefer on ESP32 when radio features are active.

## What this means for the project

### 1. GPIO32 is the right piezo input candidate
Using GPIO32 for piezo is sensible because:
- it is ADC1,
- it is already exposed,
- it avoids ADC2 radio conflicts,
- it can coexist with BLE better than ADC2 options.

### 2. Do not blindly equate GPIO32 with PMU I2C
The current implementation assumption "we must disable PMU I2C because piezo uses G32" should **not** be treated as a proven hardware fact.

Use the safer rule:
- initialize the board normally,
- verify interference empirically,
- only then disable or throttle PMU reads if necessary.

### 3. The real immediate code risk is elsewhere
The current InvisibleDrums IR code auto-probes multiple analog pins and includes **GPIO32** as a candidate.  
That is a direct conflict with the intended piezo pin and must be fixed.

## Recommended runtime strategy

### Preferred
- initialize M5Unified normally,
- start BLE, display, IMU, persistence, protocol,
- initialize piezo on GPIO32,
- reduce PMU polling frequency or remove battery reads from tight loops,
- keep PMU support if no measurable issue appears.

### Fallback
If real-device tests show PMU access or board-specific power behavior causes instability:
- keep boot-time initialization intact,
- disable or gate battery polling **after initialization**,
- surface `"batt": null` or omit the field when PMU reads are intentionally disabled,
- expose a capability or flag indicating battery telemetry is unavailable.

## Mandatory code actions

### IRDrums
- gate or isolate `M5.Power.getBatteryLevel()`
- add a fallback mode such as `powerTelemetryEnabled`
- ensure piezo ADC init does not depend on PMU reads

### InvisibleBleMidiDrums
- gate `M5.Power.getBatteryLevel()` in:
  - Hello payload
  - UI state refresh
- exclude GPIO32 from IR auto-probe when piezo is enabled
- keep `aoPin=36` explicit unless user intentionally changes it

## Decision for Codex

Implement **evidence-driven PMU fallback**, not unconditional shutdown.
