# 08 Protocol and Blazor Surface

## Principle

Do not invent a parallel transport.  
Use the existing SysEx protocol and extend it with optional piezo-related fields.

## Backward-compatible extension strategy

### Hello response
Add optional fields such as:
- `caps`: array or compact flags
- `hit_src`: `"piezo"`
- `batt_avail`: `0|1`
- `piezo_pin`: `32` (optional diagnostic)

### Config payload
Add a `piezo` object for both firmware families.

### Stats payload
Add a `piezo` or flat piezo field set:
- `pz_state`
- `pz_raw`
- `pz_env`
- `pz_noise`
- `pz_thr`
- `pz_peak`
- `pz_last_peak`
- `pz_last_vel`
- `pz_mask_ms`
- `pz_quiet_ms`
- `pz_rej_mask`
- `pz_rej_quiet`

Do not remove existing fields yet.  
Mark old IMU-trigger-only fields as deprecated where appropriate.

## C# protocol updates

### Files to touch
- `src/InvisibleDrums.Protocol/IdrmTypes.cs`
- `src/InvisibleDrums.Protocol/IdrmDeviceClient.cs`
- codec/helpers only if needed

### DTO additions
Add optional properties rather than breaking existing constructors if possible.

Examples:
- `IReadOnlyList<string>? Caps`
- `string? HitSource`
- `int? BatteryAvailable`
- piezo fields in `IdrmStatsResponse`

## Blazor service updates

### Files to touch
- `src/App.Blazor/Services/InvisibleDrumsSessionService.cs`

Update:
- config upload/download parsing
- capability detection
- module display label composition if battery is not available
- telemetry polling surface for new piezo stats

## UI page updates

### `IrDrums.razor`
Add:
- piezo config card
- piezo telemetry chips
- battery telemetry availability indicator
- frozen beacon at scan label

### `InvisibleDrums.razor`
Add:
- piezo config card
- piezo telemetry chips
- frozen zone at scan label
- optional advanced section for future BNO055-compatible targeting diagnostics

## Suggested config JSON shape

```json
{
  "piezo": {
    "enabled": 1,
    "pin": 32,
    "fs_hz": 12000,
    "scan_ms": 2.5,
    "mask_ms": 4.0,
    "quiet_ms": 1.5,
    "thr_floor": 28,
    "thr_offset": 12,
    "noise_alpha": 0.02,
    "noise_scale": 5.5,
    "quiet_thr": 14,
    "vel_min_peak": 35,
    "vel_ref_peak": 720,
    "vel_gamma": 0.78,
    "batt_telemetry": 0
  }
}
```

Use JSON keys that are short but still understandable and consistent with the existing style.
