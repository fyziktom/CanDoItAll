# 04 Piezo Front-End and Hardware

## Goal

The firmware can only be as good as the analog signal it receives.  
Codex must treat the piezo front-end as part of the system design, not as an afterthought.

## Preferred front-end

### Recommended topology
Preferred approach:
- piezo disc
- series resistor
- clamp diodes to the input rails
- ADC input biased around mid-rail (about 1.65 V on a 3.3 V system)
- bleed path so the piezo does not float indefinitely

This preserves both positive and negative motion around a known baseline and makes peak detection easier and faster.

### Why mid-rail bias is preferred
A piezo impact often has an initial polarity that depends on mounting and strike direction.  
If the signal is only clamped to positive voltage without a mid-rail bias, the first useful energy can be lost or distorted.

That can:
- reduce sensitivity to soft hits,
- increase latency,
- make velocity curves less stable.

## Simpler fallback front-end

If the team needs a quick first prototype:
- piezo -> series resistor -> GPIO32
- Schottky clamp to 3.3 V
- Schottky clamp to GND
- bleed resistor across the piezo

This can work for basic triggering, but it is less ideal for:
- soft ghost notes,
- very fast repeated hits,
- consistent velocity modeling.

## Analog configuration guidance

Treat these as starting values, not absolute truths:
- piezo pin: `32`
- ADC block: `ADC1`
- attenuation: `11 dB` / `12 dB` equivalent path currently used in project style
- sampling target: start near `8 kHz` to `12 kHz`, then measure
- baseline/noise estimator: low-pass or running median/EMA
- scan window: start around `2.0 ms` to `3.5 ms`
- mask time: start around `3 ms` to `8 ms`
- quiet window: start around `1 ms` to `4 ms`

## Mechanical guidance

Document, but do not hardcode:
- piezo mounting stiffness
- foam / adhesive damping
- cable strain relief
- whether the sensor is in the stick body or near the grip

Mechanical changes can shift the:
- peak amplitude,
- ringing duration,
- noise floor,
- rebound signature.

That is exactly why the firmware must expose live telemetry and not rely on one magic threshold.

## Hardware notes to include in docs/comments

Codex should add a short hardware note to the repository explaining:
- expected piezo wiring,
- preferred front-end,
- the fact that GPIO32 is reserved for piezo in this build,
- that IR analog input should stay on GPIO36.
