# Piezo Dual Firmware Codex Package

This package is the source of truth for the next refinement wave of the M5StickC BLE drum modules.

Goal:
- move **hit detection** to a **piezo sensor on GPIO32 / ADC1**
- keep **IMU + IR** as **targeting/orientation/context**, not as the primary hit trigger
- implement the solution for **both firmware lines**:
  - `firmware/IRDrums`
  - `firmware/InvisibleBleMidiDrums`
- add the minimum protocol and Blazor support required to configure, observe, and debug the new piezo path

Read in this order:
1. `CHECKLIST.md`
2. `docs/01-executive-summary.md`
3. `docs/02-repo-audit-and-current-state.md`
4. `docs/03-m5stickc-g32-and-power-management.md`
5. `docs/04-piezo-front-end-and-hardware.md`
6. `docs/05-common-piezo-hit-engine.md`
7. `docs/06-irdrums-piezo-integration.md`
8. `docs/07-invisible-drums-piezo-integration.md`
9. `docs/08-protocol-and-blazor-surface.md`
10. `docs/09-telemetry-tuning-and-debug.md`
11. `docs/10-validation-playtest-and-acceptance.md`
12. `docs/11-open-source-survey-and-licensing.md`
13. `docs/12-file-touch-plan-and-risks.md`

Then execute prompts strictly in order:
- `prompts/00-master-start.md`
- `prompts/01-baseline-audit-and-branching.md`
- `prompts/02-common-piezo-foundation.md`
- `prompts/03-irdrums-piezo-refactor.md`
- `prompts/04-invisible-piezo-refactor.md`
- `prompts/05-protocol-and-blazor-updates.md`
- `prompts/06-telemetry-and-tuning-tools.md`
- `prompts/07-playtest-and-regression.md`
- `prompts/08-final-audit.md`

Non-negotiable:
- do not keep IMU magnitude as the primary hit trigger path
- do not allow double-trigger from the upstroke
- freeze the current target or zone at **piezo scan start**
- use GPIO32 as the piezo ADC pin unless a build- or board-specific issue is proven
- do not blindly disable PMU access unless tests prove it is needed
- if PMU access is disabled after boot, do it as a **controlled fallback mode**
- comments in source code must stay in English
- after every phase, return to `CHECKLIST.md` and report coverage
