# Implementation Checklist

## A. Shared architectural outcomes
- [ ] Define a shared piezo-trigger model used by both firmware lines.
- [ ] Freeze target/zone at piezo candidate start, not at old IMU trigger time.
- [ ] Separate hit detection from targeting/orientation.
- [ ] Eliminate upstroke retrigger.
- [ ] Add live telemetry for raw piezo, envelope, threshold, mask, quiet, last peak, last velocity.
- [ ] Add config surface for piezo parameters via existing SysEx config flow.
- [ ] Keep existing BLE MIDI transport and current protocol major/minor unless a documented break is unavoidable.
- [ ] Preserve backward compatibility for existing module discovery and basic note playback.

## B. Hardware and board handling
- [ ] Use GPIO32 / ADC1 for piezo input.
- [ ] Keep IR analog receiver on GPIO36 unless explicitly reconfigured.
- [ ] Prevent IR auto-probe from stealing or probing GPIO32 when piezo is enabled.
- [ ] Decide whether PMU reads remain enabled, are rate-limited, or are disabled after boot as a fallback.
- [ ] Document the recommended piezo analog front-end and clamping.

## C. Common piezo hit engine
- [ ] Add `PiezoConfig` structure and persistence.
- [ ] Add fixed-rate piezo sampling path.
- [ ] Implement state machine: `Idle -> Scan -> Mask -> WaitQuiet`.
- [ ] Start scan on threshold crossing.
- [ ] Record peak amplitude during scan window.
- [ ] Emit one hit per scan.
- [ ] Start mask after scan ends.
- [ ] Re-arm only after quiet condition is satisfied.
- [ ] Map velocity from peak/envelope using configurable curve.
- [ ] Support per-role or per-profile tuning presets.

## D. IRDrums specific
- [ ] Replace current IMU-first trigger path with piezo-first trigger path.
- [ ] Freeze active beacon at piezo scan start.
- [ ] Keep IR beacon classification for selecting the instrument.
- [ ] Keep IMU only as optional context for articulation/tuning, not trigger.
- [ ] Extend stats and UI for piezo metrics.

## E. InvisibleDrums specific
- [ ] Replace `HitDetector` logic with piezo-first trigger.
- [ ] Keep IMU + IR beacons only for zone/orientation tracking.
- [ ] Freeze zone and body/orientation snapshot at piezo scan start.
- [ ] Make the design compatible with a future BNO055/BNO08x upgrade.
- [ ] Extend stats and UI for piezo metrics.

## F. Protocol and app support
- [ ] Extend Hello/config/stats payloads with piezo capabilities and fields.
- [ ] Update C# protocol DTOs.
- [ ] Update Blazor session/service code.
- [ ] Add piezo config and telemetry sections to both pages:
  - [ ] `IrDrums.razor`
  - [ ] `InvisibleDrums.razor`

## G. Validation
- [ ] Validate quarter notes, eighths, sixteenths, thirty-seconds, mixed accents, and rolls.
- [ ] Validate soft taps, ghost notes, and strong accents.
- [ ] Validate that one downstroke yields exactly one trigger.
- [ ] Validate that fast repetitions are not blocked by excessive mask time.
- [ ] Validate browser-side discovery and naming remain usable.
