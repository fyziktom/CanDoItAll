# Codex Run Notes

## Before running
Make sure Codex has access to:
- the repository root
- `dev-canvas-gallery.php`
- the prompt pack files
- the reference screenshot in `assets/outlook-week-reference.png`

## Recommended run style
- Run one phase prompt at a time.
- Keep the same branch or worktree.
- Review Codex output between phases.
- If Codex proposes adding packages, reject that and restate the constraints.
- If Codex tries to shift calendar rendering to DOM, reject that and restate the canvas-first requirement.

## Recommended prefix before each prompt
You may optionally prepend this line before pasting any phase prompt:

"Work directly in the repository. Follow the prompt pack strictly. Do not introduce npm, TypeScript, or build tooling. Keep calendar surfaces canvas-first and reuse the existing canvas layer before adding calendar-specific code."

## Recommended review checkpoints
After each phase, confirm:
- reusable layer reuse is real
- canvas-first rendering remains intact
- no unwanted tooling was introduced
- code stays modular
