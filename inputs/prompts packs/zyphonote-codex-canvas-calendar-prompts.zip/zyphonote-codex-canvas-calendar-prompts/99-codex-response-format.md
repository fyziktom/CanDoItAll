# Required Codex Response Format

At the end of each phase, stop and respond with exactly these sections:

## 1. What I inspected
- list files, directories, and key repository areas inspected in this phase

## 2. What I changed
- concise bullet list of the implemented changes

## 3. Files added
- list paths

## 4. Files modified
- list paths

## 5. Key design decisions
- brief rationale for important choices

## 6. Validation performed
- commands run, manual checks, scenarios tested

## 7. Remaining gaps or risks
- honest list of incomplete or risky areas

## 8. Recommended next step
- explicitly say which next prompt file should be run

Do not continue automatically into the next phase unless explicitly instructed.
