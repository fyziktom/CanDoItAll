# Phase 4 Prompt – PHP Integration, Blazor Interop, Performance, Accessibility, and Final Validation

Read these files first if present in the prompt pack:
- `00-master-spec.md`
- `01-reference-ui-notes.md`
- `02-implementation-guidance.md`
- `90-acceptance-checklist.md`
- `99-codex-response-format.md`

Assume Phases 1–3 have already been completed in the same working tree.

## Mission
Finish the calendar so it is realistically adoptable in both target environments:
- `zyphonote-web` (PHP)
- `Zyphonote WASM app` (Blazor WebAssembly)

Also improve:
- performance
- accessibility
- documentation
- validation completeness

## Non-negotiable rules
- pure JavaScript only
- no TypeScript
- no npm
- no build step
- no external dependencies
- keep the calendar surfaces canvas-first
- keep the shared JS core framework-agnostic

## Required outputs in this phase

### 1) PHP integration example
Provide a practical example showing:
- direct script include
- container markup
- backend-provided event JSON
- initialization
- fetch-based CRUD endpoint wiring
- timezone / locale options if useful

### 2) Blazor WebAssembly integration
Provide a JS interop wrapper and usage example showing:
- init
- set/update events
- option updates
- destroy/dispose
- callbacks to .NET via `DotNetObjectReference`
- clean lifecycle handling

### 3) Performance pass
Audit and improve:
- redraw behavior
- geometry recomputation
- resize behavior
- hit testing efficiency
- high-DPI correctness
- dense-event rendering behavior

Do not over-engineer, but remove obvious bottlenecks or waste.

### 4) Accessibility pass
Improve:
- keyboard navigation where feasible
- focus states
- semantic toolbar controls
- accessible event editor modal
- screen-reader-friendly support for selected event / date context where practical

### 5) Documentation pass
Update or add documentation for:
- architecture
- reusable canvas pieces used
- public API
- event model
- timezone strategy
- overlap algorithm
- drag/drop behavior
- export behavior
- PHP integration
- Blazor integration
- known limitations

### 6) Final validation
Use `90-acceptance-checklist.md` and make a good-faith pass over every item.
Mark items as:
- complete
- partial
- deferred with reason

## Final quality goals
The outcome should feel like a serious canvas-first scheduling foundation, not an isolated demo.

## Important guardrails
- do not replace canvas calendar surfaces with DOM shortcuts
- do not introduce a package ecosystem
- do not ignore the existing reusable canvas layer
- keep the code understandable and maintainable

## Stop condition
When integration, polish, and validation are complete, stop and respond using `99-codex-response-format.md`.
