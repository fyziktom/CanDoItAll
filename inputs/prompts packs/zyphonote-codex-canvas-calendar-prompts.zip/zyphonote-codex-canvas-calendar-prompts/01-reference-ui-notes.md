# UI Reference Notes from Outlook-Like Screenshot

These notes summarize the provided screenshot (`assets/outlook-week-reference.png`) and should guide visual familiarity. The goal is **not** to clone Outlook pixel-for-pixel, but to preserve the mental model and the productivity-oriented layout that users expect.

## Main layout visible in the reference
- Top toolbar with navigation and view switching.
- Left sidebar with:
  - a compact month calendar
  - a second compact month calendar below it
  - calendar list / checkbox area under that
- Main center area is a **week view**
- Days run Monday to Sunday
- Time axis appears on the far left of the main grid
- Week range label is visible near the top
- The selected/current day column has a subtle highlight
- Event blocks appear as compact colored rectangles with short text
- The overall feel is dense, structured, and productivity-first

## Sidebar behavior to preserve
When in week view:
- keep mini month previews visible all the time
- show at least two months
- clearly highlight the visible week across the mini months
- allow the selected day to be visible
- keep the sidebar compact and useful, not decorative

## Week view characteristics to preserve
- vertical hourly schedule
- left-side time labels
- seven day columns
- clean grid lines
- compact event blocks
- event title visible directly inside the block
- short labels are important
- overlapping events need to remain readable
- empty space should still feel structured

## Event visual cues from the reference
- events are simple solid or lightly tinted blocks
- text is compact
- there is not too much ornamentation
- the event block itself carries the information
- a selected or focused event can use a stronger highlight color

## Toolbar expectations
A familiar toolbar should include:
- Today
- previous / next period
- current period label
- Day / Week / Month / Year / List switcher
- timezone selection
- Add event
- export

## Styling direction
Aim for:
- compact enterprise UI
- light background
- subtle separators
- high information density without clutter
- readable typography
- restrained color usage

## Do not over-copy Outlook
Avoid:
- hard-coded Outlook-specific styling tokens
- exact imitation of proprietary layout details
- assuming only Microsoft workflows

Instead preserve:
- the mental model
- the ergonomics
- the dense scheduling usability
