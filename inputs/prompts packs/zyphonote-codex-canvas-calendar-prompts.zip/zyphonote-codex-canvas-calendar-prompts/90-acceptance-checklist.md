# Acceptance Checklist

Use this checklist during and after implementation.

## A. Non-negotiable architecture
- [ ] Pure JavaScript only
- [ ] No TypeScript
- [ ] No npm
- [ ] No build step
- [ ] No external calendar library
- [ ] No external date library
- [ ] No external drag-and-drop library
- [ ] Calendar surfaces are primarily canvas-rendered
- [ ] Existing reusable canvas components were inspected and reused
- [ ] Missing generic capabilities were added to the reusable layer first
- [ ] All source code comments are in English

## B. Reusable canvas layer
- [ ] `dev-canvas-gallery.php` was inspected
- [ ] Reusable canvas primitives relevant to calendar were inventoried
- [ ] Gaps were fixed in reusable code, not only calendar-specific code
- [ ] Gallery/demo was updated to show the improved primitives
- [ ] Reusable hit-testing strategy exists
- [ ] Reusable text ellipsis/clipping helper exists
- [ ] High-DPI handling exists
- [ ] Resize handling exists

## C. Core calendar
- [ ] Clean init API exists
- [ ] Destroy/dispose API exists
- [ ] Event data model is documented
- [ ] Selected date anchor is managed cleanly
- [ ] Current view state is managed cleanly
- [ ] Timezone selection / rendering model is defined
- [ ] Locale support is considered

## D. Week view
- [ ] 7 day columns
- [ ] Left time axis
- [ ] Grid lines
- [ ] Current day emphasis
- [ ] Current time line
- [ ] Compact event blocks
- [ ] Short event title shown inside block
- [ ] Overlapping events rendered side-by-side
- [ ] Dense schedules remain readable
- [ ] Mini month sidebars always visible in week view
- [ ] At least 2 mini months visible
- [ ] Visible week is highlighted in mini months
- [ ] Clicking mini month dates updates main week anchor

## E. Day view
- [ ] Detailed hourly schedule
- [ ] Shares overlap logic or equivalent with week view
- [ ] Current time indicator
- [ ] Readable event rendering

## F. Month view
- [ ] Month grid exists
- [ ] Compact day-cell event rendering exists
- [ ] Dense day-cell handling exists
- [ ] “+N more” overflow indicator exists
- [ ] Drill-down interaction exists

## G. Year view
- [ ] 12 mini months visible
- [ ] Event markers or density hints exist
- [ ] Drill-down interaction exists

## H. List views
- [ ] Day list view
- [ ] Week list view
- [ ] Month list view
- [ ] Year list view
- [ ] Sorted by start time
- [ ] Export current visible list

## I. CRUD
- [ ] Create event
- [ ] Edit event
- [ ] Delete event
- [ ] Validation of start/end
- [ ] Read-only event handling

## J. Drag / resize
- [ ] Drag event in week/day
- [ ] Drag event in month
- [ ] Snap to configured interval
- [ ] Resize event duration in week/day or clearly documented if partial
- [ ] Visual feedback during drag
- [ ] Visual feedback during resize

## K. Timezone correctness
- [ ] Canonical UTC storage model or equivalent documented
- [ ] Display timezone can be changed
- [ ] Rendering updates correctly on timezone change
- [ ] DST edge cases were manually tested
- [ ] No ambiguous local-only assumptions remain undocumented

## L. Export
- [ ] CSV export works
- [ ] XLSX export works OR practical limitation is clearly documented
- [ ] Export is scoped to current visible/filter context
- [ ] Export includes key fields
- [ ] Export behavior is documented

## M. PHP integration
- [ ] Direct script include example exists
- [ ] Backend JSON injection example exists
- [ ] CRUD endpoint wiring example exists
- [ ] Minimal practical docs exist

## N. Blazor integration
- [ ] JS interop wrapper exists
- [ ] Init example exists
- [ ] Update/set events example exists
- [ ] Dispose example exists
- [ ] Callback to .NET example exists

## O. Accessibility / UX
- [ ] Semantic toolbar buttons
- [ ] Focus states
- [ ] Keyboard navigation where feasible
- [ ] Accessible event editor modal
- [ ] Useful accessibility affordances for canvas selection context

## P. Performance / rendering
- [ ] High-DPI correctness verified
- [ ] Container resize handled
- [ ] Hit testing works after resize
- [ ] Dense overlap rendering remains usable
- [ ] No obvious excessive redraw issues
- [ ] Large visible-event count remains acceptable

## Q. Documentation
- [ ] Architecture documented
- [ ] Reusable primitives documented
- [ ] Overlap algorithm documented
- [ ] Timezone strategy documented
- [ ] Export strategy documented
- [ ] Known limitations documented
- [ ] Setup/integration instructions documented
