# Master Spec – ZyphoNote Canvas Calendar

## Objective
Build a reusable, production-ready calendar system for:
1. `zyphonote-web` (PHP + Tailwind + plain JS)
2. `Zyphonote WASM app` (Blazor WebAssembly + JS interop)

The solution must feel familiar to people who know Outlook and enterprise calendar UIs.

## Primary rendering model
The calendar must be **primarily canvas-based**.

### Canvas-first requirement
The following should be canvas-rendered unless there is a very strong reason otherwise:
- week grid
- day grid
- month grid
- year mini-months
- event blocks
- overlap layout
- mini month sidebars
- current time line
- hover and selection states
- drag preview
- resize handles
- “+N more”
- date/week highlights
- event density markers

### DOM is acceptable only for
- toolbar
- buttons
- dropdowns
- event editor modal / side panel
- list view if this is clearly more maintainable
- accessibility mirrors if useful

The calendar must **not** be implemented as normal DOM blocks styled to look like a canvas system.

---

## Non-negotiable technical constraints
- Pure JavaScript only
- No TypeScript
- No npm
- No bundlers
- No build step
- No external calendar libraries
- No external drag-and-drop libraries
- No external date libraries
- Tailwind is available in host app, but the component must work from plain JS files
- All source code comments must be in English

---

## Reuse existing canvas infrastructure first
The repository already has reusable canvas components and a gallery entry point at `dev-canvas-gallery.php`.

### Required behavior
Before implementing the calendar:
1. inspect the existing canvas components, helpers, renderers, and utilities
2. identify which reusable primitives can be reused directly
3. identify what reusable primitives are missing for a calendar
4. improve the reusable layer first
5. update the gallery/demo so the improved reusable layer is visible and testable
6. only then build the calendar on top of that improved layer

### Examples of reusable primitives that may be needed
- high-DPI canvas surface wrapper
- viewport / scroll coordinator
- split panel / sidebar layout helper
- text ellipsis / clipping helper
- hit region registry
- pointer gesture manager
- drag controller
- selection model
- keyboard focus overlay
- virtualized row/slot renderer if useful
- themed color / spacing token helper
- tooltip anchor or inspection hook
- reusable mini-month renderer
- reusable time-grid renderer
- reusable event-chip renderer

If an item is generic enough, it belongs in the reusable canvas layer, not only in the calendar.

---

## Views required

### 1) Day view
- vertical hourly schedule
- compact and readable
- all-day zone if implemented
- overlapping events shown side-by-side
- easy drag, move, and resize
- current time indicator
- short event title visible

### 2) Week view
This is the priority view and must feel Outlook-like.

Required:
- 7 day columns
- left time axis
- compact grid
- overlapping events laid out cleanly
- short titles in event blocks
- current day emphasis
- current time line
- dense schedules remain usable

Also required:
- side mini-month previews, at least 2 visible at all times
- the currently visible week highlighted inside those mini months
- current selection highlighted
- clicking mini month dates updates main anchor date

### 3) Month view
- standard month grid
- compact bars or rows inside day cells
- handle dense event counts
- show “+N more” when needed
- clicking day drills down

### 4) Year view
- 12 mini months
- event presence / density markers
- quick navigation drill-down

### 5) List views
List view(s) for currently selected:
- day
- week
- month
- year

The list view may be DOM-based if that is the right trade-off.
It must support:
- sorting by start time
- exporting visible items
- quick navigation back to spatial views

---

## Event operations required

### Create
- click / drag create where appropriate
- “Add event” button
- event editor modal or side panel

### Edit
- update fields
- move
- resize duration
- change date/time

### Delete
- delete action with appropriate confirmation behavior

### Drag and drop
- move event in day/week by dragging
- move event in month by dragging to another date
- snap to configured minute interval
- immediate visual feedback
- emit update callbacks for persistence

### Resize
- resize duration in day/week views if feasible
- if implemented, use visible handle area and cursor feedback

---

## Event data model
Use a clean canonical event model. Example:

```js
{
  id: "evt_123",
  title: "Review of E-Billing Plan",
  description: "",
  startUtc: "2026-03-03T10:00:00Z",
  endUtc: "2026-03-03T11:00:00Z",
  allDay: false,
  timezone: "Europe/Prague",
  location: "Microsoft Teams",
  category: "meeting",
  color: "#8fbf6a",
  readOnly: false
}
```

Additional derived or optional fields are fine, but keep the core model clean.

---

## Timezone handling
Timezone support is required.

### Strategy
Prefer:
- canonical storage in UTC
- render in currently selected display timezone
- use explicit timezone IDs like `Europe/Prague`

### Requirements
- allow display timezone selection
- document conversion strategy clearly
- avoid ambiguous local-only storage
- handle DST transitions carefully
- avoid hidden local timezone assumptions

Without external date libraries, be careful and explicit about all conversion logic.

---

## Dense and overlapping events
This is one of the hardest and most important areas.

### Day/week overlap handling
Implement a layout algorithm that:
- groups overlapping events
- assigns columns
- calculates width and x-offset
- preserves readability where possible
- degrades gracefully in very dense cases

### Month density handling
- cap rows rendered inside a day cell
- show “+N more”
- allow drill-down or expansion

Document the chosen algorithm.

---

## Export requirements
The user wants export for visible events.

### Required
- CSV export of visible events
- XLSX export if feasible without violating the no-dependencies rule

### Acceptable pragmatic fallback if true XLSX is too heavy without dependencies
- CSV fully implemented
- Excel-compatible XML / SpreadsheetML export if suitable
- or a well-isolated export adapter prepared for a future repository-native XLSX implementation

Do not bring npm or heavy libraries just to satisfy export.

---

## Public API expectations

### Init options
Example:
```js
{
  initialView: "week",
  selectedDate: "2026-03-07",
  timezone: "Europe/Prague",
  locale: "cs-CZ",
  weekStartsOn: 1,
  slotMinutes: 30,
  businessHoursStart: 8,
  businessHoursEnd: 20,
  miniMonthCount: 2,
  allowCreate: true,
  allowEdit: true,
  allowDelete: true,
  allowDragDrop: true,
  allowResize: true,
  enableListExport: true
}
```

### Callbacks
Expose hooks such as:
- `onEventCreate`
- `onEventUpdate`
- `onEventDelete`
- `onDateChange`
- `onViewChange`
- `onTimezoneChange`
- `onSelectionChange`

---

## PHP integration requirements
For `zyphonote-web`:
- direct script include
- no build system
- practical sample PHP page
- show how backend injects initial event JSON
- show how create/update/delete calls go to PHP endpoints via `fetch`

---

## Blazor WebAssembly integration requirements
For `Zyphonote WASM app`:
- provide a wrapper component example
- use JS interop only
- keep the JS core shared
- support init / update / dispose
- support callbacks back into .NET

---

## Performance requirements
The solution should be practical for dense schedules.

### Must address
- `devicePixelRatio` / high-DPI rendering
- resize handling
- hit testing
- redraw lifecycle
- avoiding unnecessary full recomputation
- keeping pointer interactions smooth
- readable text clipping and ellipsis

---

## Accessibility requirements
Canvas-heavy UI still needs accessibility support.

### Include
- semantic DOM toolbar controls
- keyboard navigation where feasible
- visible focus indication
- accessible modal editor
- optional hidden summary / ARIA helper for selected event information

---

## Deliverables expected from Codex
- working implementation, not just a plan
- updated reusable canvas components
- updated gallery/demo if reusable layer changes
- calendar implementation
- docs
- PHP example
- Blazor wrapper example
- validation checklist

---

## Priority order
1. reusable canvas layer and gallery audit/improvement
2. week view with mini month sidebars
3. day/month/year foundations
4. event CRUD
5. drag and drop + resize
6. list views
7. export
8. PHP integration
9. Blazor integration
10. polish, docs, validation

---

## Quality bar
This should become a serious foundation for production use, not a toy demo.
When trade-offs are required, choose:
- user-familiar behavior
- maintainability
- low dependency footprint
- reusable architecture
- canvas-first rendering
