# Implementation Guidance for Codex

This document exists to reduce failure modes in a canvas-first, no-dependency implementation.

## 1) Reusable canvas layer first
Before writing calendar-specific code:
- inspect `dev-canvas-gallery.php`
- identify reusable components and patterns
- locate shared canvas helpers, theme helpers, pointer / keyboard logic, or demo widgets
- improve generic components there first if they are missing capabilities needed by the calendar

### Calendar-relevant reusable primitives likely needed
- HiDPI canvas surface wrapper
- invalidation / redraw scheduling
- canvas viewport with scroll offsets
- region registry for hit testing
- text measurement and ellipsis
- split layout helper
- grid renderer helper
- mini month renderer
- time-grid renderer
- drag gesture coordinator
- keyboard focus / selected state renderer

If a primitive is reusable, do not bury it in calendar-only code.

---

## 2) Canvas architecture recommendations
Recommended separation:
- `calendar-core.js` – public API, initialization, orchestration
- `calendar-state.js` – state and selection
- `calendar-renderer.js` – top-level drawing orchestration
- `calendar-layout.js` – event layout, view geometry, visible region calculations
- `calendar-hit-test.js` – hit region registration and lookup
- `calendar-interactions.js` – pointer handling, drag, resize, click, hover
- `calendar-date-utils.js` – date math, timezone rendering helpers, safe formatting
- `calendar-export.js` – CSV / Excel-friendly export
- `calendar-blazor-interop.js` – JS interop wrapper

This exact naming is optional, but keep the concerns separated.

---

## 3) High-DPI rendering
Do not forget:
- canvas CSS size vs backing store size
- multiply backing store dimensions by `devicePixelRatio`
- scale the drawing context appropriately
- update when container size changes
- ensure hit testing maps correctly between client pixels and logical canvas units

---

## 4) Redraw lifecycle
Prefer:
- explicit invalidation flags
- redraw on state changes, resize, scroll, hover changes, drag changes
- avoid recomputing everything on every small interaction if easy optimizations exist
- keep layout caches where sensible

Potential layers / caches:
- static grid background
- mini month surfaces
- event geometry cache for current view
- hit region map regenerated per redraw

Do not over-engineer prematurely, but do not ignore redraw costs.

---

## 5) Hit testing strategy
Canvas requires manual hit testing.

Recommended approach:
- while drawing interactive elements, register hit regions
- each region stores:
  - type
  - id
  - bounds
  - optional metadata
- on pointer events:
  - map pointer to logical canvas coordinates
  - walk regions in reverse paint order or use indexed lookup
  - resolve hovered / clicked / dragged target

Likely interactive region types:
- event body
- event resize start
- event resize end
- day header
- month cell
- mini month day cell
- week-row in mini month
- “+N more”
- empty slot area
- all-day region

---

## 6) Text clipping and readability
Dense schedules will fail if text is not handled well.

Implement a reusable helper for:
- measuring text
- clipping text to width
- ellipsis
- optionally multi-line compact labels when height allows

Suggested priority inside event blocks:
1. title
2. time range (if space allows)
3. location (if space allows)

Never let overflowing text destroy the layout.

---

## 7) Overlap algorithm guidance
For day/week timed events:
1. normalize visible event intervals to current rendered day range
2. group events by overlap clusters
3. assign each event a column index within a cluster
4. compute total column count for each cluster
5. calculate `x`, `width`, `y`, `height`
6. optionally allow some width expansion for the rightmost visible event if no later collision blocks it

At minimum, deliver a correct and readable column layout.
Document the algorithm.

---

## 8) Timezone guidance without external libraries
Without Luxon / date-fns / Moment:
- store canonical UTC timestamps
- use `Date` and `Intl.DateTimeFormat` carefully for display
- avoid ambiguous local parsing
- prefer ISO strings
- clearly separate:
  - storage timestamps
  - display timezone
  - user-local environment timezone

Be explicit in all conversions.
DST edges need manual testing.

---

## 9) Suggested UX priorities
The week view is the most important.
Get this right first:
- geometry
- grid
- overlap layout
- mini months
- hit testing
- smooth dragging
- readable blocks

Then expand:
- day
- month
- year
- list
- export
- integrations

---

## 10) Event creation UX options
Possible approaches:
- toolbar “Add event”
- double-click empty slot
- drag in empty time grid to create a draft selection
- click a day cell in month view and open editor prefilled

Choose one or more standard approaches, but keep behavior familiar.

---

## 11) Resize UX
If resize is implemented:
- show visible handles or cursor cues
- only allow on timed events where meaningful
- snap to slot interval
- visually preview the new end/start time while dragging

---

## 12) Export guidance
### CSV
Must be fully implemented.

### XLSX
True XLSX in pure JS without helper libraries is non-trivial.
Before inventing complex packaging code, inspect the repository for:
- existing zip/archive utilities
- existing export helpers
- existing server endpoints that may generate files
- any internal XML / spreadsheet helpers

If repository already has something reusable, use it.
If not, implement:
- CSV for sure
- optionally Excel-readable XML export
- document the trade-off very clearly

Do not break the no-dependency rule.

---

## 13) Blazor interop guidance
The JS core should remain framework-agnostic.

For Blazor:
- wrapper initializes calendar on an element
- passes initial config and events
- exposes methods like:
  - init
  - setEvents
  - updateOptions
  - destroy
- callbacks to .NET via `DotNetObjectReference`

Keep disposal correct.

---

## 14) PHP integration guidance
For PHP:
- render a container
- emit JSON into the page safely
- include the JS files directly
- initialize with backend URLs or callback functions
- keep the example realistic and small

---

## 15) Validation scenarios Codex should explicitly test
- 0 events
- 1 event
- 10 overlapping events in one hour
- events across multiple days
- all-day events
- week spanning two months
- visible week highlight in mini months
- switch timezone
- DST boundary week
- drag event from one day to another
- resize event duration
- month cell with more events than visible rows
- export filtered visible set
- container resize
- high-DPI screen behavior
