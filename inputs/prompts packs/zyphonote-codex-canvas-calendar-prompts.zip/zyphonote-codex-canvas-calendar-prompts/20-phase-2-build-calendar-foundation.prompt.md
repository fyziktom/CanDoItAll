# Phase 2 Prompt – Build the Canvas Calendar Foundation (Week View First)

Read these files first if present in the prompt pack:
- `00-master-spec.md`
- `01-reference-ui-notes.md`
- `02-implementation-guidance.md`
- `90-acceptance-checklist.md`
- `99-codex-response-format.md`

Assume Phase 1 has already been completed in the same working tree.

## Mission
Implement the canvas-first calendar foundation using the reusable canvas components audited and improved in Phase 1.

## Non-negotiable rules
- pure JavaScript only
- no TypeScript
- no npm
- no build step
- no external dependencies
- calendar surfaces must be primarily canvas-rendered
- use DOM only for toolbar / controls / modal editor shell if needed
- reuse Phase 1 reusable components wherever practical
- if a missing piece is generic, add it back to the reusable layer before consuming it

## Priority in this phase
The **week view** is the most important and must be implemented first, with Outlook-like mini month sidebars visible at all times.

## Required outputs in this phase
Implement the shared calendar foundation and at minimum:
1. initialization / lifecycle API
2. state model
3. date anchor handling
4. timezone-aware display model
5. canvas renderer shell
6. week view
7. day view
8. month view foundation
9. year view foundation
10. week sidebar mini months
11. event geometry calculation
12. overlap layout for timed events
13. hit testing for interactive elements
14. current time indicator
15. selection / hover states
16. navigation controls

## Public API shape
Create a practical API that can later be used by:
- plain PHP page includes
- Blazor via JS interop

For example, expose methods like:
- init
- destroy
- setEvents
- setView
- setDate
- setTimezone
- updateOptions
- refresh

Exact naming can differ, but keep it clean.

## Week view requirements
Must include:
- 7 day columns
- time axis
- compact grid
- readable event blocks
- overlap layout
- mini month sidebars with at least 2 months visible
- visible week highlighted in mini months
- selected day highlighted
- click on mini month date updates anchor date
- short event title rendered inside block
- current day emphasis
- current time line

## Day view requirements
- detailed hourly layout
- reuse timed event layout logic
- remain consistent with week view

## Month view foundation
- full month grid
- compact event rendering
- “+N more” overflow indicator
- drill-down hooks

## Year view foundation
- 12 mini months
- visible event density markers or indicators
- click-to-drill-down interaction

## Timezone strategy
Implement and document a clear display strategy.
Prefer:
- storage in UTC
- render in selected display timezone

Without external date libraries, be explicit and cautious.

## Structure expectations
Keep the code modular, for example with separate concerns for:
- core
- state
- renderer
- layout
- hit testing
- date utilities
- interactions
- export placeholder
- interop placeholder

## Important
This phase is allowed to create the event data model and view plumbing, but do not postpone the real overlap layout.
The overlap behavior must be meaningfully implemented now.

## Acceptable scope boundary
You do not need full CRUD, drag-and-drop, export, or Blazor integration in this phase if the foundation is not yet stable.
However, the architecture must clearly prepare for them.

## Demo / examples
Update or add a demo page with realistic sample events so the week view and mini months can be visually verified.

## Stop condition
When the calendar foundation and all main views exist with week view being strongest, stop and respond using `99-codex-response-format.md`.
Do not continue into full CRUD/export/integration work in this phase.
