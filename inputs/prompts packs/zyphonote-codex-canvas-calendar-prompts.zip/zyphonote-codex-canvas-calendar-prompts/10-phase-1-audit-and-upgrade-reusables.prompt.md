# Phase 1 Prompt – Audit and Upgrade the Reusable Canvas Layer First

Read these files first if present in the prompt pack:
- `00-master-spec.md`
- `01-reference-ui-notes.md`
- `02-implementation-guidance.md`
- `90-acceptance-checklist.md`
- `99-codex-response-format.md`

Then work inside the repository.

## Mission
Before building the calendar, inspect the existing reusable canvas infrastructure and improve it so the calendar can be built **on top of reusable primitives**, not as a one-off custom canvas island.

## Mandatory repository inspection
You must inspect at minimum:
- `dev-canvas-gallery.php`
- files referenced from it
- any canvas utility / renderer / widget / helper files
- any existing JS modules or PHP includes related to canvas components
- any style files related to those components

## Non-negotiable rules
- pure JavaScript only
- no TypeScript
- no npm
- no build step
- no external dependencies
- no external calendar libraries
- all source code comments in English
- do not start the real calendar implementation yet unless it is strictly needed to validate the reusable layer

## Goals for this phase
1. Inventory the existing reusable canvas components
2. Identify what is already usable for a canvas calendar
3. Identify missing generic capabilities needed by the calendar
4. Improve the reusable layer first
5. Update `dev-canvas-gallery.php` and any related demos so the improved reusable components are visible and testable
6. Create or update documentation explaining the reusable components relevant to the calendar

## What to look for
Check whether the existing reusable canvas layer already supports:
- high-DPI scaling
- resize handling
- redraw invalidation
- text measurement and ellipsis
- hit testing
- hover / focus / selected state visuals
- scroll / viewport logic
- split layouts / sidebars
- grid rendering
- pointer gestures / dragging
- mini-calendar rendering
- keyboard support

If it does not, add or improve reusable primitives.

## Strong preference
If you need something like:
- a mini month renderer
- a time grid renderer
- a hit-region registry
- a text clipping helper
- a drag controller

create it as a reusable building block first, not only inside calendar-specific code.

## Deliverables for this phase
Implement and commit repository changes that:
- strengthen the reusable canvas foundation
- expose the new or improved primitives in the gallery/demo
- document what is now available for the calendar to consume

## Expected output artifacts
At the end of this phase, there should be:
- improved reusable canvas modules
- gallery/demo updates
- concise docs or notes
- clear statement of which reusable pieces the calendar will use in Phase 2

## Important guardrail
Do not satisfy this phase by writing only a plan.
Actually modify the repository.

## When making decisions
Choose:
- reusability
- maintainability
- canvas-first architecture
- low dependency footprint

## Stop condition
When this phase is complete, stop and respond using the exact structure defined in `99-codex-response-format.md`.
Do not continue into full calendar implementation in this phase.
