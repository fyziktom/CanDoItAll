# Phase 3 Prompt – CRUD, Drag-and-Drop, Resize, List Views, and Export

Read these files first if present in the prompt pack:
- `00-master-spec.md`
- `01-reference-ui-notes.md`
- `02-implementation-guidance.md`
- `90-acceptance-checklist.md`
- `99-codex-response-format.md`

Assume Phases 1 and 2 have already been completed in the same working tree.

## Mission
Add the operational behaviors that make the calendar truly usable:
- create
- edit
- delete
- drag-and-drop move
- resize
- list views
- export

## Non-negotiable rules
- pure JavaScript only
- no TypeScript
- no npm
- no build step
- no external dependencies
- keep calendar surfaces canvas-first
- use DOM only where clearly appropriate, such as editor modal and list view table if needed

## Required features for this phase

### 1) Event CRUD
Implement:
- create event
- edit event
- delete event

Support at least these fields:
- id
- title
- description
- startUtc
- endUtc
- allDay
- timezone
- location
- category
- color
- readOnly

### 2) Event editor
Implement a practical editor in DOM:
- modal or side panel
- validation
- prefilling for create/edit
- proper save/cancel/delete affordances

### 3) Drag-and-drop
Implement:
- drag event to another time/day in day/week views
- drag event to another date in month view
- snap to configured interval
- immediate visual preview
- final callback/event emission for persistence

### 4) Resize
Implement duration resize in day/week views if feasible in the current architecture.
If implemented:
- add visible interaction affordances
- snap to interval
- update preview during drag

### 5) List views
Implement list mode for visible:
- day
- week
- month
- year

This may be DOM-based if that is the right engineering trade-off.
It must support:
- sorting by start time
- navigation back to event/date
- export of currently visible items

### 6) Export
Implement visible-item export to:
- CSV for sure
- XLSX if feasible without violating the no-dependency rule

Before inventing complex XLSX packaging from scratch, inspect the repository for any existing helper that can be reused.
If no suitable helper exists:
- fully implement CSV
- optionally implement Excel-compatible XML / SpreadsheetML if practical
- clearly document the limitation and extension path

Do not add package dependencies.

## Callback / persistence behavior
Expose or wire clean callbacks such as:
- onEventCreate
- onEventUpdate
- onEventDelete

Use immediate optimistic UI updates where sensible, but keep architecture compatible with real backend persistence.

## Validation scenarios to explicitly cover in this phase
- create event from empty slot
- edit event title/time
- delete event
- drag event across days
- drag event within same day
- resize event longer/shorter
- month view drag to a new date
- export currently visible week
- list view for month and year
- readOnly event behavior

## Demo / examples
Update demos/examples to prove CRUD and drag-and-drop behavior.

## Stop condition
When CRUD, drag-and-drop, resize/list/export are implemented to a practical level, stop and respond using `99-codex-response-format.md`.
Do not continue into final integration/polish work in this phase.
