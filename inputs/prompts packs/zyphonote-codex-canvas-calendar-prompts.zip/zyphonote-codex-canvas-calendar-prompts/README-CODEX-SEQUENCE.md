# ZyphoNote Canvas Calendar – Codex Prompt Pack

This pack is meant to be executed **sequentially** by Codex inside the real repository.

## Important reality note
The repository files were **not available in this environment**, so this pack could not inspect `dev-canvas-gallery.php` directly.
Because of that, Phase 1 explicitly instructs Codex to inspect the repository, audit the existing reusable canvas components, and upgrade them **before** implementing the calendar.

## Global non-negotiable constraints
- Pure JavaScript only.
- No TypeScript.
- No npm.
- No bundlers.
- No build step.
- No React / Vue / Angular / jQuery / FullCalendar.
- No external drag-and-drop library.
- No external date library.
- Tailwind already exists in the host app, but the calendar itself must be **primarily canvas-rendered**.
- Use DOM only where it is clearly the correct tool:
  - toolbar
  - modal / event editor
  - dropdowns
  - optional accessible list view
  - optional hidden accessibility mirrors
- The actual calendar surfaces (day/week/month/year, grids, event blocks, mini month previews, drag previews, hit testing) must be primarily done in HTML5 Canvas.
- Reuse and improve the existing reusable canvas components from `dev-canvas-gallery.php` and related files instead of building an isolated one-off calendar stack.
- All source code comments must be in English.

## Execution order
1. Read `00-master-spec.md`
2. Read `01-reference-ui-notes.md`
3. Read `02-implementation-guidance.md`
4. Run `10-phase-1-audit-and-upgrade-reusables.prompt.md`
5. Review result
6. Run `20-phase-2-build-calendar-foundation.prompt.md`
7. Review result
8. Run `30-phase-3-crud-dnd-list-export.prompt.md`
9. Review result
10. Run `40-phase-4-integrations-polish-validation.prompt.md`

## Recommended usage pattern with Codex
- Run **one phase at a time**.
- Keep the same working tree / branch between phases.
- Require Codex to stop after each phase and summarize:
  - what it inspected
  - what files it changed
  - what remains
  - blockers or risks
- Do not let Codex skip Phase 1.
- If Codex discovers missing reusable primitives, it should first add them to the reusable canvas layer and gallery, then consume them in the calendar.

## What success should look like
A production-oriented, Outlook-familiar, canvas-first calendar system for:
- `zyphonote-web` (PHP)
- `Zyphonote WASM app` (Blazor WebAssembly via JS interop)

with:
- day / week / month / year views
- list views
- CRUD
- drag and drop
- timezone support
- export
- dense overlapping event handling
- mini month sidebars in week view
- no dependency-heavy stack

## Included files
- `00-master-spec.md` – full product / engineering spec
- `01-reference-ui-notes.md` – Outlook-like reference notes from the provided screenshot
- `02-implementation-guidance.md` – practical engineering guidance for tricky areas
- `10-phase-1-audit-and-upgrade-reusables.prompt.md`
- `20-phase-2-build-calendar-foundation.prompt.md`
- `30-phase-3-crud-dnd-list-export.prompt.md`
- `40-phase-4-integrations-polish-validation.prompt.md`
- `90-acceptance-checklist.md`
- `99-codex-response-format.md`
- `assets/outlook-week-reference.png`

## Final reminder
This pack is intentionally strict. The main risk is Codex trying to:
- fall back to DOM for the actual calendar
- introduce packages or build tooling
- ignore existing reusable canvas components
- under-design overlapping events and dense layouts

Do not allow that drift.
