# IRDrums hit engine refinement package

This package is the source of truth for the next firmware refinement pass.

Goal:
- keep the current IR-beacon target selection model,
- replace the current hit detection model with a more professional directional stroke model,
- suppress false retriggers on the return/upstroke,
- improve soft-hit reliability at realistic playing tempos,
- preserve fast switching between virtual drums/cymbals,
- improve browser-side device labeling and diagnostics.

Read order:
1. `CHECKLIST.md`
2. `docs/01-executive-summary.md`
3. `docs/02-current-code-audit.md`
4. `docs/03-open-source-survey.md`
5. `docs/04-drummer-physics-and-stroke-taxonomy.md`
6. `docs/05-hit-engine-redesign.md`
7. `docs/06-beacon-target-latching.md`
8. `docs/07-calibration-velocity-and-profiles.md`
9. `docs/08-browser-device-naming-and-host-labels.md`
10. `docs/09-protocol-telemetry-and-debug-ui.md`
11. `docs/10-validation-playtest-plan.md`
12. `docs/11-future-bno055-path.md`
13. `docs/12-risks-and-non-goals.md`

Then execute prompts strictly in order from `prompts/00-master-start.md` to `prompts/09-final-audit.md`.

Rules:
- Do not skip any prompt.
- After every prompt, return to `CHECKLIST.md` and report exact coverage.
- Keep source code comments in English only.
- Prefer deterministic stroke-phase logic over opaque adaptive heuristics.
- Preserve working BLE MIDI transport and existing SysEx protocol compatibility unless this package explicitly extends them.
- Keep the implementation reviewable and observable: add metrics, reason codes, and debug telemetry.
