Implement the IRDrums hit-engine refinement package in this folder.

Read first:
1. `README_PACKAGE.md`
2. `CHECKLIST.md`
3. `docs/01-executive-summary.md`
4. `docs/02-current-code-audit.md`
5. `docs/03-open-source-survey.md`
6. `docs/04-drummer-physics-and-stroke-taxonomy.md`
7. `docs/05-hit-engine-redesign.md`
8. `docs/06-beacon-target-latching.md`
9. `docs/07-calibration-velocity-and-profiles.md`
10. `docs/08-browser-device-naming-and-host-labels.md`
11. `docs/09-protocol-telemetry-and-debug-ui.md`
12. `docs/10-validation-playtest-plan.md`
13. `docs/11-future-bno055-path.md`
14. `docs/12-risks-and-non-goals.md`

Then execute prompts strictly in order:
- `prompts/00-master-start.md`
- `prompts/01-audit-and-baseline.md`
- `prompts/02-freeze-target-and-add-stability.md`
- `prompts/03-add-directional-features.md`
- `prompts/04-implement-stroke-fsm.md`
- `prompts/05-calibration-profiles-and-velocity.md`
- `prompts/06-telemetry-protocol-and-ui.md`
- `prompts/07-browser-labeling-and-host-fallback.md`
- `prompts/08-playtest-and-tuning.md`
- `prompts/09-final-audit.md`

Non-negotiable rules:
- do not skip any phase,
- do not keep magnitude-only hit detection as the main trigger path,
- do not keep selecting the beacon only at trigger time,
- do not depend on opaque adaptive thresholds as the primary solution,
- keep source code comments in English only,
- keep the implementation observable through telemetry and reason codes,
- preserve existing BLE MIDI transport unless there is a build-breaking reason,
- return to `CHECKLIST.md` after every phase and state exactly what is complete and what remains.

Your first response must contain:
- a checklist-to-task mapping,
- a file-touch plan,
- a risk list,
- a phase execution order,
- the exact files you will inspect first.
