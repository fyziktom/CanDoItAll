# Phase 07 - browser labeling and host fallback

Goal:
Improve the user-facing device labels without making false promises about browser behavior.

Tasks:
1. Audit the runtime firmware device name and keep it short/stable.
2. Improve boot logs so the runtime BLE name is obvious.
3. In the host app, add a display label fallback based on protocol `HelloResp`:
   - prefer protocol name when available,
   - fall back to Web MIDI port name,
   - keep raw port id for debugging.
4. Update the UI where MIDI ports are listed so the label is user-friendly.
5. Document why browser or OS can still show unknown/truncated names.

Deliverables:
- code changes in firmware and/or host app,
- label resolution strategy,
- checklist update.
