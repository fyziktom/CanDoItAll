# Phase 06 - telemetry, protocol, and UI

Goal:
Make tuning observable.

Tasks:
1. Extend protocol stats/debug responses with hit-engine fields.
2. Add serial logs for accepted/rejected strokes.
3. Add compact M5StickC UI pages or lines for:
   - phase,
   - live/frozen target,
   - approach/rebound score,
   - cooldown,
   - last reason.
4. Keep the display readable in portrait orientation.
5. Keep telemetry opt-in or compact enough to avoid BLE overload.

Deliverables:
- protocol changes,
- UI changes,
- sample debug payloads,
- checklist update.
