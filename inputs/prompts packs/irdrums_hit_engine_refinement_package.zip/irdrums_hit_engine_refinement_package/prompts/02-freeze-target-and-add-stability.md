# Phase 02 - freeze target and add stability

Goal:
Make target selection musically correct before changing hit physics.

Tasks:
1. Add target stability timing in the app layer.
2. Add `strokeTargetBeacon` or equivalent frozen target state.
3. Freeze the target when the stroke arms, not when the note is finally emitted.
4. Keep scanner fast-switch behavior for the next stroke.
5. Add compact telemetry for:
   - live target,
   - frozen target,
   - target stable ms,
   - target-confident flag.

Rules:
- do not redesign the scanner from scratch,
- do not keep selecting the beacon only inside `triggerHit()`.

Deliverables:
- code changes,
- short explanation of target lifetime,
- debug output examples,
- checklist update.
