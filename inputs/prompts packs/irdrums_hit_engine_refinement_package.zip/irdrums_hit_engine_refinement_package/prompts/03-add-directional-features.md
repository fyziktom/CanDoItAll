# Phase 03 - add directional features

Goal:
Replace norm-only hit features with signed projected features.

Tasks:
1. Introduce a hit-engine structure or equivalent module.
2. Compute:
   - gravity-compensated linear acceleration,
   - projected signed gyro,
   - projected signed linear accel,
   - approach and rebound components,
   - normalized approach and rebound scores.
3. Preserve low latency with light filtering only.
4. Keep code comments in English only.
5. Add debug fields for projected values.

Rules:
- do not use `fabs(norm(accel)-1g)` and `norm(gyro)` as the main trigger features anymore,
- do not rely on high-rate adaptive thresholds.

Deliverables:
- code changes,
- explanation of axis/sign handling,
- checklist update.
