# Phase 08 - playtest and tuning

Goal:
Tune the redesigned engine against realistic drummer patterns.

Tasks:
1. Run through the validation matrix from `docs/10-validation-playtest-plan.md`.
2. Tune one cluster at a time:
   - target stability,
   - profile thresholds,
   - fall ratio,
   - rebound threshold,
   - min gap,
   - velocity refs.
3. Summarize what changed and why.
4. Preserve evidence in logs or notes.

Deliverables:
- tuning summary,
- updated defaults,
- remaining edge cases,
- checklist update.
