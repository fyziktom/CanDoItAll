# Phase 05 - calibration, profiles, and velocity

Goal:
Make the new hit engine tunable and explainable.

Tasks:
1. Add hit profiles:
   - StickDrum,
   - StickCymbal,
   - FootKick,
   - FootHat.
2. Add mandatory stillness calibration:
   - gyro bias,
   - gravity estimate,
   - noise floor.
3. Add optional guided stroke calibration if feasible without destabilizing the codebase.
4. Add starter sensitivity defaults for levels 1..10.
5. Replace old velocity mapping with a directional-peak-based velocity curve.
6. Document fallback behavior when calibration is absent.

Deliverables:
- code changes,
- persisted config changes if needed,
- updated docs/comments,
- checklist update.
