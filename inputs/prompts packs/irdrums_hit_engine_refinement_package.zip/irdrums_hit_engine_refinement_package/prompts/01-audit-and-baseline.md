# Phase 01 - audit and baseline

Goal:
Create a precise baseline of the current implementation before changing behavior.

Tasks:
1. Audit the current `IRDrums.ino` hit-engine path and summarize:
   - where direction is lost,
   - where beacon selection is deferred until trigger time,
   - where velocity is computed.
2. Audit current browser host labeling:
   - `midiInterop.js`
   - `MidiService.cs`
   - `IMidiService.cs`
3. Add or improve baseline diagnostics only if needed:
   - current active target,
   - current impact score,
   - last hit beacon,
   - last velocity.
4. Do not change behavior yet unless a tiny safety refactor is needed.

Deliverables:
- baseline summary,
- exact touched files,
- risks discovered,
- what Phase 02 will change.

Before ending:
- return to `CHECKLIST.md`,
- mark only what is honestly complete.
