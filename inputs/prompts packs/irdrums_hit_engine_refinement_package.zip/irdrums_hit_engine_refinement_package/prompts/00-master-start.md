# Phase 00 - master start

Read:
- `README_PACKAGE.md`
- `CHECKLIST.md`
- all docs in `docs/`

Then respond with:
1. a checklist-to-task mapping,
2. a file-touch plan,
3. a risk list,
4. a phase order confirmation,
5. the exact files you will inspect first,
6. the exact files you expect to modify in firmware and host code.

Rules:
- do not write code yet,
- do not skip any document,
- do not propose magnitude-only threshold tweaks as the primary fix,
- state explicitly that target freeze and directional stroke logic are required.
