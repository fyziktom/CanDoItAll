# Phase 04 - implement stroke FSM

Goal:
Trigger exactly once per valid approach + reversal.

Tasks:
1. Implement explicit stroke phases:
   - Idle,
   - Candidate,
   - Approach,
   - TriggeredRecovery.
2. Arm only on stable target + valid approach.
3. Track peak directional features during the approach.
4. Trigger on the first valid release event:
   - fall from peak,
   - rebound threshold,
   - sign reversal,
   - short timeout.
5. Prevent retrigger during rebound/upstroke.
6. Require release/rearm conditions before next stroke.

Deliverables:
- code changes,
- reason codes,
- example trigger/reject logs,
- checklist update.

Rules:
- do not keep the current scalar-only stroke tracking as the primary path.
