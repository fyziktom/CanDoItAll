# Calibration, sensitivity, velocity, and profiles

## 1. Calibration philosophy

Calibration should be simple, deterministic, and explainable.

Avoid making the system depend on black-box adaptation during real playing. Instead, use:
- mandatory stillness calibration,
- optional guided stroke calibration,
- explicit hit profiles.

## 2. Mandatory stillness calibration

Purpose:
- estimate gyro bias,
- estimate gravity vector,
- estimate background noise floor,
- initialize release thresholds,
- initialize low-pass filters cleanly.

Procedure:
1. user holds the module still in playing pose,
2. capture 500 to 1000 ms of IMU samples,
3. compute:
   - gyro bias mean,
   - accel mean -> gravity estimate,
   - standard deviation or MAD for noise floor,
4. store:
   - `gyroBias`,
   - `gravityBodyRef`,
   - `noiseAccel`,
   - `noiseGyro`.

## 3. Optional guided stroke calibration

Purpose:
- estimate dominant strike axes,
- estimate realistic soft / medium / hard reference values,
- initialize velocity refs.

Suggested flow:
1. choose profile class (`StickDrum`, `StickCymbal`, `FootKick`, `FootHat`),
2. record 8 medium strokes on a designated calibration target,
3. for each accepted stroke, capture the early approach window,
4. estimate dominant approach direction from median or robust mean,
5. derive:
   - `attackGyroAxisBody`,
   - `attackAccelAxisBody`,
   - `velocityGyroRef`,
   - `velocityAccelRef`.

Use robust statistics:
- median,
- trimmed mean,
- MAD.

Do not use raw average if outliers are common.

## 4. Profiles

Add a small profile taxonomy.

### StickDrum
- balanced gyro + accel,
- medium cooldown,
- stronger rebound tolerance.

### StickCymbal
- higher gyro weight,
- lower accel reliance,
- shorter travel assumption,
- more sensitive to small clean taps.

### FootKick
- slower envelope,
- larger minimum gap,
- different axis set.

### FootHat
- shorter envelope than kick,
- different release profile,
- potentially lower velocity gamma.

## 5. Sensitivity levels 1..10

Sensitivity should adjust a bounded set of values, not rewrite the whole model.

Recommended knobs:
- `armThresholdScale`
- `triggerThresholdScale`
- `fallRatio`
- `reboundThresholdScale`
- `peakTimeoutMs`
- `minGapMs`

Starter matrix:

| Level | Arm scale | Trigger scale | Fall ratio | Peak timeout ms | Min gap ms |
|------:|----------:|--------------:|-----------:|----------------:|-----------:|
| 1 | 1.25 | 1.18 | 0.80 | 54 | 24 |
| 2 | 1.18 | 1.12 | 0.78 | 52 | 22 |
| 3 | 1.12 | 1.07 | 0.76 | 50 | 20 |
| 4 | 1.06 | 1.02 | 0.74 | 48 | 18 |
| 5 | 1.00 | 1.00 | 0.72 | 46 | 17 |
| 6 | 0.95 | 0.96 | 0.70 | 44 | 16 |
| 7 | 0.90 | 0.92 | 0.68 | 42 | 15 |
| 8 | 0.85 | 0.88 | 0.66 | 40 | 14 |
| 9 | 0.80 | 0.84 | 0.64 | 38 | 13 |
| 10 | 0.75 | 0.80 | 0.62 | 36 | 12 |

These are starter defaults, not final truths.

## 6. Velocity curve

Suggested starter curve:
- use mostly projected gyro peak for sticks,
- add projected accel as secondary energy,
- use `gamma` in the range `0.80 .. 1.10` depending on profile,
- clamp low-end values so ghost notes are still audible but not overinflated.

Example:
- `StickDrum`: `cG=0.70`, `cA=0.30`, `gamma=0.95`
- `StickCymbal`: `cG=0.82`, `cA=0.18`, `gamma=0.90`
- `FootKick`: `cG=0.45`, `cA=0.55`, `gamma=1.00`
- `FootHat`: `cG=0.60`, `cA=0.40`, `gamma=0.92`

## 7. Release and rearm

Cooldown alone is not enough.

Rearm should require:
- cooldown elapsed,
- projected approach below quiet threshold,
- rebound decayed below quiet threshold,
- optional minimum neutral dwell.

This is essential to suppress the second sound on the return motion.

## 8. Storage

Store:
- profile class,
- calibrated axes,
- refs,
- sensitivity level,
- optional per-slot override.

Keep default fallback behavior when explicit calibration is absent.
