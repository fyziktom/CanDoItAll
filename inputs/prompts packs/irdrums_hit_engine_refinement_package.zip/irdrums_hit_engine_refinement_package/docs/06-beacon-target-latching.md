# Beacon target latching

## 1. Problem to solve

The scanner is allowed to change `activeIndex` quickly, which is good for navigation between targets.

But a stroke should not be allowed to change its target mid-flight.

## 2. Required rule

Introduce:
- `candidateTargetBeacon`
- `strokeTargetBeacon`
- `targetStableSinceMs`

### Rule
When a new stroke arms:
- read the currently stable scanner target,
- freeze it into `strokeTargetBeacon`,
- use that frozen target until the stroke is either triggered or aborted.

Do not re-read the live scanner target inside the final trigger decision for that same stroke.

## 3. Target stability

Before `Idle -> Candidate`, require:
- `scannerActiveIndex >= 0`,
- `targetStableMs >= minTargetStableMs`,
- target confidence above a minimum threshold,
- no rapid ambiguity flag.

Starter defaults:
- sticks: `minTargetStableMs = 4..8 ms`
- feet: `minTargetStableMs = 6..12 ms`

## 4. Fast switching is still preserved

The scanner can still switch `activeIndex` aggressively. That is good. The only restriction is:
- the current live target is for the *next* stroke,
- not for the current one once it has armed.

This gives:
- smooth target changes between adjacent beacons,
- stable note identity for a single swing.

## 5. Suggested implementation details

Add fields:
- `int8_t liveTargetBeacon`
- `int8_t frozenStrokeTargetBeacon`
- `uint32_t liveTargetStableSinceMs`
- `uint32_t frozenTargetArmedAtMs`

Add telemetry:
- `liveTarget`,
- `frozenTarget`,
- `targetStableMs`,
- `targetFreezeAgeMs`,
- `targetSwitchCount`.

## 6. Interaction with IR scanner

Do not rewrite the scanner unless needed. Reuse:
- current `activeIndex`,
- current `winnerIndex`,
- current confidence metrics.

Only add one small helper in the application layer:
- a function that determines whether the scanner target is stable enough to arm a stroke.

## 7. Example timeline

- t=0 ms: beacon A becomes active
- t=5 ms: target stable long enough
- t=8 ms: approach score rises, stroke arms, frozen target = A
- t=11 ms: live scanner now sees beacon B stronger
- t=13 ms: stroke triggers -> note for A
- t=20 ms: new stroke can arm on B

That is the musically correct behavior.
