# Open-source and public-reference survey

This section does not claim there is a direct drop-in project for "M5StickC + IR beacons + BLE MIDI virtual drums". There is not a known permissive, directly reusable project that matches the current architecture exactly.

Instead, the useful move is to borrow the right *principles* from nearby projects.

## 1. Air Snare (Google Creative Lab)

Most useful takeaway:
- it treats drumming as a gesture-recognition problem on a 9DoF IMU stack,
- it uses a proper sensor pipeline instead of a single raw threshold idea,
- it proves that richer IMU information and model-based interpretation are valuable.

Why it is not a direct drop-in:
- different hardware,
- different sensor stack,
- different runtime assumptions,
- model-centered workflow rather than the lightweight deterministic firmware path used here.

What to borrow:
- treat drumming as a structured movement problem,
- design for calibration and controlled feature extraction,
- document a future path for better sensors.

## 2. Drumlet

Most useful takeaway:
- it demonstrates how simplistic mappings such as a single orientation dimension plus a simple motion trigger can produce sounds quickly.

Why it is not sufficient here:
- it is too simple for professional-feeling drumming,
- it does not solve the current false-trigger and repeatability requirements,
- it is not an architecture to copy for this project.

What to borrow:
- nothing structural; only the reminder that simple prototypes break down quickly under real playing.

## 3. Cornell-style air drum project

Most useful takeaway:
- it explicitly reasons about downstroke detection instead of generic energy,
- it includes logic to avoid multiple triggers inside one swing,
- conceptually, it is much closer to the real problem here than a pure threshold demo.

What to borrow:
- use stroke direction,
- gate repeated triggers inside one motion cycle,
- distinguish approach from recovery.

## 4. SnAIRbeats and similar wearable IMU drum experiments

Most useful takeaway:
- motion-only drumming systems need robust stroke semantics, not just energy thresholds,
- per-motion-class mapping and sensor interpretation matter.

Why not directly reuse:
- different platform assumptions,
- different operating system and host assumptions,
- uncertain fit for permissive copy-paste reuse in this repository.

## 5. Resulting decision

The best path for the current codebase is:
- keep deterministic C++ firmware logic,
- borrow the *downstroke + rebound suppression* principle,
- borrow the *better sensor model* mindset,
- avoid heavy online adaptivity as the primary trigger mechanism,
- reserve machine-learning or full 9DoF world-frame mapping for the future BNO055 path.

## 6. What should not be copied from public prototypes

Do not copy these as the main solution:
- single-axis absolute thresholds,
- raw norm-only impact detection,
- unbounded adaptive thresholds,
- fixed trigger-on-crossing logic with no stroke phase model.

Those patterns are exactly the ones that fail under ghost notes, repeated ride taps, and rebound-heavy playing.
