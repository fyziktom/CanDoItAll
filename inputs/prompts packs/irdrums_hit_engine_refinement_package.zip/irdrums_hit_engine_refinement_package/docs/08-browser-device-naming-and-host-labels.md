# Browser device naming and host labels

## 1. Key fact

Browser-side Web MIDI port labels do not come directly from arbitrary application metadata. They come from the host system's MIDI port information.

That means the browser can show:
- a good device name,
- a truncated name,
- an empty name,
- an empty manufacturer,
- or a generic unknown label,

depending on the operating system, BLE stack, and browser.

## 2. Why firmware name is necessary but not sufficient

The firmware should still set a short stable BLE name, but that does not guarantee that the browser will expose the same text.

Reasons:
- BLE advertising space is small,
- a full local name may be shortened or omitted,
- the host may resolve the final display name from a later GATT read,
- the Web MIDI layer may expose only what the system MIDI stack provides.

So it is possible for:
- OS Bluetooth settings to show `IDRM-LS-571D`,
- while browser MIDI port metadata still appears as unknown or partially named.

## 3. Current app-side behavior

The current browser bridge turns missing values into:
- name -> `(unnamed)`
- manufacturer -> `(unknown)`

This is correct as a fallback, but it is not ideal for users of this product.

## 4. Required host-side improvement

After a MIDI port connects and the host receives protocol `HelloResp`, the application should prefer:
- `protocol.name`,
- optionally `protocol.uid`,
- optionally role/profile suffix,

as the user-facing label for this device session.

Example display label:
- `IDRM-LS-571D`
- `IDRM-LS-571D (Stick Cymbal)`
- `IDRM-LS-571D / uid 5A7C571D`

That gives a stable UI label even if Web MIDI metadata is weak.

## 5. Firmware-side improvements

Keep firmware names:
- short,
- stable,
- ASCII-safe,
- role-aware when useful.

Recommended patterns:
- `IDRM-LS-571D`
- `IDRM-RS-812A`
- `IDRM-LF-09C4`
- `IDRM-RF-31B0`

Avoid overly long names.

Optional extras if practical:
- expose Device Information Service data if the BLE stack permits,
- keep advertised local name and GATT device name aligned.

## 6. What not to promise

Do not promise:
- that every browser will show the exact BLE name,
- that manufacturer will always be available,
- that host pairing dialogs will match the app label exactly.

The correct fix is two-part:
- good firmware naming,
- protocol-level host fallback labeling.

## 7. Implementation tasks

Firmware:
- audit actual runtime device name,
- keep it short,
- log the runtime name on boot.

Host:
- add `DisplayLabel`,
- cache protocol hello info by MIDI port id,
- update the UI to prefer protocol label over raw `MIDIPort.name`.
