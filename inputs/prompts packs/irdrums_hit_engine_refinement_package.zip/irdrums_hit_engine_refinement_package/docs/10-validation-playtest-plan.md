# Validation and playtest plan

## 1. General rule

Do not accept the redesign based only on "it compiles" or "one hit worked". Validate it against real playing patterns.

## 2. Test matrix

### A. Single-target stick tests
1. soft quarter-note cymbal taps at slow tempo,
2. soft quarter-note cymbal taps at faster tempo,
3. medium repeated ride pattern,
4. ghost-note style light snare hits,
5. accented single crash hits,
6. alternating medium and hard strokes on same target.

### B. Rebound suppression tests
1. one strong downstroke with obvious rebound,
2. verify exactly one note,
3. repeat at several sensitivity levels.

### C. Target-switching tests
1. move quickly between two adjacent beacon targets,
2. hit target A then target B in close succession,
3. verify no mid-stroke retargeting,
4. verify next stroke can immediately use the new target.

### D. Profile tests
1. `StickDrum`
2. `StickCymbal`
3. `FootKick`
4. `FootHat`

### E. Long-session stability
1. 2-minute continuous play with mixed dynamics,
2. verify no threshold drift,
3. verify no memory leaks or UI crashes.

## 3. What to record

For each scenario record:
- hits attempted,
- hits detected,
- false positives,
- double triggers,
- missed soft hits,
- average target switch delay,
- subjective feel notes.

## 4. Acceptance criteria

Starter acceptance targets:
- strong-hit double trigger rate near zero,
- soft repeated taps noticeably improved from baseline,
- target switch feels immediate to the player,
- no regression in BLE MIDI or protocol behavior,
- debug telemetry matches observed behavior.

## 5. Tuning discipline

When tuning:
- change one cluster of parameters at a time,
- write down the reason,
- compare against baseline,
- do not silently add more adaptive logic unless a measured problem remains.

## 6. Final sign-off

Do not sign off until:
- the checklist is fully covered,
- telemetry fields are present,
- browser label fallback works,
- documentation is updated.
