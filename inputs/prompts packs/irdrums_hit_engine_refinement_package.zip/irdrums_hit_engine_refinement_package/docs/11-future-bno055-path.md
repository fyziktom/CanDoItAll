# Future BNO055 path

This document is intentionally separate from the current implementation plan.

## 1. Why BNO055 helps

The current M5StickC IMU is only accel + gyro. That is enough for a better directional stroke engine, but not enough for robust long-term absolute orientation.

A 9DoF sensor such as BNO055 gives:
- accelerometer,
- gyroscope,
- magnetometer,
- onboard fusion outputs.

That makes it easier to:
- stabilize orientation,
- estimate a world-referenced pose,
- build target normals in a more global frame,
- reduce yaw drift.

## 2. What becomes possible later

With a fused orientation sensor:
- per-target attack normals become more meaningful,
- angular shell zones can be defined more globally,
- calibration can identify targets and strike planes more robustly,
- left/right role mirroring becomes cleaner.

## 3. What should stay the same

Even with BNO055, do not throw away the stroke-phase model.

The best future architecture is:
- better orientation input,
- same core idea of approach -> trigger -> recovery,
- same target freeze rule,
- same per-profile tuning philosophy,
- same telemetry discipline.

## 4. Recommendation

Implement the current redesign now on the existing hardware.
Then, when BNO055 hardware arrives:
- keep the same hit-engine API,
- swap the feature provider layer,
- optionally add world-frame attack vectors and better per-target geometry.

That gives continuity and protects the current work.
