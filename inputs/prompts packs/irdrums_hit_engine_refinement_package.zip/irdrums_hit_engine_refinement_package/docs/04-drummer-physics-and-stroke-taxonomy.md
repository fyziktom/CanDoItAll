# Drummer physics and stroke taxonomy

A professional-feeling algorithm must start from how drummers actually move.

## 1. A stick stroke is a phase sequence, not a scalar event

A useful abstract model is:

1. target acquisition,
2. approach,
3. peak intent / closest approach,
4. rebound or controlled stop,
5. recovery.

Not every stroke has a literal physical impact in this virtual system, but the motor pattern still has the same topology.

## 2. Why amplitude alone is not enough

Players vary all of these independently:
- stroke height,
- stroke speed,
- rebound amount,
- tempo,
- wrist versus arm contribution,
- accent level.

Examples:
- a quiet quarter-note ride tap can have a short travel but still be a valid hit,
- an accented crash can have huge travel and huge peak speed,
- a ghost note can be small but directionally clean,
- a returning stick after a valid hit can still produce large energy even though it should not retrigger.

So the invariant is not "large movement". The invariant is:
- *one directional approach*,
- followed by *one reversal or release*.

## 3. Useful drumming stroke classes

### Full stroke
- larger travel,
- larger rebound,
- often stronger acceleration and gyro,
- should produce strong velocity and longer cooldown.

### Tap stroke
- shorter travel,
- smaller rebound,
- can repeat quickly,
- must remain playable at moderate to high tempo.

### Downstroke
- large intent toward target,
- lower rebound because the stick stays lower afterwards,
- should still trigger cleanly.

### Upstroke / recovery motion
- can have significant energy,
- should normally not trigger by itself,
- must be filtered out as the return phase of a previous strike unless it clearly becomes the approach of the next stroke after release.

### Cymbal tapping
- often more wrist-led,
- can have lower linear acceleration but clear angular motion,
- requires more gyro-sensitive profiles and shorter allowed travel.

### Foot kick / foot-hat
- different dominant axes,
- slower typical motion envelope,
- different release behavior,
- should use their own hit profile.

## 4. The correct algorithmic invariant

The hit engine should look for:
- a stable target,
- a directional approach toward that target or stroke class,
- a rise toward a peak,
- one trigger at the first valid reversal / release / peak-fall event,
- no retrigger until the motion has truly exited the stroke.

This invariant survives changes in:
- loudness,
- tempo,
- playing style.

## 5. Mapping this to firmware features

A practical firmware feature set is:
- projected gyro along the dominant strike rotation axis,
- projected linear acceleration along the dominant strike translation axis,
- smoothed approach score,
- smoothed rebound score,
- peak tracking,
- release test,
- target stability time,
- cooldown,
- rearm condition.

## 6. Why this matches the user report

The user specifically described:
- light repeated cymbal taps,
- occasional strong accents,
- both slow and fast repetition,
- double-trigger on down and up motion.

All of those point to the same conclusion:
- the engine must model *stroke phase and direction*,
- not merely movement magnitude.
