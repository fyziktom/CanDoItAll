# Risks and non-goals

## Risks

### 1. Axis ambiguity without magnetometer
The current platform cannot provide perfectly stable absolute heading. The redesign should therefore rely on local body-frame directional features and profile calibration, not on fragile global yaw assumptions.

### 2. Overfitting to one player
Tuning should produce good defaults, but the system must still expose calibration and sensitivity controls. Do not tune only for one specific hand motion.

### 3. Too much telemetry
Debug visibility is important, but do not stream too much data by default over BLE MIDI. Keep high-rate telemetry opt-in.

### 4. Browser naming variance
Even after shortening the firmware name, browser-exposed labels may still vary by OS and browser. Host-side protocol fallback is required.

## Non-goals

### 1. Do not redesign the IR scanner from scratch
Use the current scanner as the base unless there is a measured failure.

### 2. Do not introduce machine learning in this pass
This pass should remain deterministic, inspectable, and firmware-friendly.

### 3. Do not solve full 3D absolute target geometry on M5StickC alone
That belongs to the future BNO055 path.

### 4. Do not hide problems behind giant refractory values
That would make the instrument feel dead and would not solve the actual physics-model issue.
