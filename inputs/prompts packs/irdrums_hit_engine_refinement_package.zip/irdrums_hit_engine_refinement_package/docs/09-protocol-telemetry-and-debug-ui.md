# Protocol telemetry and debug UI

## 1. Why telemetry is mandatory

This project is already beyond what can be tuned comfortably from "does it feel okay?" alone.

The next refinement pass needs observability for:
- target stability,
- target freeze state,
- stroke phase,
- projected feature values,
- trigger reason,
- reject reason,
- cooldown and rearm status.

## 2. Add a compact hit-debug structure

Recommended fields:
- `phase`
- `armed`
- `liveTarget`
- `frozenTarget`
- `targetStableMs`
- `approachScore`
- `reboundScore`
- `approachGyro`
- `approachAccel`
- `peakApproachScore`
- `peakGyro`
- `peakAccel`
- `cooldownMsRemaining`
- `triggerReason`
- `rejectReason`

## 3. Protocol strategy

Preserve the current SysEx protocol and extend it minimally.

Good options:
- extend `StatsResp`,
- add a new `HitDebugReq` / `HitDebugResp`,
- optionally add low-rate `LogEvent` payloads for trigger/reject reasons.

Do not stream high-rate telemetry by default. Make it opt-in.

## 4. On-device UI

The M5StickC display is narrow. Use compact pages.

Suggested pages:

### Main page
- live target label,
- frozen target label,
- phase short code,
- BLE status,
- armed state.

### Stroke page
- `A:` approach score,
- `R:` rebound score,
- `PG:` peak gyro,
- `PA:` peak accel,
- `CD:` cooldown ms.

### Scanner page
- current A/C/W indices,
- confidence,
- winner share,
- peak-to-noise.

### Last event page
- last trigger reason,
- last reject reason,
- last velocity,
- last note,
- time since hit.

Use abbreviations and simple bars instead of large text blocks.

## 5. Serial diagnostics

Add a compact single-line log for:
- accepted hit,
- rejected stroke,
- target freeze,
- target switch during active recovery,
- calibration complete.

Example accepted-hit log:
`[IDRM][HIT] tgt=3 vel=87 phase=APP->TRG reason=fall peak=1.62 g=214 a=0.78 cd=21`

Example reject log:
`[IDRM][REJ] tgt=3 reason=weak_peak phase=CAND peak=0.61 stable=3`

## 6. Why this matters for Codex

Without these metrics, tuning becomes guesswork. With them, Codex can:
- verify that the target is frozen correctly,
- confirm the phase machine is suppressing rebound doubles,
- compare soft cymbal taps against hard drum hits,
- reason about defaults instead of randomly changing thresholds.
