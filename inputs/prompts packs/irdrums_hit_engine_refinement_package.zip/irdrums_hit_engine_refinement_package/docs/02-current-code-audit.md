# Current code audit

This audit is based on the current IRDrums snapshot in `references/current_code/`.

## 1. Magnitude-only features are the core weakness

In `IRDrums.ino`, the current code computes:

- `accelNorm = vectorNorm3(ax, ay, az)`
- `linearAccel = fabsf(accelNorm - 1.0f)`
- `gyroNorm = vectorNorm3(gx, gy, gz)`

Then it builds:

- `accelScore = linearAccel / threshold`
- `gyroScore = gyroNorm / threshold`
- `impactScore = max(accelScore, gyroScore)`

This is visible in the current implementation around the `processImuAndHit()` block (current snapshot lines approximately 1252-1349).

### Why this is a real bug in the model
These operations intentionally remove:
- axis direction,
- sign,
- distinction between approach and rebound,
- distinction between the intended strike axis and unrelated motion.

As a result, the engine sees "large movement energy" but not "movement toward target" versus "movement away from target".

## 2. Current stroke tracking is scalar-only

The current state logic:
- arms when `armScore >= 1.0` and the scalar `impactScore` is rising,
- tracks scalar peaks,
- triggers on local peak, release, or timeout,
- applies dynamic refractory based on scalar hit strength.

This is better than a naive threshold crossing, but it is still blind to stroke direction.

### Consequence
A single physical stick cycle can satisfy the same scalar conditions twice:
- once on the way down,
- once again on the way back up.

That matches the observed bug report: both down and up motion can produce sound.

## 3. Beacon selection happens too late for a clean stroke model

The current `triggerHit()` reads `scanner_.snapshot()` at trigger time and then chooses:
- `activeIndex`, or
- `winnerIndex` if it looks temporarily stronger.

This is visible in the current snapshot around `triggerHit()` (current snapshot lines approximately 1352 onward).

### Why this matters
If the player transitions between two nearby targets during the same swing, the selected beacon can change during the stroke. That is not what a drummer expects. The target should be frozen once the stroke has clearly started.

## 4. Current velocity is not a strong proxy for stick intent

Velocity is currently derived from a scalar `hitScore` built from acceleration norm and gyro norm. That produces something usable, but it is not tied to:
- signed approach speed,
- time-to-peak,
- stroke class,
- target class.

This is especially weak for:
- soft cymbal taps,
- wrist-led ride patterns,
- ghost notes,
- foot-hat articulation.

## 5. The scanner itself is not the main problem

The current scanner already has:
- confidence,
- dominance,
- winner share,
- dynamic minimum magnitude,
- candidate and active states,
- fast-switch override.

This is a decent base. It should not be thrown away. The hit-engine redesign should sit on top of it.

## 6. Browser-side naming issue is partly outside the firmware

Current firmware already sets a device name in BLE MIDI startup and default config uses a short pattern like `IRD-XXXXXXXX`.

However, the browser-side app currently maps Web MIDI port info from:
- `port.name`,
- `port.manufacturer`.

If those are empty, the current app falls back to `(unnamed)` and `(unknown)`.

That means the labeling problem is not necessarily a failure of the firmware alone. The host must also support a protocol-level fallback label.

## 7. Immediate coding priorities

Priority order for the next pass:
1. Freeze beacon target at stroke-arm time.
2. Add target stability time before arm.
3. Replace norm-only hit features with signed projected features.
4. Replace scalar-only stroke tracking with an explicit stroke FSM.
5. Add calibration, profiles, and debug telemetry.
6. Add host-side fallback labels from `HelloResp`.
