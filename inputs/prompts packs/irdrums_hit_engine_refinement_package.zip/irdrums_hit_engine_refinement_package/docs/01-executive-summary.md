# Executive summary

## High-level conclusion

The current IRDrums prototype is already good enough in one important area: the IR-beacon scanner can switch targets quickly and can keep an active beacon even under noisy motion. The weak point is the hit engine, not the beacon scanner.

The current hit engine is fundamentally magnitude-based:
- linear acceleration is reduced to `fabs(norm(accel) - 1g)`,
- gyro is reduced to `norm(gyro)`,
- stroke tracking is based on the rise and fall of a single scalar impact score.

That design is exactly why one physical stroke can generate two audible events:
- one while the stick is moving toward the virtual drum/cymbal,
- another while the stick rebounds and returns.

The algorithm cannot reliably distinguish those two phases because it throws away direction.

## What should change

The next firmware pass should keep the current IR target acquisition model, but replace hit detection with a directional stroke model:

1. Use the IR beacon only to decide *which target is active*.
2. Require a short target-stability window before a stroke can arm.
3. Freeze the selected target for the lifetime of the current stroke.
4. Detect a hit from an *approach phase followed by a reversal/fall/rebound*, not from raw energy alone.
5. Use signed projected signals, not vector magnitudes only.
6. Gate re-arm on both time and release-phase completion.
7. Move velocity toward a tip-speed proxy based mainly on directional gyro peak, with acceleration as a secondary term.
8. Add instrument-class profiles, because ride taps, drum hits, foot-kick, and foot-hat do not look the same.

## Practical result expected from this redesign

This redesign should improve the exact problems reported by the user:
- fewer double triggers on downstroke + upstroke,
- more reliable soft repeated taps on cymbals,
- more consistent accents versus ghost notes,
- fast and smooth switching between virtual drums/cymbals when moving between beacons,
- better observability for tuning,
- clearer browser-side device labels.

## Important scope boundary

This package is for refining the current IMU + IR-beacon system on M5StickC. It also documents a future BNO055 path, but the primary implementation target here is the current hardware and repository state.
