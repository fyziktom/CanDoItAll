# Hit-engine redesign

## 1. Core redesign

Replace the current scalar impact engine with a directional stroke engine.

### Current model
- `impactScore = max(norm-based accel score, norm-based gyro score)`

### Proposed model
Track these directional features every sample:

- `aLinBody = accelBody - gravityEstimateBody`
- `gProj = attackSign * dot(gyroBody, attackGyroAxisBody)`
- `aProj = attackSign * dot(aLinBody, attackAccelAxisBody)`

Then derive:
- `approachGyro = max(0, gProj)`
- `approachAccel = max(0, aProj)`
- `reboundGyro = max(0, -gProj)`
- `reboundAccel = max(0, -aProj)`

And combine them into normalized scores:
- `approachScore = wG * clamp(approachGyro / gyroRef, 0, 3) + wA * clamp(approachAccel / accelRef, 0, 3)`
- `reboundScore = wrG * clamp(reboundGyro / gyroRef, 0, 3) + wrA * clamp(reboundAccel / accelRef, 0, 3)`

Use light filtering:
- EMA or biquad equivalent that is simple enough for the ESP32,
- keep latency low,
- avoid long windows.

## 2. State machine

Recommended states:
- `Idle`
- `Candidate`
- `Approach`
- `TriggeredRecovery`

### Idle
No active stroke.

Exit to `Candidate` only if:
- system armed,
- target stable long enough,
- approach score above arm threshold,
- approach slope positive,
- not in cooldown.

### Candidate
A stroke may be starting. Freeze `strokeTargetBeacon` now.
Track:
- start time,
- peak approach score,
- peak projected gyro,
- peak projected accel.

Advance to `Approach` once:
- approach score continues rising or remains above an approach hold threshold.

Abort back to `Idle` if:
- target lost too early,
- score collapses before a meaningful peak,
- wrong-direction rebound dominates.

### Approach
A real stroke is in progress.

Trigger exactly once when:
- peak score is strong enough, and
- at least one release condition happens:
  - sign reversal,
  - rebound score crosses threshold,
  - approach score falls from peak by a configured ratio,
  - short peak timeout is reached.

### TriggeredRecovery
After a trigger:
- keep cooldown timer,
- require the motion to satisfy release/rearm conditions before allowing a new stroke,
- do not allow a second trigger from the same rebound.

## 3. Trigger condition

A robust starter condition is:
- `peakApproachScore >= triggerThreshold`
- and one of:
  - `approachScore <= peakApproachScore * fallRatio`
  - `reboundScore >= reboundThreshold`
  - `gProj <= reversalGyroThreshold`
  - `elapsedSincePeak >= peakTimeoutMs`

This makes the trigger happen near the natural apex of the approach-reversal transition.

## 4. Why this prevents the current double trigger

The current engine loses sign, so down and up motion look similar.

The new engine separates:
- positive approach,
- negative rebound.

A valid hit consumes the approach peak and moves the machine into recovery. The return motion is then recognized as rebound/recovery, not a new hit.

## 5. Velocity

Velocity should be based on directional peak values, not raw energy magnitude alone.

Recommended starter model:
- `vG = clamp(peakApproachGyro / velocityGyroRef, 0, 2.0)`
- `vA = clamp(peakApproachAccel / velocityAccelRef, 0, 2.0)`
- `energy = cG * vG * vG + cA * vA * vA`
- `normalized = clamp(energy / energySat, 0, 1)`
- `velocity = round(127 * pow(normalized, gamma))`

Guidance:
- sticks: larger gyro weight than accel weight,
- cymbals: even more gyro weight,
- kick/foot: profile-dependent.

## 6. What not to do

Do not make the primary fix by:
- adding more norm thresholds,
- increasing refractory only,
- heavily adapting thresholds based on recent hits,
- adding random debounce delays.

Those may hide symptoms temporarily, but they do not solve the actual phase-model bug.

## 7. Data structure suggestion

Add a dedicated hit-engine structure instead of scattering state across many globals:
- `HitProfile`
- `HitEngineState`
- `HitFrameFeatures`
- `HitDebugSnapshot`

Keep the scanner independent and keep the hit engine consuming scanner snapshots plus IMU samples.
