# Checklist

## A. Baseline and safety
- [ ] Read all docs in the prescribed order.
- [ ] Create a baseline behavior summary from the current code.
- [ ] Identify touched files before editing.
- [ ] Keep the project compiling after each phase.
- [ ] Do not regress existing BLE MIDI note output or SysEx command handling.

## B. Current hit-engine diagnosis
- [ ] Confirm that current hit detection uses magnitude-only acceleration and gyro features.
- [ ] Confirm that current trigger selection reads the active beacon at trigger time instead of freezing it at stroke arm time.
- [ ] Confirm that current state machine can trigger on both downstroke and return motion because direction is lost.
- [ ] Confirm current velocity is driven by magnitude-based `hitScore`, not by directional approach speed.

## C. Beacon and target behavior
- [ ] Add target stability timing before a stroke can arm.
- [ ] Freeze `strokeTargetBeacon` for the lifetime of one stroke.
- [ ] Keep scanner-level fast beacon switching for the next stroke.
- [ ] Add metrics for target stability and target freeze state.

## D. Directional stroke model
- [ ] Add signed directional features instead of norm-only features.
- [ ] Add filtered projected gyro and projected linear acceleration.
- [ ] Add explicit stroke phases.
- [ ] Trigger once per valid approach + reversal.
- [ ] Block retrigger on rebound/upstroke until release conditions are satisfied.
- [ ] Keep soft strokes playable at higher tempos.

## E. Profiles and calibration
- [ ] Introduce instrument classes or hit profiles.
- [ ] Add mandatory stillness/noise calibration.
- [ ] Add optional guided stroke calibration.
- [ ] Add starter defaults for sensitivity levels 1..10.
- [ ] Add a documented velocity curve.

## F. Telemetry and UI
- [ ] Add compact on-device debug metrics.
- [ ] Add serial or SysEx telemetry with reason codes.
- [ ] Add host-visible fields for current phase, target, projected values, and reject/trigger reason.
- [ ] Keep UI readable on M5StickC portrait orientation.

## G. Browser naming and host labels
- [ ] Audit where browser MIDI port names come from.
- [ ] Keep firmware device names short and stable.
- [ ] Add host-side fallback labeling based on protocol `HelloResp`.
- [ ] Document why browser/OS can still show unknown or truncated names.

## H. Validation
- [ ] Define realistic drummer test patterns.
- [ ] Validate false positives after hard hits.
- [ ] Validate soft repeated cymbal taps.
- [ ] Validate fast movement between adjacent beacons.
- [ ] Validate per-profile settings for stick-drum, stick-cymbal, foot-kick, foot-hat.
- [ ] Final audit: code, docs, defaults, diagnostics, and known limitations.
