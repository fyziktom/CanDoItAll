#include "BleMidiBackendEsp32BleMidi.h"

#if !__has_include(<MIDI.h>) || !__has_include(<BLEMIDI_Transport.h>)
#error "BleMidiBackendEsp32BleMidi requires Arduino-BLE-MIDI (lathoub) and FortySevenEffects MIDI library."
#endif

#include <MIDI.h>
#include <BLEMIDI_Transport.h>
#include <cstring>

// Transport selection rules:
// 1) IDRM_BLE_USE_CLASSIC: force classic ESP32 BLE backend.
// 2) IDRM_BLE_USE_NIMBLE: force NimBLE backend.
// 3) Default auto: prefer NimBLE when available, then fall back to classic.
#if defined(IDRM_BLE_USE_CLASSIC)
#if !__has_include(<hardware/BLEMIDI_ESP32.h>)
#error "IDRM_BLE_USE_CLASSIC is enabled but hardware/BLEMIDI_ESP32.h is missing."
#endif
#define IDRM_USE_BLEMIDI_ESP32_CLASSIC 1
#elif defined(IDRM_BLE_USE_NIMBLE)
#if !__has_include(<hardware/BLEMIDI_ESP32_NimBLE.h>)
#error "IDRM_BLE_USE_NIMBLE is enabled but hardware/BLEMIDI_ESP32_NimBLE.h is missing."
#endif
#define IDRM_USE_BLEMIDI_ESP32_NIMBLE 1
#else
#if __has_include(<hardware/BLEMIDI_ESP32_NimBLE.h>)
#define IDRM_USE_BLEMIDI_ESP32_NIMBLE 1
#elif __has_include(<hardware/BLEMIDI_ESP32.h>)
#define IDRM_USE_BLEMIDI_ESP32_CLASSIC 1
#else
#error "No supported ESP32 BLE-MIDI transport header found (expected BLEMIDI_ESP32_NimBLE.h or BLEMIDI_ESP32.h)."
#endif
#endif

#if defined(IDRM_USE_BLEMIDI_ESP32_NIMBLE)
#if !__has_include(<NimBLEDevice.h>)
#error "NimBLE transport selected but NimBLEDevice.h is missing. Install NimBLE-Arduino."
#endif
#include <NimBLEDevice.h>
#if !defined(ESP_LE_AUTH_BOND)
#define ESP_LE_AUTH_BOND 0x01
#endif
#if !__has_include(<NimBLESecurity.h>)
// Compatibility shim for newer NimBLE-Arduino releases where NimBLESecurity was removed.
class NimBLESecurity {
 public:
  void setAuthenticationMode(uint8_t authReq) { NimBLEDevice::setSecurityAuth(authReq); }
};
#endif
#include "BleMidiEsp32NimbleCompat.h"
#elif defined(IDRM_USE_BLEMIDI_ESP32_CLASSIC)
#if __has_include(<esp_arduino_version.h>)
#include <esp_arduino_version.h>
#if defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
#error "BLEMIDI_ESP32 classic backend is incompatible with ESP32 core >= 3. Use NimBLE transport."
#endif
#endif
#include <hardware/BLEMIDI_ESP32.h>
#endif

namespace idrm {

// Keep BLE-MIDI packet payload conservative for Web Bluetooth compatibility on hosts that
// negotiate small ATT MTU values (common 23-byte MTU => 20-byte payload).
struct IdrmBleTransportSettings {
  static constexpr size_t MaxBufferSize = 20;
};

}  // namespace idrm

// Public API transport instance for ESP32 BLE-MIDI.
#if defined(IDRM_USE_BLEMIDI_ESP32_NIMBLE)
using IdrmBleTransport =
    bleMidi::BLEMIDI_Transport<idrm::BleMidiEsp32NimbleCompat, idrm::IdrmBleTransportSettings>;
static IdrmBleTransport BLEMIDI("IDRM-BOOT");
MIDI_NAMESPACE::MidiInterface<IdrmBleTransport, bleMidi::MySettings> MIDI(
    static_cast<IdrmBleTransport&>(BLEMIDI));
#else
using IdrmBleTransport = bleMidi::BLEMIDI_Transport<bleMidi::BLEMIDI_ESP32, idrm::IdrmBleTransportSettings>;
static IdrmBleTransport BLEMIDI("IDRM-BOOT");
MIDI_NAMESPACE::MidiInterface<IdrmBleTransport, bleMidi::MySettings> MIDI(
    static_cast<IdrmBleTransport&>(BLEMIDI));
#endif

namespace idrm {

namespace {

BleMidiBackendEsp32BleMidi* gInstance = nullptr;

void onBleConnected() {
  if (gInstance) {
    gInstance->onConnected();
  }
}

void onBleDisconnected() {
  if (gInstance) {
    gInstance->onDisconnected();
  }
}

void onSystemExclusiveStatic(byte* data, unsigned length) {
  if (gInstance) {
    gInstance->onSystemExclusive(data, length);
  }
}

}  // namespace

BleMidiBackendEsp32BleMidi::BleMidiBackendEsp32BleMidi() = default;

bool BleMidiBackendEsp32BleMidi::begin(const char* deviceName) {
  if (!deviceName || strlen(deviceName) == 0) {
    started_ = false;
    connected_ = false;
    return false;
  }

  gInstance = this;
  connected_ = false;

  BLEMIDI.setName(deviceName);
  BLEMIDI.setHandleConnected(onBleConnected);
  BLEMIDI.setHandleDisconnected(onBleDisconnected);

  MIDI.setHandleSystemExclusive(onSystemExclusiveStatic);
  MIDI.begin(MIDI_CHANNEL_OMNI);
  MIDI.turnThruOff();

  started_ = true;
  return true;
}

void BleMidiBackendEsp32BleMidi::poll() {
  if (!started_) {
    return;
  }
  MIDI.read();
}

bool BleMidiBackendEsp32BleMidi::isConnected() const {
  return connected_;
}

void BleMidiBackendEsp32BleMidi::setReceiveCallback(ReceiveCallback callback) {
  receiveCallback_ = callback;
}

uint8_t BleMidiBackendEsp32BleMidi::midiChannelFromZeroBased(uint8_t channelZeroBased) {
  const uint8_t normalized = channelZeroBased & 0x0F;
  return normalized + 1;  // MIDI library uses channels 1..16.
}

void BleMidiBackendEsp32BleMidi::sendNoteOn(uint8_t channel, uint8_t note, uint8_t velocity) {
  if (!started_) {
    return;
  }
  MIDI.sendNoteOn(note, velocity, midiChannelFromZeroBased(channel));
}

void BleMidiBackendEsp32BleMidi::sendNoteOff(uint8_t channel, uint8_t note, uint8_t velocity) {
  if (!started_) {
    return;
  }
  MIDI.sendNoteOff(note, velocity, midiChannelFromZeroBased(channel));
}

void BleMidiBackendEsp32BleMidi::sendControlChange(uint8_t channel, uint8_t cc, uint8_t value) {
  if (!started_) {
    return;
  }
  MIDI.sendControlChange(cc, value, midiChannelFromZeroBased(channel));
}

void BleMidiBackendEsp32BleMidi::sendSysEx(const uint8_t* data, size_t length) {
  if (!started_ || !data || length == 0) {
    return;
  }

  MIDI.sendSysEx(static_cast<unsigned>(length), data, true);
}

void BleMidiBackendEsp32BleMidi::onConnected() {
  connected_ = true;
  if (Serial) {
    Serial.println("[IDRM][BLE] connected");
  }
}

void BleMidiBackendEsp32BleMidi::onDisconnected() {
  connected_ = false;
  if (Serial) {
    Serial.println("[IDRM][BLE] disconnected");
  }
}

void BleMidiBackendEsp32BleMidi::onSystemExclusive(const uint8_t* data, size_t length) {
  if (!receiveCallback_ || !data || length == 0) {
    return;
  }

  size_t outLength = 0;

  const bool hasBoundaries = data[0] == 0xF0 && data[length - 1] == 0xF7;
  if (hasBoundaries) {
    outLength = min(length, sizeof(sysExBuffer_));
    memcpy(sysExBuffer_, data, outLength);
  } else {
    if (length + 2 > sizeof(sysExBuffer_)) {
      return;
    }
    sysExBuffer_[0] = 0xF0;
    memcpy(&sysExBuffer_[1], data, length);
    sysExBuffer_[length + 1] = 0xF7;
    outLength = length + 2;
  }

  IncomingMidiMessage message;
  message.isSysEx = true;
  message.sysExData = sysExBuffer_;
  message.sysExLength = outLength;
  receiveCallback_(message);
}

}  // namespace idrm
