using Microsoft.JSInterop;
using MusicTheory.Core.Midi;

namespace MusicNotation.Editor.Services;

public sealed class MidiService : IMidiService, IAsyncDisposable
{
    private readonly IJSRuntime jsRuntime;
    private readonly SemaphoreSlim moduleGate = new(1, 1);
    private readonly MidiActiveNotesTracker activeTracker = new();
    private readonly object sync = new();

    private IJSObjectReference? module;
    private DotNetObjectReference<MidiService>? dotNetRef;
    private bool initialized;
    private bool supported = true;
    private string? connectedInputId;
    private HashSet<int> activeMidiNotes = [];

    public MidiService(IJSRuntime jsRuntime)
    {
        this.jsRuntime = jsRuntime ?? throw new ArgumentNullException(nameof(jsRuntime));
    }

    public bool IsInitialized => initialized;
    public bool IsSupported => supported;
    public string? ConnectedInputId => connectedInputId;

    public IReadOnlyCollection<int> ActiveMidiNotes
    {
        get
        {
            lock (sync)
            {
                return activeMidiNotes.ToArray();
            }
        }
    }

    public bool SustainPedalDown
    {
        get
        {
            lock (sync)
            {
                return activeTracker.SustainPedalDown;
            }
        }
    }

    public event EventHandler<ParsedMidiMessage>? MessageReceived;
    public event EventHandler? PortsChanged;
    public event EventHandler<IReadOnlyCollection<int>>? ActiveMidiNotesChanged;

    public async Task InitializeAsync()
    {
        if (initialized)
        {
            return;
        }

        var jsModule = await EnsureModuleAsync().ConfigureAwait(false);
        try
        {
            dotNetRef ??= DotNetObjectReference.Create(this);
            _ = await jsModule.InvokeAsync<MidiPortsSnapshotDto>("init", dotNetRef, new { sysex = false }).ConfigureAwait(false);
            initialized = true;
            supported = true;
            PortsChanged?.Invoke(this, EventArgs.Empty);
        }
        catch (JSException exception) when (IsNotSupported(exception))
        {
            supported = false;
            throw new NotSupportedException(
                "Web MIDI is not supported in this browser or secure context. Use a Chromium browser over HTTPS or localhost.",
                exception);
        }
    }

    public async Task<IReadOnlyList<MidiPortInfo>> GetPortsAsync()
    {
        if (!initialized)
        {
            await InitializeAsync().ConfigureAwait(false);
        }

        if (!supported)
        {
            return Array.Empty<MidiPortInfo>();
        }

        var jsModule = await EnsureModuleAsync().ConfigureAwait(false);
        var snapshot = await jsModule.InvokeAsync<MidiPortsSnapshotDto>("listPorts").ConfigureAwait(false);
        return ConvertPorts(snapshot);
    }

    public async Task ConnectInputAsync(string inputId)
    {
        if (string.IsNullOrWhiteSpace(inputId))
        {
            throw new ArgumentException("Input id cannot be empty.", nameof(inputId));
        }

        if (!initialized)
        {
            await InitializeAsync().ConfigureAwait(false);
        }

        if (!supported)
        {
            return;
        }

        var jsModule = await EnsureModuleAsync().ConfigureAwait(false);
        await jsModule.InvokeVoidAsync("connectInput", inputId).ConfigureAwait(false);
        connectedInputId = inputId;
    }

    public async Task DisconnectInputAsync()
    {
        if (!initialized || !supported)
        {
            connectedInputId = null;
            ResetTracker(notify: true);
            return;
        }

        var jsModule = await EnsureModuleAsync().ConfigureAwait(false);
        await jsModule.InvokeVoidAsync("disconnectInput").ConfigureAwait(false);
        connectedInputId = null;
        ResetTracker(notify: true);
    }

    public async Task SendMessageAsync(string outputId, byte[] data, double? whenMs = null)
    {
        if (string.IsNullOrWhiteSpace(outputId) || data is null || data.Length == 0)
        {
            return;
        }

        if (!initialized)
        {
            await InitializeAsync().ConfigureAwait(false);
        }

        if (!supported)
        {
            return;
        }

        var jsModule = await EnsureModuleAsync().ConfigureAwait(false);
        await jsModule.InvokeVoidAsync("sendMessage", outputId, data, whenMs).ConfigureAwait(false);
    }

    public Task SendNoteOnAsync(string outputId, int channel, int note, int velocity, double? whenMs = null)
    {
        return SendNoteAsync(outputId, "sendNoteOn", channel, note, velocity, whenMs);
    }

    public Task SendNoteOffAsync(string outputId, int channel, int note, int velocity, double? whenMs = null)
    {
        return SendNoteAsync(outputId, "sendNoteOff", channel, note, velocity, whenMs);
    }

    public async Task<double> GetNowMsAsync()
    {
        if (!supported)
        {
            return 0;
        }

        try
        {
            var jsModule = await EnsureModuleAsync().ConfigureAwait(false);
            return await jsModule.InvokeAsync<double>("nowMs").ConfigureAwait(false);
        }
        catch
        {
            return 0;
        }
    }

    [JSInvokable]
    public Task OnMidiMessage(MidiMessageDto message)
    {
        message ??= new MidiMessageDto();
        var data = ToMidiBytes(message.Data);
        var parsed = MidiMessageParser.Parse(
            data: data,
            timestampMs: message.Timestamp,
            deviceId: message.DeviceId);
        var wrapped = ToWrappedMessage(parsed);

        IReadOnlyCollection<int>? notesSnapshot = null;
        var changed = false;

        lock (sync)
        {
            changed = activeTracker.Apply(parsed);
            if (changed)
            {
                activeMidiNotes = activeTracker.ActiveMidiNotes
                    .OrderBy(midi => midi)
                    .ToHashSet();
                notesSnapshot = activeMidiNotes.ToArray();
            }
        }

        MessageReceived?.Invoke(this, wrapped);
        if (changed && notesSnapshot is not null)
        {
            ActiveMidiNotesChanged?.Invoke(this, notesSnapshot);
        }

        return Task.CompletedTask;
    }

    private static byte[] ToMidiBytes(IEnumerable<int>? payload)
    {
        if (payload is null)
        {
            return Array.Empty<byte>();
        }

        return payload
            .Select(value => (byte)Math.Clamp(value, 0, 255))
            .ToArray();
    }

    [JSInvokable]
    public Task OnMidiStateChanged()
    {
        PortsChanged?.Invoke(this, EventArgs.Empty);
        return Task.CompletedTask;
    }

    private async Task<IJSObjectReference> EnsureModuleAsync()
    {
        if (module is not null)
        {
            return module;
        }

        await moduleGate.WaitAsync().ConfigureAwait(false);
        try
        {
            if (module is null)
            {
                module = await jsRuntime.InvokeAsync<IJSObjectReference>(
                    "import",
                    "./_content/Zyphonote.MusicNotation.Editor/midiInterop.js").ConfigureAwait(false);
            }

            return module;
        }
        finally
        {
            moduleGate.Release();
        }
    }

    private async Task SendNoteAsync(
        string outputId,
        string methodName,
        int channel,
        int note,
        int velocity,
        double? whenMs)
    {
        if (string.IsNullOrWhiteSpace(outputId))
        {
            return;
        }

        if (!initialized)
        {
            await InitializeAsync().ConfigureAwait(false);
        }

        if (!supported)
        {
            return;
        }

        var jsModule = await EnsureModuleAsync().ConfigureAwait(false);
        await jsModule.InvokeVoidAsync(
            methodName,
            outputId,
            Math.Clamp(channel, 0, 15),
            Math.Clamp(note, 0, 127),
            Math.Clamp(velocity, 0, 127),
            whenMs).ConfigureAwait(false);
    }

    private void ResetTracker(bool notify)
    {
        IReadOnlyCollection<int>? snapshot = null;
        lock (sync)
        {
            activeTracker.Reset();
            if (activeMidiNotes.Count == 0)
            {
                return;
            }

            activeMidiNotes.Clear();
            snapshot = Array.Empty<int>();
        }

        if (notify && snapshot is not null)
        {
            ActiveMidiNotesChanged?.Invoke(this, snapshot);
        }
    }

    private static bool IsNotSupported(JSException exception)
    {
        return exception.Message.Contains("Web MIDI", StringComparison.OrdinalIgnoreCase) ||
               exception.Message.Contains("requestMIDIAccess", StringComparison.OrdinalIgnoreCase) ||
               exception.Message.Contains("not supported", StringComparison.OrdinalIgnoreCase);
    }

    private static ParsedMidiMessage ToWrappedMessage(MidiParsedMessage message)
    {
        return new ParsedMidiMessage(
            Type: message.Type switch
            {
                MidiMessageKind.NoteOn => MidiMessageType.NoteOn,
                MidiMessageKind.NoteOff => MidiMessageType.NoteOff,
                MidiMessageKind.ControlChange => MidiMessageType.ControlChange,
                MidiMessageKind.ProgramChange => MidiMessageType.ProgramChange,
                MidiMessageKind.PitchBend => MidiMessageType.PitchBend,
                _ => MidiMessageType.Unknown
            },
            Channel: message.Channel,
            Note: message.Note,
            Velocity: message.Velocity,
            Controller: message.Controller,
            Value: message.Value,
            Timestamp: message.TimestampMs,
            DeviceId: message.DeviceId,
            Data: message.Data);
    }

    private static IReadOnlyList<MidiPortInfo> ConvertPorts(MidiPortsSnapshotDto? snapshot)
    {
        if (snapshot is null)
        {
            return Array.Empty<MidiPortInfo>();
        }

        var ports = new List<MidiPortInfo>();
        ports.AddRange(ConvertPortList(snapshot.Inputs, MidiPortDirection.Input));
        ports.AddRange(ConvertPortList(snapshot.Outputs, MidiPortDirection.Output));

        return ports
            .OrderBy(port => port.Direction)
            .ThenBy(port => port.Name, StringComparer.OrdinalIgnoreCase)
            .ThenBy(port => port.Id, StringComparer.Ordinal)
            .ToArray();
    }

    private static IEnumerable<MidiPortInfo> ConvertPortList(
        IEnumerable<MidiPortDto>? ports,
        MidiPortDirection direction)
    {
        if (ports is null)
        {
            yield break;
        }

        foreach (var port in ports)
        {
            if (port is null)
            {
                continue;
            }

            var id = string.IsNullOrWhiteSpace(port.Id) ? string.Empty : port.Id;
            if (id.Length == 0)
            {
                continue;
            }

            yield return new MidiPortInfo(
                Id: id,
                Name: string.IsNullOrWhiteSpace(port.Name) ? "(unnamed)" : port.Name,
                Manufacturer: string.IsNullOrWhiteSpace(port.Manufacturer) ? "(unknown)" : port.Manufacturer,
                State: string.IsNullOrWhiteSpace(port.State) ? "unknown" : port.State,
                Connection: string.IsNullOrWhiteSpace(port.Connection) ? "unknown" : port.Connection,
                Direction: direction);
        }
    }

    public async ValueTask DisposeAsync()
    {
        moduleGate.Dispose();
        dotNetRef?.Dispose();
        dotNetRef = null;

        if (module is null)
        {
            return;
        }

        try
        {
            await module.DisposeAsync().ConfigureAwait(false);
        }
        catch
        {
            // Ignore disposal errors during navigation/shutdown.
        }
        finally
        {
            module = null;
        }
    }

    private sealed class MidiPortsSnapshotDto
    {
        public List<MidiPortDto> Inputs { get; set; } = [];
        public List<MidiPortDto> Outputs { get; set; } = [];
    }

    private sealed class MidiPortDto
    {
        public string? Id { get; set; }
        public string? Name { get; set; }
        public string? Manufacturer { get; set; }
        public string? State { get; set; }
        public string? Connection { get; set; }
    }
}
