let midiAccess = null;
let dotNetRef = null;
let connectedInput = null;
let connectedInputId = null;

function ensureSupported() {
    if (!navigator || typeof navigator.requestMIDIAccess !== "function") {
        throw new Error("Web MIDI API is not supported in this browser.");
    }
}

function toPortInfo(port) {
    if (!port) {
        return null;
    }

    return {
        id: String(port.id || ""),
        name: String(port.name || "(unnamed)"),
        manufacturer: String(port.manufacturer || "(unknown)"),
        state: String(port.state || "unknown"),
        connection: String(port.connection || "unknown")
    };
}

function listPortSet() {
    if (!midiAccess) {
        return { inputs: [], outputs: [] };
    }

    const inputs = [];
    const outputs = [];

    for (const port of midiAccess.inputs.values()) {
        const mapped = toPortInfo(port);
        if (mapped) {
            inputs.push(mapped);
        }
    }

    for (const port of midiAccess.outputs.values()) {
        const mapped = toPortInfo(port);
        if (mapped) {
            outputs.push(mapped);
        }
    }

    return { inputs, outputs };
}

function disconnectCurrentInput() {
    if (connectedInput) {
        connectedInput.onmidimessage = null;
    }

    connectedInput = null;
    connectedInputId = null;
}

function handleMidiMessage(event) {
    if (!dotNetRef) {
        return;
    }

    const sourceId =
        (event.currentTarget && event.currentTarget.id) ||
        connectedInputId ||
        null;
    const payload = event.data ? Array.from(event.data) : [];
    const timestamp = Number.isFinite(event.timeStamp) ? event.timeStamp : performance.now();

    dotNetRef.invokeMethodAsync("OnMidiMessage", {
        deviceId: sourceId,
        timestamp,
        data: payload
    });
}

function handleStateChange() {
    if (connectedInputId && midiAccess) {
        const current = midiAccess.inputs.get(connectedInputId);
        if (!current) {
            disconnectCurrentInput();
        }
    }

    if (dotNetRef) {
        dotNetRef.invokeMethodAsync("OnMidiStateChanged");
    }
}

function toUint8Array(bytesArray) {
    if (bytesArray instanceof Uint8Array) {
        return bytesArray;
    }

    if (!Array.isArray(bytesArray)) {
        return new Uint8Array(0);
    }

    return new Uint8Array(bytesArray.map((value) => Number(value) & 0xff));
}

function resolveScheduleTimestamp(whenTimestampMsOptional) {
    if (whenTimestampMsOptional === null || whenTimestampMsOptional === undefined) {
        return undefined;
    }

    const raw = Number(whenTimestampMsOptional);
    if (!Number.isFinite(raw)) {
        return undefined;
    }

    if (raw < 10_000_000) {
        return performance.now() + Math.max(0, raw);
    }

    return raw;
}

export async function init(dotNetRefArg, options) {
    ensureSupported();

    dotNetRef = dotNetRefArg || null;
    const sysex = !!(options && options.sysex);
    midiAccess = await navigator.requestMIDIAccess({ sysex });
    midiAccess.onstatechange = handleStateChange;

    return listPortSet();
}

export function listPorts() {
    return listPortSet();
}

export function connectInput(inputId) {
    if (!midiAccess) {
        throw new Error("MIDI access is not initialized.");
    }

    disconnectCurrentInput();

    const id = String(inputId || "");
    const input = midiAccess.inputs.get(id);
    if (!input) {
        throw new Error(`MIDI input '${id}' was not found.`);
    }

    connectedInput = input;
    connectedInputId = id;
    connectedInput.onmidimessage = handleMidiMessage;
}

export function disconnectInput() {
    disconnectCurrentInput();
}

export function sendMessage(outputId, bytesArray, whenTimestampMsOptional) {
    if (!midiAccess) {
        throw new Error("MIDI access is not initialized.");
    }

    const id = String(outputId || "");
    const output = midiAccess.outputs.get(id);
    if (!output) {
        return;
    }

    const bytes = toUint8Array(bytesArray);
    if (bytes.length === 0) {
        return;
    }

    const timestamp = resolveScheduleTimestamp(whenTimestampMsOptional);
    if (timestamp === undefined) {
        output.send(bytes);
        return;
    }

    output.send(bytes, timestamp);
}

export function sendNoteOn(outputId, channel, note, velocity, whenTimestampMsOptional) {
    const status = 0x90 | (Number(channel) & 0x0f);
    const data = [status, Number(note) & 0x7f, Number(velocity) & 0x7f];
    sendMessage(outputId, data, whenTimestampMsOptional);
}

export function sendNoteOff(outputId, channel, note, velocity, whenTimestampMsOptional) {
    const status = 0x80 | (Number(channel) & 0x0f);
    const data = [status, Number(note) & 0x7f, Number(velocity) & 0x7f];
    sendMessage(outputId, data, whenTimestampMsOptional);
}

export function nowMs() {
    return performance.now();
}
