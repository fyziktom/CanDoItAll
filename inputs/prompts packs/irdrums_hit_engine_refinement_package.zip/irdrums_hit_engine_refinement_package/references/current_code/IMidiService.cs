namespace MusicNotation.Editor.Services;

public interface IMidiService
{
    bool IsInitialized { get; }
    bool IsSupported { get; }
    string? ConnectedInputId { get; }
    IReadOnlyCollection<int> ActiveMidiNotes { get; }
    bool SustainPedalDown { get; }

    Task InitializeAsync();
    Task<IReadOnlyList<MidiPortInfo>> GetPortsAsync();
    Task ConnectInputAsync(string inputId);
    Task DisconnectInputAsync();
    Task SendMessageAsync(string outputId, byte[] data, double? whenMs = null);
    Task SendNoteOnAsync(string outputId, int channel, int note, int velocity, double? whenMs = null);
    Task SendNoteOffAsync(string outputId, int channel, int note, int velocity, double? whenMs = null);
    Task<double> GetNowMsAsync();

    event EventHandler<ParsedMidiMessage>? MessageReceived;
    event EventHandler? PortsChanged;
    event EventHandler<IReadOnlyCollection<int>>? ActiveMidiNotesChanged;
}
