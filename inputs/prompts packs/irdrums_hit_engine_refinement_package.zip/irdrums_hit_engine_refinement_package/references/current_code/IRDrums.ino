#include <M5Unified.h>
#include <Preferences.h>
#include <ArduinoJson.h>

#include "src/BleMidiBackendEsp32BleMidi.h"
#include "src/Protocol.h"

using namespace idrm;

namespace {

static constexpr char kFirmwareVersion[] = "0.1.3-irdrums";
static constexpr char kPrefsNamespace[] = "irdrums";

static constexpr uint8_t kMaxBeacons = 24;
static constexpr uint8_t kDefaultBeaconCount = 20;
static constexpr uint16_t kMaxFrameSamples = 256;

static constexpr uint8_t kMaxCatchUpSamples = 96;
static constexpr uint16_t kBusyWaitThresholdUs = 180;
static constexpr uint32_t kIdleYieldIntervalUs = 2000;

static constexpr uint8_t kUiPages = 3;
static constexpr uint32_t kUiRefreshMs = 50;
static constexpr uint32_t kSerialHealthMs = 1000;
static constexpr uint32_t kButtonMultiClickWindowMs = 360;
static constexpr uint8_t kSpectrogramRows = 92;

static constexpr uint32_t kConfigMagic = 0x4952444Du;  // "IRDM"
static constexpr uint16_t kConfigVersion = 1;

static constexpr uint8_t kMsgMapSelectReq = 0x20;
static constexpr uint8_t kMsgMapSelectResp = 0x21;
static constexpr uint8_t kMsgMapListReq = 0x22;
static constexpr uint8_t kMsgMapListResp = 0x23;
static constexpr uint8_t kMsgSaveReq = 0x24;
static constexpr uint8_t kMsgSaveResp = 0x25;
static constexpr uint8_t kMsgSetFreqReq = 0x26;
static constexpr uint8_t kMsgSetFreqResp = 0x27;
static constexpr uint8_t kMsgSetSensitivityReq = 0x28;
static constexpr uint8_t kMsgSetSensitivityResp = 0x29;

static constexpr uint16_t kDefaultFrequencies[kDefaultBeaconCount] = {
    1280, 1410, 1540, 1670, 1800, 1930, 2060, 2190, 2320, 2450,
    2580, 2710, 2840, 2970, 3100, 3240, 3380, 3520, 3660, 3800,
};

static constexpr uint8_t kDefaultNotes[kDefaultBeaconCount] = {
    36, 38, 42, 46, 48, 45, 50, 49, 51, 43,
    41, 47, 57, 55, 52, 54, 56, 39, 40, 37,
};

static constexpr const char* kDefaultLabels[kDefaultBeaconCount] = {
    "KICK", "SNARE", "HH_C", "HH_O", "TOM1", "TOM2", "TOM3", "CR1", "RD1", "FLR",
    "LOM", "MID", "CR2", "SPL", "CHN", "TAB", "COW", "CLP", "RIM", "SD2",
};

float clampf(float value, float lo, float hi) {
  if (value < lo) {
    return lo;
  }
  if (value > hi) {
    return hi;
  }
  return value;
}

float sqrf(float x) {
  return x * x;
}

float vectorNorm3(float x, float y, float z) {
  return sqrtf(sqrf(x) + sqrf(y) + sqrf(z));
}

struct BeaconSlot {
  uint16_t frequencyHz {0};
  uint8_t note {38};
  uint8_t channel {9};
  uint8_t velocityMin {20};
  uint8_t velocityMax {127};
  uint8_t enabled {1};
  char label[12] {0};
};

struct IRDrumsConfig {
  uint32_t magic {kConfigMagic};
  uint16_t version {kConfigVersion};
  char uid[9] {"00000000"};
  char deviceName[24] {"IRDrums"};

  int8_t aoPin {36};
  int8_t doPin {-1};
  uint16_t sampleRateHz {10000};
  uint16_t frameSamples {96};
  float smoothingAlpha {0.35f};
  float confidenceThreshold {0.30f};
  float dominanceThreshold {0.18f};
  float winnerShareThreshold {0.28f};
  float minWinnerMagnitude {2.0f};
  uint16_t switchHoldMs {8};

  float armAccelG {0.45f};
  float hitAccelG {1.10f};
  float hitGyroDps {125.0f};
  float releaseAccelG {0.25f};
  uint16_t refractoryMs {45};
  uint8_t hitSensitivityLevel {5};

  uint8_t sendNoteOff {1};
  uint16_t noteLengthMs {22};

  uint8_t beaconCount {kDefaultBeaconCount};
  BeaconSlot slots[kMaxBeacons] {};
};

struct ScannerConfig {
  int8_t aoPin {36};
  int8_t doPin {-1};
  uint16_t sampleRateHz {10000};
  uint16_t frameSamples {96};
  float smoothingAlpha {0.35f};
  float confidenceThreshold {0.30f};
  float dominanceThreshold {0.18f};
  float winnerShareThreshold {0.28f};
  float minWinnerMagnitude {2.0f};
  uint16_t switchHoldMs {8};
  uint8_t beaconCount {0};
  uint16_t frequenciesHz[kMaxBeacons] {};
};

struct ScannerSnapshot {
  bool running {false};
  int8_t aoPin {36};
  int8_t doPin {-1};
  int8_t doState {-1};
  uint8_t beaconCount {0};

  uint16_t rawAdc {0};
  uint16_t rawMinAdc {0};
  uint16_t rawMaxAdc {0};

  uint16_t configuredSampleRateHz {0};
  float measuredSampleRateHz {0.0f};
  uint16_t frameSamples {0};
  uint32_t frameTimeUs {0};
  uint32_t frameCount {0};
  uint32_t droppedCycles {0};

  float confidence {0.0f};
  float dominance {0.0f};
  float winnerShare {0.0f};
  float peakToNoise {0.0f};
  float noiseFloor {0.0f};
  float dynamicMinMagnitude {0.0f};
  float winnerMagnitude {0.0f};
  float secondMagnitude {0.0f};
  float totalMagnitude {0.0f};

  int8_t candidateIndex {-1};
  int8_t winnerIndex {-1};
  int8_t activeIndex {-1};
  uint8_t activeLatched {0};

  uint16_t frequenciesHz[kMaxBeacons] {};
  float magnitudes[kMaxBeacons] {};
  int8_t topIndex[3] {-1, -1, -1};
  float topMagnitude[3] {0.0f, 0.0f, 0.0f};
};

class IRScanner {
 public:
  void configure(const ScannerConfig& config);
  ScannerSnapshot snapshot() const;

 private:
  static void workerEntry(void* arg);
  void workerLoop();

  ScannerConfig sanitize(const ScannerConfig& in) const;
  float makeCoeff(float sampleRateHz, float targetHz) const;
  float goertzelMagnitude(const float* samples, uint16_t count, float coeff) const;
  void applyInputSetup();
  void buildWindow();
  void buildCoefficients();
  void resetRuntime();
  void updateTop(ScannerSnapshot& snap);
  void processFrame(uint32_t frameDurationUs);

  mutable portMUX_TYPE lock_ = portMUX_INITIALIZER_UNLOCKED;
  TaskHandle_t taskHandle_ {nullptr};

  ScannerConfig pendingConfig_ {};
  ScannerConfig activeConfig_ {};
  uint32_t configRevision_ {0};
  uint32_t appliedRevision_ {0};

  ScannerSnapshot snapshot_ {};

  uint16_t rawFrame_[kMaxFrameSamples] {};
  float frameWork_[kMaxFrameSamples] {};
  float window_[kMaxFrameSamples] {};
  float coeff_[kMaxBeacons] {};
  float smoothMagnitude_[kMaxBeacons] {};

  bool smoothReady_ {false};

  uint16_t frameIndex_ {0};
  uint32_t frameSum_ {0};
  uint32_t frameWallStartUs_ {0};
  uint16_t frameMin_ {4095};
  uint16_t frameMax_ {0};

  uint32_t samplePeriodUs_ {100};
  uint32_t nextSampleUs_ {0};
  uint32_t droppedCycles_ {0};
  uint32_t lastIdleYieldUs_ {0};
  uint16_t lastRawAdc_ {0};

  int8_t stableCandidate_ {-1};
  uint32_t stableSinceMs_ {0};
  int8_t activeIndex_ {-1};
  uint32_t lastValidMs_ {0};
  float noiseFloor_ {0.0f};
};

void IRScanner::configure(const ScannerConfig& config) {
  ScannerConfig sanitized = sanitize(config);

  bool shouldCreateTask = false;
  taskENTER_CRITICAL(&lock_);
  pendingConfig_ = sanitized;
  configRevision_++;
  if (taskHandle_ == nullptr) {
    shouldCreateTask = true;
  }
  taskEXIT_CRITICAL(&lock_);

  if (shouldCreateTask) {
    TaskHandle_t task = nullptr;
    BaseType_t ok = xTaskCreatePinnedToCore(&IRScanner::workerEntry, "IRScanWorker", 8192, this, 1, &task, 0);
    if (ok != pdPASS) {
      ok = xTaskCreate(&IRScanner::workerEntry, "IRScanWorker", 8192, this, 1, &task);
    }

    taskENTER_CRITICAL(&lock_);
    if (ok == pdPASS) {
      taskHandle_ = task;
    }
    taskEXIT_CRITICAL(&lock_);
  }
}

ScannerSnapshot IRScanner::snapshot() const {
  ScannerSnapshot out;
  taskENTER_CRITICAL(&lock_);
  out = snapshot_;
  taskEXIT_CRITICAL(&lock_);
  return out;
}

void IRScanner::workerEntry(void* arg) {
  auto* self = static_cast<IRScanner*>(arg);
  if (self) {
    self->workerLoop();
  }
  vTaskDelete(nullptr);
}

ScannerConfig IRScanner::sanitize(const ScannerConfig& in) const {
  ScannerConfig cfg = in;
  if (cfg.aoPin < 0) {
    cfg.aoPin = 36;
  }
  if (cfg.doPin < -1) {
    cfg.doPin = -1;
  }

  cfg.sampleRateHz = constrain(cfg.sampleRateHz, 6200, 14000);
  cfg.frameSamples = constrain(cfg.frameSamples, 64, kMaxFrameSamples);
  cfg.smoothingAlpha = clampf(cfg.smoothingAlpha, 0.02f, 0.95f);
  cfg.confidenceThreshold = clampf(cfg.confidenceThreshold, 0.02f, 0.98f);
  cfg.dominanceThreshold = clampf(cfg.dominanceThreshold, 0.02f, 0.98f);
  cfg.winnerShareThreshold = clampf(cfg.winnerShareThreshold, 0.02f, 0.98f);
  cfg.minWinnerMagnitude = max(0.0f, cfg.minWinnerMagnitude);
  cfg.switchHoldMs = constrain(cfg.switchHoldMs, static_cast<uint16_t>(6), static_cast<uint16_t>(300));
  cfg.beaconCount = constrain(cfg.beaconCount, static_cast<uint8_t>(1), kMaxBeacons);

  for (uint8_t i = 0; i < cfg.beaconCount; ++i) {
    cfg.frequenciesHz[i] = constrain(cfg.frequenciesHz[i], static_cast<uint16_t>(700), static_cast<uint16_t>(5600));
  }

  return cfg;
}

float IRScanner::makeCoeff(float sampleRateHz, float targetHz) const {
  const float omega = 2.0f * PI * targetHz / max(1.0f, sampleRateHz);
  return 2.0f * cosf(omega);
}

float IRScanner::goertzelMagnitude(const float* samples, uint16_t count, float coeff) const {
  float q0 = 0.0f;
  float q1 = 0.0f;
  float q2 = 0.0f;

  for (uint16_t i = 0; i < count; ++i) {
    q0 = (coeff * q1) - q2 + samples[i];
    q2 = q1;
    q1 = q0;
  }

  const float power = (q1 * q1) + (q2 * q2) - (coeff * q1 * q2);
  if (power <= 0.0f) {
    return 0.0f;
  }
  return sqrtf(power) / static_cast<float>(count);
}

void IRScanner::applyInputSetup() {
  pinMode(activeConfig_.aoPin, INPUT);
  if (activeConfig_.doPin >= 0) {
    pinMode(activeConfig_.doPin, INPUT);
  }

  analogReadResolution(12);
#if defined(ADC_ATTEN_DB_12)
  analogSetPinAttenuation(activeConfig_.aoPin, ADC_ATTEN_DB_12);
#elif defined(ADC_11db)
  analogSetPinAttenuation(activeConfig_.aoPin, ADC_11db);
#endif
}

void IRScanner::buildWindow() {
  const uint16_t n = activeConfig_.frameSamples;
  if (n < 2) {
    window_[0] = 1.0f;
    return;
  }

  for (uint16_t i = 0; i < n; ++i) {
    const float phase = (2.0f * PI * static_cast<float>(i)) / static_cast<float>(n - 1U);
    window_[i] = 0.5f - (0.5f * cosf(phase));
  }
}

void IRScanner::buildCoefficients() {
  const float sampleRateHz = 1000000.0f / static_cast<float>(max<uint32_t>(1, samplePeriodUs_));
  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    coeff_[i] = makeCoeff(sampleRateHz, static_cast<float>(activeConfig_.frequenciesHz[i]));
    smoothMagnitude_[i] = 0.0f;
  }
}

void IRScanner::resetRuntime() {
  frameIndex_ = 0;
  frameSum_ = 0;
  frameWallStartUs_ = 0;
  frameMin_ = 4095;
  frameMax_ = 0;
  nextSampleUs_ = 0;
  droppedCycles_ = 0;
  lastIdleYieldUs_ = 0;
  lastRawAdc_ = 0;

  smoothReady_ = false;
  stableCandidate_ = -1;
  stableSinceMs_ = 0;
  activeIndex_ = -1;
  lastValidMs_ = 0;
  noiseFloor_ = 0.0f;

  taskENTER_CRITICAL(&lock_);
  snapshot_ = ScannerSnapshot{};
  snapshot_.running = true;
  snapshot_.aoPin = activeConfig_.aoPin;
  snapshot_.doPin = activeConfig_.doPin;
  snapshot_.beaconCount = activeConfig_.beaconCount;
  snapshot_.configuredSampleRateHz = activeConfig_.sampleRateHz;
  snapshot_.frameSamples = activeConfig_.frameSamples;
  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    snapshot_.frequenciesHz[i] = activeConfig_.frequenciesHz[i];
  }
  taskEXIT_CRITICAL(&lock_);
}

void IRScanner::updateTop(ScannerSnapshot& snap) {
  for (uint8_t i = 0; i < 3; ++i) {
    snap.topIndex[i] = -1;
    snap.topMagnitude[i] = 0.0f;
  }

  for (uint8_t i = 0; i < snap.beaconCount; ++i) {
    const float value = snap.magnitudes[i];
    if (value > snap.topMagnitude[0]) {
      snap.topMagnitude[2] = snap.topMagnitude[1];
      snap.topIndex[2] = snap.topIndex[1];
      snap.topMagnitude[1] = snap.topMagnitude[0];
      snap.topIndex[1] = snap.topIndex[0];
      snap.topMagnitude[0] = value;
      snap.topIndex[0] = static_cast<int8_t>(i);
    } else if (value > snap.topMagnitude[1]) {
      snap.topMagnitude[2] = snap.topMagnitude[1];
      snap.topIndex[2] = snap.topIndex[1];
      snap.topMagnitude[1] = value;
      snap.topIndex[1] = static_cast<int8_t>(i);
    } else if (value > snap.topMagnitude[2]) {
      snap.topMagnitude[2] = value;
      snap.topIndex[2] = static_cast<int8_t>(i);
    }
  }
}

void IRScanner::processFrame(uint32_t frameDurationUs) {
  const uint16_t n = activeConfig_.frameSamples;
  if (n == 0 || n > kMaxFrameSamples) {
    return;
  }

  const float mean = static_cast<float>(frameSum_) / static_cast<float>(n);
  for (uint16_t i = 0; i < n; ++i) {
    frameWork_[i] = (static_cast<float>(rawFrame_[i]) - mean) * window_[i];
  }

  float total = 0.0f;
  float best = -1.0f;
  float second = -1.0f;
  int8_t bestIndex = -1;
  float currentMagnitude[kMaxBeacons] {};

  const float alpha = activeConfig_.smoothingAlpha;
  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    const float mag = goertzelMagnitude(frameWork_, n, coeff_[i]);
    currentMagnitude[i] = mag;
    if (!smoothReady_) {
      smoothMagnitude_[i] = mag;
    } else {
      smoothMagnitude_[i] += alpha * (mag - smoothMagnitude_[i]);
    }
  }
  smoothReady_ = true;

  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    const float mag = currentMagnitude[i];
    total += mag;

    if (mag > best) {
      second = best;
      best = mag;
      bestIndex = static_cast<int8_t>(i);
    } else if (mag > second) {
      second = mag;
    }
  }

  if (second < 0.0f) {
    second = 0.0f;
  }

  const float eps = 1e-6f;
  const float residual = max(0.0f, total - max(0.0f, best));
  const float meanNoise = residual / static_cast<float>(max<uint8_t>(1, activeConfig_.beaconCount - 1U));
  if (noiseFloor_ <= 0.0f) {
    noiseFloor_ = meanNoise;
  } else {
    // Learn background faster when there is no clear winner, slower when a winner is present.
    const bool likelySignal = bestIndex >= 0 && best > (noiseFloor_ * 1.8f + activeConfig_.minWinnerMagnitude * 0.35f);
    const float beta = likelySignal ? 0.02f : 0.14f;
    noiseFloor_ += beta * (meanNoise - noiseFloor_);
  }
  noiseFloor_ = max(0.0f, noiseFloor_);

  const float dynamicMinMagnitude = max(activeConfig_.minWinnerMagnitude, noiseFloor_ * 1.35f + 0.25f);
  const float peakToNoise = best > 0.0f ? (best / (noiseFloor_ + 0.25f + eps)) : 0.0f;
  // Use top-two share to stay robust when many beacons are configured.
  const float winnerShare = best > 0.0f ? (best / (best + second + eps)) : 0.0f;
  const float dominance = best > 0.0f ? ((best - second) / (best + eps)) : 0.0f;
  const float strength = best > 0.0f ? (best / (best + dynamicMinMagnitude + eps)) : 0.0f;
  const float separability = clampf((peakToNoise - 1.0f) / 2.8f, 0.0f, 1.0f);
  const float confidence = clampf((0.45f * strength) + (0.30f * dominance) + (0.25f * separability), 0.0f, 1.0f);
  const float shareThreshold = clampf(activeConfig_.winnerShareThreshold, 0.12f, 0.92f);
  const bool basicSignal = bestIndex >= 0 && best >= dynamicMinMagnitude && peakToNoise >= 1.03f;
  const bool separated = (winnerShare >= shareThreshold) ||
                         (dominance >= (activeConfig_.dominanceThreshold * 0.85f)) ||
                         (confidence >= activeConfig_.confidenceThreshold);
  bool winnerValid = basicSignal && separated;

  float activeMagnitude = 0.0f;
  if (activeIndex_ >= 0 && activeIndex_ < static_cast<int8_t>(activeConfig_.beaconCount)) {
    activeMagnitude = currentMagnitude[activeIndex_];
  }

  // Fast takeover path: if a new beacon is clearly stronger than current active,
  // allow switching even when confidence terms briefly degrade during stick motion.
  const bool fastOverride = bestIndex >= 0 &&
                            bestIndex != activeIndex_ &&
                            best >= max(dynamicMinMagnitude * 0.80f, activeMagnitude * 1.20f + 0.20f) &&
                            peakToNoise >= 1.05f;
  if (!winnerValid && fastOverride) {
    winnerValid = true;
  }

  const uint32_t nowMs = millis();
  const int8_t candidate = winnerValid ? bestIndex : -1;

  if (candidate != stableCandidate_) {
    stableCandidate_ = candidate;
    stableSinceMs_ = nowMs;
  }

  if (candidate >= 0) {
    const bool acquiring = activeIndex_ < 0;
    const bool switchingToNew = activeIndex_ >= 0 && candidate != activeIndex_;
    uint16_t holdMs = activeConfig_.switchHoldMs;
    if (acquiring || switchingToNew) {
      holdMs = max<uint16_t>(2, static_cast<uint16_t>(activeConfig_.switchHoldMs / 2U));
    }

    const bool fastSwitch = switchingToNew &&
                            best >= (activeMagnitude * 1.30f + 0.30f) &&
                            dominance >= max(0.10f, activeConfig_.dominanceThreshold * 0.55f);
    if (fastSwitch || (nowMs - stableSinceMs_) >= holdMs) {
      activeIndex_ = candidate;
    }
    lastValidMs_ = nowMs;
  }

  ScannerSnapshot next;
  taskENTER_CRITICAL(&lock_);
  next = snapshot_;
  taskEXIT_CRITICAL(&lock_);

  next.running = true;
  next.aoPin = activeConfig_.aoPin;
  next.doPin = activeConfig_.doPin;
  next.doState = activeConfig_.doPin >= 0 ? digitalRead(activeConfig_.doPin) : -1;
  next.beaconCount = activeConfig_.beaconCount;
  next.rawAdc = lastRawAdc_;
  next.rawMinAdc = frameMin_;
  next.rawMaxAdc = frameMax_;
  next.configuredSampleRateHz = activeConfig_.sampleRateHz;
  next.measuredSampleRateHz = frameDurationUs == 0
                                  ? static_cast<float>(activeConfig_.sampleRateHz)
                                  : (1000000.0f * static_cast<float>(n)) / static_cast<float>(frameDurationUs);
  next.frameSamples = n;
  next.frameTimeUs = frameDurationUs;
  next.frameCount++;
  next.droppedCycles = droppedCycles_;

  next.confidence = confidence;
  next.dominance = dominance;
  next.winnerShare = winnerShare;
  next.peakToNoise = peakToNoise;
  next.noiseFloor = noiseFloor_;
  next.dynamicMinMagnitude = dynamicMinMagnitude;
  next.winnerMagnitude = max(0.0f, best);
  next.secondMagnitude = max(0.0f, second);
  next.totalMagnitude = total;
  next.candidateIndex = candidate;
  next.winnerIndex = bestIndex;
  next.activeIndex = activeIndex_;
  next.activeLatched = activeIndex_ >= 0 ? 1 : 0;

  for (uint8_t i = 0; i < activeConfig_.beaconCount; ++i) {
    next.frequenciesHz[i] = activeConfig_.frequenciesHz[i];
    next.magnitudes[i] = smoothMagnitude_[i];
  }

  updateTop(next);

  taskENTER_CRITICAL(&lock_);
  snapshot_ = next;
  taskEXIT_CRITICAL(&lock_);
}

void IRScanner::workerLoop() {
  for (;;) {
    bool changed = false;

    taskENTER_CRITICAL(&lock_);
    if (configRevision_ != appliedRevision_) {
      activeConfig_ = pendingConfig_;
      appliedRevision_ = configRevision_;
      changed = true;
    }
    taskEXIT_CRITICAL(&lock_);

    if (changed) {
      samplePeriodUs_ = max<uint32_t>(50, 1000000UL / max<uint16_t>(1, activeConfig_.sampleRateHz));
      applyInputSetup();
      buildWindow();
      buildCoefficients();
      resetRuntime();
    }

    if (appliedRevision_ == 0 || activeConfig_.beaconCount == 0) {
      vTaskDelay(pdMS_TO_TICKS(4));
      continue;
    }

    const uint32_t nowUs = micros();
    if (nextSampleUs_ == 0) {
      nextSampleUs_ = nowUs + samplePeriodUs_;
      lastIdleYieldUs_ = nowUs;
      continue;
    }

    const int32_t untilUs = static_cast<int32_t>(nextSampleUs_ - nowUs);
    if (untilUs > 0) {
      if (untilUs > static_cast<int32_t>(kBusyWaitThresholdUs)) {
        vTaskDelay(pdMS_TO_TICKS(1));
        lastIdleYieldUs_ = micros();
      } else {
        delayMicroseconds(static_cast<uint32_t>(untilUs));
      }
      continue;
    }

    uint8_t collected = 0;
    while (static_cast<int32_t>(micros() - nextSampleUs_) >= 0 && collected < kMaxCatchUpSamples) {
      const uint16_t raw = static_cast<uint16_t>(analogRead(activeConfig_.aoPin));
      lastRawAdc_ = raw;

      if (frameIndex_ == 0) {
        frameWallStartUs_ = micros();
        frameMin_ = 4095;
        frameMax_ = 0;
      }

      rawFrame_[frameIndex_] = raw;
      frameSum_ += raw;
      frameMin_ = min(frameMin_, raw);
      frameMax_ = max(frameMax_, raw);

      frameIndex_++;
      nextSampleUs_ += samplePeriodUs_;
      collected++;

      if (frameIndex_ >= activeConfig_.frameSamples) {
        const uint32_t frameDurationUs = max<uint32_t>(1, micros() - frameWallStartUs_);
        processFrame(frameDurationUs);
        frameIndex_ = 0;
        frameSum_ = 0;
      }
    }

    if (collected >= kMaxCatchUpSamples && static_cast<int32_t>(micros() - nextSampleUs_) >= 0) {
      droppedCycles_++;
      nextSampleUs_ = micros() + samplePeriodUs_;
    }

    const uint32_t guardUs = micros();
    if (lastIdleYieldUs_ == 0 || (guardUs - lastIdleYieldUs_) >= kIdleYieldIntervalUs) {
      vTaskDelay(pdMS_TO_TICKS(1));
      lastIdleYieldUs_ = micros();
    }
  }
}

struct PendingNote {
  bool active {false};
  uint8_t channel {9};
  uint8_t note {38};
  uint8_t velocity {100};
  uint32_t offAtMs {0};
};

struct PendingAssignment {
  bool active {false};
  int8_t requestedBeacon {-1};
  uint8_t note {38};
  uint8_t channel {9};
  uint8_t velocityMin {20};
  uint8_t velocityMax {127};
  char label[12] {0};
};

class IRDrumsApp {
 public:
  IRDrumsApp();
  void begin();
  void tick();

 private:
  static IRDrumsApp* instance_;
  static void onMidiMessageStatic(const IncomingMidiMessage& message);

  void onMidiMessage(const IncomingMidiMessage& message);
  void sendFrame(uint8_t sequence, MsgType type, const String& payload, uint8_t chunkIndex = 0, uint8_t chunkCount = 1);
  void sendChunked(uint8_t sequence, MsgType type, const String& payload);
  void sendNack(uint8_t sequence, const char* reason);

  void respondHello(uint8_t sequence);
  void handleArmReq(uint8_t sequence, const String& payload);
  void handleSaveReq(uint8_t sequence);
  void handleFactoryReset(uint8_t sequence);
  void handleSetFreqReq(uint8_t sequence, const String& payload);
  void handleSetSensitivityReq(uint8_t sequence, const String& payload);
  void handleMapSelectReq(uint8_t sequence, const String& payload);
  bool assignToBeacon(int8_t beaconIndex, const PendingAssignment& assignment, uint8_t responseSequence);
  void sendMappingList(uint8_t sequence, MsgType type);

  void applyScannerConfig();

  void processButtons();
  void processAssignmentClickWindow();
  void confirmPendingAssignment();
  float sensitivityScale() const;
  uint16_t computeRefractoryMs(float hitScore) const;
  void processImuAndHit();
  void triggerHit(uint32_t nowMs, float linearAccel, float gyroNorm, float hitScore);
  void scheduleNoteOff(uint8_t channel, uint8_t note, uint8_t velocity, uint16_t afterMs);
  void processNoteOffQueue();

  void drawHeader(const ScannerSnapshot& snap);
  void drawPageMain(const ScannerSnapshot& snap);
  void drawPageSpectrum(const ScannerSnapshot& snap);
  void drawPageMapping(const ScannerSnapshot& snap);
  void updateSpectrogram(const ScannerSnapshot& snap);
  void drawSpectrogram(const ScannerSnapshot& snap, int x, int y, int w, int h);
  uint16_t heatColor(uint8_t value) const;
  void drawUi(bool force);
  void logHealth();

  void makeDefaultConfig(IRDrumsConfig& out);
  bool validateConfig(IRDrumsConfig& cfg);
  void loadConfig();
  bool saveConfig();

  String detectUid() const;

  IRDrumsConfig config_ {};
  IRScanner scanner_ {};
  BleMidiBackendEsp32BleMidi midi_ {};

  PendingAssignment pendingAssignment_ {};
  PendingNote noteOffQueue_[10] {};

  bool armed_ {true};
  bool strokeTracking_ {false};
  uint32_t refractoryUntilMs_ {0};
  uint16_t lastRefractoryMs_ {0};
  uint32_t strokeStartMs_ {0};
  float prevImpactScore_ {0.0f};
  float strokePeakScore_ {0.0f};
  float strokePeakAccelG_ {0.0f};
  float strokePeakGyroDps_ {0.0f};
  float lastImpactScore_ {0.0f};
  float lastStrokePeakScore_ {0.0f};

  float lastLinearAccelG_ {0.0f};
  float lastGyroDps_ {0.0f};
  int8_t lastHitBeacon_ {-1};
  uint8_t lastHitNote_ {0};
  uint8_t lastHitVelocity_ {0};
  uint32_t lastHitAtMs_ {0};

  int8_t lastAssignedBeacon_ {-1};
  uint32_t lastAssignedAtMs_ {0};

  uint8_t uiPage_ {0};
  uint32_t lastUiDrawMs_ {0};
  uint32_t lastHealthLogMs_ {0};
  uint8_t spectrogram_[kSpectrogramRows][kMaxBeacons] {};
  uint32_t lastSpectrogramFrameCount_ {0};
  float spectrogramScale_ {1.0f};

  uint8_t btnBClickCount_ {0};
  uint32_t btnBLastReleaseMs_ {0};
  uint32_t protocolMuteUntilMs_ {0};

  String uidToken_ {"00000000"};
};

IRDrumsApp::IRDrumsApp() {
  instance_ = this;
}

void IRDrumsApp::begin() {
  auto cfg = M5.config();
  cfg.internal_imu = true;
  cfg.output_power = true;
  cfg.clear_display = true;
  cfg.serial_baudrate = 115200;
  cfg.fallback_board = m5::board_t::board_M5StickC;
  M5.begin(cfg);

  M5.Display.setRotation(0);
  M5.Display.setBrightness(180);
  M5.Display.setTextWrap(false);
  M5.Display.clear(TFT_BLACK);

  uidToken_ = detectUid();
  makeDefaultConfig(config_);
  loadConfig();

  Serial.println();
  Serial.printf("[IRDR] boot uid=%s name=%s\n", uidToken_.c_str(), config_.deviceName);
  Serial.printf("[IRDR] ir ao=%d fs=%u n=%u beacons=%u\n", config_.aoPin, config_.sampleRateHz, config_.frameSamples,
                config_.beaconCount);

  applyScannerConfig();
  memset(spectrogram_, 0, sizeof(spectrogram_));
  lastSpectrogramFrameCount_ = 0;
  spectrogramScale_ = 1.0f;

  midi_.setReceiveCallback(&IRDrumsApp::onMidiMessageStatic);
  const bool bleStarted = midi_.begin(config_.deviceName);
  armed_ = bleStarted;
  Serial.printf("[IRDR] ble_started=%d\n", bleStarted ? 1 : 0);

  drawUi(true);
}

void IRDrumsApp::tick() {
  M5.update();
  midi_.poll();

  processButtons();
  processImuAndHit();
  processNoteOffQueue();
  processAssignmentClickWindow();

  drawUi(false);
  logHealth();
}

void IRDrumsApp::onMidiMessageStatic(const IncomingMidiMessage& message) {
  if (instance_) {
    instance_->onMidiMessage(message);
  }
}

void IRDrumsApp::onMidiMessage(const IncomingMidiMessage& message) {
  if (!message.isSysEx || !message.sysExData || message.sysExLength < 2) {
    return;
  }

  SysExFrame frame;
  if (!Protocol::parseFrame(message.sysExData, message.sysExLength, frame)) {
    return;
  }

  const uint8_t msg = static_cast<uint8_t>(frame.type);
  switch (msg) {
    case static_cast<uint8_t>(MsgType::HelloReq):
      respondHello(frame.sequence);
      break;
    case static_cast<uint8_t>(MsgType::Ping):
      sendFrame(frame.sequence, MsgType::Pong, "{}");
      break;
    case static_cast<uint8_t>(MsgType::ArmReq):
      handleArmReq(frame.sequence, frame.payload);
      break;
    case static_cast<uint8_t>(MsgType::GetCfgReq):
    case kMsgMapListReq:
      sendMappingList(frame.sequence, static_cast<MsgType>(kMsgMapListResp));
      break;
    case kMsgMapSelectReq:
      handleMapSelectReq(frame.sequence, frame.payload);
      break;
    case kMsgSaveReq:
    case static_cast<uint8_t>(MsgType::SaveCfgReq):
      handleSaveReq(frame.sequence);
      break;
    case kMsgSetFreqReq:
      handleSetFreqReq(frame.sequence, frame.payload);
      break;
    case kMsgSetSensitivityReq:
      handleSetSensitivityReq(frame.sequence, frame.payload);
      break;
    case static_cast<uint8_t>(MsgType::FactoryResetReq):
      handleFactoryReset(frame.sequence);
      break;
    default:
      sendNack(frame.sequence, "unsupported_msg");
      break;
  }
}

void IRDrumsApp::sendFrame(uint8_t sequence, MsgType type, const String& payload, uint8_t chunkIndex, uint8_t chunkCount) {
  // Keep realtime note traffic out of chunked SysEx windows.
  protocolMuteUntilMs_ = max(protocolMuteUntilMs_, millis() + 45U);
  uint8_t out[256] {};
  const size_t length = Protocol::buildFrame(sequence, type, chunkIndex, chunkCount, payload, out, sizeof(out));
  if (length > 0) {
    midi_.sendSysEx(out, length);
  }
}

void IRDrumsApp::sendChunked(uint8_t sequence, MsgType type, const String& payload) {
  static constexpr size_t kChunkSize = 88;
  const size_t total = payload.length();
  const uint8_t chunkCount = max<uint8_t>(1, static_cast<uint8_t>((total + kChunkSize - 1) / kChunkSize));

  if (chunkCount == 1) {
    sendFrame(sequence, type, payload, 0, 1);
    return;
  }

  const uint32_t holdMs = 220U + static_cast<uint32_t>(chunkCount) * 240U;
  protocolMuteUntilMs_ = max(protocolMuteUntilMs_, millis() + holdMs);
  for (uint8_t i = 0; i < chunkCount; ++i) {
    const size_t start = static_cast<size_t>(i) * kChunkSize;
    const size_t end = min(total, start + kChunkSize);
    sendFrame(sequence, type, payload.substring(start, end), i, chunkCount);
    if ((i + 1U) < chunkCount) {
      vTaskDelay(pdMS_TO_TICKS(2));
    }
  }
}

void IRDrumsApp::sendNack(uint8_t sequence, const char* reason) {
  StaticJsonDocument<96> doc;
  doc["ok"] = 0;
  doc["err"] = reason;
  String payload;
  serializeJson(doc, payload);
  sendFrame(sequence, MsgType::Nack, payload);
}

void IRDrumsApp::respondHello(uint8_t sequence) {
  const ScannerSnapshot snap = scanner_.snapshot();

  StaticJsonDocument<224> doc;
  doc["uid"] = uidToken_;
  doc["fw"] = kFirmwareVersion;
  doc["name"] = config_.deviceName;
  doc["armed"] = armed_ ? 1 : 0;
  doc["beacons"] = config_.beaconCount;
  doc["active"] = snap.activeIndex;
  doc["conf"] = snap.confidence;
  doc["sens"] = config_.hitSensitivityLevel;

  JsonArray caps = doc.createNestedArray("caps");
  caps.add("midi_note");
  caps.add("ir_bank");
  caps.add("map_assign");
  caps.add("btn_confirm");
  caps.add("switch_latch");
  caps.add("sensitivity");

  String payload;
  serializeJson(doc, payload);
  sendFrame(sequence, MsgType::HelloResp, payload);
}

void IRDrumsApp::handleArmReq(uint8_t sequence, const String& payload) {
  StaticJsonDocument<96> doc;
  if (deserializeJson(doc, payload) != DeserializationError::Ok) {
    sendNack(sequence, "bad_json");
    return;
  }

  const bool nextArmed = (doc["armed"] | 0) != 0;
  armed_ = nextArmed;

  StaticJsonDocument<64> out;
  out["ok"] = 1;
  out["armed"] = armed_ ? 1 : 0;
  String outPayload;
  serializeJson(out, outPayload);
  sendFrame(sequence, MsgType::ArmResp, outPayload);
}

void IRDrumsApp::handleSaveReq(uint8_t sequence) {
  const bool ok = saveConfig();

  StaticJsonDocument<72> out;
  out["ok"] = ok ? 1 : 0;
  String payload;
  serializeJson(out, payload);
  sendFrame(sequence, static_cast<MsgType>(kMsgSaveResp), payload);
}

void IRDrumsApp::handleFactoryReset(uint8_t sequence) {
  makeDefaultConfig(config_);
  applyScannerConfig();
  const bool ok = saveConfig();

  StaticJsonDocument<80> out;
  out["ok"] = ok ? 1 : 0;
  out["beacons"] = config_.beaconCount;
  String payload;
  serializeJson(out, payload);
  sendFrame(sequence, MsgType::FactoryResetResp, payload);
}

void IRDrumsApp::handleSetFreqReq(uint8_t sequence, const String& payload) {
  StaticJsonDocument<1024> doc;
  if (deserializeJson(doc, payload) != DeserializationError::Ok) {
    sendNack(sequence, "bad_json");
    return;
  }

  JsonArrayConst arr = doc["freqs"].as<JsonArrayConst>();
  if (arr.isNull() || arr.size() == 0) {
    sendNack(sequence, "freqs_missing");
    return;
  }

  const uint8_t count = min<uint8_t>(arr.size(), kMaxBeacons);
  config_.beaconCount = count;
  for (uint8_t i = 0; i < count; ++i) {
    config_.slots[i].frequencyHz = constrain(static_cast<uint16_t>(arr[i].as<uint32_t>()), static_cast<uint16_t>(700),
                                             static_cast<uint16_t>(5600));
  }

  applyScannerConfig();

  StaticJsonDocument<96> out;
  out["ok"] = 1;
  out["count"] = config_.beaconCount;
  String outPayload;
  serializeJson(out, outPayload);
  sendFrame(sequence, static_cast<MsgType>(kMsgSetFreqResp), outPayload);
}

void IRDrumsApp::handleSetSensitivityReq(uint8_t sequence, const String& payload) {
  StaticJsonDocument<128> doc;
  if (deserializeJson(doc, payload) != DeserializationError::Ok) {
    sendNack(sequence, "bad_json");
    return;
  }

  const int requestedLevel = doc["level"] | static_cast<int>(config_.hitSensitivityLevel);
  config_.hitSensitivityLevel = constrain(requestedLevel, 1, 10);
  const bool ok = saveConfig();

  const float scale = sensitivityScale();

  StaticJsonDocument<144> out;
  out["ok"] = ok ? 1 : 0;
  out["level"] = config_.hitSensitivityLevel;
  out["scale"] = scale;
  out["hit_g"] = max(0.07f, config_.hitAccelG * scale * 0.72f);
  out["hit_dps"] = max(22.0f, config_.hitGyroDps * scale * 0.70f);
  String outPayload;
  serializeJson(out, outPayload);
  sendFrame(sequence, static_cast<MsgType>(kMsgSetSensitivityResp), outPayload);
}

void IRDrumsApp::handleMapSelectReq(uint8_t sequence, const String& payload) {
  StaticJsonDocument<256> doc;
  if (deserializeJson(doc, payload) != DeserializationError::Ok) {
    sendNack(sequence, "bad_json");
    return;
  }

  PendingAssignment next;
  next.active = true;
  next.requestedBeacon = static_cast<int8_t>(doc["beacon"] | -1);
  next.note = constrain(static_cast<int>(doc["note"] | 38), 0, 127);
  next.channel = constrain(static_cast<int>(doc["ch"] | 9), 0, 15);
  next.velocityMin = constrain(static_cast<int>(doc["vel_min"] | 20), 1, 127);
  next.velocityMax = constrain(static_cast<int>(doc["vel_max"] | 127), static_cast<int>(next.velocityMin), 127);

  const char* label = doc["name"] | "DRUM";
  strlcpy(next.label, label, sizeof(next.label));

  pendingAssignment_ = next;

  int8_t directBeacon = next.requestedBeacon;
  if (directBeacon >= 0) {
    const bool ok = assignToBeacon(directBeacon, pendingAssignment_, sequence);
    if (ok) {
      pendingAssignment_.active = false;
    }
    return;
  }

  StaticJsonDocument<112> out;
  out["ok"] = 1;
  out["pending"] = 1;
  out["note"] = pendingAssignment_.note;
  out["hint"] = "double_click_btnb_to_confirm";
  String outPayload;
  serializeJson(out, outPayload);
  sendFrame(sequence, static_cast<MsgType>(kMsgMapSelectResp), outPayload);
}

bool IRDrumsApp::assignToBeacon(int8_t beaconIndex, const PendingAssignment& assignment, uint8_t responseSequence) {
  if (beaconIndex < 0 || beaconIndex >= static_cast<int8_t>(config_.beaconCount)) {
    if (responseSequence != 0) {
      sendNack(responseSequence, "beacon_out_of_range");
    }
    return false;
  }

  BeaconSlot& slot = config_.slots[beaconIndex];
  slot.note = assignment.note;
  slot.channel = assignment.channel;
  slot.velocityMin = assignment.velocityMin;
  slot.velocityMax = assignment.velocityMax;
  slot.enabled = 1;
  if (assignment.label[0] != '\0') {
    strlcpy(slot.label, assignment.label, sizeof(slot.label));
  }

  if (responseSequence != 0) {
    StaticJsonDocument<192> out;
    out["ok"] = 1;
    out["beacon"] = beaconIndex;
    out["freq"] = slot.frequencyHz;
    out["note"] = slot.note;
    out["ch"] = slot.channel;
    out["label"] = slot.label;
    String payload;
    serializeJson(out, payload);
    sendFrame(responseSequence, static_cast<MsgType>(kMsgMapSelectResp), payload);
  }

  saveConfig();
  return true;
}

void IRDrumsApp::sendMappingList(uint8_t sequence, MsgType type) {
  DynamicJsonDocument doc(2048);
  doc["ok"] = 1;
  doc["beacon_count"] = config_.beaconCount;

  const ScannerSnapshot snap = scanner_.snapshot();
  doc["active"] = snap.activeIndex;
  doc["candidate"] = snap.candidateIndex;
  doc["winner"] = snap.winnerIndex;
  doc["conf"] = snap.confidence;
  doc["pn"] = snap.peakToNoise;
  doc["noise"] = snap.noiseFloor;
  doc["dyn_min"] = snap.dynamicMinMagnitude;
  doc["sens"] = config_.hitSensitivityLevel;

  JsonArray slots = doc.createNestedArray("slots");
  for (uint8_t i = 0; i < config_.beaconCount; ++i) {
    JsonObject row = slots.createNestedObject();
    row["idx"] = i;
    row["freq"] = config_.slots[i].frequencyHz;
    row["note"] = config_.slots[i].note;
    row["ch"] = config_.slots[i].channel;
    row["en"] = config_.slots[i].enabled;
    row["name"] = config_.slots[i].label;
    row["mag"] = roundf(snap.magnitudes[i] * 10.0f) / 10.0f;
  }

  String payload;
  serializeJson(doc, payload);
  sendChunked(sequence, type, payload);
}

void IRDrumsApp::applyScannerConfig() {
  ScannerConfig sc;
  sc.aoPin = config_.aoPin;
  sc.doPin = config_.doPin;
  sc.sampleRateHz = config_.sampleRateHz;
  sc.frameSamples = config_.frameSamples;
  sc.smoothingAlpha = config_.smoothingAlpha;
  sc.confidenceThreshold = config_.confidenceThreshold;
  sc.dominanceThreshold = config_.dominanceThreshold;
  sc.winnerShareThreshold = config_.winnerShareThreshold;
  sc.minWinnerMagnitude = config_.minWinnerMagnitude;
  sc.switchHoldMs = config_.switchHoldMs;
  sc.beaconCount = config_.beaconCount;

  for (uint8_t i = 0; i < config_.beaconCount; ++i) {
    sc.frequenciesHz[i] = config_.slots[i].frequencyHz;
  }

  scanner_.configure(sc);
}

void IRDrumsApp::processButtons() {
  if (M5.BtnA.wasClicked()) {
    armed_ = !armed_;
  }

  if (M5.BtnB.wasReleased()) {
    const uint32_t nowMs = millis();
    if (nowMs - btnBLastReleaseMs_ <= kButtonMultiClickWindowMs) {
      btnBClickCount_++;
    } else {
      btnBClickCount_ = 1;
    }
    btnBLastReleaseMs_ = nowMs;
  }
}

void IRDrumsApp::processAssignmentClickWindow() {
  if (btnBClickCount_ == 0) {
    return;
  }

  const uint32_t nowMs = millis();
  if (nowMs - btnBLastReleaseMs_ <= kButtonMultiClickWindowMs) {
    return;
  }

  const uint8_t clicks = btnBClickCount_;
  btnBClickCount_ = 0;

  if (clicks == 1) {
    uiPage_ = (uiPage_ + 1U) % kUiPages;
    return;
  }

  if (clicks == 2) {
    confirmPendingAssignment();
    return;
  }

  if (clicks >= 3) {
    pendingAssignment_.active = false;
  }
}

void IRDrumsApp::confirmPendingAssignment() {
  if (!pendingAssignment_.active) {
    return;
  }

  const ScannerSnapshot snap = scanner_.snapshot();
  int8_t target = pendingAssignment_.requestedBeacon;
  if (target < 0) {
    target = snap.activeIndex;
  }

  if (target < 0 || target >= static_cast<int8_t>(config_.beaconCount)) {
    Serial.println("[IRDR] assign failed: no active beacon");
    return;
  }

  if (assignToBeacon(target, pendingAssignment_, 0)) {
    lastAssignedBeacon_ = target;
    lastAssignedAtMs_ = millis();
    pendingAssignment_.active = false;
    Serial.printf("[IRDR] assigned beacon=%d freq=%u note=%u\n", target, config_.slots[target].frequencyHz,
                  config_.slots[target].note);
  }
}

float IRDrumsApp::sensitivityScale() const {
  const float t = static_cast<float>(constrain(static_cast<int>(config_.hitSensitivityLevel), 1, 10) - 1) / 9.0f;
  // Level 1 = hard trigger, level 10 = very sensitive.
  return 1.50f - (1.15f * t);
}

uint16_t IRDrumsApp::computeRefractoryMs(float hitScore) const {
  const float normalized = clampf((hitScore - 1.0f) / 2.6f, 0.0f, 1.0f);
  const float factor = 0.30f + (1.80f * normalized);
  const uint16_t base = max<uint16_t>(10, config_.refractoryMs);
  const uint16_t refractory = static_cast<uint16_t>(roundf(static_cast<float>(base) * factor));
  return constrain(refractory, static_cast<uint16_t>(8), static_cast<uint16_t>(320));
}

void IRDrumsApp::processImuAndHit() {
  float ax = 0.0f;
  float ay = 0.0f;
  float az = 0.0f;
  float gx = 0.0f;
  float gy = 0.0f;
  float gz = 0.0f;

  if (!M5.Imu.getAccel(&ax, &ay, &az) || !M5.Imu.getGyro(&gx, &gy, &gz)) {
    return;
  }

  const uint32_t nowMs = millis();
  const float accelNorm = vectorNorm3(ax, ay, az);
  const float linearAccel = fabsf(accelNorm - 1.0f);
  const float gyroNorm = vectorNorm3(gx, gy, gz);

  lastLinearAccelG_ = linearAccel;
  lastGyroDps_ = gyroNorm;

  if (!armed_) {
    strokeTracking_ = false;
    prevImpactScore_ = 0.0f;
    lastImpactScore_ = 0.0f;
    return;
  }

  const float scale = sensitivityScale();
  const float armAccelThreshold = max(0.05f, config_.armAccelG * scale * 0.75f);
  const float hitAccelThreshold = max(0.07f, config_.hitAccelG * scale * 0.72f);
  const float hitGyroThreshold = max(22.0f, config_.hitGyroDps * scale * 0.70f);
  const float releaseAccelThreshold = max(0.02f, config_.releaseAccelG * scale * 0.65f);
  const float releaseGyroThreshold = max(12.0f, hitGyroThreshold * 0.22f);

  const float accelScore = linearAccel / max(0.02f, hitAccelThreshold);
  const float gyroScore = gyroNorm / max(1.0f, hitGyroThreshold);
  const float impactScore = max(accelScore, gyroScore);
  const float armScore = max(linearAccel / max(0.02f, armAccelThreshold),
                             gyroNorm / max(1.0f, hitGyroThreshold * 0.50f));
  const float riseScore = impactScore - prevImpactScore_;
  const float sensitivityNorm = static_cast<float>(constrain(static_cast<int>(config_.hitSensitivityLevel), 1, 10) - 1) / 9.0f;
  const float triggerScoreThreshold = 1.18f - (0.30f * sensitivityNorm);  // 1.18 -> 0.88
  const float armRiseMin = 0.03f + (0.05f * (1.0f - sensitivityNorm));
  const float fallRatio = 0.70f + (0.10f * (1.0f - sensitivityNorm));      // sensitive mode triggers earlier
  const uint16_t peakWindowMs = static_cast<uint16_t>(68U - static_cast<uint16_t>(18.0f * sensitivityNorm));

  lastImpactScore_ = impactScore;

  if (nowMs < refractoryUntilMs_) {
    prevImpactScore_ = impactScore;
    return;
  }

  if (!strokeTracking_) {
    if (armScore >= 1.0f && riseScore >= armRiseMin) {
      strokeTracking_ = true;
      strokeStartMs_ = nowMs;
      strokePeakScore_ = impactScore;
      strokePeakAccelG_ = linearAccel;
      strokePeakGyroDps_ = gyroNorm;
    }
    prevImpactScore_ = impactScore;
    return;
  }

  strokePeakScore_ = max(strokePeakScore_, impactScore);
  strokePeakAccelG_ = max(strokePeakAccelG_, linearAccel);
  strokePeakGyroDps_ = max(strokePeakGyroDps_, gyroNorm);

  const uint32_t elapsedMs = nowMs - strokeStartMs_;
  const bool localPeak = prevImpactScore_ > (impactScore + 0.03f);
  const bool released = (linearAccel <= releaseAccelThreshold && gyroNorm <= releaseGyroThreshold) ||
                        (impactScore <= strokePeakScore_ * fallRatio);
  const bool timeout = elapsedMs >= peakWindowMs;
  const bool strongEnough = strokePeakScore_ >= triggerScoreThreshold;

  if (strongEnough && (localPeak || released || timeout)) {
    const float hitScore = clampf(strokePeakScore_, 1.0f, 3.6f);
    triggerHit(nowMs, strokePeakAccelG_, strokePeakGyroDps_, hitScore);
    strokeTracking_ = false;
    lastStrokePeakScore_ = strokePeakScore_;
    strokePeakScore_ = 0.0f;
    strokePeakAccelG_ = 0.0f;
    strokePeakGyroDps_ = 0.0f;
    lastRefractoryMs_ = computeRefractoryMs(hitScore);
    refractoryUntilMs_ = nowMs + lastRefractoryMs_;
    prevImpactScore_ = impactScore;
    return;
  }

  if (timeout || (released && !strongEnough)) {
    strokeTracking_ = false;
    strokePeakScore_ = 0.0f;
    strokePeakAccelG_ = 0.0f;
    strokePeakGyroDps_ = 0.0f;
  }

  prevImpactScore_ = impactScore;
}

void IRDrumsApp::triggerHit(uint32_t nowMs, float linearAccel, float gyroNorm, float hitScore) {
  (void)linearAccel;
  (void)gyroNorm;

  if (nowMs < protocolMuteUntilMs_) {
    return;
  }

  const ScannerSnapshot snap = scanner_.snapshot();
  int8_t selected = snap.activeIndex;
  const bool winnerLooksStable = snap.winnerIndex >= 0 &&
                                 snap.winnerMagnitude >= max(snap.dynamicMinMagnitude * 0.85f, snap.secondMagnitude * 1.18f + 0.2f) &&
                                 snap.peakToNoise >= 1.04f;
  if (winnerLooksStable && snap.winnerIndex != selected) {
    selected = snap.winnerIndex;
  }

  if (selected < 0 || selected >= static_cast<int8_t>(config_.beaconCount)) {
    return;
  }

  BeaconSlot& slot = config_.slots[selected];
  if (!slot.enabled) {
    return;
  }

  const float score = clampf(hitScore, 1.0f, 2.8f);
  const float normalized = (score - 1.0f) / 1.8f;
  const uint8_t velocity = static_cast<uint8_t>(roundf(slot.velocityMin + normalized * (slot.velocityMax - slot.velocityMin)));

  midi_.sendNoteOn(slot.channel, slot.note, velocity);

  if (config_.sendNoteOff) {
    scheduleNoteOff(slot.channel, slot.note, velocity, config_.noteLengthMs);
  }

  lastHitBeacon_ = selected;
  lastHitNote_ = slot.note;
  lastHitVelocity_ = velocity;
  lastHitAtMs_ = nowMs;
}

void IRDrumsApp::scheduleNoteOff(uint8_t channel, uint8_t note, uint8_t velocity, uint16_t afterMs) {
  for (PendingNote& pending : noteOffQueue_) {
    if (pending.active) {
      continue;
    }
    pending.active = true;
    pending.channel = channel;
    pending.note = note;
    pending.velocity = velocity;
    pending.offAtMs = millis() + afterMs;
    return;
  }

  // Queue saturated fallback.
  midi_.sendNoteOff(channel, note, velocity);
}

void IRDrumsApp::processNoteOffQueue() {
  const uint32_t nowMs = millis();
  if (nowMs < protocolMuteUntilMs_) {
    return;
  }

  for (PendingNote& pending : noteOffQueue_) {
    if (!pending.active || nowMs < pending.offAtMs) {
      continue;
    }

    midi_.sendNoteOff(pending.channel, pending.note, pending.velocity);
    pending.active = false;
  }
}

void IRDrumsApp::drawHeader(const ScannerSnapshot&) {
  M5.Display.fillRect(0, 0, 80, 16, TFT_DARKGREY);
  M5.Display.setTextColor(TFT_WHITE, TFT_DARKGREY);
  M5.Display.setTextSize(1);
  M5.Display.setCursor(2, 4);
  M5.Display.printf("IRD P%u", static_cast<unsigned>(uiPage_));
  M5.Display.setCursor(45, 4);
  M5.Display.printf("%u%%", M5.Power.getBatteryLevel());
}

void IRDrumsApp::drawPageMain(const ScannerSnapshot& snap) {
  M5.Display.fillRect(0, 16, 80, 144, TFT_BLACK);
  M5.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5.Display.setTextSize(1);

  const int active = snap.activeIndex;
  const uint16_t activeFreq = (active >= 0 && active < snap.beaconCount) ? snap.frequenciesHz[active] : 0;

  M5.Display.setCursor(2, 20);
  M5.Display.printf("ARM:%s BLE:%s", armed_ ? "ON" : "OFF", midi_.isConnected() ? "ON" : "OFF");
  M5.Display.setCursor(2, 32);
  M5.Display.printf("ACT:%d F:%u", active, activeFreq);
  M5.Display.setCursor(2, 44);
  M5.Display.printf("CF:%3u%% LT:%s", static_cast<unsigned>(roundf(snap.confidence * 100.0f)),
                    snap.activeLatched ? "ON" : "OFF");

  if (active >= 0 && active < config_.beaconCount) {
    const BeaconSlot& slot = config_.slots[active];
    M5.Display.setCursor(2, 56);
    M5.Display.printf("N:%u C:%u", slot.note, slot.channel);
    M5.Display.setCursor(2, 68);
    M5.Display.printf("%s", slot.label);
  } else {
    M5.Display.setCursor(2, 56);
    M5.Display.printf("NO ACTIVE BEACON");
  }

  M5.Display.setCursor(2, 80);
  M5.Display.printf("A:%1.2f G:%3.0f", lastLinearAccelG_, lastGyroDps_);
  M5.Display.setCursor(2, 92);
  M5.Display.printf("IMP:%1.2f PK:%1.2f", lastImpactScore_, lastStrokePeakScore_);
  M5.Display.setCursor(2, 104);
  M5.Display.printf("S:%u REF:%ums", static_cast<unsigned>(config_.hitSensitivityLevel),
                    static_cast<unsigned>(lastRefractoryMs_));

  M5.Display.setCursor(2, 116);
  M5.Display.printf("HIT B:%d N:%u V:%u", lastHitBeacon_, lastHitNote_, lastHitVelocity_);

  if (pendingAssignment_.active) {
    M5.Display.setCursor(2, 128);
    M5.Display.printf("PEND N:%u C:%u", pendingAssignment_.note, pendingAssignment_.channel);
    M5.Display.setCursor(2, 140);
    M5.Display.printf("2xB CONF 3xB CAN");
  } else {
    M5.Display.setCursor(2, 128);
    M5.Display.printf("1xB PAGE 2xB ASSN");
    M5.Display.setCursor(2, 140);
    M5.Display.printf("BtnA ARM toggle");
  }

  if (lastAssignedBeacon_ >= 0 && (millis() - lastAssignedAtMs_) < 2500) {
    M5.Display.setCursor(2, 150);
    M5.Display.printf("ASSIGNED B:%d", lastAssignedBeacon_);
  }
}

void IRDrumsApp::updateSpectrogram(const ScannerSnapshot& snap) {
  if (snap.beaconCount == 0) {
    return;
  }

  if (snap.frameCount == lastSpectrogramFrameCount_) {
    return;
  }
  lastSpectrogramFrameCount_ = snap.frameCount;

  memmove(&spectrogram_[1][0],
          &spectrogram_[0][0],
          static_cast<size_t>(kSpectrogramRows - 1U) * static_cast<size_t>(kMaxBeacons));
  memset(&spectrogram_[0][0], 0, kMaxBeacons);

  const float top = max(1.0f, snap.topMagnitude[0]);
  spectrogramScale_ = max(top, spectrogramScale_ * 0.97f);
  spectrogramScale_ = max(1.0f, spectrogramScale_);

  const float invScale = 1.0f / (spectrogramScale_ + 1e-6f);
  for (uint8_t i = 0; i < snap.beaconCount; ++i) {
    const float normalized = clampf(snap.magnitudes[i] * invScale, 0.0f, 1.6f);
    const float enhanced = sqrtf(normalized * (1.0f / 1.6f));
    const int value = static_cast<int>(roundf(enhanced * 255.0f));
    spectrogram_[0][i] = static_cast<uint8_t>(constrain(value, 0, 255));
  }
}

uint16_t IRDrumsApp::heatColor(uint8_t value) const {
  if (value < 6) {
    return TFT_BLACK;
  }

  uint8_t r = 0;
  uint8_t g = 0;
  uint8_t b = 0;
  if (value < 86) {
    g = static_cast<uint8_t>(value * 2U);
    b = static_cast<uint8_t>(40U + static_cast<uint8_t>(value * 2U));
  } else if (value < 171) {
    const uint8_t t = static_cast<uint8_t>(value - 86U);
    r = static_cast<uint8_t>(t * 3U);
    g = 255U;
    b = static_cast<uint8_t>(255U - t * 2U);
  } else {
    const uint8_t t = static_cast<uint8_t>(value - 171U);
    r = 255U;
    g = static_cast<uint8_t>(255U - min<uint16_t>(255U, static_cast<uint16_t>(t) * 3U));
    b = 0U;
  }

  return M5.Display.color565(r, g, b);
}

void IRDrumsApp::drawSpectrogram(const ScannerSnapshot& snap, int x, int y, int w, int h) {
  const int bins = max(1, static_cast<int>(snap.beaconCount));
  const int rowsToDraw = min(h, static_cast<int>(kSpectrogramRows));
  const float rowStep = static_cast<float>(kSpectrogramRows) / static_cast<float>(max(1, rowsToDraw));

  const int cellW = max(1, w / bins);
  const int usedW = cellW * bins;
  const int x0 = x + ((w - usedW) / 2);

  M5.Display.drawRect(x, y, w, h, TFT_DARKGREY);
  for (int dy = 0; dy < rowsToDraw; ++dy) {
    const int srcRow = min(static_cast<int>(kSpectrogramRows) - 1, static_cast<int>(floorf(static_cast<float>(dy) * rowStep)));
    for (int bin = 0; bin < bins; ++bin) {
      const uint8_t intensity = spectrogram_[srcRow][bin];
      M5.Display.fillRect(x0 + bin * cellW, y + dy, cellW, 1, heatColor(intensity));
    }
  }
}

void IRDrumsApp::drawPageSpectrum(const ScannerSnapshot& snap) {
  M5.Display.fillRect(0, 16, 80, 144, TFT_BLACK);
  M5.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5.Display.setTextSize(1);

  updateSpectrogram(snap);

  M5.Display.setCursor(2, 20);
  M5.Display.printf("Beacon spectrogram");
  M5.Display.setCursor(2, 30);
  M5.Display.printf("A:%d C:%d W:%d", snap.activeIndex, snap.candidateIndex, snap.winnerIndex);
  M5.Display.setCursor(2, 40);
  M5.Display.printf("CF:%2u PN:%2u", static_cast<unsigned>(roundf(snap.confidence * 100.0f)),
                    static_cast<unsigned>(roundf(snap.peakToNoise * 10.0f)));
  M5.Display.setCursor(2, 50);
  M5.Display.printf("MN:%.1f NF:%.1f", snap.dynamicMinMagnitude, snap.noiseFloor);

  drawSpectrogram(snap, 2, 62, 76, 92);

}

void IRDrumsApp::drawPageMapping(const ScannerSnapshot& snap) {
  M5.Display.fillRect(0, 16, 80, 144, TFT_BLACK);
  M5.Display.setTextColor(TFT_WHITE, TFT_BLACK);
  M5.Display.setTextSize(1);

  M5.Display.setCursor(2, 20);
  M5.Display.printf("Mapping view");
  M5.Display.setCursor(2, 30);
  M5.Display.printf("A:%d C:%d W:%d", snap.activeIndex, snap.candidateIndex, snap.winnerIndex);

  const int8_t active = snap.activeIndex;
  if (active >= 0 && active < config_.beaconCount) {
    const BeaconSlot& slot = config_.slots[active];
    M5.Display.setCursor(2, 42);
    M5.Display.printf("B%u F%u", static_cast<unsigned>(active), slot.frequencyHz);
    M5.Display.setCursor(2, 54);
    M5.Display.printf("N%u C%u", slot.note, slot.channel);
    M5.Display.setCursor(2, 66);
    M5.Display.printf("%s", slot.label);
  } else {
    M5.Display.setCursor(2, 42);
    M5.Display.printf("Point at beacon...");
  }

  M5.Display.setCursor(2, 82);
  M5.Display.printf("Pending:");
  if (pendingAssignment_.active) {
    M5.Display.setCursor(2, 94);
    M5.Display.printf("N%u C%u %s", pendingAssignment_.note, pendingAssignment_.channel, pendingAssignment_.label);
    M5.Display.setCursor(2, 106);
    M5.Display.printf("2x BtnB = assign");
    M5.Display.setCursor(2, 118);
    M5.Display.printf("3x BtnB = cancel");
  } else {
    M5.Display.setCursor(2, 94);
    M5.Display.printf("No pending from app");
    M5.Display.setCursor(2, 106);
    M5.Display.printf("Send MapSelectReq");
  }

  M5.Display.setCursor(2, 130);
  M5.Display.printf("Slots:%u", config_.beaconCount);
  M5.Display.setCursor(2, 142);
  M5.Display.printf("PN:%2u CF:%2u", static_cast<unsigned>(roundf(snap.peakToNoise * 10.0f)),
                    static_cast<unsigned>(roundf(snap.confidence * 100.0f)));
}

void IRDrumsApp::drawUi(bool force) {
  const uint32_t nowMs = millis();
  if (!force && (nowMs - lastUiDrawMs_) < kUiRefreshMs) {
    return;
  }

  const ScannerSnapshot snap = scanner_.snapshot();

  drawHeader(snap);
  switch (uiPage_) {
    case 0:
      drawPageMain(snap);
      break;
    case 1:
      drawPageSpectrum(snap);
      break;
    case 2:
    default:
      drawPageMapping(snap);
      break;
  }

  lastUiDrawMs_ = nowMs;
}

void IRDrumsApp::logHealth() {
  const uint32_t nowMs = millis();
  if (nowMs - lastHealthLogMs_ < kSerialHealthMs) {
    return;
  }

  const ScannerSnapshot snap = scanner_.snapshot();
  Serial.printf("[IRDR][IR] act=%d latch=%u win=%d cand=%d conf=%.2f dom=%.2f ws=%.2f pn=%.2f mn=%.2f nf=%.2f raw=%u/%u/%u fs=%.0f drop=%lu\n",
                snap.activeIndex, snap.activeLatched, snap.winnerIndex, snap.candidateIndex, snap.confidence, snap.dominance,
                snap.winnerShare, snap.peakToNoise, snap.dynamicMinMagnitude, snap.noiseFloor, snap.rawAdc, snap.rawMinAdc,
                snap.rawMaxAdc, snap.measuredSampleRateHz, static_cast<unsigned long>(snap.droppedCycles));

  lastHealthLogMs_ = nowMs;
}

void IRDrumsApp::makeDefaultConfig(IRDrumsConfig& out) {
  out = IRDrumsConfig{};
  out.magic = kConfigMagic;
  out.version = kConfigVersion;

  uidToken_.substring(0, 8).toCharArray(out.uid, sizeof(out.uid));
  if (strlen(out.uid) == 0) {
    strlcpy(out.uid, "00000000", sizeof(out.uid));
  }

  snprintf(out.deviceName, sizeof(out.deviceName), "IRD-%s", out.uid);

  out.beaconCount = kDefaultBeaconCount;
  out.hitSensitivityLevel = 5;
  for (uint8_t i = 0; i < out.beaconCount; ++i) {
    out.slots[i].frequencyHz = kDefaultFrequencies[i];
    out.slots[i].note = kDefaultNotes[i];
    out.slots[i].channel = 9;
    out.slots[i].velocityMin = 20;
    out.slots[i].velocityMax = 127;
    out.slots[i].enabled = 1;
    strlcpy(out.slots[i].label, kDefaultLabels[i], sizeof(out.slots[i].label));
  }
}

bool IRDrumsApp::validateConfig(IRDrumsConfig& cfg) {
  if (cfg.magic != kConfigMagic || cfg.version != kConfigVersion) {
    return false;
  }

  cfg.aoPin = constrain(cfg.aoPin, static_cast<int8_t>(0), static_cast<int8_t>(39));
  cfg.doPin = constrain(cfg.doPin, static_cast<int8_t>(-1), static_cast<int8_t>(39));
  cfg.sampleRateHz = constrain(cfg.sampleRateHz, static_cast<uint16_t>(6200), static_cast<uint16_t>(14000));
  cfg.frameSamples = constrain(cfg.frameSamples, static_cast<uint16_t>(64), kMaxFrameSamples);
  cfg.smoothingAlpha = clampf(cfg.smoothingAlpha, 0.02f, 0.95f);
  cfg.confidenceThreshold = clampf(cfg.confidenceThreshold, 0.02f, 0.98f);
  cfg.dominanceThreshold = clampf(cfg.dominanceThreshold, 0.02f, 0.98f);
  cfg.winnerShareThreshold = clampf(cfg.winnerShareThreshold, 0.02f, 0.98f);
  cfg.minWinnerMagnitude = max(0.0f, cfg.minWinnerMagnitude);
  cfg.switchHoldMs = constrain(cfg.switchHoldMs, static_cast<uint16_t>(6), static_cast<uint16_t>(300));

  cfg.armAccelG = clampf(cfg.armAccelG, 0.10f, 4.0f);
  cfg.hitAccelG = clampf(cfg.hitAccelG, 0.20f, 8.0f);
  cfg.hitGyroDps = clampf(cfg.hitGyroDps, 40.0f, 1500.0f);
  cfg.releaseAccelG = clampf(cfg.releaseAccelG, 0.02f, 2.0f);
  cfg.refractoryMs = constrain(cfg.refractoryMs, static_cast<uint16_t>(8), static_cast<uint16_t>(250));
  cfg.hitSensitivityLevel = constrain(cfg.hitSensitivityLevel, static_cast<uint8_t>(1), static_cast<uint8_t>(10));

  cfg.sendNoteOff = cfg.sendNoteOff ? 1 : 0;
  cfg.noteLengthMs = constrain(cfg.noteLengthMs, static_cast<uint16_t>(5), static_cast<uint16_t>(200));

  cfg.beaconCount = constrain(cfg.beaconCount, static_cast<uint8_t>(1), kMaxBeacons);
  for (uint8_t i = 0; i < cfg.beaconCount; ++i) {
    cfg.slots[i].frequencyHz = constrain(cfg.slots[i].frequencyHz, static_cast<uint16_t>(700), static_cast<uint16_t>(5600));
    cfg.slots[i].note = constrain(static_cast<int>(cfg.slots[i].note), 0, 127);
    cfg.slots[i].channel = constrain(static_cast<int>(cfg.slots[i].channel), 0, 15);
    cfg.slots[i].velocityMin = constrain(static_cast<int>(cfg.slots[i].velocityMin), 1, 127);
    cfg.slots[i].velocityMax = constrain(static_cast<int>(cfg.slots[i].velocityMax), static_cast<int>(cfg.slots[i].velocityMin), 127);
    cfg.slots[i].enabled = cfg.slots[i].enabled ? 1 : 0;
    if (cfg.slots[i].label[0] == '\0') {
      snprintf(cfg.slots[i].label, sizeof(cfg.slots[i].label), "B%u", static_cast<unsigned>(i));
    }
  }

  return true;
}

void IRDrumsApp::loadConfig() {
  Preferences pref;
  pref.begin(kPrefsNamespace, true);
  const size_t expected = sizeof(IRDrumsConfig);
  const size_t n = pref.getBytesLength("cfg");
  if (n == expected) {
    IRDrumsConfig loaded;
    const size_t read = pref.getBytes("cfg", &loaded, sizeof(loaded));
    if (read == expected && validateConfig(loaded)) {
      config_ = loaded;
      pref.end();
      return;
    }
  }

  pref.end();
  makeDefaultConfig(config_);
}

bool IRDrumsApp::saveConfig() {
  Preferences pref;
  if (!pref.begin(kPrefsNamespace, false)) {
    return false;
  }

  const size_t written = pref.putBytes("cfg", &config_, sizeof(config_));
  pref.end();
  return written == sizeof(config_);
}

String IRDrumsApp::detectUid() const {
  const uint64_t mac = ESP.getEfuseMac();
  char uid[9] {};
  snprintf(uid, sizeof(uid), "%08llX", static_cast<unsigned long long>(mac & 0xFFFFFFFFULL));
  return String(uid);
}

IRDrumsApp* IRDrumsApp::instance_ = nullptr;
IRDrumsApp gApp;

}  // namespace

void setup() {
  gApp.begin();
}

void loop() {
  gApp.tick();
}
