# Hit Detection Model Notes

## Physics Framing
A stick stroke is not a static threshold event. It has phases:
1) acceleration build-up
2) impact peak
3) decay/rebound

If firmware only checks instant threshold crossing, it misses light strokes or false-triggers on rebound.
If firmware requires full stillness before re-arm, it blocks realistic tempo.

## Implemented Approach
- Compute linear acceleration magnitude and gyro magnitude each loop.
- Build normalized impact score using effective sensitivity-scaled thresholds.
- Arm only when impact is rising.
- While tracking a stroke, keep peak score and peak accel/gyro.
- Trigger when stroke is strong enough and one of these occurs:
  - local peak detected,
  - release condition detected,
  - short peak window timeout.
- Apply dynamic refractory based on stroke strength:
  - soft stroke => short lockout,
  - hard stroke => longer lockout.

## Why This Matches Drumming Better
- Triggering near the peak aligns with natural stick impact energy.
- Rising-edge arm avoids random background noise.
- Dynamic lockout suppresses rebound doubles while preserving fast soft rolls.

## Tuning Knobs
- `hitSensitivityLevel` (1..10)
- `armAccelG`, `hitAccelG`, `hitGyroDps`, `releaseAccelG`
- `refractoryMs` (base for strength scaling)

## Additional Improvements To Consider
- Per-drum sensitivity/refractory profiles (kick/snare/hihat differ)
- Velocity-curved refractory with non-linear shape
- Optional per-user adaptive calibration from captured stroke histograms
