# Request For ChatGPT Pro

Please review and improve this IRDrums pipeline:

1. Hit detection quality
- Keep low false positives after hard impacts.
- Improve soft-hit trigger reliability at high tempos.
- Preserve dynamic lockout behavior: soft notes can be repeated quickly, hard notes should naturally space out.

2. Beacon switching under motion
- During continuous hit patterns, switching between beacon frequencies must happen immediately.
- Verify whether winner/candidate/active logic should use stronger hysteresis per beacon pair.

3. Suggested deliverables
- Proposed algorithm changes with rationale.
- Concrete parameter defaults for sensitivity levels 1..10.
- Any additional debug metrics to display on M5StickC screen and serial logs.
- Validation protocol for realistic drummer patterns.
