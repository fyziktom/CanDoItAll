# Source notes

These public references informed the design direction:

- Google Creative Lab - Air Snare:
  - useful for the idea that drumming gestures benefit from richer IMU interpretation and a 9DoF pipeline mindset.
- Drumlet:
  - useful as a counterexample showing how simple orientation + trigger ideas become too weak for serious drumming.
- Cornell air-drum style project:
  - useful for the concept of downstroke-only detection and suppressing multiple triggers in one swing.
- SnAIRbeats:
  - useful conceptually for wearable IMU drumming, but not a direct architectural match.
- Web MIDI specification and MDN:
  - useful for explaining that browser MIDI port names come from the host MIDI system.
- BLE GAP naming and advertising references:
  - useful for explaining why a configured device name can still appear truncated or unknown in some host contexts.
- Bosch BNO055 documentation:
  - useful for planning the future 9DoF path.
