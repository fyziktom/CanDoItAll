#pragma once

#include <stdint.h>

namespace idrm {

enum class InstrumentClass : uint8_t {
  StickDrum = 0,
  StickCymbal = 1,
  FootKick = 2,
  FootHat = 3,
};

enum class StrokePhase : uint8_t {
  Idle = 0,
  Candidate = 1,
  Approach = 2,
  TriggeredRecovery = 3,
};

enum class TriggerReason : uint8_t {
  None = 0,
  FallFromPeak = 1,
  ReboundCross = 2,
  SignReversal = 3,
  PeakTimeout = 4,
};

enum class RejectReason : uint8_t {
  None = 0,
  Cooldown = 1,
  NoStableTarget = 2,
  WeakApproach = 3,
  WrongDirection = 4,
  LostTargetTooEarly = 5,
  NoRelease = 6,
};

struct Vec3f {
  float x;
  float y;
  float z;
};

struct HitProfile {
  InstrumentClass instrumentClass;
  Vec3f attackGyroAxisBody;
  Vec3f attackAccelAxisBody;
  int8_t attackSign;
  float gyroArmRefDps;
  float accelArmRefG;
  float gyroTriggerRefDps;
  float accelTriggerRefG;
  float reboundTriggerRef;
  float quietGyroDps;
  float quietAccelG;
  float fallRatio;
  uint16_t peakTimeoutMs;
  uint16_t minGapMs;
  uint16_t minTargetStableMs;
  float velocityGyroRef;
  float velocityAccelRef;
  float velocityGamma;
  float gyroWeight;
  float accelWeight;
};

struct HitFrameFeatures {
  float linearAccelProj;
  float gyroProj;
  float approachAccel;
  float approachGyro;
  float reboundAccel;
  float reboundGyro;
  float approachScore;
  float reboundScore;
};

struct HitDebugSnapshot {
  StrokePhase phase;
  int8_t liveTarget;
  int8_t frozenTarget;
  uint32_t targetStableMs;
  float approachScore;
  float reboundScore;
  float peakApproachScore;
  float peakApproachGyro;
  float peakApproachAccel;
  uint16_t cooldownMsRemaining;
  TriggerReason triggerReason;
  RejectReason rejectReason;
};

struct HitDecision {
  bool triggered;
  uint8_t velocity;
  int8_t beaconIndex;
  TriggerReason triggerReason;
  RejectReason rejectReason;
};

class HitEngineDirectional {
 public:
  void reset();
  void setProfile(const HitProfile& profile);
  void setArmed(bool armed);
  void setLiveTarget(int8_t liveTarget, uint32_t stableMs, bool confident);
  void updateCalibration(const Vec3f& gravityBody, const Vec3f& gyroBias);
  HitDecision update(uint32_t nowMs, const Vec3f& accelBody, const Vec3f& gyroBody);
  HitDebugSnapshot debugSnapshot() const;

 private:
  HitFrameFeatures computeFeatures(const Vec3f& accelBody, const Vec3f& gyroBody) const;
  uint8_t computeVelocity(float peakGyro, float peakAccel) const;
  bool canArmTarget() const;
  void enterCandidate(uint32_t nowMs);
  void enterApproach(uint32_t nowMs);
  void enterTriggeredRecovery(uint32_t nowMs, TriggerReason reason);
  void clearStrokeState();

  HitProfile profile_ {};
  Vec3f gravityBody_ {};
  Vec3f gyroBias_ {};
  StrokePhase phase_ {StrokePhase::Idle};
  bool armed_ {true};
  bool liveTargetConfident_ {false};
  int8_t liveTarget_ {-1};
  int8_t frozenTarget_ {-1};
  uint32_t targetStableMs_ {0};
  uint32_t phaseStartMs_ {0};
  uint32_t cooldownUntilMs_ {0};
  float lastApproachScore_ {0.0f};
  float peakApproachScore_ {0.0f};
  float peakApproachGyro_ {0.0f};
  float peakApproachAccel_ {0.0f};
  TriggerReason lastTriggerReason_ {TriggerReason::None};
  RejectReason lastRejectReason_ {RejectReason::None};
};

}  // namespace idrm
