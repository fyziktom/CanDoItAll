#include "HitEngineDirectional.h"

namespace idrm {

namespace {

float clampf(float value, float lo, float hi) {
  if (value < lo) {
    return lo;
  }
  if (value > hi) {
    return hi;
  }
  return value;
}

float dot3(const Vec3f& a, const Vec3f& b) {
  return a.x * b.x + a.y * b.y + a.z * b.z;
}

Vec3f subtract3(const Vec3f& a, const Vec3f& b) {
  return Vec3f{a.x - b.x, a.y - b.y, a.z - b.z};
}

}  // namespace

void HitEngineDirectional::reset() {
  phase_ = StrokePhase::Idle;
  frozenTarget_ = -1;
  phaseStartMs_ = 0;
  cooldownUntilMs_ = 0;
  lastApproachScore_ = 0.0f;
  peakApproachScore_ = 0.0f;
  peakApproachGyro_ = 0.0f;
  peakApproachAccel_ = 0.0f;
  lastTriggerReason_ = TriggerReason::None;
  lastRejectReason_ = RejectReason::None;
}

void HitEngineDirectional::setProfile(const HitProfile& profile) {
  profile_ = profile;
}

void HitEngineDirectional::setArmed(bool armed) {
  armed_ = armed;
  if (!armed_) {
    reset();
  }
}

void HitEngineDirectional::setLiveTarget(int8_t liveTarget, uint32_t stableMs, bool confident) {
  liveTarget_ = liveTarget;
  targetStableMs_ = stableMs;
  liveTargetConfident_ = confident;
}

void HitEngineDirectional::updateCalibration(const Vec3f& gravityBody, const Vec3f& gyroBias) {
  gravityBody_ = gravityBody;
  gyroBias_ = gyroBias;
}

HitFrameFeatures HitEngineDirectional::computeFeatures(const Vec3f& accelBody, const Vec3f& gyroBody) const {
  const Vec3f aLin = subtract3(accelBody, gravityBody_);
  const Vec3f gyroUnbiased = subtract3(gyroBody, gyroBias_);

  const float sign = static_cast<float>(profile_.attackSign == 0 ? 1 : profile_.attackSign);
  const float gyroProj = sign * dot3(gyroUnbiased, profile_.attackGyroAxisBody);
  const float accelProj = sign * dot3(aLin, profile_.attackAccelAxisBody);

  const float approachGyro = gyroProj > 0.0f ? gyroProj : 0.0f;
  const float approachAccel = accelProj > 0.0f ? accelProj : 0.0f;
  const float reboundGyro = gyroProj < 0.0f ? -gyroProj : 0.0f;
  const float reboundAccel = accelProj < 0.0f ? -accelProj : 0.0f;

  const float gyroScore = clampf(approachGyro / profile_.gyroTriggerRefDps, 0.0f, 3.0f);
  const float accelScore = clampf(approachAccel / profile_.accelTriggerRefG, 0.0f, 3.0f);
  const float reboundScore =
      0.6f * clampf(reboundGyro / profile_.gyroTriggerRefDps, 0.0f, 3.0f) +
      0.4f * clampf(reboundAccel / profile_.accelTriggerRefG, 0.0f, 3.0f);

  return HitFrameFeatures{
      .linearAccelProj = accelProj,
      .gyroProj = gyroProj,
      .approachAccel = approachAccel,
      .approachGyro = approachGyro,
      .reboundAccel = reboundAccel,
      .reboundGyro = reboundGyro,
      .approachScore = profile_.gyroWeight * gyroScore + profile_.accelWeight * accelScore,
      .reboundScore = reboundScore,
  };
}

bool HitEngineDirectional::canArmTarget() const {
  return armed_ &&
         liveTargetConfident_ &&
         liveTarget_ >= 0 &&
         targetStableMs_ >= profile_.minTargetStableMs;
}

void HitEngineDirectional::enterCandidate(uint32_t nowMs) {
  phase_ = StrokePhase::Candidate;
  phaseStartMs_ = nowMs;
  frozenTarget_ = liveTarget_;
  peakApproachScore_ = 0.0f;
  peakApproachGyro_ = 0.0f;
  peakApproachAccel_ = 0.0f;
  lastTriggerReason_ = TriggerReason::None;
  lastRejectReason_ = RejectReason::None;
}

void HitEngineDirectional::enterApproach(uint32_t nowMs) {
  phase_ = StrokePhase::Approach;
  phaseStartMs_ = nowMs;
}

void HitEngineDirectional::enterTriggeredRecovery(uint32_t nowMs, TriggerReason reason) {
  phase_ = StrokePhase::TriggeredRecovery;
  phaseStartMs_ = nowMs;
  cooldownUntilMs_ = nowMs + profile_.minGapMs;
  lastTriggerReason_ = reason;
}

void HitEngineDirectional::clearStrokeState() {
  phase_ = StrokePhase::Idle;
  frozenTarget_ = -1;
  peakApproachScore_ = 0.0f;
  peakApproachGyro_ = 0.0f;
  peakApproachAccel_ = 0.0f;
}

uint8_t HitEngineDirectional::computeVelocity(float peakGyro, float peakAccel) const {
  const float vG = clampf(peakGyro / profile_.velocityGyroRef, 0.0f, 2.0f);
  const float vA = clampf(peakAccel / profile_.velocityAccelRef, 0.0f, 2.0f);
  const float energy = 0.7f * vG * vG + 0.3f * vA * vA;
  const float normalized = clampf(energy / 1.6f, 0.0f, 1.0f);
  const float curved = powf(normalized, profile_.velocityGamma);
  return static_cast<uint8_t>(clampf(127.0f * curved, 1.0f, 127.0f));
}

HitDecision HitEngineDirectional::update(uint32_t nowMs, const Vec3f& accelBody, const Vec3f& gyroBody) {
  HitDecision decision{};
  const HitFrameFeatures f = computeFeatures(accelBody, gyroBody);

  const bool inCooldown = nowMs < cooldownUntilMs_;
  const bool quietNow = f.approachGyro <= profile_.quietGyroDps &&
                        f.approachAccel <= profile_.quietAccelG &&
                        f.reboundGyro <= profile_.quietGyroDps &&
                        f.reboundAccel <= profile_.quietAccelG;

  switch (phase_) {
    case StrokePhase::Idle:
      if (inCooldown) {
        lastRejectReason_ = RejectReason::Cooldown;
        break;
      }
      if (!canArmTarget()) {
        lastRejectReason_ = RejectReason::NoStableTarget;
        break;
      }
      if (f.approachGyro >= profile_.gyroArmRefDps || f.approachAccel >= profile_.accelArmRefG) {
        enterCandidate(nowMs);
      }
      break;

    case StrokePhase::Candidate:
      if (liveTarget_ != frozenTarget_ && targetStableMs_ < profile_.minTargetStableMs) {
        lastRejectReason_ = RejectReason::LostTargetTooEarly;
        clearStrokeState();
        break;
      }
      peakApproachScore_ = peakApproachScore_ > f.approachScore ? peakApproachScore_ : f.approachScore;
      peakApproachGyro_ = peakApproachGyro_ > f.approachGyro ? peakApproachGyro_ : f.approachGyro;
      peakApproachAccel_ = peakApproachAccel_ > f.approachAccel ? peakApproachAccel_ : f.approachAccel;
      if (f.approachScore >= 0.85f) {
        enterApproach(nowMs);
      } else if (f.reboundScore > 0.30f) {
        lastRejectReason_ = RejectReason::WrongDirection;
        clearStrokeState();
      }
      break;

    case StrokePhase::Approach: {
      peakApproachScore_ = peakApproachScore_ > f.approachScore ? peakApproachScore_ : f.approachScore;
      peakApproachGyro_ = peakApproachGyro_ > f.approachGyro ? peakApproachGyro_ : f.approachGyro;
      peakApproachAccel_ = peakApproachAccel_ > f.approachAccel ? peakApproachAccel_ : f.approachAccel;

      const bool strongEnough = peakApproachScore_ >= 1.0f;
      const bool fallFromPeak = f.approachScore <= peakApproachScore_ * profile_.fallRatio;
      const bool reboundCross = f.reboundScore >= profile_.reboundTriggerRef;
      const bool signReversal = f.gyroProj <= 0.0f;
      const bool timeout = (nowMs - phaseStartMs_) >= profile_.peakTimeoutMs;

      if (strongEnough && (fallFromPeak || reboundCross || signReversal || timeout)) {
        TriggerReason reason = TriggerReason::FallFromPeak;
        if (reboundCross) {
          reason = TriggerReason::ReboundCross;
        } else if (signReversal) {
          reason = TriggerReason::SignReversal;
        } else if (timeout) {
          reason = TriggerReason::PeakTimeout;
        }
        decision.triggered = true;
        decision.beaconIndex = frozenTarget_;
        decision.velocity = computeVelocity(peakApproachGyro_, peakApproachAccel_);
        decision.triggerReason = reason;
        enterTriggeredRecovery(nowMs, reason);
      } else if ((nowMs - phaseStartMs_) > (profile_.peakTimeoutMs * 2U) && !strongEnough) {
        lastRejectReason_ = RejectReason::WeakApproach;
        clearStrokeState();
      }
      break;
    }

    case StrokePhase::TriggeredRecovery:
      if (!inCooldown && quietNow) {
        clearStrokeState();
      } else {
        lastRejectReason_ = RejectReason::NoRelease;
      }
      break;
  }

  lastApproachScore_ = f.approachScore;
  if (!decision.triggered) {
    decision.rejectReason = lastRejectReason_;
  }
  return decision;
}

HitDebugSnapshot HitEngineDirectional::debugSnapshot() const {
  HitDebugSnapshot out{};
  out.phase = phase_;
  out.liveTarget = liveTarget_;
  out.frozenTarget = frozenTarget_;
  out.targetStableMs = targetStableMs_;
  out.peakApproachScore = peakApproachScore_;
  out.peakApproachGyro = peakApproachGyro_;
  out.peakApproachAccel = peakApproachAccel_;
  out.cooldownMsRemaining = 0;
  out.triggerReason = lastTriggerReason_;
  out.rejectReason = lastRejectReason_;
  return out;
}

}  // namespace idrm
