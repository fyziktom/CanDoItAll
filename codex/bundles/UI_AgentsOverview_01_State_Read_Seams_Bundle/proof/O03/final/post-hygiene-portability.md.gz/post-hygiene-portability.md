# Portability scan summary

- Repository: `C:/repositories/CanDoItAll`
- Commit: `ad2ded645e65b8b205959f6fed816d082b99a7be`
- Scanned files: 6433
- Findings: 43796
- Truncated: false

## Severity

| Severity | Count |
|---|---:|
| critical | 838 |
| high | 17603 |
| low | 4141 |
| medium | 21214 |

## Category

| Category | Count |
|---|---:|
| windows-path | 9288 |
| mcp | 8180 |
| case-policy | 6221 |
| absolute-path-field | 5525 |
| path-api | 3677 |
| external-tool | 2983 |
| process-domain | 1551 |
| shell-elevation | 1481 |
| secret-provider | 828 |
| manager-discovery | 796 |
| atomic-write | 745 |
| windows-executable | 682 |
| path-normalization | 315 |
| permissions | 315 |
| link-reparse | 287 |
| os-branch | 283 |
| environment | 222 |
| filesystem-enumeration | 181 |
| process-start | 152 |
| dataprotection | 40 |
| direct-process-host | 34 |
| dpapi | 10 |

## Owner domain

| Owner | Count |
|---|---:|
| Unassigned | 19629 |
| Tests | 14045 |
| Agent Framework | 4522 |
| Workbench | 1399 |
| Processes Module | 916 |
| Processes | 797 |
| Foundation Infrastructure | 681 |
| FileTools Integration | 396 |
| Development Manager | 347 |
| Security | 333 |
| Installation | 293 |
| Application Composition | 289 |
| Plugins | 107 |
| CI | 36 |
| Security Abstractions | 6 |

## Review rule

Every high/critical hit and every unassigned owner must be reviewed. A pattern match is an inventory lead, not proof of a defect.
