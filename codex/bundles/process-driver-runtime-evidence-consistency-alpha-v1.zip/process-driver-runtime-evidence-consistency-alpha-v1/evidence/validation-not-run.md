# Prepared Validation Note

This bundle was prepared outside a local repository checkout, so repo validators were not executed here.

Codex must run before implementation:
- `scripts/validate_bundle.py --stage prepared`
- `candoitall-bundle-validator`
- repair until green

Codex must run at closure:
- build
- full unit tests
- focused integration/architecture tests
- source scans
- prepared and completed bundle validators
