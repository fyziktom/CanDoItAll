# Prepared Validation Not Run

This bundle was prepared outside a local checkout. Codex must run:

- `scripts/validate_bundle.py --stage prepared`
- `candoitall-bundle-validator`
- any repository-specific bundle validation commands

before implementation starts, and repair the bundle if validation fails.
