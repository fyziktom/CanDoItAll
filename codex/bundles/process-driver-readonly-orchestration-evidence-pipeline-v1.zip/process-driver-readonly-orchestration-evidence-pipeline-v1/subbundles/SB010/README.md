# SB010 - Add explicit typed batch request/response to VerificationGateway

## Status
- Completed
## Objective
Advance explicit multi-domain batch gateway without runtime host by completing: Add explicit typed batch request/response to VerificationGateway.

## Covered Inputs
- `inputs/raw-request.md`
- `inputs/source-artifacts.md`
- `analysis/01-current-state.md`

## Prerequisites
- Previous subbundle closure gate passed.
- For critical gates, all upstream proof manifests and semantic invariants must be present.

## Exact Source References
- repo://src/CanDoItAll.Processes.Drivers.VerificationGateway/ProcessDriverVerificationGateway.cs
- repo://src/CanDoItAll.Modules.Processes/Automation/Dispatch/ProcessDomainEvidenceReadOnlyAdapters.cs
- repo://src/CanDoItAll.Processes.Drivers.Abstractions
- repo://src/CanDoItAll.Processes.Core
- repo://tests/CanDoItAll.Tests.Unit
- repo://tests/CanDoItAll.Tests.Integration

## Scope
- Keep the change read-only and deterministic. Preserve current behavior while improving structure, tests, or docs.

## Dependency Impact
- This subbundle is part of P04 - Explicit multi-domain batch gateway without runtime host. Downstream work is invalid if its closure proof is weak or report-only.

## Validation Depth
- Critical semantic adequacy gate with build, full/focused tests, source scans, anti-stub audit, changed-file hashes, and red-team negative proof.

## Implementation Steps
1. Re-read the exact source references.
2. Implement only the scoped change.
3. Add or update focused tests before broad tests.
4. Run source scans for forbidden runtime, DI, file/network, storage/workspace, mutation, Core reverse dependency, UI/media drift, and stubs.
5. Record command transcripts and changed-file hashes.

## Scope Exceptions
No runtime host, registry, selector, DI registration, manager command, scheduler/workflow hook, shell execution, Graph/Office runtime call, file/network access, workspace/storage write, process mutation, claim/transition/finalizer/retry mutation, or UI work is approved.

## Do Not Do
- Do not add generic `Verify(object)` or lane-based object dispatch.
- Do not add service registration or manager commands.
- Do not create execution-capable drivers.
- Do not silently skip tests or collapse report rows.

## Acceptance Checklist
- [x] Build passes with zero warnings/errors.
- [x] Full unit suite passes or any skip/debt is explicitly owned and justified.
- [x] Focused tests for this subbundle pass.
- [x] Source scans pass.
- [x] No UI/media drift.
- [x] Critical proof manifest exists when required.

## Proof Required
- Create `proof/SB010/manifest.md` and `proof/SB010/semantic-invariants.md` with artifact-backed transcripts, shallow-pass trap, adversarial negative proof, semantic positive proof, and production behavior artifact matrix if new records/signals are introduced.

## Browser Validation Logging
- N/A runtime/service/Core/driver work. If UI/media files change unexpectedly, fail and re-scope.

## Progression Gate
- SB010 is a critical gate. Do not proceed until all proof artifacts pass and are referenced from reviews/01-execution-report.md.

## Closure Proof
- Added `ProcessDriverVerificationBatchRequest`, `ProcessDriverVerificationBatchResponse`, and `ProcessDriverVerificationBatchAggregationRequest` in `repo://src/CanDoItAll.Processes.Drivers.VerificationGateway/ProcessDriverVerificationBatch.cs`.
- Build proof: `bundle://proof/SB012/transcripts/build-typed-batch-gateway-explicit-lanes.txt`.
- Focused test proof: `bundle://proof/SB012/transcripts/focused-p04-gateway-tests-explicit-lanes.txt`.
- Full unit proof: `bundle://proof/SB012/transcripts/full-unit-p04-explicit-lanes-rerun.txt`.
- Source scan proof: `bundle://proof/SB012/transcripts/p04-source-scans-explicit-lanes.txt`.
- Critical manifest: `bundle://proof/SB010/manifest.md`.

## Suggested Agent Prompt
Implement SB010 carefully using source-backed proof. Do not trust existing reports without opening current branch code.

