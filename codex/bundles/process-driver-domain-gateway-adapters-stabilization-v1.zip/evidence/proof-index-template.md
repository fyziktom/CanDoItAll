# Proof Index Template

Codex must populate during execution.

| Gate | Manifest | Semantic invariants | Key transcripts | Status |
| --- | --- | --- | --- | --- |
| SB003 | proof/SB003/manifest.md | proof/SB003/semantic-invariants.md | TBD | Pending |
| SB006 | proof/SB006/manifest.md | proof/SB006/semantic-invariants.md | TBD | Pending |
| SB009 | proof/SB009/manifest.md | proof/SB009/semantic-invariants.md | TBD | Pending |
| SB012 | proof/SB012/manifest.md | proof/SB012/semantic-invariants.md | TBD | Pending |
| SB015 | proof/SB015/manifest.md | proof/SB015/semantic-invariants.md | TBD | Pending |
| SB018 | proof/SB018/manifest.md | proof/SB018/semantic-invariants.md | TBD | Pending |
| SB021 | proof/SB021/manifest.md | proof/SB021/semantic-invariants.md | TBD | Pending |
| SB024 | proof/SB024/manifest.md | proof/SB024/semantic-invariants.md | TBD | Pending |
| SB027 | proof/SB027/manifest.md | proof/SB027/semantic-invariants.md | TBD | Pending |
| SB030 | proof/SB030/manifest.md | proof/SB030/semantic-invariants.md | TBD | Pending |
| SB033 | proof/SB033/manifest.md | proof/SB033/semantic-invariants.md | TBD | Pending |
| SB036 | proof/SB036/manifest.md | proof/SB036/semantic-invariants.md | TBD | Pending |
| SB039 | proof/SB039/manifest.md | proof/SB039/semantic-invariants.md | TBD | Pending |
| SB042 | proof/SB042/manifest.md | proof/SB042/semantic-invariants.md | TBD | Pending |
| SB045 | proof/SB045/manifest.md | proof/SB045/semantic-invariants.md | TBD | Pending |
| SB048 | proof/SB048/manifest.md | proof/SB048/semantic-invariants.md | TBD | Pending |
| SB051 | proof/SB051/manifest.md | proof/SB051/semantic-invariants.md | TBD | Pending |
| SB054 | proof/SB054/manifest.md | proof/SB054/semantic-invariants.md | TBD | Pending |
