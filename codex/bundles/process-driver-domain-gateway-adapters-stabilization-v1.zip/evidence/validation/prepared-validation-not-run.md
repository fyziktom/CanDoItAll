# Prepared Validation Not Run Locally

This bundle was prepared outside a local checkout. Codex must run before implementation:
- `scripts/validate_bundle.py --stage prepared codex/bundles/process-driver-domain-gateway-adapters-stabilization-v1`
- `candoitall-bundle-validator --stage prepared codex/bundles/process-driver-domain-gateway-adapters-stabilization-v1`

Repair the bundle before implementing if either validator fails.
