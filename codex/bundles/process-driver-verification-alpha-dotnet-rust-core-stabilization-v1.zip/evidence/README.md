# Evidence

This folder contains prepared checklists and validation instructions. Implementation proof must be added by Codex during execution.
