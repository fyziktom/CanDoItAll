# Prepared Validation Not Run Locally

This bundle was generated outside the target repository checkout. Codex must run these before implementation:

```powershell
python codex/skills/bundles/candoitall-bundle-preparation/scripts/validate_bundle.py --stage prepared codex/bundles/process-driver-verification-alpha-dotnet-rust-core-stabilization-v1
candoitall-bundle-validator codex/bundles/process-driver-verification-alpha-dotnet-rust-core-stabilization-v1
```

If validation fails, repair the bundle first.
