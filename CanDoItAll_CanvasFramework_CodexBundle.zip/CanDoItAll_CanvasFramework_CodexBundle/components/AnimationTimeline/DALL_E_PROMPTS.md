# AnimationTimeline DALL·E Prompts

Use the prompts below to generate visual exploration variants for `AnimationTimeline`.

## clean professional

```text
Design a desktop web app UI concept for the `AnimationTimeline` component in CanDoItAll. The component purpose is: Provide a minimal shared animation system for smooth transitions, focus pans, hover fades, and connector or badge micro-animations. Show the component inside a realistic Blazor-style application workbench with a canvas-centric layout. Use a clean professional SaaS product style, high information clarity, restrained motion language. Prioritize usability, spatial clarity, strong affordances, clear states, and realistic product-ready details. Do not create a mobile layout. Focus on this component, not a generic dashboard.
```## modern SaaS

```text
Design a desktop web app UI concept for the `AnimationTimeline` component in CanDoItAll. The component purpose is: Provide a minimal shared animation system for smooth transitions, focus pans, hover fades, and connector or badge micro-animations. Show the component inside a realistic Blazor-style application workbench with a canvas-centric layout. Use a modern SaaS workbench aesthetic, subtle gradients, polished depth, sharp hierarchy. Prioritize usability, spatial clarity, strong affordances, clear states, and realistic product-ready details. Do not create a mobile layout. Focus on this component, not a generic dashboard.
```## high-clarity productivity

```text
Design a desktop web app UI concept for the `AnimationTimeline` component in CanDoItAll. The component purpose is: Provide a minimal shared animation system for smooth transitions, focus pans, hover fades, and connector or badge micro-animations. Show the component inside a realistic Blazor-style application workbench with a canvas-centric layout. Use a high-clarity productivity UI, dense but readable information design, precise spacing. Prioritize usability, spatial clarity, strong affordances, clear states, and realistic product-ready details. Do not create a mobile layout. Focus on this component, not a generic dashboard.
```## canvas-heavy advanced editor UI

```text
Design a desktop web app UI concept for the `AnimationTimeline` component in CanDoItAll. The component purpose is: Provide a minimal shared animation system for smooth transitions, focus pans, hover fades, and connector or badge micro-animations. Show the component inside a realistic Blazor-style application workbench with a canvas-centric layout. Use a canvas-heavy advanced editor interface with overlays, guides, and spatial editing affordances. Prioritize usability, spatial clarity, strong affordances, clear states, and realistic product-ready details. Do not create a mobile layout. Focus on this component, not a generic dashboard.
```## subtle premium look

```text
Design a desktop web app UI concept for the `AnimationTimeline` component in CanDoItAll. The component purpose is: Provide a minimal shared animation system for smooth transitions, focus pans, hover fades, and connector or badge micro-animations. Show the component inside a realistic Blazor-style application workbench with a canvas-centric layout. Use a subtle premium enterprise design, elegant contrast, refined materials, quiet sophistication. Prioritize usability, spatial clarity, strong affordances, clear states, and realistic product-ready details. Do not create a mobile layout. Focus on this component, not a generic dashboard.
```
